<script setup lang="ts">
import { type ComponentInternalInstance } from 'vue'
import {
  opsMscLiveClearIpErrorLimit,
  opsMscLiveKickout,
  opsMscLiveList,
  opsMscLiveClearDeviceSendLimit,
  opsMscLiveClearCaptchaSendLimit,
  opsMscLiveClearTotpVerifyLimit,
  opsMscLiveClearDeviceVerifyLimit,
  opsMscLiveListOnlineUser,
  opsMscLiveListLogonUser,
  opsMscLiveListIpErrorLimit,
  opsMscLiveListDeviceSendLimit,
  opsMscLiveListCaptchaSendLimit,
  opsMscLiveListTotpVerifyLimit,
  opsMscLiveListDeviceVerifyLimit,
  opsMscLiveCheckUserActive,
  opsMscLiveCheckUserLogon,
  type MscLiveInfo
} from '@/api/uwAuthCenterOpsApi'
import { useI18n } from 'vue-i18n'
import {
  ElMessageBox,
  FormInstance,
  ElMessage,
  type Column
} from 'element-plus'
import { useSimplifyPrompt } from '@/hooks/useSimplifyPrompt'
import { useCommonSelectTypes } from '@/utils/selectOptions'
import { useMainStore } from '@/store/main'
import { PermVo } from '@/api/uwAuthCenterUserApi'

// 获取全局挂载的方法
const { proxy } = getCurrentInstance() as ComponentInternalInstance
const { useActivated } = proxy as any
const { t } = useI18n()
const { userTypes, handleTypeForLabel } = useCommonSelectTypes()
const mainStore = useMainStore()

// 获取实时MSC信息
const liveMSCInfo = ref<MscLiveInfo>({})
const handleList = () => {
  opsMscLiveList()
    .then(res => {
      liveMSCInfo.value = res.data || {}
    })
    .catch(() => {
      liveMSCInfo.value = {}
    })
}

// 用户类型
const newUserTypes = computed(() =>
  userTypes.value.filter(item => item.value !== 0)
)

// 应用实时在线用户
const onlineTokenValue = computed(() => liveMSCInfo.value.onlineToken || 0)
const onlineToken = useTransition(onlineTokenValue, {
  duration: 1500
})

// 登录token
const logonTokenValue = computed(() => liveMSCInfo.value.logonToken || 0)
const logonToken = useTransition(logonTokenValue, {
  duration: 1500
})

// 失效token
const invalidateTokenValue = computed(
  () => liveMSCInfo.value.invalidateToken || 0
)
const invalidateToken = useTransition(invalidateTokenValue, {
  duration: 1500
})

// MFA信息数
const mfaLimitNumValue = computed(() => liveMSCInfo.value.mfaLimitNum || 0)
const mfaLimitNum = useTransition(mfaLimitNumValue, {
  duration: 1500
})

// 清除用户登录错误
const loading = ref(false)
const clearErrorFormForIPRef = ref<FormInstance>()
const clearErrorFormForIP = ref<{
  ip?: string
}>({})

// 清除登录错误
const handleSubmitError = () => {
  clearErrorFormForIPRef.value?.validate(valid => {
    if (valid) {
      useSimplifyPrompt({
        message: '请输入清除登录错误备注',
        confirmCallBack(remark) {
          loading.value = true
          opsMscLiveClearIpErrorLimit({
            ip: clearErrorFormForIP.value.ip as string,
            remark: remark || ''
          })
            .then(res => {
              if (res.state === 'success') {
                ElMessage.success('清除登录错误成功')
              } else {
                ElMessage.error(res.msg)
              }
              loading.value = false
            })
            .catch(() => {
              loading.value = false
            })
        }
      })
    }
  })
}

// 清除发送设备验证码限制
const clearDeviceSendLimitFormForIPRef = ref<FormInstance>()
const clearDeviceSendLimitFormForIP = ref<{
  ip?: string
  remark?: string
}>({})
const handleSubmitDeviceSendLimit = () => {
  clearDeviceSendLimitFormForIPRef.value?.validate(valid => {
    if (valid) {
      useSimplifyPrompt({
        message: '请输入清除设备码发送限制备注',
        confirmCallBack(remark) {
          loading.value = true
          opsMscLiveClearDeviceSendLimit({
            ip: clearDeviceSendLimitFormForIP.value.ip as string,
            remark: remark || ''
          })
            .then(res => {
              if (res.state === 'success') {
                ElMessage.success('清除设备码发送限制成功')
              } else {
                ElMessage.error(res.msg || '清除设备码发送限制失败')
              }
              loading.value = false
            })
            .catch(() => {
              loading.value = false
            })
        }
      })
    }
  })
}

const handleSubmitCaptchaSendLimit = () => {
  clearDeviceSendLimitFormForIPRef.value?.validate(valid => {
    if (valid) {
      useSimplifyPrompt({
        message: '请输入清除Captcha码发送限制备注',
        confirmCallBack(remark) {
          loading.value = true
          opsMscLiveClearCaptchaSendLimit({
            ip: clearDeviceSendLimitFormForIP.value.ip as string,
            remark: remark || ''
          })
            .then(res => {
              if (res.state === 'success') {
                ElMessage.success('清除设备码发送限制成功')
              } else {
                ElMessage.error(res.msg || '清除设备码发送限制失败')
              }
              loading.value = false
            })
            .catch(() => {
              loading.value = false
            })
        }
      })
    }
  })
}

// 踢出在线用户
const kickoutFormForIPRef = ref<FormInstance>()
const kickoutFormForIP = ref<{
  loginAgent?: string // 登录代理
  saasId?: number // saasId
  userId?: number // 用户ID
  remark?: string // 备注
}>({
  loginAgent: mainStore.loginAgent
})

// 踢出用户
const handleKickoutUser = () => {
  kickoutFormForIPRef.value?.validate(valid => {
    if (valid) {
      useSimplifyPrompt({
        message: '请输入踢出用户备注',
        confirmCallBack(remark) {
          loading.value = true
          opsMscLiveKickout({
            loginAgent: kickoutFormForIP.value.loginAgent as string,
            saasId: kickoutFormForIP.value.saasId as number,
            userId: kickoutFormForIP.value.userId as number,
            remark: remark || ''
          })
            .then(res => {
              if (res.state === 'success') {
                ElMessage.success('用户踢出成功')
              } else {
                ElMessage.error(res.msg)
              }
              loading.value = false
            })
            .catch(() => {
              loading.value = false
            })
        }
      })
    }
  })
}

// 检查用户是否在线
const checkUserOnlineFormForIPRef = ref<FormInstance>()
const checkUserOnlineFormForIP = ref<{
  saasId?: number // saasId
  userId?: number // 用户ID
  userType?: number // 用户类型
}>({})

// 检查用户是否在线
const handleCheckUserOnline = () => {
  checkUserOnlineFormForIPRef.value?.validate(valid => {
    if (valid) {
      opsMscLiveCheckUserActive({
        saasId: checkUserOnlineFormForIP.value.saasId as number,
        userId: checkUserOnlineFormForIP.value.userId as number,
        userType: checkUserOnlineFormForIP.value.userType as number
      })
        .then(res => {
          if (res.state === 'success') {
            ElMessageBox.alert(
              `ID为${checkUserOnlineFormForIP.value.userId}的用户当前状态为在线`,
              '在线状态',
              {
                type: 'success'
              }
            )
          } else {
            ElMessageBox.alert(
              `ID为${checkUserOnlineFormForIP.value.userId}的用户当前状态为下线`,
              '在线状态',
              {
                type: 'warning'
              }
            )
          }
          loading.value = false
        })
        .catch(() => {
          loading.value = false
        })
    }
  })
}

// 检查用户是否登录
const handleCheckUserLogon = () => {
  checkUserOnlineFormForIPRef.value?.validate(valid => {
    if (valid) {
      opsMscLiveCheckUserLogon({
        saasId: checkUserOnlineFormForIP.value.saasId as number,
        userId: checkUserOnlineFormForIP.value.userId as number,
        userType: checkUserOnlineFormForIP.value.userType as number
      })
        .then(res => {
          if (res.state === 'success') {
            ElMessageBox.alert(
              `ID为${checkUserOnlineFormForIP.value.userId}的用户当前已登录`,
              '在线状态',
              {
                type: 'success'
              }
            )
          } else {
            ElMessageBox.alert(
              `ID为${checkUserOnlineFormForIP.value.userId}的用户当前未登录`,
              '在线状态',
              {
                type: 'warning'
              }
            )
          }
          loading.value = false
        })
        .catch(() => {
          loading.value = false
        })
    }
  })
}

// 清除TOTP校验限制
const clearTOTPValidateLimitFormRef = ref<FormInstance>()
const clearTOTPValidateLimitForm = ref<{
  userInfo?: string
  userId?: string
  userType?: number
  saasId?: number
  remark?: string
}>({})

const handleClearTOTPValidate = () => {
  clearTOTPValidateLimitFormRef.value?.validate(valid => {
    if (valid) {
      useSimplifyPrompt({
        message: '请输入清除TOTP校验限制备注',
        confirmCallBack(remark) {
          const userInfo = `${clearTOTPValidateLimitForm.value
            .saasId!}:${clearTOTPValidateLimitForm.value
            .userType!}:${clearTOTPValidateLimitForm.value.userId!}`
          opsMscLiveClearTotpVerifyLimit({
            userInfo: userInfo,
            remark: remark || ''
          })
            .then(res => {
              if (res.state === 'success') {
                ElMessage.success('清除TOTP校验限制成功')
              } else {
                ElMessage.error('清除TOTP校验限制失败')
              }
              loading.value = false
            })
            .catch(() => {
              loading.value = false
            })
        }
      })
    }
  })
}

// 清除设备验证码校验限制
const clearDeviceValidateLimitFormRef = ref<FormInstance>()
const clearDeviceValidateLimitForm = ref<{
  deviceId?: string
  remark?: string
}>({})

const handleClearDeviceValidate = () => {
  clearDeviceValidateLimitFormRef.value?.validate(valid => {
    if (valid) {
      useSimplifyPrompt({
        message: '请输入清除设备码校验限制备注',
        confirmCallBack(remark) {
          opsMscLiveClearDeviceVerifyLimit({
            deviceId: clearDeviceValidateLimitForm.value.deviceId!,
            remark: remark || ''
          })
            .then(res => {
              if (res.state === 'success') {
                ElMessage.success('清除设备码校验限制成功')
              } else {
                ElMessage.error('清除设备码校验限制失败')
              }
              loading.value = false
            })
            .catch(() => {
              loading.value = false
            })
        }
      })
    }
  })
}

// 查看数据列表
const viewList = computed<
  Array<{
    label: string
    key: string
    icon: string
    type: 'default' | 'success' | 'primary' | 'warning' | 'info' | 'danger'
  }>
>(() => [
  {
    label: '在线用户',
    key: 'listOnlineUser',
    type: 'primary',
    icon: 'User'
  },
  {
    label: '登录用户',
    key: 'listLogonUser',
    type: 'success',
    icon: 'User'
  },
  {
    label: '错误IP限制',
    key: 'listIpErrorLimit',
    type: 'danger',
    icon: 'View'
  },
  {
    label: 'Captcha发送限制',
    key: 'listCaptchaSendLimit',
    type: 'warning',
    icon: 'Tickets'
  },
  {
    label: '设备码发送限制',
    key: 'listDeviceSendLimit',
    type: 'warning',
    icon: 'Notebook'
  },
  {
    label: '设备码校验限制',
    key: 'listDeviceVerifyLimit',
    type: 'warning',
    icon: 'Document'
  },
  {
    label: 'TOTP校验限制',
    key: 'listTotpVerifyLimit',
    type: 'warning',
    icon: 'Memo'
  }
])

// 展示的列表数据
const listData = ref<Array<string>>([])
// 弹窗展示
const dialogShow = ref(false)
// 列表数据标题
const dialogTitle = ref('')
// 当前展示类型
const showType = ref('')
// 查看数据列表
const handleView = (index: number) => {
  dialogTitle.value = viewList.value[index].label
  showType.value = viewList.value[index].key
  dialogShow.value = true
  switch (viewList.value[index].key) {
    case 'listOnlineUser':
      handleListOnlineUser()
      break
    case 'listLogonUser':
      handleListLogonUser()
      break
    case 'listIpErrorLimit':
      handleListIpErrorLimit()
      break
    case 'listDeviceVerifyLimit':
      handleListDeviceVerifyLimit()
      break
    case 'listDeviceSendLimit':
      handleListDeviceSendLimit()
      break
    case 'listCaptchaSendLimit':
      handleListCaptchaSendLimit()
      break
    case 'listTotpVerifyLimit':
      handleListTotpVerifyLimit()
      break
  }
}
// 列表数据
const handleListOnlineUser = () => {
  opsMscLiveListOnlineUser()
    .then(res => {
      listData.value = res.data || []
    })
    .catch(() => {
      listData.value = []
    })
}
const handleListLogonUser = () => {
  opsMscLiveListLogonUser()
    .then(res => {
      listData.value = res.data || []
    })
    .catch(() => {
      listData.value = []
    })
}
const handleListIpErrorLimit = () => {
  opsMscLiveListIpErrorLimit()
    .then(res => {
      listData.value = res.data || []
    })
    .catch(() => {
      listData.value = []
    })
}
const handleListDeviceVerifyLimit = () => {
  opsMscLiveListDeviceVerifyLimit()
    .then(res => {
      listData.value = res.data || []
    })
    .catch(() => {
      listData.value = []
    })
}
const handleListDeviceSendLimit = () => {
  opsMscLiveListDeviceSendLimit()
    .then(res => {
      listData.value = res.data || []
    })
    .catch(() => {
      listData.value = []
    })
}
const handleListCaptchaSendLimit = () => {
  opsMscLiveListCaptchaSendLimit()
    .then(res => {
      listData.value = res.data || []
    })
    .catch(() => {
      listData.value = []
    })
}
const handleListTotpVerifyLimit = () => {
  opsMscLiveListTotpVerifyLimit()
    .then(res => {
      listData.value = res.data || []
    })
    .catch(() => {
      listData.value = []
    })
}

const columns = computed<Array<Column>>(() => [
  {
    key: 'saasId',
    title: 'SAASID',
    dataKey: 'saasId',
    width: 150,
    align: 'center'
  },
  {
    key: 'id',
    title: 'ID',
    dataKey: 'id',
    width: 150,
    align: 'center'
  },
  {
    key: 'userType',
    title: '用户类型',
    dataKey: 'userType',
    width: 150,
    align: 'center'
  }
])
const tableData = computed(() => {
  if (
    ['listOnlineUser', 'listLogonUser', 'listTotpVerifyLimit'].includes(
      showType.value
    )
  ) {
    const data = listData.value.map(item => {
      return {
        saasId: item.split(':')[0],
        id: item.split(':')[2],
        userType: handleTypeForLabel(
          Number(item.split(':')[1]),
          newUserTypes.value
        )
      }
    })
    return data
  }
  return []
})

//  查找permCode
const searchPermCode = (code: string): boolean => {
  let hasPermCode = false
  const menu = mainStore.loadAppMenu
  const menuTree = menu.map(item => item.permVoList)
  for (const item of menuTree as PermVo[][]) {
    const target = item.find(subItem => {
      const permCode = subItem.permCode?.split(':')[0]
      return permCode === code
    })
    if (target) {
      hasPermCode = true
      break
    }
  }
  return hasPermCode
}

const permShow = ref<Record<string, boolean>>({})
useActivated(() => {
  handleList()
  permShow.value['clearDeviceSendLimit'] = searchPermCode(
    '/uwAuthCenter/ops/msc/live/clearDeviceSendLimit'
  )
  permShow.value['clearCaptchaSendLimit'] = searchPermCode(
    '/uwAuthCenter/ops/msc/live/clearCaptchaSendLimit'
  )
  permShow.value['clearTotpVerifyLimit'] = searchPermCode(
    '/uwAuthCenter/ops/msc/live/clearTotpVerifyLimit'
  )
  permShow.value['clearDeviceVerifyLimit'] = searchPermCode(
    '/uwAuthCenter/ops/msc/live/clearDeviceVerifyLimit'
  )
  permShow.value['kickout'] = searchPermCode(
    '/uwAuthCenter/ops/msc/live/kickout'
  )
  permShow.value['checkUserActive'] = searchPermCode(
    '/uwAuthCenter/ops/msc/live/checkUserActive'
  )
  permShow.value['checkUserLogon'] = searchPermCode(
    '/uwAuthCenter/ops/msc/live/checkUserLogon'
  )
  permShow.value['clearIpErrorLimit'] = searchPermCode(
    '/uwAuthCenter/ops/msc/live/clearIpErrorLimit'
  )
  permShow.value
})
</script>

<template>
  <el-row>
    <el-col :span="24">
      <el-card shadow="hover">
        <template #header>
          <div class="flex-center">MSC实时在线数据</div>
        </template>
        <el-row :gutter="10">
          <el-col
            :span="6"
            class="flex-center"
          >
            <div class="flex-center">
              <el-statistic :value="onlineToken">
                <template #title>
                  <div class="value-icon-wrapper">
                    在线TOKEN
                    <el-icon
                      style="margin-left: 4px"
                      :size="12"
                      color="var(--el-color-primary)"
                    >
                      <UserFilled />
                    </el-icon>
                  </div>
                </template>
              </el-statistic>
            </div>
          </el-col>
          <el-col :span="6">
            <div class="flex-center">
              <el-statistic :value="logonToken">
                <template #title>
                  <div class="value-icon-wrapper">
                    登录Token
                    <el-icon
                      style="margin-left: 4px"
                      :size="12"
                      color="var(--el-color-success)"
                    >
                      <UserFilled />
                    </el-icon>
                  </div>
                </template>
              </el-statistic>
            </div>
          </el-col>
          <el-col :span="6">
            <div class="flex-center">
              <el-statistic :value="invalidateToken">
                <template #title>
                  <div class="value-icon-wrapper">
                    失效Token
                    <el-icon
                      style="margin-left: 4px"
                      :size="12"
                      color="var(--el-color-danger)"
                    >
                      <UserFilled />
                    </el-icon>
                  </div>
                </template>
              </el-statistic>
            </div>
          </el-col>
          <el-col :span="6">
            <div class="flex-center">
              <el-statistic :value="mfaLimitNum">
                <template #title>
                  <div class="value-icon-wrapper">
                    MFA信息
                    <el-icon
                      style="margin-left: 4px"
                      :size="12"
                      color="var(--el-color-primary)"
                    >
                      <InfoFilled />
                    </el-icon>
                  </div>
                </template>
              </el-statistic>
            </div>
          </el-col>
        </el-row>
      </el-card>
    </el-col>
    <el-col
      :span="24"
      class="margin-top-10"
    >
      <el-card shadow="hover">
        <template #header>
          <div class="flex-center">
            <span>查看在线信息</span>
          </div>
        </template>
        <div class="space-around">
          <el-button
            v-for="(item, index) in viewList"
            :key="item.key"
            :type="item.type"
            :icon="item.icon"
            @click="handleView(index)"
            v-permission="item.key"
          >
            {{ item.label }}
          </el-button>
        </div>
      </el-card>
    </el-col>
    <el-col :span="24">
      <el-row :gutter="10">
        <el-col
          :span="8"
          class="margin-top-10"
        >
          <el-card shadow="hover">
            <template #header>
              <div class="flex-center">检查用户是否在线/登录</div>
            </template>
            <el-form
              :model="checkUserOnlineFormForIP"
              label-width="110px"
              ref="checkUserOnlineFormForIPRef"
            >
              <el-form-item
                label="SAASID"
                :rules="[{ required: true, message: t('pleaseInput') }]"
                prop="saasId"
                style="width: 80%"
              >
                <el-input
                  v-model="checkUserOnlineFormForIP.saasId"
                  :placeholder="t('pleaseInput')"
                />
              </el-form-item>
              <el-form-item
                label="用户类型"
                :rules="[{ required: true, message: t('pleaseInput') }]"
                prop="userType"
                style="width: 80%"
              >
                <el-select
                  v-model="checkUserOnlineFormForIP.userType"
                  :placeholder="t('pleaseInput')"
                >
                  <el-option
                    v-for="item in newUserTypes"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                  />
                </el-select>
              </el-form-item>
              <el-form-item
                label="用户ID"
                :rules="[{ required: true, message: t('pleaseInput') }]"
                prop="userId"
                style="width: 80%"
              >
                <el-input v-model="checkUserOnlineFormForIP.userId" />
              </el-form-item>
            </el-form>
            <div class="flex-center margin-top-30">
              <el-button
                icon="Search"
                @click="handleCheckUserOnline"
                type="primary"
              >
                是否在线
              </el-button>
              <el-button
                icon="Search"
                @click="handleCheckUserLogon"
                type="success"
              >
                是否登录
              </el-button>
            </div>
          </el-card>
        </el-col>
        <el-col
          :span="8"
          class="margin-top-10"
          v-if="permShow.kickout"
        >
          <el-card shadow="hover">
            <template #header>
              <div class="flex-center">踢出在线用户</div>
            </template>
            <el-form
              :model="kickoutFormForIP"
              label-width="110px"
              ref="kickoutFormForIPRef"
            >
              <el-form-item
                label="SAASID"
                :rules="[{ required: true, message: t('pleaseInput') }]"
                prop="saasId"
                style="width: 80%"
              >
                <el-input
                  v-model="kickoutFormForIP.saasId"
                  :placeholder="t('pleaseInput')"
                />
              </el-form-item>
              <el-form-item
                label="用户ID"
                :rules="[{ required: true, message: t('pleaseInput') }]"
                prop="userId"
                style="width: 80%"
              >
                <el-input
                  v-model="kickoutFormForIP.userId"
                  placeholder="请输入用户名"
                ></el-input>
              </el-form-item>
              <el-form-item
                label="登录代理"
                :rules="[{ required: true, message: t('pleaseInput') }]"
                prop="loginAgent"
                style="width: 80%"
              >
                <el-input
                  v-model="kickoutFormForIP.loginAgent"
                  :placeholder="t('pleaseInput')"
                  disabled
                />
              </el-form-item>
            </el-form>
            <div class="flex-center margin-top-30">
              <el-button
                icon="Check"
                @click="handleKickoutUser"
                type="primary"
              >
                {{ t('confirm') }}
              </el-button>
            </div>
          </el-card>
        </el-col>
        <el-col
          :span="8"
          class="margin-top-10"
          v-if="permShow.clearTotpVerifyLimit"
        >
          <el-card shadow="hover">
            <template #header>
              <div class="flex-center">清除TOTP校验限制</div>
            </template>
            <el-form
              :model="clearTOTPValidateLimitForm"
              label-width="100px"
              ref="clearTOTPValidateLimitFormRef"
            >
              <el-form-item
                label="SAASID"
                :rules="[{ required: true, message: t('pleaseInput') }]"
                prop="saasId"
                style="width: 80%"
              >
                <el-input
                  v-model="clearTOTPValidateLimitForm.saasId"
                  :placeholder="t('pleaseInput')"
                />
              </el-form-item>
              <el-form-item
                label="用户类型"
                :rules="[{ required: true, message: t('pleaseInput') }]"
                prop="userType"
                style="width: 80%"
              >
                <el-select
                  v-model="clearTOTPValidateLimitForm.userType"
                  :placeholder="t('pleaseInput')"
                >
                  <el-option
                    v-for="item in newUserTypes"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                  />
                </el-select>
              </el-form-item>
              <el-form-item
                label="用户ID"
                :rules="[{ required: true, message: t('pleaseInput') }]"
                prop="userId"
                style="width: 80%"
              >
                <el-input
                  v-model="clearTOTPValidateLimitForm.userId"
                  :placeholder="t('pleaseInput')"
                />
              </el-form-item>
            </el-form>
            <div class="flex-center margin-top-30">
              <el-button
                icon="Check"
                @click="handleClearTOTPValidate"
                type="primary"
              >
                {{ t('confirm') }}
              </el-button>
            </div>
          </el-card>
        </el-col>
        <el-col
          :span="8"
          class="margin-top-10"
          v-if="permShow.clearIpErrorLimit"
        >
          <el-card shadow="hover">
            <template #header>
              <div class="flex-center">清除错误IP限制</div>
            </template>
            <el-form
              :model="clearErrorFormForIP"
              label-width="50px"
              ref="clearErrorFormForIPRef"
            >
              <el-form-item
                label="IP"
                :rules="[{ required: true, message: t('pleaseInput') }]"
                prop="ip"
                style="width: 80%"
              >
                <el-input
                  v-model="clearErrorFormForIP.ip"
                  :placeholder="t('pleaseInput')"
                />
              </el-form-item>
            </el-form>
            <div class="flex-center margin-top-30">
              <el-button
                icon="Check"
                @click="handleSubmitError"
                type="primary"
              >
                {{ t('confirm') }}
              </el-button>
            </div>
          </el-card>
        </el-col>
        <el-col
          :span="8"
          class="margin-top-10"
          v-if="permShow.clearDeviceSendLimit || permShow.clearCaptchaSendLimit"
        >
          <el-card shadow="hover">
            <template #header>
              <div class="flex-center">清除设备码发送限制/Captcha发送限制</div>
            </template>
            <el-form
              :model="clearDeviceSendLimitFormForIP"
              label-width="50px"
              ref="clearDeviceSendLimitFormForIPRef"
            >
              <el-form-item
                label="IP"
                :rules="[{ required: true, message: t('pleaseInput') }]"
                prop="ip"
                style="width: 80%"
              >
                <el-input
                  v-model="clearDeviceSendLimitFormForIP.ip"
                  :placeholder="t('pleaseInput')"
                />
              </el-form-item>
            </el-form>
            <div class="flex-center margin-top-30">
              <el-button
                icon="RefreshRight"
                @click="handleSubmitDeviceSendLimit"
                type="primary"
                v-show="permShow.clearDeviceSendLimit"
              >
                清除设备码发送限制
              </el-button>
              <el-button
                icon="RefreshLeft"
                @click="handleSubmitCaptchaSendLimit"
                type="success"
                v-show="permShow.clearCaptchaSendLimit"
              >
                清除Captcha发送限制
              </el-button>
            </div>
          </el-card>
        </el-col>
        <el-col
          :span="8"
          class="margin-top-10"
          v-if="permShow.clearDeviceVerifyLimit"
        >
          <el-card shadow="hover">
            <template #header>
              <div class="flex-center">清除设备码校验限制</div>
            </template>
            <el-form
              :model="clearDeviceValidateLimitForm"
              label-width="100px"
              ref="clearDeviceValidateLimitFormRef"
            >
              <el-form-item
                label="手机号/邮箱"
                :rules="[{ required: true, message: t('pleaseInput') }]"
                prop="deviceId"
                style="width: 80%"
              >
                <el-input
                  v-model="clearDeviceValidateLimitForm.deviceId"
                  :placeholder="t('pleaseInput')"
                />
              </el-form-item>
            </el-form>
            <div class="flex-center margin-top-30">
              <el-button
                icon="Check"
                @click="handleClearDeviceValidate"
                type="primary"
              >
                {{ t('confirm') }}
              </el-button>
            </div>
          </el-card>
        </el-col>
      </el-row>
    </el-col>
  </el-row>
  <div class="dialogByViewList">
    <el-dialog
      v-model="dialogShow"
      :title="`${dialogTitle}${
        listData.length ? '(' + listData.length + ')' : ''
      }`"
      width="500px"
      draggable
    >
      <template v-if="listData.length > 0">
        <div
          v-if="
            ['listOnlineUser', 'listLogonUser', 'listTotpVerifyLimit'].includes(
              showType
            )
          "
          class="flex-center"
        >
          <el-table-v2
            :columns="columns"
            :data="tableData"
            :width="450"
            :height="330"
            fixed
            header-class="tableHeader"
          />
        </div>
        <div
          v-else
          class="flex-start flex-wrap"
        >
          <el-tag
            v-for="item in listData"
            :key="item"
            type="primary"
            class="margin-bottom-10 margin-right-10"
          >
            {{ item }}
          </el-tag>
        </div>
      </template>
      <template v-else>
        <el-empty description="暂无数据" />
      </template>
    </el-dialog>
  </div>
</template>

<style lang="scss" scoped>
:deep(.el-statistic__content) {
  text-align: center;
}

.dialogByViewList {
  :deep(.el-dialog__body) {
    height: 350px;
    overflow: hidden;
    .tableHeader {
      .el-table-v2__header-cell {
        background: var(--el-color-info-light-9);
      }
    }
  }
}
</style>
