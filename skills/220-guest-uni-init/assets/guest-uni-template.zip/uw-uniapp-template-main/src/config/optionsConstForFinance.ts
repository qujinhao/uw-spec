export const TypeWithdrawOptions = [
  { label: '银行', value: 0 },
  { label: '支付宝', value: 1 },
  { label: '微信', value: 2 }
]

export const StateFinBalanceBillOptions = [
  { label: '未确认', value: 0 },
  { label: '对账中', value: 1 },
  { label: '对账完成', value: 2 },
  { label: '对账失败', value: -2 },
  { label: '开票申请', value: 3 },
  { label: '已开票', value: 4 },
  { label: '已开票', value: -4 }
]

export const TypeFinBillDateOptions = [
  { label: '不使用', value: 0 },
  { label: '入住时间/游玩日期', value: 1 },
  { label: '离店时间', value: 2 },
  { label: '确认时间', value: 3 },
  { label: '支付时间', value: 4 },
  { label: '完成时间', value: 5 },
  { label: '下单时间', value: 6 },
  { label: '对账时间', value: 7 }
]

export const StateFinBalanceDealOptions = [
  { label: '未确认', value: 0 },
  { label: '审核确认', value: 1 },
  { label: '审核拒绝', value: -1 },
  { label: '审核完成', value: 2 },
  { label: '审核失败', value: -2 },
  { label: '已成功', value: 3 },
  { label: '已失败', value: -3 }
]

export const StateFinBillOptions = [
  { label: '对账异常', value: -1 },
  { label: '未对账', value: 0 },
  { label: '已对账 未付/收款', value: 1 },
  { label: '已对账 部分付/收款', value: 2 },
  { label: '已对账 已付/收全款', value: 3 }
]

export const TypeFinBillResultOptions = [
  { label: 'none', value: 1 },
  { label: 'problem', value: 2 },
  { label: 'our_miss', value: 3 }
]

export const StateFinPayRefundOptions = [
  { label: '初始状态', value: 0 },
  { label: '退款申请成功', value: 50 },
  { label: '退款申请失败', value: -50 },
  { label: '退款处理中', value: 60 },
  { label: '退款关闭', value: 61 },
  { label: '退款异常', value: -60 },
  { label: '退款通知异常', value: -61 },
  { label: '退款成功', value: 70 }
]

export const TypeFinBizOrderListOptions = [
  { label: '订单ID列表', value: 1 },
  { label: '供应/分销订单列表', value: 2 },
  { label: '酒店确认号列表', value: 3 }
]

export const TypeFinPayOptions = [
  { label: '线下支付', value: 0 },
  { label: '在线支付', value: 1 },
  { label: '预存', value: 10 },
  { label: '授信', value: 11 },
  { label: '货仓预存', value: 20 }
]

export const TypeFinBalanceOptions = [
  { label: '预存', value: 1 },
  { label: '授信', value: 2 },
  { label: '返佣', value: 3 }
]

export const TypeFinBalanceDealOptions = [
  { label: '存款充值', value: 10 },
  { label: '充值退款', value: -10 },
  { label: '存款消费', value: -11 },
  { label: '存款消费退还', value: 11 },
  { label: '存款收入', value: 12 },
  { label: '存款收入退款', value: -12 },
  { label: '存款收入提现', value: -13 },
  { label: '返点提现', value: -33 },
  { label: '返点收入', value: 30 },
  { label: '返点取消', value: -30 },
  { label: '信用还款', value: 20 },
  { label: '信用消费', value: -21 },
  { label: '信用消费退款', value: 21 }
]

export const StateFinPayOrderOptions = [
  { label: '初始状态', value: 0 },
  { label: '预下单成功', value: 10 },
  { label: '预下单失败', value: -10 },
  { label: '用户支付中', value: 20 },
  { label: '未支付', value: 21 },
  { label: '转入退款', value: 22 },
  { label: '支付已关闭', value: 23 },
  { label: '支付已撤销(付款码)', value: 24 },
  { label: '支付失败', value: -20 },
  { label: '支付通知失败', value: -21 },
  { label: '支付成功', value: 30 }
]
