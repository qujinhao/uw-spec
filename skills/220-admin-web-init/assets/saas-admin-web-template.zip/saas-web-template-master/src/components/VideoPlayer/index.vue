<script setup lang="ts">
import { computed, ref, watch, onUnmounted } from 'vue'
// @ts-expect-error
import videojs from 'video.js/dist/video.es.js' // 暂时这样引入，不然会报错
import 'video.js/dist/video-js.css'
import { useI18n } from 'vue-i18n'
import video_zhCN from 'video.js/dist/lang/zh-CN.json'
import video_Ja from 'video.js/dist/lang/ja.json'
import video_zhTw from 'video.js/dist/lang/zh-TW.json'
import video_En from 'video.js/dist/lang/en.json'
import video_Ko from 'video.js/dist/lang/ko.json'

// 添加多语言包
videojs.addLanguage('zh-CN', video_zhCN)
videojs.addLanguage('ja', video_Ja)
videojs.addLanguage('zh-TW', video_zhTw)
videojs.addLanguage('en', video_En)
videojs.addLanguage('ko', video_Ko)

const props = withDefaults(
  defineProps<{
    show: boolean
    height?: string | number
    preload?: 'auto' | 'metadata' | 'none'
    src?: string
    width?: string | number
    expand?: Record<string, any> // 扩展字段
  }>(),
  {
    height: '400px',
    width: '800px',
    expand: () => ({})
  }
)

const emits = defineEmits<{
  (e: 'update:show', val: boolean): void
}>()

const { locale } = useI18n()

// 是否显示
const isShow = computed({
  get() {
    return props.show
  },
  set(val) {
    emits('update:show', val)
  }
})

const resetForm = () => {
  isShow.value = false
  if (videoPlayer.value) {
    videoPlayer.value.currentTime(0)
    videoPlayer.value.pause()
  }
}

// 视频播放高度
const videoHeight = computed(() => {
  if (typeof props.height === 'string') {
    return props.height
  }
  return props.height + 'px'
})

// 视频播放宽度
const videoWidth = computed(() => {
  if (typeof props.width === 'string') {
    return props.width
  }
  return props.width + 'px'
})

// 弹窗宽度
const dialogWidth = computed(() => {
  if (typeof props.width === 'string') {
    return Number(props.width.replace('px', '')) + 20 + 'px'
  }
  return props.width + 20 + 'px'
})

// 视频播放元素
const videoPlayerEl = ref()
const videoPlayer = ref()
// 初始化配置
const initOptions = computed(() => {
  return {
    ...props.expand,
    controls: true, // 显示控制属性
    height: videoHeight.value, // 视频高度
    width: videoWidth.value, // 视频宽度
    language: locale.value, // 设置默认语言为中文
    sources: [
      {
        src: props.src,
        type: videoType.value
      }
    ]
  }
})

// 自动推断视频类型
const videoType = computed(() => {
  const lastIndex = props.src?.lastIndexOf('.')
  if (lastIndex && !props.src?.includes('blob')) {
    const type = props.src?.slice(lastIndex + 1)
    return `video/${type}`
  }
  return 'video/mp4'
})

const timer = ref()
// 初始化，实例
const initVideo = () => {
  if (videoPlayerEl.value) {
    videoPlayer.value = videojs(
      videoPlayerEl.value,
      initOptions.value,
      function onPlayerReady() {
        console.log('onPlayerReady')
      }
    )
    clearTimeout(timer.value)
  } else {
    timer.value = setTimeout(() => {
      initVideo()
    }, 500)
  }
}

// 初始化实例
watch(
  () => isShow.value,
  val => {
    if (val && !videoPlayer.value) {
      initVideo()
    }
  }
)

// 动态切换多语言
watch(
  () => locale.value,
  val => {
    if (val) {
      videoPlayer.value?.language(val)
    }
  }
)

onUnmounted(() => {
  if (videoPlayer.value) {
    videoPlayer.value.dispose()
  }
  timer.value && clearTimeout(timer.value)
})
</script>

<template>
  <el-dialog
    v-model="isShow"
    title="视频播放"
    @close="resetForm"
    :width="dialogWidth"
    draggable
    :append-to-body="true"
    body-class="video-player-wrapper"
  >
    <video
      ref="videoPlayerEl"
      class="video-js vjs-default-skin vjs-big-play-centered"
    ></video>
  </el-dialog>
</template>

<style scoped lang="scss">
:deep(.video-player-wrapper) {
  padding: 0;
}
</style>
