<script lang="ts" setup>
import type { ProductInfo } from '@/api/saasMallAppGuestApi'
// import { formatPrice } from '@/utils/tool'
import { useI18n } from 'vue-i18n'
import ZTag from '@/components/ZTag/index.vue'

const { t } = useI18n()

const props = withDefaults(
  defineProps<{
    item: ProductInfo // 产品信息
  }>(),
  {
    // item: () => {}
  }
)

const emit = defineEmits<{
  (e: 'bookClick'): void
  (e: 'goDetail'): void
}>()

const handleBookClick = () => {
  emit('bookClick')
}
const handleDetail = () => {
  emit('goDetail')
}
</script>

<template>
  <div
    class="flex flex-col gap-[16rpx] p-[12rpx] border border-[#E5E5E5] rounded-[10rpx]"
  >
    <!--上内容-->
    <div class="flex items-start justify-between gap-[10rpx]">
      <div class="font-bold text-[16px] leading-[40rpx] text-[#030D18]">
        {{ props.item.productName }}
      </div>
      <div class="flex items-center gap-[5rpx]">
        <span
          class="cursor-pointer text-[14px] text-nowrap text-[#8A9098] underline"
          @click="handleDetail"
        >
          {{ t('详情') }}
        </span>
      </div>
    </div>

    <template v-if="true">
      <div class="flex gap-4 overflow-x-scroll">
        <ZTag
          v-for="item in ['立即确认', '预订当日有效', 'TODO']"
          :key="item"
          :text="item"
        />
      </div>
    </template>

    <div class="flex items-end justify-between">
      <div class="flex align-bottom gap-[8rpx]">
        <div class="text-[16px] leading-[26rpx] font-bold text-primary-buy">
          {{ t('CNY') }} {{ 0 }}
          <!-- <span class="font-bold">{{ formatPrice(props.item.) }}</span> -->
        </div>
        <span class="text-[10px] text-[#8A9098]">
          {{ t('起') }}
        </span>
      </div>
      <div
        class="bg-primary flex items-center rounded-[10rpx] p-[6rpx_16rpx] text-white"
        @click="handleBookClick"
      >
        {{ t('预订') }}
      </div>
    </div>
  </div>
</template>

<style lang="scss" scoped></style>
