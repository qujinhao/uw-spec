// 值                                    平台
// APP-PLUS                            App
// APP-PLUS-NVUE                       App nvue
// H5                                  H5
// MP-WEIXIN                           微信小程序
// MP-ALIPAY                           支付宝小程序
// MP-BAIDU                            百度小程序
// MP-TOUTIAO                          字节跳动小程序
// MP-KUAISHOU                         快手小程序
// MP-QQ                               QQ小程序
// MP-360                              360小程序
// MP-XHS                              小红书小程序
// MP                                  微信小程序/支付宝小程序/百度小程序/字节跳动小程序/QQ小程序/360小程序

type ObjType = {
  [key in any]: any
}

const channelType = (env: any): any => {
  const obj: ObjType = {
    h5: '3',
    'app-plus': '4',
    'mp-weixin': '6',
    'mp-toutiao': '7',
    'mp-xhs': '20',
    'mp-kuaishou': '14',
    'mp-baidu': '15',
    'mp-alipay': '13'
  }
  return obj[env]
}

export default channelType
