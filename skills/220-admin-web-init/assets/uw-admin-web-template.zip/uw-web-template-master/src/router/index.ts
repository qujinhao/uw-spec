import { useMainStore } from '@/store/main'
import { createRouter, createWebHashHistory, RouteRecordRaw } from 'vue-router'
import NProgress from 'nprogress'

// 自动导入当前文件夹的所有文件
const RouterList = import.meta.glob(['./*', '!./index', '!./typings.d.ts'], {
  import: 'default',
  eager: true
})

// 需要用到 layout 布局的路由页面
export let routes: RouteRecordRaw[] = []

for (const key in RouterList) {
  if (Object.hasOwn(RouterList, key)) {
    const item = RouterList[key]
    routes = routes.concat(item as RouteRecordRaw)
  }
}

const routerList: RouteRecordRaw[] = [
  {
    path: '/',
    redirect: '/login'
  },
  {
    path: '/login',
    component: () => import('@/pages/login/index.vue'),
    name: 'login', // 唯一值
    meta: {
      title: '登录',
      icon: '' // 路由 icon 图标
    }
  },
  {
    path: '/password',
    component: () => import('@/pages/password/index.vue'),
    name: 'password', // 唯一值
    meta: {
      title: '重置密码',
      icon: '' // 路由 icon 图标
    }
  },
  // 需要用到 layout 布局的路由页面
  {
    path: '/app',
    name: 'app',
    component: () => import('@/layout/index.vue')
  },
  {
    path: '/:pathMatch(.*)*',
    name: 'NotFound',
    component: () => import('@/pages/404/index.vue'),
    meta: {
      title: '404'
    },
    children: []
  }
]

const router = createRouter({
  history: createWebHashHistory(),
  routes: routerList,
  scrollBehavior() {
    // 始终滚动到顶部
    return {
      top: 0,
      behavior: 'smooth'
    }
  }
})

// 进度条配置
NProgress.configure({
  showSpinner: false, // 不显示左上角圆环
  speed: 400 // 动画速度500ms，与loading效果的速度一致
})

router.beforeEach(async (to, form, next) => {
  const mainStore = useMainStore()
  // 没有token的情况
  if (to.name === 'password') {
    // 忘记密码
    next()
    // 进度条开启
    NProgress.start()
  } else if (to.name !== 'login' && !mainStore.loginInfo.token) {
    // 进度条开启
    NProgress.start()
    next({ name: 'login' })
  } else if (to.name === 'NotFound' && mainStore.loadAppMenu.length === 0) {
    // 处理刷新页面 导致路由丢失问题
    const menuList = await mainStore.handleUserLoadAppMenu()
    mainStore.setAppMenu(menuList)
    // 进度条开启
    NProgress.start()
    next({
      path: to.path,
      query: to.query
    })
  } else {
    // 进度条开启
    NProgress.start()
    next()
  }
})

router.afterEach(to => {
  const mainStore = useMainStore()
  mainStore.setPageTabs({
    path: to.fullPath,
    title: to.meta.title || '未设置名称',
    name: to.name as string,
    dynamicRoute: to.meta.dynamicRoute || '',
    query: {
      ...to.query
    },
    params: {
      ...to.params
    }
  })
  // 页面关闭进度条
  NProgress.done()
})

router.onError(err => {
  // 页面关闭进度条
  NProgress.done()
  console.error('onError', err)
})

export default router
