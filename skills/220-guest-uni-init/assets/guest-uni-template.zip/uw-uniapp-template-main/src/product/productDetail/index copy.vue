<script lang="ts" setup>
import { reactive, ref } from 'vue'
import {
  onLoad,
  onPageScroll
  // onShareTimeline,
  // onShareAppMessage
} from '@dcloudio/uni-app'
import ZUp from '@/components/ZUp/index.vue'
import ZCalendar from '@/components/ZCalendar/index.vue'
import ZInsuranceBar from './components/ZInsuranceBar/index.vue'
import ZScenicInfo from '@/components/ZScenicInfo/index.vue'
import ZRichText from '@/components/ZRichText/index.vue'
// import ZParseHtml from '@/components/ZParseHtml/index.vue'

import ZDetailSwiper from './components/ZDetailSwiper/index.vue'
import ZBottomBtn from './components/ZBottomBtn/index.vue'
import { navToUrl, parseTime } from '@/utils/tool'
import {
  guestProductInfoPriceList,
  guestProductInfoLoad,
  type ProductInfo
} from '@/api/saasMallAppGuestApi'
function datePriceList() {
  const arr = []
  const y = new Date().getFullYear()
  const m = new Date().getMonth() + 1
  const days = new Date(2022, m, 0).getDate()
  for (let i = 1; i <= days; i++) {
    arr.push({
      travelDate: `${y}-${m < 10 ? '0' + m : m}-${i < 10 ? '0' + i : i}`,
      salePrice: 838,
      price: 793,
      num: 700,
      noSale: 0,
      isApply: 0,
      isHandle: 0,
      bounty: null,
      breaker: null,
      unit: '间'
    })
  }

  return arr
}

const detail = {
  services: [
    { name: '2', value: '停车场' },
    { name: '4', value: '健身中心' },
    { name: '6', value: '游泳池' },
    { name: '10', value: '商务中心' }
  ],
  address: '环市东路367号环市东路367号环市东路367号',
  phone: '020-83333998',
  phone1: '020-83333998,123456789、020-83333998，123456789 123456789',
  longitude: 113.2786,
  latitude: 23.13618
}

const title = '100万元保险免费赠送'
const content = `<p>2、保险责任： 意外伤害身故100万元</p>
        <p style="text-indent: 7em">意外伤害全残100万元</p>
        <p style="text-indent: 7em">意外伤害残疾10万元¬—100万元</p>
        <p style="text-indent: 7em">(伤残级别鉴定标准见投保须知及声明）</p>
        <p>3、保险期限: 进入景区检票大门至离开景区的期间，不超过5天。</p>
        <p>4、特别约定：</p>
        <p>1）按中国保监会规定，除航空意外死亡及重大自然灾害意外死亡外，任何不满10周岁的被保险人,其死亡保险金额不得超过人民币20万元：已满10周岁但未满18周岁的被保险人，其死亡保险金额不得超过人民币50万元。本公司对于超出中国保监会规定的限额的保险金额不承担保险责任。</p>                        
        <p>2）本保险附加《平安附加承保地域特约条款》，仅承保通过正常售票进入景区检票大门至出景区所发生的意外事故导致的身故和伤残。</p>
        <p>3）本保单除外海滨浴场内发生的意外事故。</p>
        <p>5、如何联系我们；</p>
        <p>本产品由中国平安财产保险股份有限公司深圳分公司主承，****共保，由平安产险深圳分公司提供理赔服务，保单查询及理赔电话95511。</p>
        <p style="color: #222; font-size:14px">投保须知及声明   保险条款：</p>
        <p>1 、本人同意领取由自我游平台及其授权的第三方服务企业赠送的游客意外险，本保障的受益人为被保险人法定受益人，该保险保障游客入园区至出园区期间因观光游玩发生的意外事故导致身故、伤残责任。</p>
        <p>2、信息提供：本人同意自我游平台及其授权的第三方服务者在中国法律允许或要求的范围内， 在下列情况下收集、使用、储存、披露、传送或以其他方式处理任何本人身份信 息（“个人资料”）作为赠险的投保资料。</p>
        <p>3 、本保障的适用条款《平安意外伤害保险（B款）》责任免除、投保人、被保险人义务等内容详见产品条款， 请务必仔细阅读产品条款及电子保单的特别约定。</p>
        <p>4、 本产品由中国平安财产保险股份有限公司深圳分公司主承，****共保，由平安产险深圳分公司提供理赔服务，保单查询及理赔电话95511,目前该公司在北京、天津、河北、山西、内蒙古、辽宁、吉林、黑龙江、上海、江苏、浙江、安徽、福建、江西、山东、河南、湖北、湖南、广东、广西壮族自治区、海南、重庆、四川、贵州、云南、西藏、陕西、甘肃、宁夏、青海、新疆维吾尔自治区设有分支机构。本产品的销售区域为全国。 </p>
        <p>5、承保年龄为出生后0至70周岁，以保单生效时的周岁年龄为准。</p>
        <p>6、 按中国保监会规定，除航空意外死亡及重大自然灾害意外死亡外，任何不满10周岁的被保险人，其死亡保险金额不得超过人民币20万元；已满10周岁但未满18周岁的被保险人，其死亡保险金额不得超过人民币50万元。本公司对于超出中国保监会规定的限额的保险金额不承担保险责任，被保险人年龄＜10岁，死亡保额须≤20万元；10岁≤被保险人年龄＜18岁，死亡保额须≤50万元，其中：16岁≤被保人年龄＜18周岁，如投保人为用人单位且被保险人为主被保险人，被保险人以自己的劳动收入为生活来源，保额可不受此限制。航空意外死亡保险金额以及重大自然灾害意外死亡保险金额不计算在前面规定限额之中。</p>
        <p>7、在同一保险期间，每位被保险人投保同一产品（包括同一产品的同一计划或不同计划）限投保一份，多投无效，以保额最高的保单为准，保险费将无息退还。</p>
        <p>8、本保单除外海滨浴场内发生的意外事故。</p>`

const list1 = [
  {
    title: '《平安旅行意外伤害保险（B款）》',
    content: `<p style="color: #222; text-align: center;">中国平安财产保险股份有限公司</p>
            <p style="color: #222; text-align: center;">平安旅行意外伤害保险（B款）条款</p>
            <p style="color: #222; text-align: center;">注册号为：C00001732312018030700051</p>
            <p style="margin-top: 15px;">总则</p>
            <p><span style="font-weight: bold; color: #333;">第一条</span> 本保险合同由保险条款、投保单、保险单、保险凭证以及批单等组成。凡涉及本保险合同的约定，均应采用书面形式。</p>
            <p><span style="font-weight: bold; color: #333;">第二条</span> 本保险合同的被保险人应为80周岁以下、身体健康、能正常工作或正常生活的旅行者。</p>
            <p><span style="font-weight: bold; color: #333;">第三条</span> 本保险合同的投保人应为具有完全民事行为能力的被保险人本人、对被保险人有保险利益的其他人。</p>
            <p><span style="font-weight: bold; color: #333;">第四条</span> 本保险合同的受益人包括：</p>
            <p>（一）身故保险金受益人</p>
            <p>订立本保险合同时，被保险人或投保人可指定一人或数人为身故保险金受益人。身故保险金受益人为数人时，应确定其受益顺序和受益份额；未确定受益份额的，各身故保险金受益人按照相等份额享有受益权。投保人指定受益人时须经被保险人同意。</p>
            <p>被保险人死亡后，有下列情形之一的，保险金作为被保险人的遗产，由保险人依照《中华人民共和国继承法》的规定履行给付保险金的义务：</p>
            <p>1．没有指定受益人，或者受益人指定不明无法确定的；</p>
            <p>2．受益人先于被保险人死亡，没有其他受益人的；</p>
            <p>3．受益人依法丧失受益权或者放弃受益权，没有其他受益人的。</p>
            <p>受益人与被保险人在同一事件中死亡，且不能确定死亡先后顺序的，推定受益人死亡在先。</p>
            <p>被保险人或投保人可以变更身故保险金受益人，但需书面通知保险人，由保险人在本保险合同上批注。<span style="font-weight: bold; color: #333;">对因身故保险金受益人变更发生的法律纠纷，保险人不承担任何责任。</span></p>
            <p>投保人指定或变更身故保险金受益人的，应经被保险人书面同意。被保险人为无民事行为能力人或限制民事行为能力人的，应由其监护人指定或变更身故保险金受益人。</p>
            <p>（二）伤残保险金受益人</p>
            <p>除另有约定外，本保险合同的伤残保险金的受益人为被保险人本人。</p>
            <p style="margin-top: 15px;">保险责任</p>
            <p><span style="font-weight: bold; color: #333;">第五条</span> 在保险期间内，被保险人在旅行期间因遭受意外伤害事故导致身故、伤残的，保险人依照下列约定给付保险金，<span style="font-weight: bold; color: #333;">且给付各项保险金之和不超过保险金额</span>。</p>
            <p>（一）身故保险责任</p>
            <p>在保险期间内，被保险人在旅行期间遭受意外伤害事故，并自事故发生之日起180日内因该事故身故的，保险人按意外伤害保险金额给付身故保险金，对被保险人的保险责任终止。</p>
            <p>被保险人因遭受意外伤害事故且自该事故发生日起下落不明，后经人民法院宣告死亡的，保险人按意外伤害保险金额给付身故保险金。<span style="font-weight: bold; color: #333;">但若被保险人被宣告死亡后生还的，保险金受领人应于知道或应当知道被保险人生还后30日内退还保险人给付的身故保险金</span>。</p>
            <p><span style="font-weight: bold; color: #333;">被保险人身故前保险人已给付第（二）款约定的伤残保险金的，身故保险金应扣除已给付的保险金。</span></p>
            <p>（二）伤残保险责任</p>
            <p>在保险期间内，被保险人在旅行期间遭受意外伤害事故，并自该事故发生之日起180日内因该事故造成《人身保险伤残评定标准及代码》（标准编号为JR/T0083—2013，下简称《伤残评定标准》）所列伤残之一的，<span style="font-weight: bold;">保险人按《伤残评定标准》所列给付比例乘以意外伤害保险金额给付伤残保险金</span>。如第180日治疗仍未结束的，按当日的身体情况进行伤残鉴定，并据此给付伤残保险金。</p>
            <p>1．当同一保险事故造成两处或两处以上伤残时，应首先对各处伤残程度分别进行评定，如果几处伤残等级不同，以最重的伤残等级作为最终的评定结论；如果两处或两处以上伤残等级相同，伤残等级在原评定基础上最多晋升一级，最高晋升至第一级。同一部位和性质的伤残，不应采用《伤残评定标准》条文两条以上或者同一条文两次以上进行评定。</p>
            <p>2．<span style="font-weight: bold; color: #333;">被保险人如在本次意外伤害事故之前已有伤残，保险人按合并后的伤残程度在《伤残评定标准》中所对应的给付比例给付伤残保险金，但应扣除原有伤残程度在《伤残评定标准》所对应的伤残保险金。</span></p>
            <p><span style="font-weight: bold; color: #333;">在保险期间内，前述第（一）、（二）款下的保险金累计给付金额以保险单载明的意外伤害保险金额为限。</span></p>
            <p style="margin-top: 15px;">责任免除</p>
            <p><span style="font-weight: bold; color: #333;">第六条 因下列原因造成被保险人身故、伤残的，保险人不承担给付保险金责任：</span></p>
            <p><span style="font-weight: bold; color: #333;">（一）投保人的故意行为；</span></p>
            <p><span style="font-weight: bold; color: #333;">（二）被保险人自致伤害或自杀，但被保险人自杀时为无民事行为能力人的除外；</span></p>
            <p><span style="font-weight: bold; color: #333;">（三）因被保险人挑衅或故意行为而导致的打斗、被袭击或被谋杀；</span></p>
            <p><span style="font-weight: bold; color: #333;">（四）被保险人妊娠、流产、分娩、疾病、药物过敏、中暑、猝死；</span></p>
            <p><span style="font-weight: bold; color: #333;">（五）被保险人接受整容手术及其他内、外科手术；</span></p>
            <p><span style="font-weight: bold; color: #333;">（六）被保险人未遵医嘱，私自服用、涂用、注射药物；</span></p>
            <p><span style="font-weight: bold; color: #333;">（七）核爆炸、核辐射或核污染；</span></p>
            <p><span style="font-weight: bold; color: #333;">（八）恐怖袭击；</span></p>
            <p><span style="font-weight: bold; color: #333;">（九）被保险人犯罪或拒捕；</span></p>
            <p><span style="font-weight: bold; color: #333;">（十）被保险人从事高风险运动或参加职业或半职业体育运动。</span></p>
            <p><span style="font-weight: bold; color: #333;">第七条 被保险人在下列期间遭受伤害导致身故、伤残的，保险人也不承担给付保险金责任：</span></p>
            <p><span style="font-weight: bold; color: #333;">（一）战争、军事行动、暴动或武装叛乱期间；</span></p>
            <p><span style="font-weight: bold; color: #333;">（二）被保险人醉酒或受毒品、管制药物的影响期间；</span></p>
            <p><span style="font-weight: bold; color: #333;">（三）被保险人酒后驾车、无有效驾驶证驾驶或驾驶无有效行驶证的机动车期间。</span></p>
            <p style="margin-top: 15px;">保险金额和保险费</p>
            <p><span style="font-weight: bold; color: #333;">第八条</span> 保险金额是保险人承担给付保险金责任的最高限额。</p>
            <p>本保险合同的意外伤害保险金额由投保人、保险人双方约定，并在保险单中载明。</p>
            <p>投保人应该按照合同约定向保险人交纳保险费。</p>
            <p style="margin-top: 15px;">保险期间</p>
            <p><span style="font-weight: bold; color: #333;">第九条</span> 本保险可以按单次旅行投保或按年度保障投保，保险期间由保险人和投保人协商确定，以保险单载明的起讫时间为准。</p>
            <p>若按单次旅行投保，保险人开始承担保险责任的时间为被保险人离开保险单上载明的旅行出发地之时，但<span style="font-weight: bold; color: #333;">最早不得早于保险期间起始日</span>；保险人终止承担保险责任的时间为被保险人返回旅行出发地之时，但<span style="font-weight: bold;">最迟不得迟于保险期间终止日</span>。</p>
            <p>若按年度保障投保，保险期间为一年，被保险人在保险期间内可开始进行多次旅行，但对于每次旅行，<span style="font-weight: bold; color: #333;">保险人承担保险责任的期间自被保险人离开保险单上载明的旅行出发地之时起最长不超过连续90天</span>。</p>
            <p>在保险期间届满的情况下，如果因不可抗力导致被保险人的旅行被迫延长，保险人将根据合理情况免费自动延长保险期间至被保险人实际返回旅行出发地之时。</p>
            <p style="margin-top: 15px;">保险人义务</p>
            <p><span style="font-weight: bold; color: #333;">第十条</span> 本保险合同成立后，保险人应当及时向投保人签发保险单或其他保险凭证。</p>
            <p><span style="font-weight: bold; color: #333;">第十一条</span> 保险人按照本保险合同的约定，认为被保险人提供的有关索赔的证明和资料不完整的，应当及时一次性通知投保人、被保险人补充提供。</p>
            <p><span style="font-weight: bold; color: #333;">第十二条</span> 保险人收到被保险人的给付保险金的请求后，应当及时作出是否属于保险责任的核定；情形复杂的，保险人将在确定是否属于保险责任的基本材料收集齐全后，尽快做出核定。</p>
            <p>保险人应当将核定结果通知被保险人；对属于保险责任的，在与被保险人达成给付保险金的协议后十日内，履行给付保险金义务。保险合同对给付保险金的期限有约定的，保险人应当按照约定履行给付保险金的义务。保险人依照前款约定作出核定后，对不属于保险责任的，应当自作出核定之日起三日内向被保险人发出拒绝给付保险金通知书，并说明理由。</p>
            <p><span style="font-weight: bold; color: #333;">第十三条</span> 保险人自收到给付保险金的请求和有关证明、资料之日起六十日内，对其给付的数额不能确定的，应当根据已有证明和资料可以确定的数额先予支付；保险人最终确定给付的数额后，应当支付相应的差额。</p>
            <p><span style="font-weight: bold; color: #333;">第十四条</span> 投保人符合保险法规定的退还保险费相关要求的，保险人应当按照保险法相关规定退还未满期净保费。</p>
            <p style="margin-top: 15px;">投保人、被保险人义务</p>
            <p><span style="font-weight: bold; color: #333;">第十五条</span> 除另有约定外，投保人应当在保险合同成立时交清保险费。 </p>
            <p><span style="font-weight: bold; color: #333;">第十六条</span> 订立保险合同，保险人就被保险人的有关情况提出询问的，投保人应当如实告知 </p>
            <p><span style="font-weight: bold; color: #333;">投保人故意或者因重大过失未履行前款规定的义务，足以影响保险人决定是否同意承保或者提高保险费率的，保险人有权解除本保险合同。</span></p>
            <p>前款规定的合同解除权，自保险人知道有解除事由之日起，超过三十日不行使而消灭。自合同成立之日起超过二年的，保险人不得解除合同；发生保险事故的，保险人应当承担给付保险金责任。</p>
            <p><span style="font-weight: bold; color: #333;">投保人故意不履行如实告知义务的，保险人对于合同解除前发生的保险事故，不承担给付保险金责任，并不退还保险费。</span></p>
            <p><span style="font-weight: bold; color: #333;">投保人因重大过失未履行如实告知义务，对保险事故的发生有严重影响的，保险人对于合同解除前发生的保险事故，不承担给付保险金责任，但应当退还保险费。</span></p>
            <p>保险人在合同订立时已经知道投保人未如实告知的情况的，保险人不得解除合同；发生保险事故的，保险人应当承担给付保险金责任。</p>
            <p><span style="font-weight: bold; color: #333;">第十七条</span> 投保人住所或通讯地址变更时，应及时以书面形式通知保险人。投保人未通知的，保险人按本保险合同所载的最后住所或通讯地址发送的有关通知，均视为已发送给投保人。</p>
            <p><span style="font-weight: bold; color: #333;">第十八条</span> 投保人、被保险人或者保险金受益人知道保险事故发生后，应当及时通知保险人。<span style="font-weight: bold; color: #333;">故意或者因重大过失未及时通知，致使保险事故的性质、原因、损失程度等难以确定的，保险人对无法确定的部分，不承担给付保险金责任</span>，但保险人通过其他途径已经及时知道或者应当及时知道保险事故发生的除外。</p>
            <p>上述约定，不包括因不可抗力而导致的迟延。</p>
            <p style="margin-top: 15px;">保险金申请与给付</p>
            <p><span style="font-weight: bold; color: #333;">第十九条</span> 保险金申请人向保险人申请给付保险金时，应提交以下材料。保险金申请人因特殊原因不能提供以下材料的，应提供其他合法有效的材料。<span style="font-weight: bold; color: #333;">保险金申请人未能提供有关材料，导致保险人无法核实该申请的真实性的，保险人对无法核实部分不承担给付保险金的责任</span>。</p>
            <p>（一）身故保险金申请</p>
            <p>1．保险金给付申请书；</p>
            <p>2．保险单原件；</p>
            <p>3．保险金申请人的身份证明；</p>
            <p>4．公安部门或医疗机构出具的被保险人死亡证明书。若被保险人为宣告死亡，保险金申请人应提供人民法院出具的宣告死亡证明文件；</p>
            <p>5．被保险人的户籍注销证明；</p>
            <p>6．被保险人的旅行交通票据（如机票、车票等）、酒店住宿票据、旅游团费单据等旅行凭证，须提交复印件并提供原件以查验；</p>
            <p>7．保险金申请人所能提供的与确认保险事故的性质、原因、损失程度等有关的其他证明和资料；</p>
            <p>8．若保险金申请人委托他人申请的，还应提供授权委托书原件、委托人和受托人的身份证明等相关证明文件。</p>
            <p>（二）伤残保险金申请</p>
            <p>1．保险金给付申请书；</p>
            <p>2．保险单原件；</p>
            <p>3．被保险人身份证明；</p>
            <p>4．二级以上（含二级）或保险人认可的医疗机构或司法鉴定机构出具的伤残鉴定诊断书；</p>
            <p>5．被保险人的旅行交通票据（如机票、车票等）、酒店住宿票据、旅游团费单据等旅行凭证，须提交复印件并提供原件以查验；</p>
            <p>6．保险金申请人所能提供的与确认保险事故的性质、原因、损失程度等有关的其他证明和资料；</p>
            <p>7．若保险金申请人委托他人申请的，还应提供授权委托书原件、委托人和受托人的身份证明等相关证明文件。</p>
            <p><span style="font-weight: bold; color: #333;">第二十条</span> 保险金申请人向保险人请求给付保险金的诉讼时效期间为二年，自其知道或者应当知道保险事故发生之日起计算。</p>
            <p style="margin-top: 15px;">争议处理和法律适用</p>
            <p><span style="font-weight: bold; color: #333;">第二十一条</span> 因履行本保险合同发生的争议，由当事人协商解决。协商不成的，提交保险单载明的仲裁机构仲裁；保险单未载明仲裁机构或者争议发生后未达成仲裁协议的，依法向人民法院起诉。</p>
            <p><span style="font-weight: bold; color: #333;">第二十二条</span> 与本保险合同有关的以及履行本保险合同产生的一切争议处理适用中华人民共和国法律（不包括港澳台地区法律）。</p>
            <p style="margin-top: 15px;">其他事项</p>
            <p><span style="font-weight: bold; color: #333;">第二十三条</span>  投保人和保险人可以协商变更合同内容。</p>
            <p>变更保险合同的，应当由保险人在保险单或者其他保险凭证上批注或附贴批单，或者投保人和保险人订立变更的书面协议。</p>
            <p><span style="font-weight: bold; color: #333;">第二十四条</span>  在本保险合同成立后，投保人可以书面形式通知保险人解除合同，但保险人已根据本保险合同约定给付保险金的除外。</p>
            <p>投保人解除本保险合同时，应提供下列证明文件和资料：</p>
            <p>（一）保险合同解除申请书；</p>
            <p>（二）保险单原件；</p>
            <p>（三）保险费交付凭证；</p>
            <p>（四）投保人身份证明。</p>
            <p>投保人要求解除本保险合同，自保险人接到保险合同解除申请书之时起，本保险合同的效力终止。保险人收到上述证明文件和资料之日起30日内退还保险单的未满期净保费。</p>
            <p style="margin-top: 15px;">释义</p>
            <p><span style="font-weight: bold; color: #333;">第二十五条</span></p>
            <p>【旅行】指因旅游、洽谈公务、探亲等必须离开被保险人所在地的行为。</p>
            <p>【周岁】以法定身份证明文件中记载的出生日期为基础计算的实足年龄。</p>
            <p>【保险人】指与投保人签订本保险合同的中国平安财产保险股份有限公司。</p>
            <p>【意外伤害】指以外来的、突发的、非本意的和非疾病的客观事件为直接且单独的原因致使身体受到的伤害。</p>
            <p>【高风险运动】指比一般常规性的运动风险等级更高、更容易发生人身伤害的运动，在进行此类运动前需有充分的心理准备和行动上的准备，必须具备一般人不具备的相关知识和技能或者必须在接受专业人士提供的培训或训练之后方能掌握。被保险人进行此类运动时须具备相关防护措施或设施，以避免发生损失或减轻损失，包括但不限于潜水，滑水，滑雪，滑冰，驾驶或乘坐滑翔翼、滑翔伞，跳伞，攀岩运动，探险活动，武术比赛，摔跤比赛，柔道，空手道，跆拳道，马术，拳击，特技表演，驾驶卡丁车，赛马，赛车，各种车辆表演，蹦极。</p>
            <p>【无有效驾驶证】被保险人存在下列情形之一者：</p>
            <p>（1）无驾驶证，驾驶证被依法扣留、暂扣、吊销、注销；</p>
            <p>（2）驾驶的机动车与驾驶证载明的准驾车型不符；</p>
            <p>（3）实习期内驾驶公共汽车、营运客车或者执行任务的警车、载有危险物品的机动车或牵引挂车的机动车；</p>
            <p>（4）使用各种专用机械车、特种车的人员无国家有关部门核发的有效操作证、许可证书或其他必备证书，驾驶出租机动车或营业性机动车无交通运输管理部门核发的许可证书或其他必备证书。</p>
            <p>【无有效行驶证】指下列情形之一：</p>
            <p>（1）机动车行驶证、号牌被注销的；</p>
            <p>（2）未按规定检验或检验不合格。</p>
            <p>【未满期净保费】未满期净保费＝保险费×[1－（保险单已经过天数/保险期间天数）] ×（1－35%）。经过天数不足一天的按一天计算。</p>
            <p>【每次旅行】指为旅游、商务、探亲等目的，从离开旅行出发地开始，至返回旅行出发地为止的期间。</p>
            <p>【不可抗力】指不能预见、不能避免并不能克服的客观情况。</p>
            <p>【保险金申请人】指受益人或被保险人的继承人或依法享有保险金请求权的其他自然人。</p>`
  },
  {
    title: '《平安附加承保地域特约条款》',
    content: `<p style="color: #222; text-align: center;">中国平安财产保险股份有限公司</p>
            <p style="color: #222; text-align: center;">平安附加承保地域特约条款</p>
            <p style="color: #222; text-align: center;">注册号为：C00001732322018031302341</p>
            <p style=" margin-top: 15px;text-indent: 2em">本附加保险合同须附加于各类意外伤害保险、健康保险主险合同（以下简称“主保险合同”）。主保险合同所附条款、投保单、保险单、保险凭证以及批单等，凡与本附加保险合同相关者，均为本附加保险合同的构成部分。凡涉及本附加保险合同的约定，均应采用书面形式。本附加保险合同未尽事宜，以主保险合同的条款规定为准。若主保险合同与本附加保险合同的条款互有冲突，则以本附加保险合同的条款为准。</p>
            <p style="text-indent: 2em">经投保人申请并经保险人同意，在保险期间内，在主保险合同下，保险人<span style="font-weight: bold; color: #333;">仅对被保险人在保险单载明的区域范围内</span>发生的保险责任范围内保险事故承担给付保险金的责任。</p>`
  }
]

const pageData = {
  infoId: 11111,
  viewName: 11111,
  areaName: 11111,
  startDay: 11111,
  startTime: 11111,
  isConfirm: 1,
  isOnlinePay: 1,
  isOnlinepay: 1,
  hotelDetail: { nights: 1, roomGrade: 5, brekker: '有', internet: '有' }
}

const state = reactive({
  id: Number.NaN,
  scrollTop: 0
})
const detailData = ref<ProductInfo>({})

const imgList = ref<string[]>([])
const travelDate = ref('')
const year = ref(parseTime(new Date(), '{y}'))
const month = ref(parseTime(new Date(), '{m}'))

const handleClickMap = (item: any) => {
  uni.showToast({
    title: 'handleClickMap' + item,
    icon: 'none'
  })
}

const handleLoad = async (id: number) => {
  const res = await guestProductInfoLoad({ id })
  if (res.state === 'success' && res.data) {
    console.log('res.data', res.data)
  }
}
const getGuestProductInfoPriceList = async (id: number) => {
  const res = await guestProductInfoPriceList({
    productId: detailData.value.id,
    priceDateRange: ['2024-12-01 00:00:00', '2024-12-20 00:00:00']
  })
  console.log(res, id)
}

const handleClick = () => {
  navToUrl(
    `/packages/order/placeOrder/index?productData=${JSON.stringify(detailData.value)}`
  )
}

// 获取日期的回调
const getDate = (e: any) => {
  const date = typeof e === 'object' ? JSON.stringify(e) : e
  console.log('date', date)
}
const getDatePrice = (e: any) => {
  const { year, month } = e
  // year.value = year
  // month.value = month
  console.log(year)
  console.log(month)

  // datePriceList = [
  //   {
  //     travelDate: '2020-07-19',
  //     salePrice: 3,
  //     num: '>9张',
  //     noSale: 0,
  //     isApply: 0,
  //     isHandle: 0,
  //     bounty: 0,
  //     breaker: null
  //   },
  //   {
  //     travelDate: '2020-07-20',
  //     salePrice: 5,
  //     num: '>9张',
  //     noSale: 0,
  //     isApply: 0,
  //     isHandle: 0,
  //     bounty: 0,
  //     breaker: null
  //   }
  // ]
}

onLoad((options: any) => {
  if (options.productData) {
    detailData.value = JSON.parse(options.productData)
    imgList.value = [detailData.value.imgMain as string]

    handleLoad(JSON.parse(options.productData).id)

    getGuestProductInfoPriceList(JSON.parse(options.productData).id)
  }
})
// 滚动页面
onPageScroll((e) => {
  state.scrollTop = e.scrollTop
})
</script>

<template>
  <view class="product-page">
    <ZDetailSwiper :covers="imgList" />
    <ZScenicInfo
      :address="detail.address"
      :phone="detail.phone1"
      :latitude="detail.latitude"
      :longitude="detail.longitude"
      @click-map="handleClickMap"
    />

    <ZInsuranceBar
      :title="title"
      :content="content"
      :list="list1"
    ></ZInsuranceBar>
    <ZCalendar
      mode="B2B"
      type="range"
      product-type="酒店"
      :range-text="{ stext: '入住', etext: '退房' }"
      v-model:value="travelDate"
      fie-id="travelDate"
      :current-month="month"
      :current-year="year"
      :date-price-list="datePriceList()"
      @changeMonth="getDatePrice"
      @changeDate="getDate"
    />
    <ZRichText
      title="基本信息"
      class="mt10"
    >
      <view>
        <view class="rich_item">
          <text>产品编号：</text>
          {{ pageData.infoId }}
        </view>
        <view class="rich_item">
          <text>对应酒店：</text>
          {{ pageData.viewName }}
        </view>
        <view class="rich_item">
          <text>所在城市：</text>
          {{ pageData.areaName }}
        </view>
        <view class="rich_item">
          <text>提前天数：</text>
          {{ `需提前${pageData.startDay}天预订` }}
        </view>
        <view class="rich_item">
          <text>确认方式：</text>
          {{ pageData.isConfirm === 1 ? '预订后需人工确认订单才' : '预订后即'
          }}{{ pageData.isOnlinePay === 1 ? '可支付' : '有效' }}
        </view>
        <view class="rich_item">
          <text>付款方式：</text>
          {{ pageData.isOnlinepay === 1 ? '在线支付' : '窗口现付' }}
        </view>
        <template v-if="pageData.hotelDetail">
          <view
            class="rich_item"
            v-if="pageData.hotelDetail.nights !== 0"
          >
            <text>连住要求：</text>
            要求连住{{ pageData.hotelDetail.nights }}晚以上
          </view>
          <view class="rich_item">
            <text>星级：</text>
            {{ pageData.hotelDetail.roomGrade }}
          </view>
          <view class="rich_item">
            <text>早餐：</text>
            {{ pageData.hotelDetail.brekker }}
          </view>
          <view class="rich_item">
            <text>宽带：</text>
            {{ pageData.hotelDetail.internet }}
          </view>
        </template>
      </view>
    </ZRichText>
    <view class="product-page__box m10 p20 fontBold">
      <view class="title fontBold">——产品介绍——</view>
    </view>
    <view class="product-page__box m10 p20 fontBold">
      <view class="parse flex-center m-t-100">
        {{ detailData.productName }}
      </view>
    </view>

    <!-- <view class="parse flex-center m-t-100"></view> -->
    <!-- <ZParseHtml :content="content" /> -->
    <!-- 底部操作菜单 -->
    <ZBottomBtn @click="handleClick" />

    <ZUp :scrollTop="state.scrollTop" />
  </view>
</template>

<style lang="scss" scoped>
.product-page {
  width: 100vw;
  overflow: hidden;
  box-sizing: border-box;
  background-color: #f7f7f7;
  padding-bottom: calc(env(safe-area-inset-bottom) / 2 + 100rpx);

  &__box {
    position: relative;
    border-radius: 10rpx;
    background-color: #ffffff;
  }
}
</style>
