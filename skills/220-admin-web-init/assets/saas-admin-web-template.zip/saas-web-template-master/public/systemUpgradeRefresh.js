// 从 package.json 获取应用名称作为 localStorage key 前缀
const appName = window.__APP_NAME__
const language = localStorage.getItem(`${window.__APP_NAME__}-lang`) || 'zh-CN' // 默认为中文
const Message = {
  en: {
    updateMsg: 'The system has been upgraded, please refresh the page!'
  },
  ja: {
    updateMsg: 'システムがアップグレードされました。ページを更新してください。'
  },
  ko: {
    updateMsg: '시스템이 업그레이드되었습니다. 페이지를 새로고침해주세요!'
  },
  'zh-CN': {
    updateMsg: '系统已升级，请刷新页面！'
  },
  'zh-TW': {
    updateMsg: '系統已升級，請重新整理頁面！'
  }
}

class SystemUpgradeRefresh {
  // 节流变量
  isChecking = false
  constructor() {
    this.isChecking = false
  }

  // 处理js资源请求错误的404
  handlePathErrorForJS = err => {
    // 判断是否js请求报错
    if (
      err.target &&
      ['link', 'script'].includes(err.target.localName) &&
      ((err.target.href && err.target.href.includes('js')) ||
        (err.target.src && err.target.src.includes('js'))) &&
      !this.isChecking
    ) {
      this.isChecking = true
      // 解除绑定
      window.removeEventListener('error', this.handleRefreshSystem)
      // 请求资源路径是否404
      this.getResponseCode(err.target.href || err.target.src).then(res => {
        if (res === 404) {
          window.alert(Message[language].updateMsg)
          window.location.reload()
        }
      })
    }
  }

  // 获取响应的静态资源
  getResponseCode = url => {
    return new Promise((resolve, reject) => {
      fetch(url)
        .then(res => {
          if (res) {
            resolve(res.status)
          } else {
            resolve(500)
          }
        })
        .catch(() => {
          reject(500)
        })
    })
  }

  // 开始监听error
  startErrorListener = () => {
    window.addEventListener('error', this.handlePathErrorForJS, true)
  }
}

const systemUpgrade = new SystemUpgradeRefresh()
systemUpgrade.startErrorListener()
