<script setup lang="ts">
import pinia from '@/store'
import { useMainStore } from '@/store/main'
import { messages } from '@/i18n/index'

const mainStore = useMainStore(pinia)

const locale = computed(() => {
  // @ts-expect-error
  return messages[mainStore.i18n] || messages['zh-CN']
})
</script>

<template>
  <el-config-provider :locale="locale">
    <router-view></router-view>
  </el-config-provider>
</template>

<style lang="scss">
@use './styles/normalize.css';
@use './styles/flex.scss';

html,
body,
#app {
  width: 100%;
  height: 100%;
  overflow: hidden;

  // 国际化统一label样式
  .el-form {
    .el-form-item__label {
      display: flex;
      align-items: center;
      justify-content: flex-end;
      line-height: normal;
    }
  }
}
</style>
