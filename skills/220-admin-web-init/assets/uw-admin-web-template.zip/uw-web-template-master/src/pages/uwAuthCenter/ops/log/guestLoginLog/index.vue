<script setup lang="ts">
import { type ComponentInternalInstance } from 'vue'
import { SearchFormType } from '@/components/SearchForm/type'
import {
  opsLogGuestLoginLogList,
  type MscGuestLoginEsLogQueryParam,
  type MscGuestLoginEsLog
} from '@/api/uwAuthCenterOpsApi'
import { useI18n } from 'vue-i18n'
import { useCrud } from '@/hooks/useCrud'
import { ResponseData, DataList } from '@/api/uwAuthCenterAuthApi'
import { useCommonSelectTypes } from '@/utils/selectOptions'
import { useExportExcel } from '@/hooks/useExportExcel'

const LoginUserInfoCard = defineAsyncComponent(
  () =>
    import('@/pages/uwAuthCenter/ops/log/component/LoginUserInfoCard/index.vue')
)

// 获取全局挂载的方法
const { proxy } = getCurrentInstance() as ComponentInternalInstance
const { formatDate, useActivated } = proxy as any
const { t } = useI18n()
const {
  getAllUserTypes,
  userTypes,
  loginTypes,
  loginDeviceTypes,
  loginResultTypes,
  handleTypeForLabel
} = useCommonSelectTypes()

const {
  tableConfig, // 表格相关配置属性
  handleList // 列表请求函数
} = useCrud<MscGuestLoginEsLog, MscGuestLoginEsLogQueryParam>(
  {
    // 列表请求接口
    listFn: (): Promise<ResponseData<DataList<MscGuestLoginEsLog>>> => {
      return opsLogGuestLoginLogList(tableConfig.queryParams)
    }
  },
  {
    isCombinedFetch: true
  }
)

// 搜索表单 结构组成数据
const searchList = computed<SearchFormType[]>(() => {
  return [
    {
      field: 'userId',
      componentType: 'input',
      formItem: {
        label: '用户ID',
        labelWidth: '70'
      },
      formItemWidth: 280,
      placeholder: t('pleaseInput'),
      clearable: true
    },
    {
      field: 'userName',
      componentType: 'input',
      formItem: {
        label: '登录名称',
        labelWidth: '70'
      },
      formItemWidth: 280,
      placeholder: t('pleaseInput'),
      clearable: true
    },
    {
      field: 'realName',
      componentType: 'input',
      formItem: {
        label: '真实姓名',
        labelWidth: '70'
      },
      formItemWidth: 280,
      placeholder: t('pleaseInput'),
      clearable: true
    },
    {
      field: 'userType',
      componentType: 'select',
      formItem: {
        label: '用户类型',
        labelWidth: '70'
      },
      formItemWidth: 280,
      placeholder: t('pleaseSelect'),
      clearable: true,
      componentWidth: '100%',
      options: getAllUserTypes.value
    },

    {
      field: 'userIp',
      componentType: 'input',
      formItem: {
        label: '用户IP',
        labelWidth: '70'
      },
      formItemWidth: 280,
      placeholder: t('pleaseInput'),
      clearable: true
    },
    {
      field: 'mchId',
      componentType: 'input',
      formItem: {
        label: '商户ID',
        labelWidth: '70'
      },
      formItemWidth: 280,
      placeholder: t('pleaseInput'),
      clearable: true
    },
    {
      field: 'appInfo',
      componentType: 'input',
      formItem: {
        label: '应用信息',
        labelWidth: '70'
      },
      formItemWidth: 280,
      placeholder: t('pleaseInput'),
      clearable: true
    },
    {
      field: 'appHost',
      componentType: 'input',
      formItem: {
        label: '应用主机',
        labelWidth: '70'
      },
      formItemWidth: 280,
      placeholder: t('pleaseInput'),
      clearable: true
    },
    {
      field: 'loginAgent',
      componentType: 'input',
      formItem: {
        label: '登录代理',
        labelWidth: '70'
      },
      formItemWidth: 280,
      placeholder: t('pleaseInput'),
      clearable: true
    },
    {
      field: 'responseState',
      componentType: 'select',
      formItem: {
        label: '登录结果',
        labelWidth: '70'
      },
      formItemWidth: 280,
      componentWidth: '100%',
      options: loginResultTypes.value,
      placeholder: t('pleaseInput'),
      clearable: true
    },
    {
      field: 'loginDateRange',
      componentType: 'datePicker',
      formItem: {
        label: t('uwAuthCenter.MscLoginESLog.loginDate'),
        labelWidth: '90'
      },
      componentWidth: 380,
      clearable: true,
      type: 'datetimerange',
      startPlaceholder: '请输入开始时间',
      endPlaceholder: '请输入结束时间',
      defaultTime: [
        new Date(2000, 1, 1, 0, 0, 0),
        new Date(2000, 2, 1, 23, 59, 59)
      ],
      valueFormat: 'YYYY-MM-DD HH:mm:ss'
    }
  ]
})

// 用户资料
const popoverData = ref({})
// popover 显示
const handlePopoverShow = (item: MscGuestLoginEsLog) => {
  popoverData.value = JSON.parse(JSON.stringify(item))
}

const data = computed(() => [
  {
    field: 'appHost',
    label: 'App主机'
  },
  {
    field: 'appInfo',
    label: 'App信息'
  },
  {
    field: 'loginAgent',
    label: '登录客户端'
  },
  {
    field: 'loginType',
    label: '登录类型',
    options: loginTypes.value
  },
  {
    field: 'loginId',
    label: '登录标识'
  },
  {
    field: 'userId',
    label: '用户Id'
  },
  {
    field: 'userName',
    label: '用户信息'
  },
  {
    field: 'nickName',
    label: '昵称信息'
  },
  {
    field: 'realName',
    label: '真实姓名'
  },
  {
    field: 'saasId',
    label: '运营商Id'
  },
  {
    field: 'mchId',
    label: '商户Id'
  },
  {
    field: 'groupId',
    label: '用户组Id'
  },
  {
    field: 'userType',
    label: '用户类型',
    options: userTypes.value
  },
  {
    field: 'userIp',
    label: '登录IP'
  },
  {
    field: 'clientType',
    label: '登录设备'
  },
  {
    field: 'clientAgent',
    label: '用户代理'
  },
  {
    field: 'loginResult',
    label: '登录结果',
    options: loginResultTypes.value
  },
  {
    field: 'loginDate',
    label: '请求时间',
    valueFormat: 'YYYY-MM-DD HH:mm:ss'
  },
  {
    field: 'remark',
    label: '备注'
  },
  {
    field: 'responseMillis',
    label: '执行返回毫秒数'
  }
])

const { startExport } = useExportExcel()
const exportExcel = () => {
  startExport({
    url: '/uw-auth-center/ops/log/guestLoginLog/list',
    queryParams: tableConfig.queryParams,
    columns: data.value,
    sizeAll: tableConfig.sizeAll
  })
}

useActivated(() => {
  handleList()
})
</script>

<template>
  <div class="flex_col">
    <div class="flex_col_header">
      <SearchForm
        v-model="tableConfig.queryParams"
        :bnt-loading="tableConfig.tableLoading"
        :list="searchList"
        @change="handleList()"
        @search="handleList"
      >
        <template #right>
          <el-button
            @click="exportExcel"
            round
            type="primary"
            size="small"
            icon="Download"
          >
            导出
          </el-button>
        </template>
      </SearchForm>
    </div>
    <el-table
      border
      style="width: 100%"
      :header-cell-style="{
        backgroundColor: 'var(--el-color-info-light-9)'
      }"
      :data="tableConfig.dataList"
      v-loading="tableConfig.tableLoading"
      class="flex_col_body"
      stripe
      show-overflow-tooltip
    >
      <el-table-column
        label="登录标识"
        align="center"
        minWidth="150"
        fixed="left"
      >
        <template #default="{ row }">
          <div>{{ row.loginId }}</div>
          <div>
            {{ handleTypeForLabel(row.userType, userTypes) }}
          </div>
        </template>
      </el-table-column>
      <el-table-column
        label="登录信息"
        width="200"
        align="center"
        :show-overflow-tooltip="false"
      >
        <template #default="{ row }">
          <el-popover
            placement="top-start"
            :width="400"
            trigger="hover"
            @show="() => handlePopoverShow(row)"
            :persistent="false"
          >
            <template #reference>
              <el-text type="primary">
                <span>
                  {{ row.userName }}
                </span>
                <span v-if="row.realName">/{{ row.realName }}</span>
              </el-text>
            </template>
            <LoginUserInfoCard :data="popoverData" />
          </el-popover>
          <p>{{ row.userIp }}</p>
        </template>
      </el-table-column>
      <el-table-column
        :label="t('uwAuthCenter.MscLoginESLog.loginType')"
        width="150"
        align="center"
      >
        <template #default="scope">
          <div>{{ handleTypeForLabel(scope.row.loginType, loginTypes) }}</div>
          <div v-if="scope.row.saasId">{{ `saasId:${scope.row.saasId}` }}</div>
        </template>
      </el-table-column>
      <el-table-column
        label="登录代理"
        align="center"
        width="200"
      >
        <template v-slot="{ row }">
          <div v-if="row.loginAgent">{{ row.loginAgent.split('/')[0] }}</div>
          <div v-if="row.loginAgent">{{ row.loginAgent.split('/')[1] }}</div>
        </template>
      </el-table-column>
      <el-table-column
        label="Auth主机信息"
        width="200"
        align="center"
      >
        <template #default="scope">
          <div>{{ scope.row.appInfo }}</div>
          <div>{{ scope.row.appHost }}</div>
        </template>
      </el-table-column>
      <el-table-column
        prop="clientType"
        :label="t('uwAuthCenter.MscLoginESLog.clientType')"
        width="120"
        align="center"
      >
        <template #default="scope">
          <el-tooltip
            effect="dark"
            :content="scope.row.clientAgent ? scope.row.clientAgent : ''"
            :disabled="!scope.row.clientAgent"
            placement="top"
          >
            <el-link
              underline="never"
              :type="scope.row.clientAgent ? 'success' : 'info'"
            >
              {{ handleTypeForLabel(scope.row.clientType, loginDeviceTypes) }}
            </el-link>
          </el-tooltip>
        </template>
      </el-table-column>
      <el-table-column
        :label="t('uwAuthCenter.MscLoginESLog.loginResult')"
        min-width="250"
        align="center"
      >
        <template #default="{ row }">
          <div>
            <el-link
              underline="never"
              :type="row.responseState === 'success' ? 'success' : 'danger'"
            >
              {{ handleTypeForLabel(row.responseState, loginResultTypes) }}
            </el-link>
            <span>{{ `(${row.responseMillis}ms)` }}</span>
          </div>
          <div v-if="row.responseState !== 'success'">
            {{ row.responseMsg }}
          </div>
        </template>
      </el-table-column>
      <el-table-column
        prop="loginDate"
        :label="t('uwAuthCenter.MscLoginESLog.loginDate')"
        width="180"
        align="center"
      >
        <template #default="scope">
          <span>
            {{ formatDate(scope.row.loginDate) }}
          </span>
        </template>
      </el-table-column>
    </el-table>
    <Pagination
      v-model:page-size="tableConfig.queryParams.$rn"
      @page-size-change="handleList(false)"
      :total="tableConfig.sizeAll"
      v-model:current-page="tableConfig.queryParams.$pg"
      @current-change="handleList(false)"
      class="flex_col_bottom"
    />
  </div>
</template>

<style lang="scss" scoped></style>
