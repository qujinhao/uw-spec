<script lang="ts" setup>
import { computed } from 'vue'
import type { GuestAddress } from '@/api/saasMallAppGuestApi'

const props = withDefaults(
  defineProps<{
    addressList: GuestAddress[]
  }>(),
  {}
)

const emits = defineEmits<{
  (e: 'edit', record: GuestAddress): void
  (e: 'delete', id: number): void
  (e: 'select', record: GuestAddress): void
}>()
const handleEdit = (record: GuestAddress) => {
  emits('edit', record)
}
const handleDelete = (id: number) => {
  emits('delete', id)
}

const defaultVal = computed(() => {
  let val = 0
  props.addressList.forEach((item, index) => {
    if (item.isDefault === 1) {
      val = index
    }
  })
  return val
})
const handleChange = (record: GuestAddress) => {
  emits('select', record)
}
</script>

<template>
  <up-radio-group
    style="background-color: #f7f9f8; padding: 0"
    v-model="defaultVal"
  >
    <view
      class="address_card"
      v-for="(item, index) in addressList"
      :key="index"
    >
      <view class="address_card_title">
        <view class="address_card_title_name">{{ item.guestName }}</view>
        <view class="address_card_title_phone">
          {{ item.guestPhone }}
        </view>
      </view>

      <view class="address_card_content">
        {{ item.guestAddress }}
      </view>
      <view class="flex mt10">
        <view class="address_card_title_default">
          <up-radio
            label="默认地址"
            :name="index"
            size="16"
            labelSize="14"
            activeColor="#f58c1c"
            @change="handleChange(item)"
          ></up-radio>
        </view>
        <view class="address_card_title_operate flex">
          <view
            class="address_card_title_edit"
            @click="handleEdit(item)"
          >
            <i class="iconfont icon-bianji"></i>
            编辑
          </view>
          <view
            v-if="item.id"
            class="address_card_title_delete"
            @click="handleDelete(item.id)"
          >
            <i class="iconfont icon-shanchu"></i>
            删除
          </view>
        </view>
      </view>
    </view>
  </up-radio-group>
</template>

<style lang="scss" scoped>
.address {
  background-color: #f7f9f8;
}
.address_card {
  width: 100%;
  // height: 160rpx;
  background-color: #fff;
  padding: 20rpx 40rpx;
  border-radius: 20rpx;

  .address_card_title {
    display: flex;
    margin-bottom: 8rpx;
    .address_card_title_name {
      font-weight: 700;
      width: 28%;
    }
    .address_card_title_phone {
      width: 72%;
      color: #666;
    }
  }
  .address_card_content {
    color: #666;
    font-size: 26rpx;
  }
  .address_card_title_default {
    width: 60%;
  }
  .address_card_title_operate {
    width: 40%;
    color: #666;
    font-size: 26rpx;

    .address_card_title_edit {
      width: 50%;
    }
    .address_card_title_delete {
      width: 50%;
    }
  }
}
</style>
