<script lang="ts" setup>
// 产品列表
import { computed, type CSSProperties } from 'vue'
import { formatDate } from '../utils/tool'
// import { cmpStyle, unit } from '../utils/registerBaseStyle'
import { unit } from '../utils/registerBaseStyle'
import type { Styles, Attrs } from './type'

const props = withDefaults(
  defineProps<{
    attrs?: Partial<Attrs>
    styles?: Partial<Styles>
    lists?: any
  }>(),
  {
    attrs: () => ({}),
    styles: () => ({})
  }
)

// 合并后的属性，包含默认值
const mergedAttrs = computed(() => ({
  typeStyle: 'rush', // 类型样式 rush抢购 rush-min抢购卡片 reserve预订 info资讯 info-default资讯2 card卡片 card-min小卡片
  typeUi: 'B2C', // UI类别
  lists: [
    {
      img: 'http://qnimg.zowoyoo.com/img/84826/1724411102629.jpg', // 产品背景图
      currentTime: 1754561412854, // 当前时间戳
      orderStartDate: 1754582400000, // 抢购开始时间戳
      orderEndDate: 1754668800000, // 抢购结束时间戳
      areaName: '北京', // 区域名称
      title: '抢购标题', // 抢购标题
      insuranceId: '保险', // 保险
      insuranceTitle: '保险', // 保险
      themes: [{ themeName: '实惠', themeId: '123456' }], // 主题数组
      salePrice: 100, // 零售价
      minSalePrice: 100, // 最小零售价
      price: 100, // 分销价
      marketPrice: 100, // 市场价
      brokerage: 100, // 佣金
      progressBar: 30, // 进度条百分比
      createDate: 1754323200000, // 活动创建时间
      treeName: '门票' // 类目名称
    },
    {
      img: 'http://qnimg.zowoyoo.com/img/84826/1724411102629.jpg', // 产品背景图
      currentTime: 1754561412854, // 当前时间戳
      orderStartDate: 1754582400000, // 抢购开始时间戳
      orderEndDate: 1754668800000, // 抢购结束时间戳
      areaName: '北京', // 区域名称
      title: '抢购标题', // 抢购标题
      insuranceId: '保险', // 保险
      insuranceTitle: '保险', // 保险
      themes: [{ themeName: '实惠', themeId: '123456' }], // 主题数组
      salePrice: 100, // 零售价
      minSalePrice: 100, // 最小零售价
      price: 100, // 分销价
      marketPrice: 100, // 市场价
      brokerage: 100, // 佣金
      progressBar: 30, // 进度条百分比
      createDate: 1754323200000, // 活动创建时间
      treeName: '门票' // 类目名称
    }
  ],
  ...props.attrs
}))

// 合并后的样式，包含默认值
const mergedStyles = computed(() => ({
  cmpUpperPadding: 10, // 列表整体上边距
  cmpLowerPadding: 10, // 列表整体下边距
  cmpBackground: '', // 列表整体背景色
  radius: 10, // item容器圆角
  backgroundColor: '#fff', // item容器背景色
  salePriceSize: 16, // 价格字体大小
  regionPosition: 'bottom-left', // 定位位置
  unitSize: 10, // 价格单位大小
  titleSize: 16, // 标题字体大小
  titleColor: '#222222', // 标题颜色
  progressColor: '#D2843E', // 进度条标题色
  progressBorderColor: 'rgba(0,0,0,0)', // 进度条边线色
  progressBackgroundColor: '#FFF4EC', // 进度条背景色
  progressStyle: '#F9D1AD', // 进度条色
  salePriceColor: '#fb6046', // 价格颜色
  width:
    mergedAttrs.value.typeStyle === 'card-min' ||
    mergedAttrs.value.typeStyle === 'rush-min'
      ? 168
      : 345, // 宽度
  imgWidth: getImgWidth(), // 图片宽度
  // imgWidth: 300, // 图片宽度
  imgHeight: getImgHeight(), // 图片高度
  // imgHeight: 200, // 图片高度
  titleRow: 1, // 标题行数
  countDownType: 'short', // 倒计时类型
  countDownPosition: 'top-left', // 倒计时位置
  countDownBackground: 'rgba(0,0,0,0.8)', // 倒计时背景色
  countDownRadius: 10, // 倒计时圆角
  countDownFontSize: 12, // 倒计时字体大小
  countDownColor: '#ffffff', // 倒计时颜色
  regionFontSize: 12, // 区域字体大小
  regionFontColor: '#ffffff', // 区域字体颜色
  regionBackground: 'rgba(0, 0, 0, 0.7)', // 区域背景色
  titleWeight: 'bold', // 标题字体粗细
  priceDesShow: true, // 是否显示价格描述
  priceDes: '起', // 价格描述
  priceDesSize: 12, // 价格描述字体大小
  marketPriceShow: true, // 是否显示市场价
  marketPriceSize: 10, // 市场价字体大小
  marketPriceColor: '#bbbbbb', // 市场价颜色
  marketPriceWeight: 500, // 市场价字体粗细
  marketPriceLine: true, // 市场价是否有删除线
  showProgressTitle: true, // 是否显示进度条标题
  progressWidth: '', // 进度条宽度
  progressHeight: mergedAttrs.value.typeStyle === 'rush' ? 4 : 12, // 进度条高度
  progressFontSize: 12, // 进度条字体大小
  tagFontSize: [12, 12], // 标签字体大小
  tagColor: ['#eff6ff', '#fff2f0'], // 标签颜色
  tagTextColor: ['#78b1f6', '#fb6046'], // 标签文字颜色
  dateSize: 12, // 日期字体大小
  dateColor: '#999', // 日期颜色
  dateTagPositio: '', // 日期标签位置
  pricePosition: 'left', // 价格位置
  ...props.styles
}))

// 计算背景图宽度
const getImgWidth = () => {
  const typeWidthMap = {
    'rush-min': '100%',
    'card-min': '100%',
    card: '100%',
    rush: '100%',
    reserve: 110,
    info: 120,
    'info-default': 120
  }
  return typeWidthMap[mergedAttrs.value.typeStyle as keyof typeof typeWidthMap]
}

// 计算背景图高度
const getImgHeight = () => {
  const typeHeightMap = {
    'rush-min': 130,
    'card-min': 167,
    card: 193,
    rush: 208,
    reserve: 110,
    info: 92,
    'info-default': 92
  }
  return typeHeightMap[
    mergedAttrs.value.typeStyle as keyof typeof typeHeightMap
  ]
}

// 计算价格位置
const pricePosition = computed(() => {
  if (mergedStyles.value.pricePosition) return mergedStyles.value.pricePosition
  let position = ''
  switch (mergedAttrs.value.typeStyle) {
    case 'rush': {
      position = 'left'
      break
    }
    case 'card-min': {
      position = 'left'
      break
    }
    case 'card': {
      position = 'left'
      break
    }
    case 'rush-min': {
      position = 'top'
      break
    }
    case 'reserve': {
      position = 'left'
      break
    }
    default: {
      break
    }
  }
  return position
})

// 枚举位置
const enumPosition = {
  left: 'row' as const,
  right: 'row-reverse' as const,
  top: 'column' as const,
  bottom: 'column-reverse' as const
}
// 整体列表样式
const listStyle = computed(() => {
  return {
    paddingTop: unit(mergedStyles.value.cmpUpperPadding),
    paddingBottom: unit(mergedStyles.value.cmpLowerPadding),
    backgroundColor: mergedStyles.value.cmpBackground
  }
})
// 单个盒子样式
const boxStyle = computed(() => ({
  width: unit(mergedStyles.value.width),
  borderRadius: unit(mergedStyles.value.radius),
  backgroundColor: mergedStyles.value.backgroundColor
}))

// 图片样式
const imgStyle = computed(() => ({
  width:
    typeof mergedStyles.value.imgWidth === 'string'
      ? mergedStyles.value.imgWidth
      : unit(mergedStyles.value.imgWidth),
  height: unit(mergedStyles.value.imgHeight)
}))

// 倒计时样式
const countDownStyle = computed(() => {
  const styleObj: {
    position: 'absolute' | 'relative' | 'fixed' | 'sticky' | 'static' // 明确指定 position 类型
    width: string
    background: string
    fontSize: string
    color: string
    borderRadius: string
    top: string
    left: string
    right: string
    bottom: string
  } = {
    position: 'absolute',
    width: mergedStyles.value.countDownType === 'short' ? 'auto' : '100%',
    background: mergedStyles.value.countDownBackground,
    fontSize: unit(mergedStyles.value.countDownFontSize),
    color: mergedStyles.value.countDownColor,
    borderRadius: '',
    top: '',
    left: '',
    right: '',
    bottom: ''
  }

  // 判断倒计时长短类型
  if (mergedStyles.value.countDownType === 'short') {
    if (mergedStyles.value.countDownPosition === 'top-left') {
      styleObj.borderRadius = `${unit(
        mergedStyles.value.countDownRadius
      )} 0 ${unit(mergedStyles.value.countDownRadius)} 0`
    }
    if (mergedStyles.value.countDownPosition === 'top-right') {
      styleObj.borderRadius = `0 ${unit(
        mergedStyles.value.countDownRadius
      )} 0 ${unit(mergedStyles.value.countDownRadius)}`
    }
    if (mergedStyles.value.countDownPosition === 'bottom-left') {
      styleObj.borderRadius = `0 ${unit(mergedStyles.value.countDownRadius)} 0 0`
    }
    if (mergedStyles.value.countDownPosition === 'bottom-right') {
      styleObj.borderRadius = `${unit(mergedStyles.value.countDownRadius)} 0 0 0`
    }
  } else {
    if (mergedStyles.value.countDownPosition.includes('top')) {
      styleObj.borderRadius = `0 0 ${unit(
        mergedStyles.value.countDownRadius
      )} ${unit(mergedStyles.value.countDownRadius)}`
    }
    if (mergedStyles.value.countDownPosition.includes('bottom')) {
      styleObj.borderRadius = `${unit(
        mergedStyles.value.countDownRadius
      )} ${unit(mergedStyles.value.countDownRadius)} 0 0`
    }
  }

  // 倒计时位置
  if (mergedStyles.value.countDownPosition === 'top-left') {
    styleObj.top = '0'
    styleObj.left = '0'
  }
  if (mergedStyles.value.countDownPosition === 'top-right') {
    styleObj.top = '0'
    styleObj.right = '0'
  }
  if (mergedStyles.value.countDownPosition === 'bottom-left') {
    styleObj.bottom = '0'
    styleObj.left = '0'
  }
  if (mergedStyles.value.countDownPosition === 'bottom-right') {
    styleObj.bottom = '0'
    styleObj.right = '0'
  }
  return styleObj
})

// 区域样式
const regionStyle = computed(() => {
  let topNum = 10
  let bottomNum = 10
  let leftNum = 10
  const rightNum = 10
  const styleObj: {
    position: 'absolute' | 'relative' | 'fixed' | 'sticky' | 'static'
    fontSize: string
    color: string
    backgroundColor: string
    top: string
    bottom: string
    left: string
    right: string
  } = {
    position: 'absolute',
    fontSize: unit(mergedStyles.value.regionFontSize),
    color: mergedStyles.value.regionFontColor,
    backgroundColor: mergedStyles.value.regionBackground,
    top: '',
    bottom: '',
    left: '',
    right: ''
  }

  if (
    mergedAttrs.value.typeStyle !== 'rush' &&
    mergedAttrs.value.typeStyle !== 'rush-min'
  ) {
    if (mergedStyles.value.regionPosition.includes('top')) {
      styleObj.top = unit(10)
    }
    if (mergedStyles.value.regionPosition.includes('bottom')) {
      styleObj.bottom = unit(10)
    }
    if (mergedStyles.value.regionPosition.includes('left')) {
      styleObj.left = unit(10)
    }
    if (mergedStyles.value.regionPosition.includes('right')) {
      styleObj.right = unit(10)
    }
  } else if (
    mergedStyles.value.countDownType === 'long' ||
    mergedAttrs.value.typeStyle === 'rush-min'
  ) {
    // 如果倒计时是长条的
    if (mergedStyles.value.countDownPosition.includes('top')) {
      topNum = 30
    } else {
      bottomNum = 30
    }
    if (mergedStyles.value.regionPosition.includes('top')) {
      styleObj.top = unit(topNum)
    }
    if (mergedStyles.value.regionPosition.includes('bottom')) {
      styleObj.bottom = unit(bottomNum)
    }
    if (mergedStyles.value.regionPosition.includes('left')) {
      styleObj.left = unit(leftNum)
    }
    if (mergedStyles.value.regionPosition.includes('right')) {
      styleObj.right = unit(rightNum)
    }
  } else {
    // 处理倒计时和区域位置重叠的情况
    if (
      mergedStyles.value.countDownPosition === 'top-left' &&
      mergedStyles.value.regionPosition === 'top-left'
    ) {
      topNum = 30
    }
    if (
      mergedStyles.value.countDownPosition === 'top-right' &&
      mergedStyles.value.regionPosition === 'top-right'
    ) {
      topNum = 30
    }
    if (
      mergedStyles.value.countDownPosition === 'bottom-right' &&
      mergedStyles.value.regionPosition === 'bottom-right'
    ) {
      bottomNum = 30
    }
    if (
      mergedStyles.value.countDownPosition === 'bottom-left' &&
      mergedStyles.value.regionPosition === 'bottom-left'
    ) {
      bottomNum = 30
    }
    if (mergedStyles.value.countDownPosition === 'top-right') {
      topNum = 30
      leftNum = 10
    }

    if (mergedStyles.value.regionPosition.includes('top')) {
      styleObj.top = unit(topNum)
    }
    if (mergedStyles.value.regionPosition.includes('bottom')) {
      styleObj.bottom = unit(bottomNum)
    }
    if (mergedStyles.value.regionPosition.includes('left')) {
      styleObj.left = unit(leftNum)
    }
    if (mergedStyles.value.regionPosition.includes('right')) {
      styleObj.right = unit(rightNum)
    }
  }

  return styleObj
})

// 标题样式
const titleStyle = computed(() => ({
  color: mergedStyles.value.titleColor,
  fontSize: unit(mergedStyles.value.titleSize),
  fontWeight: mergedStyles.value.titleWeight,
  height: unit(mergedStyles.value.titleRow * 22),
  display: '-webkit-box',
  '-webkit-box-orient': 'vertical',
  '-webkit-line-clamp': mergedStyles.value.titleRow,
  overflow: 'hidden'
}))

// 进度条宽度样式
const progressWidthStyle = computed(() => {
  if (
    typeof mergedStyles.value.progressWidth === 'number' &&
    mergedStyles.value.progressWidth
  )
    return mergedStyles.value.progressWidth + 'px'
  if (
    typeof mergedStyles.value.progressWidth === 'string' &&
    mergedStyles.value.progressWidth
  )
    return mergedStyles.value.progressWidth
  if (mergedAttrs.value.typeStyle === 'rush') {
    return '110px'
  }
  return '90%'
})

// 产品信息样式
const prodInfoStyle = computed<{
  flexDirection: CSSProperties['flexDirection']
}>(() => {
  const styleObj: {
    flexDirection: CSSProperties['flexDirection']
  } = {
    flexDirection: 'row'
  }
  if (
    mergedAttrs.value.typeStyle === 'rush' &&
    (pricePosition.value === 'left' || pricePosition.value === 'right')
  ) {
    styleObj.flexDirection = enumPosition[pricePosition.value]
  }

  if (
    mergedAttrs.value.typeStyle === 'card' &&
    (pricePosition.value === 'left' || pricePosition.value === 'right')
  ) {
    const position = pricePosition.value === 'left' ? 'right' : 'left'
    styleObj.flexDirection = enumPosition[position]
  }

  if (
    mergedAttrs.value.typeStyle === 'rush-min' &&
    (pricePosition.value === 'top' || pricePosition.value === 'bottom')
  ) {
    styleObj.flexDirection = enumPosition[pricePosition.value]
  }
  return styleObj
})

// 产品信息价格样式
const prodInfoMoneyStyle = computed(() => {
  const styleObj: {
    justifyContent: string
    flexDirection: CSSProperties['flexDirection'] // 明确指定类型
  } = {
    justifyContent: '',
    flexDirection: 'row'
  }
  if (
    (mergedAttrs.value.typeStyle === 'rush' ||
      mergedAttrs.value.typeStyle === 'card') &&
    pricePosition.value === 'right'
  ) {
    styleObj.justifyContent = 'flex-end'
  }
  if (
    mergedAttrs.value.typeStyle === 'card-min' &&
    (pricePosition.value === 'right' || pricePosition.value === 'left')
  ) {
    styleObj.flexDirection = enumPosition[pricePosition.value]
  }
  if (
    (mergedAttrs.value.typeStyle === 'rush' ||
      mergedAttrs.value.typeStyle === 'card') &&
    pricePosition.value === 'right'
  ) {
    styleObj.justifyContent = 'flex-end'
  }
  if (
    mergedAttrs.value.typeStyle === 'reserve' &&
    (pricePosition.value === 'right' || pricePosition.value === 'left')
  ) {
    styleObj.flexDirection = enumPosition[pricePosition.value]
  }
  return styleObj
})

// 进度条样式
const progressStype = computed(() => ({
  color: mergedStyles.value.progressColor, // 字体颜色
  borderColor: mergedStyles.value.progressBorderColor, // 边框颜色
  backgroundColor: mergedStyles.value.progressBackgroundColor, // 背景颜色
  progressStyle: mergedStyles.value.progressStyle,
  fontSize: mergedStyles.value.progressFontSize // 字体大小
}))
const progressAttrs = (item: any) => {
  return {
    percentage: item.progressBar,
    type: 1,
    showTitle: mergedStyles.value.showProgressTitle,
    height: mergedStyles.value.progressHeight
  }
}
// 信息创建日期类型样式
const infoCreateDateType = computed<{
  flexDirection: CSSProperties['flexDirection']
}>(() => {
  const Enum = {
    left: 'row',
    right: 'row-reverse'
  } as const

  if (mergedStyles.value.dateTagPositio) {
    return {
      flexDirection:
        Enum[mergedStyles.value.dateTagPositio as keyof typeof Enum]
    }
  }
  if (mergedAttrs.value.typeStyle === 'info') {
    return {
      flexDirection: 'row'
    }
  }
  return {
    flexDirection: 'row-reverse'
  }
})

// 倒计时组件样式
const countDownStyles = computed(() => ({
  backgroundColor: '',
  containerRadius: 0,
  location: 'left',
  model: 'one',
  paddingBottom: 0,
  paddingLeft: 0,
  paddingRight: 0,
  paddingTop: 0,
  timeColor: '',
  isTitle: false
}))

const emit = defineEmits<{
  jump: [item: object]
}>()

// 获取倒计时数据
const getCountDownData = (
  startTime: number,
  endTime: number,
  currentTime: number
) => {
  return {
    attrs: {
      text: '活动',
      startTime: startTime,
      endTime: endTime,
      currentTime: currentTime
    }
  }
}

// 是否显示倒计时
const showCountDown = (item: any) => {
  // 当前时间大于结束时间 那么就是抢购结束了 不显示倒计时了
  if (item.currentTime - item.orderEndDate > 0) return false
  // 产品开售开始时间 减去 当前服务器时间 大于 3天 不显示倒计时
  if (item.orderStartDate - item.currentTime >= 259200000) return false
  // 产品售卖结束时间  减去 当前服务器时间  大于 3天 不显示倒计时 并且 服务器当前时间要大于产品开售时间
  if (
    item.orderEndDate - item.currentTime >= 259200000 &&
    item.currentTime > item.orderStartDate
  )
    return false

  return true
}

// 计算倒计时时间
const times = (item: any) => {
  const obj = {
    time: 0,
    title: ''
  }
  // 服务器时间大于产品开售时间
  if (item.currentTime > item.orderStartDate) {
    if (item.currentTime > item.orderEndDate) {
      obj.time = 0
      obj.title = '抢购已结束'
    } else {
      obj.time = item.orderEndDate - item.currentTime
      obj.title = '距结束'
    }
  } else {
    obj.time = item.orderStartDate - item.currentTime
    obj.title = '距开始'
  }
  return obj
}

// 点击事件
const handleClick = (item: any) => {
  emit('jump', item)
}

// 获取包裹样式
// const getWrapStyle = () => {
//   return {
//     ...cmpStyle(mergedStyles.value)
//   }
// }
</script>

<template>
  <view
    :class="
      mergedAttrs.typeStyle === 'card-min' ||
      mergedAttrs.typeStyle === 'rush-min'
        ? 'z-product-list around'
        : 'z-product-list'
    "
    :style="listStyle"
  >
    <view
      :class="`z-product-list-box ` + mergedAttrs.typeStyle"
      :style="boxStyle"
      v-for="(item, index) in mergedAttrs.lists"
      :key="index"
      @click.stop="handleClick(item)"
    >
      <!-- 产品图 背景 -->
      <view
        class="z-product-img"
        :style="[imgStyle, { backgroundImage: `url(${item.img})` }]"
      >
        <!-- 抢购 倒计时 -->
        <view
          v-if="
            mergedAttrs.typeStyle === 'rush' ||
            mergedAttrs.typeStyle === 'rush-min'
          "
        >
          <view
            class="count-down"
            v-if="item.currentTime > 0 && showCountDown(item)"
            :style="countDownStyle"
          >
            <u-icon
              name="hourglass-half-fill"
              color="#fb6046"
              size="16"
            ></u-icon>
            <view
              v-if="times(item).time === 0"
              class="item"
            >
              <text class="time-title">
                {{ times(item).title }}
              </text>
            </view>
            <view
              v-else
              class="item"
            >
              <text class="time-title">
                {{ times(item).title }}
              </text>
              <view class="flex-align">
                <m-count-down
                  :styles="countDownStyles"
                  :attrs="
                    getCountDownData(
                      item.orderStartDate,
                      item.orderEndDate,
                      item.currentTime
                    ).attrs
                  "
                ></m-count-down>
              </view>
            </view>
          </view>
        </view>
        <!-- 区域标签 -->
        <view
          class="z-product-region"
          :style="regionStyle"
          v-if="
            mergedAttrs.typeStyle !== 'card-min' &&
            mergedAttrs.typeStyle !== 'info' &&
            mergedAttrs.typeStyle !== 'info-default'
          "
        >
          <u-icon
            name="map-fill"
            color="#fff"
            size="12"
          ></u-icon>
          {{ item.areaName }}
        </view>
      </view>
      <view class="z-product-main">
        <!-- 抢购 标题 -->
        <p
          class="z-product-title"
          :style="titleStyle"
        >
          {{ item.title }}
        </p>
        <!-- 抢购 市场价格 分销价格 零食价格 佣金 -->
        <view
          class="z-product-info"
          :style="prodInfoStyle"
        >
          <view
            class="z-product-tags flex-align-start"
            v-if="mergedAttrs.typeStyle === 'reserve' && item.areaName"
          >
            <!-- 保险 -->
            <view
              class="z-product-insurance"
              v-if="item.insuranceId"
            >
              <i class="z-product-insurance-icon"></i>
              {{ item.insuranceTitle }}
            </view>
          </view>
          <view
            class="z-product-themes"
            v-if="item.themes && item.themes.length > 0"
          >
            <!-- 蓝色标签 -->
            <view
              v-if="
                item.themes &&
                item.themes.length > 0 &&
                mergedAttrs.typeStyle != 'rush' &&
                mergedAttrs.typeStyle != 'rush-min' &&
                mergedAttrs.typeStyle != 'card-min'
              "
            >
              <view
                class="tags-list tag"
                v-for="(e, i) in item.themes.slice(0, 3)"
                :key="i"
                :style="{
                  backgroundColor: e.color || mergedStyles.tagColor[0],
                  color: e.color || mergedStyles.tagTextColor[0]
                }"
              >
                <text
                  class="ellipsis"
                  :style="{
                    fontSize: unit(mergedStyles.tagFontSize[0] || 12)
                  }"
                >
                  {{ e.themeName }}
                </text>
              </view>
              <br />
            </view>
          </view>

          <view
            class="z-product-info-money"
            :style="prodInfoMoneyStyle"
          >
            <!-- 零售价 -->
            <text
              class="salePrice"
              v-if="
                item.salePrice ||
                item.minSalePrice ||
                [0, 12].includes(item.treeId!)
              "
              :style="{
                color: mergedStyles.salePriceColor
              }"
            >
              <text
                :style="{
                  fontSize: unit(mergedStyles.unitSize)
                }"
              >
                ￥
              </text>
              <text
                class="u"
                :style="{
                  fontSize: unit(mergedStyles.salePriceSize)
                }"
              >
                {{
                  [0, 12].includes(item.treeId!)
                    ? item.salePrice
                    : item.salePrice || item.minSalePrice
                }}
              </text>
              <text
                v-if="mergedStyles.priceDesShow"
                :style="{
                  fontSize: unit(mergedStyles.priceDesSize)
                }"
              >
                {{ mergedStyles.priceDes }}
              </text>
            </text>
            <view
              class="price-box"
              v-if="!['info', 'info-default'].includes(mergedAttrs.typeStyle!)"
            >
              <!-- 分销价 -->
              <text
                class="price"
                v-if="item.price && mergedAttrs.typeUi === 'B2B'"
              >
                <text class="currency">
                  <text>￥</text>
                </text>
                <text class="p">{{ item.price }}</text>
              </text>
              <!-- 佣金 -->
              <text
                class="brokerage"
                v-if="item.brokerage && mergedAttrs.typeUi === 'B2B'"
              >
                <text class="brokerage_i">佣金{{ item.brokerage }}</text>
              </text>
            </view>
            <!-- 游客端 市场价 -->
            <text
              v-if="
                item.marketPrice &&
                mergedAttrs.typeUi === 'B2C' &&
                mergedStyles.marketPriceShow
              "
              class="marketPrice"
              :style="{
                fontSize: unit(mergedStyles.marketPriceSize),
                color: mergedStyles.marketPriceColor,
                fontWeight: mergedStyles.marketPriceWeight,
                textDecoration: mergedStyles.marketPriceLine
                  ? 'line-through'
                  : 'none'
              }"
            >
              市场价￥{{ item.marketPrice }}
            </text>
          </view>
          <!-- 进度条  -->
          <view
            :class="{
              'z-product-info-progress': true,
              'z-product-info-progress-rush': mergedAttrs.typeStyle === 'rush',
              'progress-rush-min': mergedAttrs.typeStyle === 'rush-min'
            }"
            :style="{
              width: progressWidthStyle
            }"
            v-if="
              item.progressBar &&
              (mergedAttrs.typeStyle === 'rush' ||
                mergedAttrs.typeStyle === 'rush-min')
            "
          >
            <m-progress
              :attrs="progressAttrs(item)"
              :styles="progressStype"
            />
          </view>
          <!-- 进度条不显示时，显示抢购新品标签  -->
          <view
            :class="{
              'z-product-info-progress': true,
              'z-product-info-progress-rush':
                (mergedAttrs.typeStyle as string) === 'rush'
            }"
            :style="{
              width: progressWidthStyle
            }"
            v-else-if="
              !item.progressBar && mergedAttrs.typeStyle === 'rush-min'
            "
          >
            <m-progress
              :attrs="progressAttrs(item)"
              :styles="progressStype"
            />
          </view>
        </view>
        <!-- 活动创建时间 -->
        <view
          v-if="
            mergedAttrs.typeStyle === 'info' ||
            mergedAttrs.typeStyle === 'info-default'
          "
          class="info-createDate"
          :style="infoCreateDateType"
        >
          <text
            v-if="item.createDate"
            :style="{
              fontSize: unit(mergedStyles.dateSize),
              color: mergedStyles.dateColor
            }"
          >
            {{ item.createDate && formatDate(item.createDate, 'Y-M-D') }}
          </text>
          <p
            class="tags"
            v-if="item.treeName"
          >
            <view
              class="tags-list tag"
              :style="{
                backgroundColor: mergedStyles.tagColor[0],
                color: mergedStyles.tagTextColor[0]
              }"
            >
              <text
                class="ellipsis"
                :style="{
                  fontSize: unit(mergedStyles.tagFontSize[0] || 12)
                }"
              >
                {{ item.treeName }}
              </text>
            </view>
          </p>
        </view>
      </view>
    </view>
  </view>
</template>

<style lang="scss" scoped>
@import './style/index.scss';
</style>
