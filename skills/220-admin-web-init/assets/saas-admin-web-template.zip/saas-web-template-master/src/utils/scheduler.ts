// 2. 调度器类
export default class requestScheduler {
  private queue: (() => Promise<void>)[] = []
  private isProcessing = false // 队列是否正在处理
  private sleepTime = 100 // 等待100ms
  private callback?: () => void // 执行完成后的回调

  constructor(callback?: () => void) {
    if (callback) {
      this.callback = callback
    }
  }

  // 添加任务到队列（原子操作）
  addTask(task: () => Promise<void>) {
    this.queue.push(task)
    if (!this.isProcessing) this.processQueue()
  }

  // 处理队列（动态调度）
  private async processQueue() {
    this.isProcessing = true
    while (this.queue.length > 0) {
      const task = this.queue.shift()!
      try {
        // 每次请求等待一定秒数后请求
        // eslint-disable-next-line no-await-in-loop
        await this.sleep(this.sleepTime)
        // eslint-disable-next-line no-await-in-loop
        await task() // 串行执行
      } catch (err) {
        console.error(`[Error] ${err}`) // 错误隔离
      }
    }
    // 存在回调，执行完成后就执行回调
    if (this.callback) {
      this.callback()
    }
    this.isProcessing = false
  }

  // 暂停执行指定毫秒数的时间
  sleep = (ms: number) => {
    return new Promise(resolve => {
      const timer = setTimeout(() => {
        resolve(null)
        clearTimeout(timer)
      }, ms)
    })
  }
}
