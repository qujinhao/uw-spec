<template>
  <!--轮播导航 - 未使用 -->
  <view>
    <view
      class="menus-grid"
      v-if="list.length > 0"
      :style="menusStyle"
    >
      <swiper
        v-if="filterMenus.length"
        class="menus-swiper"
        circular
        :indicator-dots="listData.length > 1"
        :interval="4000"
        indicator-color="rgba(0, 0, 0, 0.4)"
        indicator-active-color="#000"
      >
        <swiper-item
          class="menus-box"
          :class="{ 'noflex-menus-box': list.length > attrs.rowNumber }"
          v-for="(items, index) in listData"
          :key="index"
        >
          <view
            class="menus-list"
            v-for="item in items"
            :key="item[listField.name]"
            :style="menusWidth"
            @click.stop="handleClick(item)"
          >
            <img
              :src="item[listField.logo]"
              lazy-load
              mode="aspectFit"
            />
            <!-- <image
              :src="item[listField.logo]"
              mode="aspectFit"
            /> -->
            <text>
              {{ item[listField.name] }}
            </text>
          </view>
        </swiper-item>
      </swiper>
    </view>
  </view>
</template>
<script lang="ts" setup>
import { computed } from 'vue'
import type { PropsType } from './type'

const props = withDefaults(defineProps<PropsType>(), {
  attrs: () => ({
    rowNumber: 5, // 行数量
    colNumber: 2, // 列数量
    menusConfg: [] // 菜单配置数据
  }),
  styles: () => ({
    RLpadding: 32, //	左右边距
    height: 160, //	高度
    backgroundColor: '' //	背景颜色
  }),
  listField: () => ({
    logo: 'menuLogo', // 图片
    name: 'menuName' //	名称
  })
})
const emit = defineEmits(['jump'])

const RLpadding = computed(() => {
  return props.styles.RLpadding || 32
})
const rowNumber = computed(() => {
  return props.attrs.rowNumber || 5
})
const colNumber = computed(() => {
  return props.attrs.colNumber || 2
})
const menusConfg = computed(() => {
  return props.attrs.menusConfg || []
})
const menusWidth = computed(() => {
  const w = 100 / rowNumber.value
  const css = `width: ${w}%`
  return css
})

const filterMenus = computed(() => {
  const arr: any = []
  props.list.forEach((item) => {
    const path = item.menuLink
    // debugger 过滤掉了非本地的路径
    if (menusConfg.value.length > 0) {
      for (let i = 0; i < menusConfg.value.length; i++) {
        const element = menusConfg.value[i]

        if (path.includes(element)) {
          // 菜单栏 运营商后台小程序是可以单独设置的 菜单栏里面所有的外链都不放出来
          arr.push(item)
          break
        }
      }
    }
  })
  return menusConfg.value.length > 0 ? arr : props.list
})

const listData = computed(() => {
  const arrAll = []
  const number = rowNumber.value * colNumber.value
  const num = Math.ceil(filterMenus.value.length / number)
  for (let i = 0; i < num; i++) {
    const item = filterMenus.value.slice(i * number, i * number + number)
    arrAll.push(item)
  }
  return arrAll
})

const menusStyle = computed(() => {
  let style = ''
  style = `height: ${props.styles.height * colNumber.value}rpx;margin: 0 ${
    RLpadding.value
  }rpx;backgroundColor: ${props.styles.backgroundColor};`

  return style
})
function handleClick(item: any) {
  emit('jump', item)
}
</script>

<style lang="scss" scoped>
.menus-grid {
  &.mrl10 {
    margin: 0 10rpx !important;
  }

  .menus-swiper {
    height: 100% !important;

    .menus-box {
      display: flex;
      flex-wrap: wrap;
      justify-content: space-between;

      .menus-list {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: flex-start;
        // width: 20%;
        height: 136rpx;
        margin: 10rpx 0;

        image {
          width: 90rpx;
          height: 90rpx;
        }

        text {
          padding-top: 10rpx;
          font-size: 24rpx;
        }
      }
    }

    .noflex-menus-box {
      justify-content: unset;
    }

    // .swiper-image {
    // }
  }
}
</style>
