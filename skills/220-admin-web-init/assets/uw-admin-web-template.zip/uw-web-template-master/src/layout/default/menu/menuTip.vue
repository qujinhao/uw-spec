<script lang="ts" setup>
import type { MENU_ITEM } from './type'
import MenuTip from './menuTip.vue'

import { ArrowDownBold } from '@element-plus/icons-vue'

interface Porps {
  list: MENU_ITEM[]
  route?: string
  activeId?: number | string // 激活的ID
}
type EMITS = (e: 'click', item: MENU_ITEM) => void
const props = withDefaults(defineProps<Porps>(), {})

const emits = defineEmits<EMITS>()

const router = useRouter()
const active = ref<number | string>()
const showChild = ref(false)

const activeItem = computed(() => {
  if (!props.activeId) return active.value
  return props.activeId
})

const clickMenuItem = (item: MENU_ITEM) => {
  if (item.list) {
    showChild.value = !showChild.value
  } else {
    active.value = item.route
    if (item.route) router.push(item.route)
    emits('click', item)
  }
}

const clickMeunChild = (item: MENU_ITEM) => {
  active.value = item.route
  emits('click', item)
}
</script>

<template>
  <div
    class="menu-tip"
    v-for="(item, index) in props.list"
    :key="index"
  >
    <div
      class="menu-tip__title flex-align"
      :class="{
        'menu-tip__active': item.route === activeItem && !item.list
      }"
      @click="clickMenuItem(item)"
    >
      <span>{{ $t(item.route) }}</span>
      <template v-if="item.list">
        <el-icon
          :class="{
            'menu-tip__icon': true,
            'menu-tip__collapse': showChild
          }"
        >
          <ArrowDownBold />
        </el-icon>
      </template>
    </div>
    <template v-if="item.list">
      <el-collapse-transition>
        <div
          class="menu-tip__child"
          v-show="showChild"
        >
          <MenuTip
            :list="item.list"
            :active-id="active"
            @click="clickMeunChild"
          />
        </div>
      </el-collapse-transition>
    </template>
  </div>
</template>

<style lang="scss" scoped>
.menu-tip {
  cursor: pointer;
  line-height: 40px;
  box-sizing: border-box;
  .menu-tip__title {
    padding: 0 10px;
    &:hover {
      background-color: $asideBackgroundColorHover;
    }
    &.menu-tip__active {
      background-color: $asideBackgroundColorActive;
    }
    > span {
      padding-right: 10px;
    }
    .menu-tip__icon {
      transition: 0.3s;
    }
    .menu-tip__collapse {
      transform: rotate(-90deg);
    }
  }
  .menu-tip__child {
    padding-left: 10px;
  }
}
</style>
