<script setup lang="ts">
import {
  onLaunch,
  onShow,
  onHide,
  onError,
  onPageNotFound
} from '@dcloudio/uni-app'
import { useMainStore } from '@/store/main'
import { navToUrl } from '@/utils/tool'
import { useUserStore } from '@/store/user'
import dayjs from 'dayjs'
import tz from 'dayjs/plugin/timezone'
import utc from 'dayjs/plugin/utc'
import isBetween from 'dayjs/plugin/isBetween'

dayjs.extend(utc)
dayjs.extend(tz)
dayjs.extend(isBetween)

const mainStore = useMainStore()
const userStore = useUserStore()

// 获取匿名token
// const getAuthGenANYToken = async () => {
//   openGuestAuthGenANYToken({ saasId: defaultSiteInfo.saasId, mchId: 0 }).then(
//     (res) => {
//       if (res.state === 'success' && res.data) {
//         mainStore.setAnonymousToken(res.data) // "0$0!0@8821909"
//       }
//     }
//   )
// }

onLaunch(() => {
  // console.log('App Launch')
  // 获取匿名token
  // getAuthGenANYToken()

  // 获取ossSite域名
  mainStore.handleGetUploadDomain()

  // DEV开发环境 动态加载 vConsole
  // if (mainStore.DEV) {
  //   const script = document.createElement('script')
  //   script.src = 'https://unpkg.com/vconsole@latest/dist/vconsole.min.js'
  //   script.onload = () => {
  //     // 创建 vConsole 实例
  //     // @ts-ignore
  //     new window.VConsole()
  //   }
  //   document.head.appendChild(script)
  // }
  userStore.setAppId()

  uni.getSystemInfo({
    success: function (data) {
      mainStore.setStatusHeight(data.statusBarHeight as number)
    }
  })
  // #ifdef MP-WEIXIN
  // 获取胶囊按钮信息
  const menuButtonInfo = uni.getMenuButtonBoundingClientRect() as unknown as {
    top: number
    left: number
    width: number
    height: number
  }
  mainStore.setMenuButtonInfo(menuButtonInfo)
  // #endif
})
onShow(() => {
  const pages = getCurrentPages()
  const currentPage = pages[pages.length - 1]
  const route = currentPage?.route

  if (route === 'template/template/home') {
    navToUrl('/')
  }
  // console.log('当地时区', dayjs().format('YYYY-MM-DD HH:mm:ss')) // 当地时区
  // console.log(
  //   '指定日本时区',
  //   dayjs().tz('Asia/Tokyo').format('YYYY-MM-DD HH:mm:ss')
  // ) // 东京
})
onHide(() => {
  // console.log('App Hide')
})
onError((err) => {
  console.log('onError --------------------------------')
  console.log(err)
})
onPageNotFound(() => {
  console.log('onPageNotFound --------------------------------')
  // 重定向首页
  uni.reLaunch({
    url: '/'
  })
})
</script>

<style src="./styles/main.css"></style>
<style lang="scss">
@import 'uview-plus/index.scss';
@import '@/styles/index.scss';
@import '@/static/font/iconfont.css';

page {
  width: 100vw;
  min-height: 100%;
}
</style>
