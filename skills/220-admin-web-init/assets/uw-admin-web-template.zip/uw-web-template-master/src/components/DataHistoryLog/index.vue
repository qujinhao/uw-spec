<template>
  <div class="dataHistoryDialog">
    <el-dialog
      v-model="isShow"
      :title="props.id ? `数据详情#${props.id}` : '数据详情'"
      @close="resetForm"
      width="1000px"
      draggable
    >
      <el-descriptions
        :column="1"
        border
      >
        <el-descriptions-item
          v-for="item in showDataForKey"
          :key="item"
        >
          <template #label>
            <div
              class="label"
              :title="item"
            >
              {{ item }}
            </div>
          </template>
          <div v-if="item.includes('Date')">
            {{
              showData[item as string]
                ? dayjs(showData[item as string]).format('YYYY-MM-DD HH:mm:ss')
                : '--'
            }}
          </div>
          <div
            v-else
            class="ellipsis"
            :title="showData[item as string]"
          >
            {{ showData[item as string] }}
          </div>
        </el-descriptions-item>
      </el-descriptions>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { isJSON } from '@/utils/tool'
import dayjs from 'dayjs'

const props = defineProps<{
  show: boolean
  data: string
  id?: number
}>()

const showData = computed(() => {
  if (isJSON(props.data)) {
    return JSON.parse(props.data) as Record<string, any>
  }
  return {}
})

const showDataForKey = computed(() => {
  if (isJSON(props.data)) {
    const res = JSON.parse(props.data) as string[]
    return Object.keys(res)
  }
  return []
})

const emits = defineEmits<{
  (e: 'update:show', val: boolean): void
}>()

// 是否显示
const isShow = computed({
  get() {
    return props.show
  },
  set(val) {
    emits('update:show', val)
  }
})

const resetForm = () => {
  isShow.value = false
}
</script>

<style scoped lang="scss">
.dataHistoryDialog {
  :deep(.el-dialog__body) {
    max-height: 650px;
    overflow: hidden auto;

    .label {
      width: 120px; // 设置元素宽度为父元素宽度的100%
      white-space: nowrap; // 防止文本换行
      overflow: hidden; // 隐藏溢出的文本
      text-overflow: ellipsis; // 显示省略号
    }
    .ellipsis {
      width: 820px; // 设置元素宽度为父元素宽度的100%
      white-space: nowrap; // 防止文本换行
      overflow: hidden; // 隐藏溢出的文本
      text-overflow: ellipsis; // 显示省略号
    }
  }
}
</style>
