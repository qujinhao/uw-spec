// 自动导入当前文件夹的所有文件下多语言包
const enCN = import.meta.glob(['./*', '!./index', '!./type.d.ts'], {
  import: 'default',
  eager: true
})

let i18nEn = {
  ...enCN
}

for (const key in enCN) {
  if (Object.prototype.hasOwnProperty.call(enCN, key)) {
    const item = enCN[key]
    i18nEn = Object.assign(i18nEn, item)
  }
}

export default i18nEn
