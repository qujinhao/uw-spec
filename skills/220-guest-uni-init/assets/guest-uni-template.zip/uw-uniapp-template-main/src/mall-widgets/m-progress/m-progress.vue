<script lang="ts" setup>
// 进度条
import { computed } from 'vue'
import { unit } from '../utils/registerBaseStyle'

const props = defineProps<{
  attrs: {
    type?: number // 类型选择
    showTitle?: boolean // 显示文字标题
    title?: string // 文字标题
    percentage?: number // 进度
    width?: string | number
    height?: number
    flex?: number // 进度条位置
  }
  styles: {
    color?: string // 字体颜色
    fontSize?: number // 字体大小
    borderColor?: string // 边框颜色
    backgroundColor?: string // 背景颜色
    progressStyle?: string
  }
}>()

const mergedAttrs = computed(() => ({
  type: 0,
  showTitle: true,
  title: '',
  percentage: 0,
  width: '100%',
  height: 20,
  flex: 1,
  ...props.attrs
}))

const mergedStyles = computed(() => ({
  color: '#F47F02',
  fontSize: 12,
  borderColor: '#f47f02',
  backgroundColor: '#fff8e7',
  progressStyle:
    '#ffd060;background-image: linear-gradient(-60deg, transparent 0, transparent 10px, #ffdb86 10px, #ffdb86 19px, transparent 19px, transparent 28px, #ffdb86 28px);',
  ...props.styles
}))

const progressTitle = computed(() => {
  if (mergedAttrs.value.title) {
    return mergedAttrs.value.title.replace(
      /{}/,
      String(mergedAttrs.value.percentage)
    )
  }
  return '已抢' + mergedAttrs.value.percentage + '%'
})

const className = computed(() => {
  if (mergedAttrs.value.type === 1) {
    return 'progress-rush'
  }
  return ''
})

const progressHeight = computed(() => {
  if (mergedAttrs.value.height) return mergedAttrs.value.height
  // if (mergedAttrs.value.type === 0) {
  //   return 12
  // }
  return 12
})

const extent = computed(() => {
  if (typeof mergedAttrs.value.width === 'string') {
    return mergedAttrs.value.width
  }
  return mergedAttrs.value.width + '%'
})
</script>

<template>
  <view
    class="progress-box"
    :style="{
      'justify-content': ['left', 'center', 'right'][mergedAttrs.flex]
    }"
  >
    <view
      :class="['z-progress', className]"
      :style="{
        width: extent,
        height: unit(progressHeight)
      }"
    >
      <p
        class="txt"
        :style="{
          color: mergedStyles.color,
          fontSize: unit(mergedStyles.fontSize)
        }"
        v-if="mergedAttrs.showTitle"
      >
        {{ progressTitle }}
      </p>
      <p
        class="width"
        :style="`width: ${mergedAttrs.percentage}%;background-color:${mergedStyles.progressStyle};borderColor:${mergedStyles.borderColor}`"
      ></p>
      <p
        class="bg"
        :style="{
          borderColor: mergedStyles.borderColor,
          backgroundColor: mergedStyles.backgroundColor
        }"
      ></p>
    </view>
  </view>
</template>

<style lang="scss" scoped>
@import './style/index.scss';
.progress-box {
  display: flex;
  width: 100%;
}
</style>
