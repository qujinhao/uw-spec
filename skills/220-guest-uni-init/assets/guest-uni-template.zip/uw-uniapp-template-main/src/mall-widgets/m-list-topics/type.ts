/*
 * @Description:
 * @Date: 2024-06-17 10:21:36
 * @LastEditors: niezihao
 * @LastEditTime: 2024-06-28 10:31:01
 * @Author: niezihao
 */
export interface PropsType {
  // 参数
  attrs: {
    model: string // 模式选择
    type: string // 显示类型
    max: number // 一行显示数量
    overHide: boolean //超出是否隐藏
  }
  // 样式控制
  styles: {
    pagePadding: number //	页面边距
    cmpUpperPadding: number //	上边距
    cmpLowerPadding: number //	下边距
    imgPadding: number //	单项间距
    cmpUpperRadius: number //	上圆角
    cmpLowerRadius: number //	下圆角
    itemWidth: number //	单项宽度
    imgWidth: number //	图片宽度
    imgRadius: number // 图片圆角
    fontSize: number //	文本字体
    titleColor: string //	文本颜色
    cmpBackground: string //	组件背景
  }
  // 字段替换
  listField?: {
    imgKey?: string // 显示的key字段 用来定义list中要显示的那个字段的值
    pathKey?: string // 路径跳转链接
    nameKey?: string
  }
  list: Record<string, string>[]
}

export interface JumpType {
  id?: string
  type?: string
}
