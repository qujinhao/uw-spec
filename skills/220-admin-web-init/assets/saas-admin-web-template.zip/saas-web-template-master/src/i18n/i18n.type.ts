export type Lang_Type = 'zh-CN' | 'zh-TW' | 'en'

export type I18N = 'zh-CN' | 'zh-TW' | 'en' | 'ja' | 'ko'

export const localeEnum = {
  'zh-CN': '简体中文',
  'zh-TW': '繁體中文',
  en: 'English',
  ja: '日本語',
  ko: '한어'
}

export interface LANG_LIST {
  label: string
  value: I18N
}
