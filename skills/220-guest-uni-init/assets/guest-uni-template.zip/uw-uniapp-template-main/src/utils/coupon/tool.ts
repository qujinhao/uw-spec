import { useUserStore } from '@/store/user'
const userStore = useUserStore()

// 获取格式化后的时间
const getDate = (date: any) => {
  if (typeof date === 'string') {
    date = new Date(Number.parseInt(date))
  } else {
    date = new Date(date)
  }
  const year = date.getFullYear()
  const month = fillZero(date.getMonth() + 1)
  const day = fillZero(date.getDate())
  return `${year}-${month}-${day}`
}

// 时间补0
const fillZero = (str: any) => {
  str = '0' + str
  return str.slice(-2)
}

// 格式化时间
const formatData = (item: any) => {
  const { validityType = null, validityValue, receiveDate = null } = item
  if (validityType === 0) {
    const valueArr = validityValue.split(',')
    return valueArr[0] + '—' + valueArr[1]
  }
  if (validityType === 3) {
    return '领券当日起永久有效'
  }
  if (receiveDate) {
    const day = 24 * 60 * 60 * 1000
    const allDay = day * validityValue
    if (validityType === 1) {
      return getDate(receiveDate) + '—' + getDate(receiveDate + allDay)
    }
    return (
      getDate(receiveDate + day) + '—' + getDate(receiveDate + day + allDay)
    )
  }
  if (validityType === 1) {
    return `领券当日起${validityValue}天内有效`
  }
  return `领券次日起${validityValue}天内有效`
}
interface Rule {
  apply_types: number[]
  apply_filter: number
  product_infos: { product_id: number }[]
  limit_amount: number
  deduct_ratio: number
  deduct_money: number
}
// 显示规则
const showTips = (data: Rule[], useNote: string): string => {
  const currencyName = userStore.currencyCN
  const typesMap: { [key: number]: string } = {
    0: '门票',
    1: '套餐',
    2: '自由行',
    3: '线路',
    5: '住宿',
    7: '出租车',
    8: '签证',
    11: '商品',
    12: '抢购',
    14: '交通',
    99: '全部'
  }
  const filterMap: { [key: number]: string } = {
    0: '全部商品可用',
    1: '指定商品可用',
    2: '指定商品不可用'
  }
  const limitMap: { [key: number]: string } = {
    0: '无使用门槛'
  }
  let str = ''
  let count = 0
  data.forEach((rule: Rule, index: number) => {
    count = index + 1
    const {
      apply_types: types,
      apply_filter: filter,
      product_infos: productInfos,
      limit_amount: limit,
      deduct_ratio: ratio,
      deduct_money: money
    } = rule
    str += index + 1 + '.【'
    if (types.length > 0) {
      const hasAll = types.indexOf(99)
      if (hasAll !== -1) {
        str += typesMap[99]
      } else {
        const newTypes = types.filter((item: number) => item !== 99)
        newTypes.forEach((id: number, index: number) => {
          str += typesMap[id]
          if (index !== newTypes.length - 1) str += '、'
        })
      }
    }
    str += '品类】'
    if (typeof filter === 'number') {
      str += filterMap[filter]
      if (filter !== 0) {
        str += '(产品ID:'
        productInfos.forEach((item: { product_id: number }, index: number) => {
          // 超过9个省略号
          if (index >= 9) return
          // 如果是最后一个了,后面就不加逗号了
          if (index === productInfos.length - 1) {
            str += item.product_id
            return
          }
          str += item.product_id + ','
        })
        // 超过9个省略号
        if (productInfos.length > 9) str += '...'
        // 如果有产品id，闭合括号
        if (productInfos.length > 0) str += ')'
      }
      str += '，'
    }
    if (typeof limit === 'number') {
      if (limit === 0) {
        str += limitMap[limit]
      } else {
        str += '订单满' + limit + currencyName + '可用'
      }
      str += '，'
    }
    if (typeof ratio === 'number') {
      str += '最高优惠' + ratio + '%'
      if (money !== 0) str += '，最高优惠' + money + currencyName
    }
    str += '。'
  })
  if (useNote) {
    str += `${count + 1}. 【使用说明】${useNote}。`
  }
  console.log('当前排序排到了', count)
  return str
}
export { getDate, formatData, showTips }
