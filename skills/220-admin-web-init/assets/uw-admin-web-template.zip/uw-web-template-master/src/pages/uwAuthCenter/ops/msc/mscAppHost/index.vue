<script setup lang="ts">
import { type ComponentInternalInstance } from 'vue'
import { SearchFormType } from '@/components/SearchForm/type'
import {
  opsMscMscAppHostList,
  type MscAppHost,
  type MscAppHostQueryParam
} from '@/api/uwAuthCenterOpsApi'
import { ResponseData, DataList } from '@/api/uwAuthCenterAuthApi'
import { useI18n } from 'vue-i18n'
import { useCrud } from '@/hooks/useCrud'
import { useCommonSelectTypes } from '@/utils/selectOptions'
import { convertBytes } from '@/utils/tool'

// 获取全局挂载的方法
const { proxy } = getCurrentInstance() as ComponentInternalInstance
const { dayjs, useActivated } = proxy as any
const { t } = useI18n()
const { handleTypeForLabel, appStates } = useCommonSelectTypes()

const {
  tableConfig, // 表格相关配置属性
  handleList // 列表请求函数
} = useCrud<MscAppHost, MscAppHostQueryParam>({
  // 列表请求接口
  listFn: (): Promise<ResponseData<DataList<MscAppHost>>> => {
    tableConfig.queryParams.stateGte = 0
    return opsMscMscAppHostList(tableConfig.queryParams)
  }
})

// 搜索表单 结构组成数据
const searchFormConfig = computed<SearchFormType[]>(() => {
  return [
    {
      field: 'id',
      formItem: {
        label: 'ID',
        labelWidth: '90'
      },
      formItemWidth: 280,
      clearable: true,
      componentType: 'input',
      placeholder: t('pleaseInput') + 'id'
    },
    {
      field: 'appId',
      formItem: {
        label: 'appId',
        labelWidth: '90'
      },
      formItemWidth: 280,
      clearable: true,
      componentType: 'input',
      placeholder: t('pleaseInput') + 'appId'
    },
    {
      field: 'createDateRange',
      componentType: 'datePicker',
      formItem: {
        label: t('createDate'),
        labelWidth: '70'
      },
      componentWidth: 380,
      clearable: true,
      type: 'datetimerange',
      startPlaceholder: t('startDate'),
      endPlaceholder: t('endDate'),
      defaultTime: [
        new Date(2000, 1, 1, 0, 0, 0),
        new Date(2000, 2, 1, 23, 59, 59)
      ],
      valueFormat: 'YYYY-MM-DD HH:mm:ss'
    },
    {
      field: 'modifyDateRange',
      componentType: 'datePicker',
      formItem: {
        label: t('modifyDate'),
        labelWidth: '70'
      },
      componentWidth: 380,
      clearable: true,
      type: 'datetimerange',
      startPlaceholder: t('startDate'),
      endPlaceholder: t('endDate'),
      defaultTime: [
        new Date(2000, 1, 1, 0, 0, 0),
        new Date(2000, 2, 1, 23, 59, 59)
      ],
      valueFormat: 'YYYY-MM-DD HH:mm:ss'
    },
    {
      field: 'lastUpdateRange',
      componentType: 'datePicker',
      formItem: {
        label: '更新时间',
        labelWidth: '70'
      },
      componentWidth: 380,
      clearable: true,
      type: 'datetimerange',
      startPlaceholder: t('startDate'),
      endPlaceholder: t('endDate'),
      defaultTime: [
        new Date(2000, 1, 1, 0, 0, 0),
        new Date(2000, 2, 1, 23, 59, 59)
      ],
      valueFormat: 'YYYY-MM-DD HH:mm:ss'
    },
    {
      field: 'state',
      formItem: {
        label: '状态',
        labelWidth: '90'
      },
      options: appStates.value,
      formItemWidth: 280,
      clearable: true,
      componentType: 'select',
      placeholder: t('pleaseSelect') + '状态',
      value: ''
    }
  ]
})

// 显示各项用户数
const handleShowUserInfo = (item: MscAppHost) => {
  return `<div><span>rpc：</span><span>${item.userRpcNum}</span><div>
<div><span>root：</span><span>${item.userRootNum}</span><div>
<div><span>ops：</span><span>${item.userOpsNum}</span><div>
<div><span>admin：</span><span>${item.userAdminNum}</span><div>
<div><span>saas：</span><span>${item.userSaasNum}</span><div>
<div><span>会员：</span><span>${item.userGuestNum}</span><div>
    `
}

useActivated(() => {
  handleList()
})
</script>

<template>
  <div class="flex_col">
    <div class="flex_col_header">
      <SearchForm
        v-model="tableConfig.queryParams"
        :bnt-loading="tableConfig.tableLoading"
        :list="searchFormConfig"
        @change="handleList"
        @search="handleList"
      ></SearchForm>
    </div>
    <el-table
      border
      style="width: 100%"
      :header-cell-style="{
        backgroundColor: 'var(--el-color-info-light-9)'
      }"
      :data="tableConfig.dataList"
      v-loading="tableConfig.tableLoading"
      class="flex_col_body"
    >
      <el-table-column
        prop="id"
        label="ID"
        align="center"
        width="90"
        fixed="left"
      ></el-table-column>
      <el-table-column
        prop="appId"
        label="APPID"
        align="center"
        width="80"
      ></el-table-column>
      <el-table-column
        label="应用信息"
        header-align="center"
        align="left"
        width="220px"
      >
        <template v-slot="{ row }">
          <div>
            <span>{{ row.appName }}</span>
            <span class="margin-left-5">{{ row.appVersion }}</span>
          </div>
          <div>
            <span>{{ row.appHost }}</span>
            <span>{{ ':' + row.appPort }}</span>
          </div>
        </template>
      </el-table-column>
      <!-- 在线rpc/root/ops/admin/saas/会员用户数 -->
      <el-table-column
        label="在线用户数"
        align="center"
        width="180"
      >
        <template v-slot="{ row }">
          <el-tooltip
            :content="handleShowUserInfo(row)"
            raw-content
            placement="top-start"
          >
            <el-text type="primary">
              <span>{{ row.userRpcNum }}</span>
              <span>/</span>
              <span>{{ row.userRootNum }}</span>
              <span>/</span>
              <span>{{ row.userOpsNum }}</span>
              <span>/</span>
              <span>{{ row.userAdminNum }}</span>
              <span>/</span>
              <span>{{ row.userSaasNum }}</span>
              <span>/</span>
              <span>{{ row.userGuestNum }}</span>
            </el-text>
          </el-tooltip>
        </template>
      </el-table-column>
      <el-table-column
        prop="accessCount"
        label="访问数"
        align="center"
        width="100"
      ></el-table-column>
      <el-table-column
        prop="jvmMemMax"
        label="jvm内存信息"
        align="center"
        min-width="280"
      >
        <template v-slot="{ row }">
          <div class="textAlignLeft">
            <span>总数：</span>
            <span>{{ convertBytes(row.jvmMemTotal) }}</span>
            ，
            <span>空闲：</span>
            <span>{{ convertBytes(row.jvmMemFree) }}</span>
          </div>
          <div class="textAlignLeft">
            <span>最大：</span>
            <span>{{ convertBytes(row.jvmMemMax) }}</span>
          </div>
        </template>
      </el-table-column>
      <el-table-column
        label="线程信息"
        align="center"
        min-width="220"
      >
        <template v-slot="{ row }">
          <div class="textAlignLeft">
            <span>活跃：</span>
            <span>{{ row.threadActive }}</span>
            ，
            <span>守护：</span>
            <span>{{ row.threadDaemon }}</span>
          </div>
          <div class="textAlignLeft">
            <span>峰值：</span>
            <span>{{ row.threadPeak }}</span>
            ，
            <span>累计：</span>
            <span>{{ row.threadStarted }}</span>
          </div>
        </template>
      </el-table-column>
      <el-table-column
        prop="createDate"
        label="创建/修改时间"
        align="center"
        width="180px"
      >
        <template v-slot="{ row }">
          <div>
            {{ dayjs(row['createDate']).format('YYYY-MM-DD HH:mm:ss') }}
          </div>
          <div>
            {{
              row.modifyDate
                ? dayjs(row['modifyDate']).format('YYYY-MM-DD HH:mm:ss')
                : ''
            }}
          </div>
        </template>
      </el-table-column>
      <el-table-column
        prop="lastUpdate"
        label="最后更新时间"
        align="center"
        width="170"
      >
        <template v-slot="{ row }">
          <span>
            {{
              row.lastUpdate
                ? dayjs(row['lastUpdate']).format('YYYY-MM-DD HH:mm:ss')
                : ''
            }}
          </span>
        </template>
      </el-table-column>
      <el-table-column
        prop="state"
        label="状态"
        align="center"
        width="80"
        fixed="right"
      >
        <template v-slot="{ row }">
          <el-link
            :type="row.state === 1 ? 'success' : 'danger'"
            underline="never"
          >
            {{ handleTypeForLabel(row.state, appStates) }}
          </el-link>
        </template>
      </el-table-column>
    </el-table>

    <!-- 分页组件 -->
    <Pagination
      v-model:page-size="tableConfig.queryParams.$rn"
      @page-size-change="handleList(false)"
      :total="tableConfig.sizeAll"
      v-model:current-page="tableConfig.queryParams.$pg"
      @current-change="handleList(false)"
      class="flex_col_bottom"
    />
  </div>
</template>

<style lang="scss" scoped>
.textAlignLeft {
  text-align: left;
}
</style>
