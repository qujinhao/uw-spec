package uw.app;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import uw.common.app.AppBootStrap;

@SpringBootApplication
@EnableDiscoveryClient
public class UwAppApplication {

    public static void main(String[] args) {
        AppBootStrap.run(UwAppApplication.class, args);
    }

}
