<template>
  <view
    class="z-scenic-info"
    v-if="zScenicInfo"
  >
    <view
      class="view-address"
      v-if="viewAddress"
    >
      <view
        class="view-address-left"
        v-if="address"
      >
        <view class="view-address-left-address">
          <text>{{ address }}</text>
        </view>
        <view
          v-if="longitude !== 0 && latitude !== 0"
          class="view-address-left-map flex-end"
          @click="handleClickMap"
        >
          <text>{{ t('zDetailInfo.map') }}</text>
        </view>
      </view>
      <view
        v-if="phone"
        class="view-address-right"
        @click="handleCallPhone"
      >
        <text>{{ t('zDetailInfo.phone') }}</text>
      </view>
    </view>
    <!-- 设施服务-->
    <view
      class="view-service"
      v-if="services && services.length > 0"
    >
      <template
        v-for="item in services"
        :key="item.name"
      >
        <view class="view-service-text">
          <i
            class="view-service-sprite"
            :class="`view-service-sprite-item${item.name}`"
          ></i>
          <text style="margin-left: 5px">{{ item.value }}</text>
        </view>
      </template>
      <view style="clear: both"></view>
    </view>
    <up-action-sheet
      :show="show"
      :actions="actions"
      @select="onSelect"
      :title="t('zProductPopup.call')"
      :cancel-text="t('zNavBar.cancel')"
      @close="show = false"
    />
  </view>
</template>

<script lang="ts" setup>
import { ref, computed } from 'vue'
import i18n from '@/i18n/index'

const { t } = i18n().global
const props = withDefaults(
  defineProps<{
    address?: string
    phone?: string | number
    longitude?: number
    latitude?: number
    services?: { name: string; value: string }[]
  }>(),
  {
    address: '', // 不设置默认值（保持 undefined）
    phone: '', // 默认值 ''
    longitude: 0, // 默认值 0
    latitude: 0, // 默认值 0
    services: () => [] // 默认值空数组
  }
)

const show = ref(false)

const viewAddress = computed(() => {
  return props.address || props.phone
})

const zScenicInfo = computed(() => {
  return props.address || props.phone || props.services.length > 0
})

const actions = computed(() => {
  const arr = (props.phone as string)
    .replaceAll(/[\u4e00-\u9fa5]|\(|\)|（|）/g, '')
    .split(/,|、|，|\s/)
  return arr.map((item) => ({ name: item }))
})

const emit = defineEmits(['click-map'])

const handleClickMap = () => {
  emit('click-map', {
    longitude: props.longitude,
    latitude: props.latitude
  })
}

const handleCallPhone = () => {
  if (actions.value.length > 1) {
    show.value = true
  } else {
    window.location.href = `tel:${actions.value[0].name}`
  }
}

const onSelect = (item: any) => {
  show.value = false
  window.location.href = `tel:${item.name}`
}
</script>
<style lang="scss" scoped>
@import './style/index.scss';
</style>
