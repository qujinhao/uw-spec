<script setup lang="ts">
import { type ComponentInternalInstance } from "vue";
import { ElMessage, FormRules, ElTree } from "element-plus";
import { SearchFormType } from "@/components/SearchForm/type";
import {
  saasAccountGroupUpdate,
  saasAccountGroupSave,
  saasAccountGroupList,
  saasAccountGroupDelete,
  saasAccountGroupDisable,
  saasAccountGroupEnable,
  saasAccountGroupLoadPermMenu,
  type MscUserGroup,
  type MscUserGroupQueryParam,
  type MscUserPerm,
  type PermVo,
} from "@/api/uwAuthCenterSaasApi";
import { usePermissionCode } from "@/hooks/usePermissionCode";
import { useSimplifyPrompt } from "@/hooks/useSimplifyPrompt";
import { useCommonSelectTypes } from "@/utils/selectOptions";
import { useI18n } from "vue-i18n";
import { useMainStore } from "@/store/main";
import { useCrud } from "@/hooks/useCrud";
import { ResponseData, DataList } from "@/api/uwAuthCenterAuthApi";
import { handleBuildPermTreeMenu } from "@/utils/buildTreeMenu";

interface MscMenu {
  id?: number | string; //id
  permCode?: string; //权限菜单URI
  permName?: string; //权限菜单名称
  permRank?: number;
  label?: string;
  children?: MscMenu[];
  disabled?: boolean;
  permVoList?: PermVo[];
}

// 删除接口参数类型
interface deleteParamsType {
  id: number;
  remark: string; // 备注
}

const { t } = useI18n();
const { handleTypeForLabel, commonTypes } = useCommonSelectTypes();
// 获取全局挂载的方法
const { proxy } = getCurrentInstance() as ComponentInternalInstance;
const { useActivated, formatDate } = proxy as any;
const mainStore = useMainStore();

const userType = computed(() => mainStore.userInfo.userType);

const {
  tableConfig, // 表格相关配置属性
  handleList, // 列表请求函数
  dialogConfig, // 弹窗相关配置属性
  dialogFormRef, // 弹窗表单ref
  handleDelete, // 删除函数
  handleOpenSaveDialog, // 打开保存弹窗
  handleOpenUpdateDialog, // 打开编辑弹窗
  handleResetDialog,
  handleSubmitDialog,
} = useCrud<MscUserGroup, MscUserGroupQueryParam, deleteParamsType>(
  {
    // 列表请求接口
    listFn: async (): Promise<ResponseData<DataList<MscUserGroup>>> => {
      tableConfig.queryParams.userType = userType.value;
      tableConfig.queryParams.stateGte = 0;
      return saasAccountGroupList(tableConfig.queryParams);
    },
    // 新增请求接口
    saveFn: (): Promise<ResponseData<MscUserGroup>> => {
      handleData();
      return saasAccountGroupSave({
        ...dialogConfig.dialogFormData,
        userType: userType.value,
      });
    },
    openSaveDialogCallback: () => {
      loadPermMenu();
    },
    // 修改请求接口
    updateFn: (remark?: string): Promise<ResponseData<MscUserGroup>> => {
      handleData();
      return saasAccountGroupUpdate(dialogConfig.dialogFormData, {
        remark: remark || "",
      });
    },
    // 删除请求接口
    deleteFn: (params: deleteParamsType) => {
      return saasAccountGroupDelete(params);
    },
    openUpdateDialogCallback: () => {
      loadPermMenu();
      userAuth.value = dialogConfig.dialogFormData.groupPerm;
    },
    resetDialogCallback: () => {
      userAuth.value = "";
      mscMenu.value = [];
    },
  },
  {
    openUpdateRemark: true,
    openDeleteRemark: true,
  }
);

// 搜索表单 结构组成数据
const searchList = computed<SearchFormType[]>(() => {
  return [
    {
      field: "groupName",
      formItem: {
        label: "组名称",
        labelWidth: "90",
      },
      formItemWidth: 280,
      clearable: true,
      componentType: "input",
      placeholder: t("pleaseInput") + "组名称",
    },
    {
      field: "state",
      formItem: {
        label: t("uwAuthCenter.MscUserGroup.state"),
        labelWidth: "90",
      },
      formItemWidth: 280,
      clearable: true,
      componentType: "select",
      options: commonTypes.value,
      placeholder: t("pleaseSelect") + t("uwAuthCenter.MscUserGroup.state"),
    },
  ];
});

// 新增/修改 表单校验
const dialogListRules = computed<FormRules>(() => {
  return {
    groupName: [
      {
        required: true,
        message: t("pleaseInput") + "组名称",
      },
    ],
    userType: [
      {
        required: true,
        message: t("pleaseInput") + "类型",
      },
    ],
  };
});

const treeRefOnDialog = ref();

// 新增/编辑保存数据处理
const handleData = () => {
  const list = treeRefOnDialog.value!.getCheckedKeys(false);
  const list2 = treeRefOnDialog.value!.getHalfCheckedKeys();
  const userPerm = list2.concat(list).filter((item: number | string) => {
    return typeof item === "number";
  });
  dialogConfig.dialogFormData.groupPerm = userPerm.join(",");
};

// 查看权限
const handleClickPerm = (row: MscUserGroup) => {
  if (!row.id) return;
  userAuthInfo.value = row;
  userAuth.value = row.groupPerm;
  authType.value = 0;
  loadPermMenu(true);
};

// 加载权限菜单
const loadPermMenu = (isWatchPerm?: boolean) => {
  dialogConfig.dialogLoading = true;
  saasAccountGroupLoadPermMenu()
    .then((res) => {
      if (res.state === "success") {
        if (res.data) {
          const list = res.data.map((item) => {
            const childrenArray = handleBuildPermTreeMenu(
              item.permVoList || []
            );
            const obj = {
              ...item,
              label: item.appLabel,
              children: childrenArray,
              id: `app-${item.id}`,
              disabled: !item.permVoList || childrenArray.length === 0,
            };
            return obj;
          });
          mscMenu.value = list;
          // 查看权限
          if (isWatchPerm) {
            authShow.value = true;
          }
        } else {
          ElMessage.error(t("noData"));
        }
      } else {
        ElMessage.error(res.msg);
      }
    })
    .catch((e) => {
      ElMessage.error(e);
    })
    .finally(() => {
      dialogConfig.dialogLoading = false;
    });
};

const treeRef = ref<InstanceType<typeof ElTree>>();
const authShow = ref(false);
const userAuthInfo = ref<MscUserPerm>();
const userAuth = ref<string>();
const mscMenu = ref<MscMenu[]>();
const authType = ref<0 | 1 | 2>(); // 0查看 1修改 2 新增

// 默认选中
const defaultCheckedKeys = computed(() => {
  if (!userAuth.value) return [];
  const arr: number[] = [];
  const list = (userAuth.value || "").split(",").map(Number) as number[];
  mscMenu.value?.forEach((item) => {
    if (item.permVoList) {
      const ls = item.permVoList;
      ls.forEach((itemC) => {
        for (let i = 0; i < list.length; i++) {
          const el = list[i];
          if (
            el === itemC.id &&
            itemC.permCode &&
            (itemC.permCode.includes(":") ||
              itemC.permCode.includes("dashboard"))
          ) {
            arr.push(el);
          }
        }
      });
    }
  });
  return arr;
});

//  确认选择
const clickAuthSave = () => {
  const list = treeRef.value!.getCheckedKeys(false);
  const list2 = treeRef.value!.getHalfCheckedKeys();
  const userPerm = list2.concat(list).filter((item: number | string) => {
    return typeof item === "number";
  });
  dialogConfig.dialogFormData.groupPerm = userPerm.join(",");
  authShow.value = false;
};

// 禁用
const handleDisable = (row: MscUserGroup) => {
  useSimplifyPrompt({
    message: t("pleaseInputDisableReason"),
    confirmCallBack: (remark) => {
      saasAccountGroupDisable({
        id: row.id!,
        remark: remark || "",
      }).then((res) => {
        if (res.state === "success") {
          ElMessage.success(t("disableSuccess"));
          handleList();
        } else {
          ElMessage.error(res.msg);
        }
      });
    },
  });
};

// 启用
const handleEnable = (row: MscUserGroup) => {
  useSimplifyPrompt({
    message: t("pleaseInputEnableReason"),
    confirmCallBack: (remark) => {
      saasAccountGroupEnable({
        id: row.id!,
        remark: remark || "",
      }).then((res) => {
        if (res.state === "success") {
          ElMessage.success(t("enableSuccess"));
          handleList();
        } else {
          ElMessage.error(res.msg);
        }
      });
    },
  });
};

useActivated(() => {
  handleList();
});
</script>

<template>
  <div class="flex_col">
    <div class="flex_col_header">
      <SearchForm
        v-model="tableConfig.queryParams"
        :bnt-loading="tableConfig.tableLoading"
        :list="searchList"
        @change="handleList"
        @search="handleList"
      >
        <template #right>
          <el-button
            class="margin-left-10"
            type="primary"
            size="small"
            @click="handleOpenSaveDialog"
            v-permission="usePermissionCode('save')"
            round
            icon="Plus"
          >
            {{ t("add") }}
          </el-button>
        </template>
      </SearchForm>
    </div>
    <el-table
      border
      :style="{ width: '100%' }"
      :header-cell-style="{
        backgroundColor: 'var(--el-color-info-light-9)',
      }"
      :data="tableConfig.dataList"
      v-loading="tableConfig.tableLoading"
      stripe
      class="flex_col_body"
    >
      <el-table-column
        prop="id"
        label="ID"
        width="140"
        align="center"
        fixed="left"
      ></el-table-column>
      <el-table-column
        prop="groupName"
        label="部门名称"
        width="150"
        align="center"
      ></el-table-column>
      <el-table-column
        prop="groupDesc"
        label="部门描述"
        minWidth="200"
        align="center"
      ></el-table-column>
      <el-table-column
        prop="groupPerm"
        label="部门限制权限"
        width="200"
        align="center"
      >
        <template #default="scope">
          <el-text
            type="primary"
            underline="never"
            @click="handleClickPerm(scope.row)"
          >
            查看权限
          </el-text>
        </template>
      </el-table-column>
      <el-table-column
        prop="createDate"
        :label="t('uwAuthCenter.MscUserGroup.createDate')"
        width="180"
        align="center"
      >
        <template #default="scope">
          <span>
            {{ formatDate(scope.row.createDate) }}
          </span>
        </template>
      </el-table-column>
      <el-table-column
        prop="modifyDate"
        :label="t('uwAuthCenter.MscUserGroup.modifyDate')"
        width="180"
        align="center"
      >
        <template #default="scope">
          <span>
            {{ formatDate(scope.row.modifyDate) }}
          </span>
        </template>
      </el-table-column>
      <el-table-column
        prop="userNum"
        label="用户数"
        width="100"
        align="center"
      ></el-table-column>
      <el-table-column
        prop="state"
        :label="t('uwAuthCenter.MscUserGroup.state')"
        width="100"
        align="center"
      >
        <template #default="scope">
          <el-text
            :type="scope.row.state === 1 ? 'success' : 'danger'"
            underline="never"
          >
            {{ handleTypeForLabel(scope.row.state, commonTypes) }}
          </el-text>
        </template>
      </el-table-column>
      <el-table-column :label="t('operation')" align="center" width="150">
        <template #default="scope">
          <el-button-group v-if="scope.row.state !== -1">
            <el-tooltip :content="t('edit')" placement="top" :enterable="false">
              <el-button
                type="primary"
                @click="handleOpenUpdateDialog(scope.row)"
                v-permission="usePermissionCode('update')"
                icon="Edit"
                size="small"
              />
            </el-tooltip>
            <template v-if="scope.row.state === 1">
              <el-tooltip
                :content="t('disabled')"
                placement="top"
                :enterable="false"
              >
                <el-button
                  type="info"
                  @click="handleDisable(scope.row)"
                  v-permission="usePermissionCode('disable')"
                  icon="Remove"
                  size="small"
                />
              </el-tooltip>
            </template>
            <template v-if="scope.row.state === 0">
              <el-tooltip
                :content="t('enable')"
                placement="top"
                :enterable="false"
              >
                <el-button
                  type="success"
                  @click="handleEnable(scope.row)"
                  v-permission="usePermissionCode('enable')"
                  icon="CircleCheck"
                  size="small"
                />
              </el-tooltip>
            </template>
            <template v-if="scope.row.state === 0">
              <el-tooltip
                :content="t('delete')"
                placement="top"
                :enterable="false"
              >
                <el-button
                  type="danger"
                  @click="handleDelete({ id: scope.row.id, remark: '' })"
                  v-permission="usePermissionCode('delete')"
                  icon="Delete"
                  size="small"
                />
              </el-tooltip>
            </template>
          </el-button-group>
        </template>
      </el-table-column>
    </el-table>
    <Pagination
      class="flex_col_bottom"
      v-model:page-size="tableConfig.queryParams.$rn"
      @pageSizeChange="handleList"
      :total="tableConfig.sizeAll"
      v-model:current-page="tableConfig.queryParams.$pg"
      @current-change="handleList"
    />
  </div>

  <el-dialog
    v-model="dialogConfig.dialogShow"
    :title="dialogConfig.dialogType === 0 ? t('add') : t('edit')"
    destroy-on-close
    @close="handleResetDialog"
    width="1200px"
    draggable
  >
    <el-row :gutter="20">
      <el-col :span="8">
        <div v-loading="dialogConfig.dialogLoading">
          <titleHeader title="管理组信息" class="margin-top-15" />
          <el-form
            ref="dialogFormRef"
            :model="dialogConfig.dialogFormData"
            :rules="dialogListRules"
            label-width="110px"
          >
            <el-row :gutter="10">
              <el-col :span="24">
                <el-form-item label="组名称" prop="groupName">
                  <el-input
                    v-model="dialogConfig.dialogFormData.groupName"
                    :placeholder="t('pleaseInput') + '组名称'"
                  />
                </el-form-item>
              </el-col>
              <el-col :span="24">
                <el-form-item label="描述" prop="groupDesc">
                  <el-input
                    v-model="dialogConfig.dialogFormData.groupDesc"
                    :placeholder="
                      t('pleaseInput') +
                      t('uwAuthCenter.MscUserGroupUpdateVo.groupDesc')
                    "
                    type="textarea"
                    :autosize="{ minRows: 2, maxRows: 4 }"
                  />
                </el-form-item>
              </el-col>
            </el-row>
          </el-form>
        </div>
      </el-col>
      <el-col :span="16">
        <titleHeader title="权限" class="margin-top-15" />
        <div style="height: 580px; overflow: auto">
          <el-tree
            class="user-tree"
            :data="mscMenu"
            show-checkbox
            node-key="id"
            ref="treeRefOnDialog"
            :default-checked-keys="defaultCheckedKeys"
            :props="{
              children: 'children',
              label: 'label',
            }"
          ></el-tree>
        </div>
      </el-col>
    </el-row>
    <template #footer>
      <el-button @click="dialogConfig.dialogShow = false" icon="Close">
        {{ t("cancel") }}
      </el-button>
      <el-button
        type="primary"
        @click="handleSubmitDialog"
        :loading="dialogConfig.dialogLoading"
        icon="Check"
      >
        {{ dialogConfig.dialogType === 0 ? t("add") : t("edit") }}
      </el-button>
    </template>
  </el-dialog>

  <!-- 授权 -->
  <div class="auth-dialog">
    <el-dialog
      v-model="authShow"
      title="权限详情"
      destroy-on-close
      draggable
      width="900px"
      @close="handleResetDialog"
    >
      <el-tree
        class="user-tree"
        :data="mscMenu"
        show-checkbox
        node-key="id"
        ref="treeRef"
        :default-checked-keys="defaultCheckedKeys"
        :props="{
          children: 'children',
          label: 'label',
        }"
      ></el-tree>
      <template #footer>
        <el-button @click="authShow = false" icon="Close">
          {{ t("cancel") }}
        </el-button>
        <el-button
          type="primary"
          @click="clickAuthSave"
          icon="Check"
          v-show="authType !== 0"
        >
          {{ t("confirm") }}
        </el-button>
      </template>
    </el-dialog>
  </div>
</template>

<style lang="scss" scoped>
.auth-dialog {
  :deep(.el-dialog__body) {
    height: 650px;
    overflow: auto;
  }
}

.operatorDialog {
  :deep(.el-dialog__body) {
    height: 650px;
  }
}

.user-tree {
  .is-focusable {
    .el-tree-node {
      .el-tree-node {
        .el-tree-node__children {
          white-space: break-spaces;
        }

        .el-tree-node {
          &.is-focusable {
            display: inline-block;
          }
        }
      }
    }
  }
}
</style>
