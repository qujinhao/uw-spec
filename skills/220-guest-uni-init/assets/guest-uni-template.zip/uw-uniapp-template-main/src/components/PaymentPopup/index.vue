<!-- 支付弹窗 -->
<script lang="ts" setup>
// import type { AisLinkerConfigInfo } from '@/api/saasFinanceAppGuestApi'
import { useMainStore } from '@/store/main'
import { ref, onMounted, watch } from 'vue'
import type { Extend_AisLinkerConfigInfo } from './type'
import { CalculationPrice } from '@/utils/tool'

const mainStore = useMainStore()

const props = withDefaults(
  defineProps<{
    modelValue: boolean // 是否显示支付弹窗
    priceTotal: number // 支付总金额 (分单位)
  }>(),
  {
    modelValue: false
  }
)
const emits = defineEmits<{
  (e: 'update:modelValue', bool: boolean): void
  (e: 'submit', payItem: Extend_AisLinkerConfigInfo): void
}>()

const isShow = ref(props.modelValue)

// 当前选中的支付方式
const curPaymentId = ref<number>()

// 支付备注
const payRemark = ref('')

watch(
  () => props.modelValue,
  (value: boolean) => {
    isShow.value = value
    emits('update:modelValue', value)
  }
)
// {
//         "id": 1605319725128821909,
//         "saasId": 8821909,
//         "poiId": 216714,
//         "siteId": 0,
//         "agentId": 0,
//         "guestId": 220,
//         "orderInfo": "{\"id\":5638821909,\"saasId\":8821909,\"extId\":0,\"areaCode\":\"100001100010010000\",\"catCode\":0,\"skuType\":1,\"productName\":\"jsw普通产品1\",\"productNameShort\":\"jsw普通产品1\",\"imgMain\":\"{\\\"2553\\\":\\\"8821909/product_info/0_2553.png\\\"}\",\"tagIds\":\"2\",\"poiIds\":\"216714\",\"stockType\":202,\"stockAll\":0,\"stockSale\":0,\"specType\":0,\"supplierConfigId\":0,\"supplierMchId\":0,\"supplierState\":1,\"rankOrder\":0,\"nights\":0,\"breakfast\":0,\"unpayCancelMinutes\":0,\"isConfirm\":0,\"state\":1}",
//         "unpayCancelMinutes": 0,
//         "areaCode": 100001100010010000,
//         "saleType": 0,
//         "payType": 0,
//         "payMoney": 0,
//         "useDateType": 0,
//         "deliveryType": 0,
//         "deliveryState": 0,
//         "confirmType": 0,
//         "finishNum": 0,
//         "finishMoney": 0,
//         "remark": "11",
//         "channelId": 0,
//         "distributorMchId": 0,
//         "distributorParentId": 0,
//         "distributorMoney": 0,
//         "distributorOrderState": 0,
//         "distributorMoneyReceipted": 0,
//         "distributorMoneyRefund": 0,
//         "distributorVerifyState": 0,
//         "distributorRebate": 0,
//         "issueType": 0,
//         "issueState": 0,
//         "refundNum": 0,
//         "refundMoney": 0,
//         "refundState": 0,
//         "orderCurrency": "CNY",
//         "orderMoney": 23800,
//         "orderState": 10,
//         "orderDate": 1765351874385,
//         "state": 1
//     }
// 支付弹窗提交
const handlePaySubmit = () => {
  if (!curPaymentId.value) {
    uni.showToast({
      icon: 'none',
      title: '请选择支付方式'
    })
    return
  }

  /*
  {
    "id": 90,
    "state": 1,
    "appName": "saas-finance-app",
    "saasId": 8821909,
    "createDate": 1765243324164,
    "linkerId": 53,
    "linkerFunction": "payOrderNotify,payRefundNotify,payRefund,payOrder",
    "linkerVersion": "1.0.5",
    "linkerIcon": "",
    "mchId": 0,
    "configSid": "",
    "configName": "微信支付接口",
    "modifyDate": 1765275767758,
    "pubParamMap": {
        "pay.channel": "WECHAT"
    },
    "payRemark": "22"
}
  */
  const findItem = mainStore.paymentConfigList.find(
    (item) => item.id === curPaymentId.value
  )
  const payChannel = findItem ? findItem.pubParamMap['pay.channel'] : ''
  const extendItem: Extend_AisLinkerConfigInfo = {
    ...findItem,
    payRemark: payRemark.value,
    payChannel
  }
  emits('submit', extendItem)
}

onMounted(() => {})
</script>

<template>
  <up-popup
    :show="isShow"
    :round="20"
    closeable
    :closeOnClickOverlay="false"
    @close="emits('update:modelValue', false)"
  >
    <div class="p-[30rpx]">
      <div class="flex flex-row gap-1">
        <u-title>支付金额</u-title>
        <span class="text-primary-buy">
          CNY {{ CalculationPrice(props.priceTotal / 100) }}
        </span>
      </div>
      <div class="div-br"></div>

      <u-title>选择支付方式</u-title>
      <up-radio-group
        v-model="curPaymentId"
        placement="column"
      >
        <div class="flex gap-2">
          <up-radio
            v-for="item in mainStore.paymentConfigList"
            :key="item.id"
            :label="item.configName"
            :name="item.id"
          />
        </div>
      </up-radio-group>

      <u-title>下单信息</u-title>
      <div><slot></slot></div>

      <u-title>支付备注信息</u-title>
      <up-input
        v-model="payRemark"
        placeholder="请输入支付备注"
      />

      <up-button
        type="primary"
        @click="handlePaySubmit"
      >
        提交支付
      </up-button>
    </div>
  </up-popup>
</template>

<style lang="scss" scoped></style>
