###### 组件属性

```typescript
width?: number | string            // echart图宽度
height?: number | string           // echart图高度
options: EChartsOption             // echart的option配置，详情看echart官网
onMouseOverEvent?: boolean         // 是否开启echart图中的mouseOver事件，默认不开启，配合自定义事件mouseOverFn
onMouseOutEvent?: boolean          // 是否开启echart图中的mouseOut事件，默认不开启，配合自定义事件mouseOutFn
isShowTooltip?: boolean            // 是否鼠标移入就显示第一组数据
```

###### 组件事件

```typescript
mouseOverFn: () => void                                                              // 当属性onMouseOverEvent为true时，且echart图中的鼠标悬停事件发生时触发此自定义事件
mouseOutFn: () => void                                                              // 当属性onMouseOutEvent为true时，且echart图中的鼠标悬停事件发生时触发此自定义事件
```
