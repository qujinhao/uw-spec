<template>
  <div class="appoint-calendar">
    <div class="weeks">
      <span
        class="cell"
        :class="week.class"
        v-for="week in weekList"
        :key="week.id"
      >
        {{ week.text }}
      </span>
    </div>
    <div class="days">
      <div
        class="cell"
        :class="{
          weekend: day.weekStatus,
          chosen: travelDate.includes(day.intackDate),
          'c-star': travelDate[0] === day.intackDate,
          'c-end':
            travelDate.length > 1 &&
            travelDate[travelDate.length - 1] === day.intackDate,
          full: day.stock === '已约满',
          hotel: treeId === '5'
        }"
        @click="chooseDay(day)"
        v-for="day in picker"
        :key="day.id"
      >
        <template v-if="day.monthStatus">
          <span
            class="ku"
            :class="colorMap[day.stock]"
          >
            {{ handleStock(day) }}
          </span>
          <span>{{ day.dateNum }}</span>
          <span
            class="bu"
            v-if="
              day.chajia > 0 &&
              !(
                travelDate.length > 1 &&
                travelDate[travelDate.length - 1] === day.intackDate
              )
            "
          >
            {{ t('appoint.Bu') }}
            {{ currency }}
            {{ day.chajia }}
          </span>
        </template>
      </div>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { computed } from 'vue'
// import { useUserStore } from '@/store/user'
import { parseTime } from '@/utils/tool'
import i18n from '@/i18n/index'

const { t } = i18n().global

// 定义接口
interface DayItem {
  id?: number
  intackDate: string
  dateNum: string | number
  monthStatus: boolean
  weekStatus: boolean
  dateStatus: boolean
  stock?: string
  num?: string | number
  chajia?: number
  [key: string]: any
}

interface WeekItem {
  text: string
  class: string
  id?: number
}

interface PriceItem {
  date: string
  [key: string]: any
}

// 定义props
const props = withDefaults(
  defineProps<{
    dateList: PriceItem[]
    showStock?: boolean
    treeId?: string | number
    themeColor?: string
    modelValue: string[]
    type?: string
    nights?: string | number
    currentMonth?: string | number
    currentYear?: string | number
  }>(),
  {
    dateList: () => [],
    showStock: false,
    treeId: '',
    themeColor: '',
    modelValue: () => [],
    type: '',
    nights: 0,
    currentMonth: new Date().getMonth() + 1,
    currentYear: new Date().getFullYear()
  }
)

const emit = defineEmits(['update:modelValue', 'change'])

// const store = useUserStore()
const env = process.env.VUE_APP_PLATFORM

// 周列表数据
const weekList: WeekItem[] = [
  { text: '周日', class: 'weekend' },
  { text: '周一', class: '' },
  { text: '周二', class: '' },
  { text: '周三', class: '' },
  { text: '周四', class: '' },
  { text: '周五', class: '' },
  { text: '周六', class: 'weekend' }
]

// 库存状态颜色映射
const colorMap: Record<string, string> = {
  紧张: 's1',
  申请: 's2',
  已约满: 's3',
  可预约: 's4'
}

// 计算属性
const currency = computed(() => '￥')

// 旅行日期处理
const travelDate = computed({
  get: () => props.modelValue,
  set: (val: string[]) => {
    const arr = [...val]
    // 酒店补差不计算末尾日期，因为末尾是离店
    if (props.treeId === '5') {
      arr.pop()
    }
    let chajia = 0
    let dateObj: DayItem = {} as DayItem

    // 范围的话取第一个日期对象+范围总差价
    picker.value.forEach((e: DayItem) => {
      for (const price of arr) {
        if (price === e.intackDate) {
          chajia += e.chajia || 0
          dateObj = e
        }
      }
    })

    emit('update:modelValue', val)
    emit('change', { val, chajia, dateObj })
  }
})

// 日历数据计算
const picker = computed(() => {
  const initCalendarList = initCalendar(props.currentYear, props.currentMonth)
  for (let date of initCalendarList) {
    for (const price of props.dateList) {
      if (price.date === date.intackDate) {
        date = Object.assign(date, price)
      }
    }
  }
  return initCalendarList as unknown as any
})

// 选择日期
const chooseDay = (day: DayItem) => {
  if (!day.monthStatus || day.stock === '已约满') return

  if (props.type === 'range') {
    // +1是因为酒店当天入住第二天离店，最后的那天其实是离店日期
    travelDate.value = getDateStr(day.intackDate, Number(props.nights) + 1)
  } else {
    travelDate.value = [day.intackDate]
  }
}

// 初始化日历
const initCalendar = (
  year: string | number,
  month: string | number
): DayItem[] => {
  const monthStr = Number(month) < 10 ? `0${Number(month)}` : `${month}`
  const firstDay = new Date(`${year}/${monthStr}/01`)
  const day = firstDay.getDay() // 第一天周几
  const startDate = new Date(firstDay)
  startDate.setDate(firstDay.getDate() - day)

  const tempArr: DayItem[] = []

  for (let i = 0; i < 42; i++) {
    const item = new Date(startDate)
    item.setDate(startDate.getDate() + i)

    const monthNum = item.getMonth() + 1
    const monthStr = monthNum > 9 ? monthNum : '0' + monthNum
    const dateStr = item.getDate() > 9 ? item.getDate() : '0' + item.getDate()

    const tempItem: DayItem = {
      id: i,
      intackDate: `${item.getFullYear()}-${monthStr}-${dateStr}`,
      dateNum: dateStr,
      monthStatus: item.getMonth() + 1 === Number(month),
      weekStatus: [0, 6].includes(item.getDay()),
      dateStatus: calTodayArterDate(parseTime(item, '{y}-{m}-{d}'))
    }

    tempArr.push(tempItem)
  }

  return tempArr
}

// 获取date日期的后面多少天
const getDateStr = (date: string, num: number): string[] => {
  const dd = new Date(date)
  const arr: string[] = []

  for (let i = 0; i < num; i++) {
    dd.setDate(dd.getDate() + (i === 0 ? 0 : 1))
    const y = dd.getFullYear()
    const m =
      dd.getMonth() + 1 < 10 ? '0' + (dd.getMonth() + 1) : dd.getMonth() + 1
    const d = dd.getDate() < 10 ? '0' + dd.getDate() : dd.getDate()
    arr.push(`${y}-${m}-${d}`)
  }

  return arr
}

// 计算是否是今天之后的日期 是：true
const calTodayArterDate = (date: string): boolean => {
  const dY = date.split('-')
  const cY = parseTime(Date.now(), '{y}-{m}-{d}').split('-')

  if (Number(dY[0]) > Number(cY[0])) {
    return true
  } else if (dY[0] === cY[0]) {
    if (Number(dY[1]) > Number(cY[1])) {
      return true
    } else if (dY[1] === cY[1]) {
      return Number(dY[2]) >= Number(cY[2])
    } else {
      return false
    }
  } else {
    return false
  }
}

// 处理库存显示
const handleStock = (item: DayItem): string | number => {
  // 小红薯特殊处理 -- num=0或者大于9的时候只显示stock，大于0小于9的时候再显示库存
  if (env === 'mp-xhs') {
    const num = Number(item.num)
    if (num === 0 || num > 9) {
      return item.stock || ''
    } else {
      return item.num || ''
    }
  }

  if (props.showStock) {
    return item.num || ''
  } else {
    return item.stock || ''
  }
}
</script>

<style lang="scss" scoped>
.appoint-calendar {
  padding: 0 10rpx;
}
.weeks,
.days {
  width: 100%;
  display: flex;
  flex-wrap: wrap;
  .cell {
    width: 14.285%;
    color: #333;
  }
}
.weeks {
  padding: 40rpx 0;
  .cell {
    font-size: 26rpx;
    text-align: center;
  }
}
.days {
  padding: 0;
  .cell {
    font-size: 32rpx;
    font-weight: bold;
    height: 100rpx;
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;
    box-sizing: border-box;
    border-radius: 20rpx;
    margin-bottom: 10rpx;
    .ku,
    .bu {
      position: absolute;
      left: 50%;
      transform: translateX(-50%) scale(0.8, 0.8);
      font-size: 24rpx;
      font-weight: 400;
      white-space: nowrap;
    }
    .ku {
      top: 3rpx;
      color: #ffcb00;
    }
    .ku.s1 {
      color: #ffcb00; /* 紧张 */
    }
    .ku.s2 {
      color: #ff5d0d; /* 申请 */
    }
    .ku.s3 {
      color: #cbcbcb; /* 已满 */
    }
    .ku.s4 {
      color: #008000; /* 可预约 */
    }
    .bu {
      bottom: 3rpx;
      color: #ff8b0d;
    }
  }
}
.cell.weekend {
  color: #ff5d0d;
}
.cell.full {
  color: #cbcbcb !important;
}
.cell.chosen {
  color: #ff8b0d;
  background-color: rgba(255, 139, 13, 0.1);
  .ku {
    display: none;
  }
}
.cell.chosen.c-star,
.cell.chosen.c-end {
  background-color: #ff8b0d;
  color: #fff;
  position: relative;
  border-radius: 20rpx;
  .bu {
    color: #fff;
  }
}
.cell.chosen.hotel {
  border-radius: 0;
}
.cell.chosen.c-star.hotel {
  border-radius: 20rpx 0 0 20rpx;
}
.cell.chosen.c-end.hotel {
  border-radius: 0 20rpx 20rpx 0;
}
.cell.chosen.hotel.full {
  background-color: #eee;
  &::before {
    content: '已满';
    background-color: #ddd;
    color: #333;
    position: absolute;
    top: 0;
    left: 50%;
    transform: translateX(-50%);
    font-size: 20rpx;
    border-radius: 0 0 8rpx 8rpx;
    padding: 2rpx 10rpx;
    white-space: nowrap;
    font-weight: 400;
  }
}
.cell.chosen.c-end.hotel.full {
  background-color: #ff8b0d;
  color: #fff !important;
  &::before {
    color: #ff8b0d;
    background-color: rgba(255, 255, 255, 0.8);
  }
}
.cell.chosen.c-star::before,
.cell.chosen.c-end::before {
  position: absolute;
  top: 0;
  left: 50%;
  transform: translateX(-50%);
  font-size: 20rpx;
  color: #ff8b0d;
  background-color: rgba(255, 255, 255, 0.8);
  border-radius: 0 0 8rpx 8rpx;
  padding: 2rpx 10rpx;
  white-space: nowrap;
  font-weight: 400;
}
.cell.chosen.c-star::before {
  content: '出发';
}
.cell.chosen.c-end::before {
  content: '结束';
}
.cell.chosen.c-star.hotel::before {
  content: '入住';
}
.cell.chosen.c-end.hotel::before {
  content: '离店';
}
</style>
