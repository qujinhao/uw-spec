import { PermVo } from '@/api/uwAuthCenterUserApi'
import { type RouteRecordRaw } from 'vue-router'
import { HIDE_MENU } from '@/config/common'

// 传入的权限菜单
interface newMscMenuTreeVo extends PermVo {
  children?: newMscMenuTreeVo[]
  label?: string
}

// 返回的权限菜单那
interface MscMenu extends PermVo {
  label?: string
  children?: MscMenu[]
  disabled?: boolean
  permVoList?: PermVo[]
}

// 侧边菜单
export interface MenuType {
  id?: number
  permCode?: string
  permName?: string
  permRank?: number
  displayState?: number //状态1:正常,2:vip
  children?: Array<MenuType>
}

// 数字倒序以3进行分割
export const formatNumberToGroups = (data: number) => {
  const numStr = data.toString() // 将数字转换为字符串
  const result = [] // 初始化结果数组
  // 从字符串的末尾开始，每三个字符一组添加到结果数组
  for (let i = numStr.length - 1; i >= 0; i -= 3) {
    // 如果不是起始位置，则添加逗号
    if (i > 0) {
      result.unshift(numStr.substring(i - 2, i + 1)) // 取当前位置前两个字符到当前位置的子串
    } else {
      result.unshift(numStr.substring(0, i + 1)) // 处理不足三位数的情况
    }
  }
  return result
}

/**
 * 组建树形权限菜单，依据后台返回的permRank，生成树形权限菜单
 * mscPerm排序说明：
 * mscPerm一共有3.5级权限。
 * 分别是：一级菜单;二级菜单;功能权限;功能子集，功能子集权限。
 * 排序的思路是，每个级别使用3位数(999)，一共12位数。
 * 排序按照正序进行，序号小的排在前面。
 * 总的规则是：一级菜单 * 1_000_000_000 + 二级菜单 * 1_000_000 + 功能权限 + 功能子集 * 1_000 + 功能子集权限;
 * @param menu 菜单值
 * @returns  返回树状权限菜单
 * @author qjh
 */
export const handleBuildPermTreeMenu = (menu: newMscMenuTreeVo[]) => {
  if (!menu || menu.length === 0) return []
  const data: MscMenu[] = []
  const merchantData: MscMenu[] = []
  // 正常一级菜单数据
  const allFirstNumberForNormal: number[] = []
  // 分销商、供应商一级菜单数据（合并成一个商户） 统称为商户
  const allFirstNumberForMerchant: number[] = []
  // 正常的菜单
  menu.forEach(item => {
    // 正常
    if (!item.permCode?.startsWith('/mch/')) {
      const permRankSplit = formatNumberToGroups(item.permRank!)
      const newFirstRank = Number(permRankSplit[0])
      if (!allFirstNumberForNormal.includes(newFirstRank)) {
        allFirstNumberForNormal.push(newFirstRank)
      }
    }
    // 商户
    if (item.permCode?.startsWith('/mch/')) {
      const permRankSplit = formatNumberToGroups(item.permRank!)
      const newFirstRank = Number(permRankSplit[0])
      if (!allFirstNumberForMerchant.includes(newFirstRank)) {
        allFirstNumberForMerchant.push(newFirstRank)
      }
    }
  })
  allFirstNumberForNormal.sort()
  allFirstNumberForMerchant.sort()
  // 正常的一级菜单
  allFirstNumberForNormal.forEach(item => {
    const target = menu.find(
      targetItem =>
        String(targetItem.permRank) === `${item}000000000` &&
        !targetItem.permCode?.startsWith('/mch/')
    )
    if (target) {
      data.push({ ...target, label: target.permName })
    }
  })
  // 正常的二级菜单
  data.forEach(item => {
    const rank = formatNumberToGroups(item.permRank!)[0]
    const targetArray = menu.filter(menuItem => {
      const splitRank = formatNumberToGroups(menuItem.permRank!)
      if (
        splitRank[0] === rank &&
        '000' === splitRank[2] &&
        '000' === splitRank[3] &&
        String(menuItem.permRank) !== `${rank}000000000` &&
        !menuItem.permCode?.startsWith('/mch/')
      ) {
        return true
      }
      return false
    })
    if (targetArray.length) {
      if (item.children) {
        targetArray.forEach(target =>
          item.children!.push({ ...target, label: target.permName })
        )
      } else {
        item.children = targetArray.map(target => {
          return {
            ...target,
            label: target.permName
          }
        })
      }
    }
  })
  // 正常的三级菜单
  data.forEach(item => {
    if (item.children && item.children.length) {
      item.children.forEach(subItem => {
        const rankGroup = formatNumberToGroups(subItem.permRank!)
        const rank1 = rankGroup[0]
        const rank2 = rankGroup[1]
        const targetArray = menu.filter(menuItem => {
          const splitRank = formatNumberToGroups(menuItem.permRank!)
          if (
            splitRank[0] === rank1 &&
            rank2 === splitRank[1] &&
            String(menuItem.permRank) !== `${rank1}${rank2}000000` &&
            ((splitRank[2] !== '000' && splitRank[3] === '000') ||
              (splitRank[2] === '000' && splitRank[3] !== '000')) &&
            !menuItem.permCode?.startsWith('/mch/')
          ) {
            return true
          }
          return false
        })
        if (targetArray.length) {
          // 补充3.5级权限
          targetArray.forEach(childItem => {
            const splitRank = formatNumberToGroups(childItem.permRank!)
            if (splitRank[2] !== '000' && splitRank[3] === '000') {
              const threeChild = menu.filter(menuItem => {
                const childRankGroup = formatNumberToGroups(menuItem.permRank!)
                if (
                  splitRank[0] === childRankGroup[0] &&
                  splitRank[1] === childRankGroup[1] &&
                  splitRank[2] === childRankGroup[2] &&
                  childRankGroup[3] !== '000' &&
                  !menuItem.permCode?.startsWith('/mch/')
                ) {
                  return true
                }
                return false
              })
              if (threeChild?.length) {
                threeChild.forEach(threeChildItem => {
                  if (childItem?.children) {
                    childItem.children.push({
                      ...threeChildItem,
                      label: threeChildItem.permName
                    })
                  } else {
                    childItem.children = [
                      { ...threeChildItem, label: threeChildItem.permName }
                    ]
                  }
                })
              }
            }
          })
          // 正常填充
          if (subItem.children) {
            targetArray.forEach(target =>
              subItem.children!.push({ ...target, label: target.permName })
            )
          } else {
            subItem.children = targetArray.map(target => {
              return {
                ...target,
                label: target.permName
              }
            })
          }
        }
      })
    }
  })

  if (allFirstNumberForMerchant?.length) {
    // 商户一级菜单
    allFirstNumberForMerchant.forEach(item => {
      const target = menu.find(
        targetItem =>
          String(targetItem.permRank) === `${item}000000000` &&
          targetItem.permCode?.startsWith('/mch/')
      )
      if (target) {
        merchantData.push({ ...target, label: target.permName })
      }
    })
    // 商户的二级菜单
    merchantData.forEach(item => {
      const rank = formatNumberToGroups(item.permRank!)[0]
      const targetArray = menu.filter(menuItem => {
        const splitRank = formatNumberToGroups(menuItem.permRank!)
        if (
          splitRank[0] === rank &&
          '000' === splitRank[2] &&
          '000' === splitRank[3] &&
          String(menuItem.permRank) !== `${rank}000000000` &&
          menuItem.permCode?.startsWith('/mch/')
        ) {
          return true
        }
        return false
      })
      if (targetArray.length) {
        if (item.children) {
          targetArray.forEach(target =>
            item.children!.push({ ...target, label: target.permName })
          )
        } else {
          item.children = targetArray.map(target => {
            return {
              ...target,
              label: target.permName
            }
          })
        }
      }
    })
    // 商户的三级菜单
    merchantData.forEach(item => {
      if (item.children && item.children.length) {
        item.children.forEach(subItem => {
          const rankGroup = formatNumberToGroups(subItem.permRank!)
          const rank1 = rankGroup[0]
          const rank2 = rankGroup[1]
          const targetArray = menu.filter(menuItem => {
            const splitRank = formatNumberToGroups(menuItem.permRank!)
            //  必须是接口
            if (
              splitRank[0] === rank1 &&
              rank2 === splitRank[1] &&
              String(menuItem.permRank) !== `${rank1}${rank2}000000` &&
              ((splitRank[2] !== '000' && splitRank[3] === '000') ||
                (splitRank[2] === '000' && splitRank[3] !== '000')) &&
              menuItem.permCode?.startsWith('/mch/')
            ) {
              return true
            }
            return false
          })
          if (targetArray.length) {
            // 补充3.5级权限
            targetArray.forEach(childItem => {
              const splitRank = formatNumberToGroups(childItem.permRank!)
              if (splitRank[2] !== '000' && splitRank[3] === '000') {
                const threeChild = menu.filter(menuItem => {
                  const childRankGroup = formatNumberToGroups(
                    menuItem.permRank!
                  )
                  if (
                    splitRank[0] === childRankGroup[0] &&
                    splitRank[1] === childRankGroup[1] &&
                    splitRank[2] === childRankGroup[2] &&
                    childRankGroup[3] !== '000' &&
                    menuItem.permCode?.startsWith('/mch/')
                  ) {
                    return true
                  }
                  return false
                })
                if (threeChild?.length) {
                  threeChild.forEach(threeChildItem => {
                    if (childItem?.children) {
                      childItem.children.push({
                        ...threeChildItem,
                        label: threeChildItem.permName
                      })
                    } else {
                      childItem.children = [
                        { ...threeChildItem, label: threeChildItem.permName }
                      ]
                    }
                  })
                }
              }
            })
            if (subItem.children) {
              targetArray.forEach(target =>
                subItem.children!.push({ ...target, label: target.permName })
              )
            } else {
              subItem.children = targetArray.map(target => {
                return {
                  ...target,
                  label: target.permName
                }
              })
            }
          }
        })
      }
    })
  }
  // 如果存在商户信息，就添加进去
  if (merchantData?.length) {
    merchantData.forEach(item => data.push(item))
  }
  return data
}

/**
 * 构建侧边菜单
 * @param menu 菜单原数据
 * @param isOwnHandRoutesAndShowInMenu 手动添加的路由数组
 * @param isHomePageRoutes 首页的路径数组
 * @returns 返回树状侧边栏菜单
 * @author qjh
 */
export const handleBuildSlideMenu = (
  menu: PermVo[],
  isOwnHandRoutesAndShowInMenu: RouteRecordRaw[],
  isHomePageRoutes: string[]
) => {
  const data: MenuType[] = []
  const allFirstNumber = [
    ...new Set(
      menu
        .map(item => Number(String(item.permRank).slice(0, -9)))
        .sort((a, b) => a - b)
    )
  ]
  // 一级菜单
  allFirstNumber.forEach(item => {
    const target = menu.find(
      targetItem => String(targetItem.permRank) === `${item}000000000`
    )
    if (target) {
      data.push(target)
    }
  })
  // 二级目录
  data.forEach(item => {
    const rank = formatNumberToGroups(item.permRank!)[0]
    const targetArray = menu.filter(menuItem => {
      const splitRank = formatNumberToGroups(menuItem.permRank!)
      if (
        splitRank[0] === rank &&
        '000' === splitRank[2] &&
        '000' === splitRank[3] &&
        String(menuItem.permRank) !== `${rank}000000000`
      ) {
        // 判断是否存在对应的list接口
        const hasListApiIndex = menu.findIndex(
          dataItem => dataItem.permCode === `${menuItem.permCode}/list:GET`
        )
        return hasListApiIndex > -1
      }
      return false
    })
    if (targetArray.length) {
      if (item.children) {
        targetArray.forEach(target => {
          if (!HIDE_MENU.includes(item.permCode!)) {
            item.children!.push(target)
          }
        })
      } else {
        item.children = targetArray.filter(target => {
          return !HIDE_MENU.includes(target.permCode!)
        })
      }
    }
  })
  // 处理首页的情况
  if (isHomePageRoutes?.length) {
    for (const item of isHomePageRoutes) {
      const ownHandRouteIndex = item.lastIndexOf('/')
      const targetIndex = data.findIndex(menuItem => {
        return menuItem.permCode === item.slice(0, ownHandRouteIndex)
      })
      if (targetIndex > -1) {
        data[targetIndex] = {
          permName: '首页',
          permCode: item,
          displayState: 1
        }
      }
    }
  }
  // 处理手动显示侧边菜单栏的情况
  if (isOwnHandRoutesAndShowInMenu?.length) {
    for (const item of isOwnHandRoutesAndShowInMenu) {
      if (isHomePageRoutes.includes(item.path)) {
        continue
      }
      const ownHandRouteIndex = item.path.lastIndexOf('/')
      const target = data.find(menuItem => {
        return menuItem.permCode === item.path.slice(0, ownHandRouteIndex)
      })
      if (target) {
        if (target.children) {
          target.children.push({
            permName: item.meta?.title as string,
            permCode: item.path,
            displayState: 1
          })
        } else {
          target.children = [
            {
              permName: item.meta?.title as string,
              permCode: item.path,
              displayState: 1
            }
          ]
        }
      }
    }
  }
  return data
}
