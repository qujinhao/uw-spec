import { usePrompt } from './usePrompt'
import { getT } from '@/i18n'

// useSimplifyPrompt入参类型配置
interface useSimplifyPromptType {
  message: string // 消息
  confirmCallBack?: (remark?: string) => void // 点击确认执行方法
  cancelCallBack?: () => void // 点击取消执行方法
}
/**
 * 基于usePrompt方法 简化 启用/禁用/修改等系列的操作
 */
export const useSimplifyPrompt = (config: useSimplifyPromptType) => {
  const t = getT()
  usePrompt({
    title: t('tip'),
    message: config.message,
    type: 'warning',
    confirmButtonText: t('confirm'),
    cancelButtonText: t('cancel'),
    inputType: 'textarea',
    inputErrorMessage: t('pleaseInput'),
    inputValidator: (value: string) => {
      if (value) {
        return true
      }
      return false
    },
    confirmCallBack: remark =>
      config.confirmCallBack && config.confirmCallBack(remark),
    cancelCallBack: () => config.cancelCallBack && config.cancelCallBack()
  })
}
