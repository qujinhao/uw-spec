<template>
  <view class="coupon_card_component">
    <view class="top">
      <view
        class="top_l"
        :class="{
          highlight: !notUse,
          notUse
        }"
      >
        <!-- 优惠券价格 -->
        <text class="icon">￥</text>
        <text class="price">{{ data.price }}</text>
      </view>
      <view class="top_c">
        <!-- 优惠券标题 -->
        <text
          class="title"
          :class="{ notUse }"
        >
          {{ data.title }}
        </text>
        <text
          v-if="data.desc"
          :class="{ notUse }"
          class="desc"
        >
          {{ data.desc }}
        </text>
      </view>
      <view class="top_r">
        <!-- 待使用状态 -->
        <button
          v-if="status === 'use'"
          class="use_btn"
          @click="$emit('onClick')"
        >
          立即使用
        </button>
        <view v-else>
          <!-- 已使用状态 -->
          <img
            class="status_img"
            v-if="status === 'used'"
            :src="usedImg"
            lazy-load
          />
          <!-- 已过期状态 -->
          <img
            class="status_img"
            v-if="status === 'expired'"
            :src="expiredImg"
            lazy-load
          />
        </view>
      </view>
    </view>
    <view class="bottom">
      <view class="bottom_t">
        <!-- 显示时间 -->
        <view class="time">{{ data.time }}</view>
        <view
          class="use_rules"
          :class="{ notUse }"
          @click="toShowRules"
        >
          详细规则
          <!-- <u-icon
            class="arrow"
            :name="rulesStates ? 'arrow-up' : 'arrow-down'"
          /> -->
          <uni-icons
            class="arrow"
            :type="rulesStates ? 'up' : 'down'"
          ></uni-icons>
          <!-- <Icon
            class="arrow"
            :name="rulesStates ? 'arrow-up' : 'arrow-down'"
          /> -->
        </view>
      </view>
      <!-- 使用规则 -->
      <view
        class="rules"
        :class="{ notUse }"
        v-show="rulesStates"
      >
        {{ data.rules }}
      </view>
    </view>
  </view>
</template>

<script lang="ts" setup>
import { ref, computed } from 'vue'

const props = defineProps<{
  status: string
  data: {
    title: string
    desc?: string
    time: string
    rules: string
    price: number
  }
}>()

// const emit = defineEmits(['onClick'])
const usedImg = 'https://qnimg.zowoyoo.com/img/84826/1612410966167.png'
const expiredImg = 'https://qnimg.zowoyoo.com/img/84826/1612410627671.png'
// const store = useStore()

const rulesStates = ref(false)

const notUse = computed(() => {
  return props.status !== 'use'
})

function toShowRules() {
  rulesStates.value = !rulesStates.value
}
</script>

<style lang="scss" scoped>
.coupon_card_component {
  display: flex;
  flex-direction: column;
  box-sizing: border-box;
  width: 93%;
  margin: 0 auto;
  min-height: 122.5px;
  padding: 17px 16px 0;
  background: #fff;
  box-shadow: 0 2px 6px 0 rgba(201, 201, 201, 0.3);
  border-radius: 10px;
  .highlight {
    color: #f47f02 !important;
  }
  .notUse {
    color: #aaa !important;
  }
  .top {
    display: flex;
    height: 66px;
    padding-bottom: 13px;
    border-bottom: 1px solid #f6f6f6;
    .top_l {
      flex: 1;
      display: flex;
      justify-content: center;
      align-items: center;
      width: 89px;
      border-right: 1px solid #f6f6f6;
      .icon {
        border: unset;
        display: flex;
        align-items: flex-end;
        height: 34px;
        margin-top: -6px;
        font-size: 15px;
        font-family: PingFang SC;
        font-weight: 500;
      }
      .price {
        line-height: 34px;
        font-size: 34px;
        font-weight: 800;
        font-family: PingFang SC;
      }
    }
    .top_c {
      display: flex;
      flex-direction: column;
      justify-content: center;
      padding-left: 13.5px;
      flex-grow: 1;
      flex: 3;
      .title {
        line-height: 17px;
        font-size: 17px;
        font-weight: 500;
        color: #28303a;
      }
      .desc {
        line-height: 13px;
        margin-top: 13.5px;
        font-size: 13px;
        color: #666;
      }
    }
    .top_r {
      flex: 1;
      display: flex;
      justify-content: center;
      align-items: center;
      width: 99px;
      transform: translateX(8px);
      button {
        border: unset;
      }
      .use_btn {
        width: 70px;
        height: 30px;
        line-height: 30px;
        font-size: 13px;
        color: #fff;
        background: linear-gradient(90deg, #fca172, #fb7030);
        border-radius: 15px;
        padding: 0;
        ::after {
          display: none;
        }
      }
      .status_img {
        width: 60px;
        height: 45px;
      }
    }
  }
  .bottom {
    padding: 10px 0;
    font-size: 13px;
    color: #999;
    .bottom_t {
      display: flex;
      justify-content: space-between;
      > .time {
        color: #bcbcbc;
      }
      .use_rules {
        .arrow {
          margin-left: 10px;
        }
      }
    }
    .rules {
      word-break: break-all;
      padding-top: 20px;
    }
  }
}
</style>
