// 自动导入当前文件夹的所有文件下多语言包
const ja = import.meta.glob(['./*', '!./index', '!./type.d.ts'], {
  import: 'default',
  eager: true
})

let i18nZh = {
  ...ja
}

for (const key in ja) {
  if (Object.prototype.hasOwnProperty.call(ja, key)) {
    const item = ja[key]
    i18nZh = Object.assign(i18nZh, item)
  }
}
export default i18nZh
