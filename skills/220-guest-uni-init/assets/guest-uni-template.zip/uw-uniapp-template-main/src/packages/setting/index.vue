<script lang="ts" setup>
import { ref } from 'vue'
import { onLoad } from '@dcloudio/uni-app'
import ZSetTitle from './components/ZSetTitle.vue'

import { useUserStore } from '@/store/user'

const userStore = useUserStore()

const settingArr = ref<any[]>([])

const handleClick = (item: any) => {
  console.log(item)
  uni.navigateTo({
    url: item.path
  })
}

const logOut = () => {
  uni.showModal({
    content: '确定要退出登录吗？',
    success: async (e) => {
      if (e.confirm) {
        userStore.LogOut()
      }
    }
  })
}

onLoad(() => {
  console.log('用户设置页 ---')

  settingArr.value = [
    {
      label: '个人资料',
      icon: 'user',
      path: '/packages/setting/userInfo'
    },
    {
      label: '账号与安全',
      icon: 'user',
      path: '/packages/setting/accountSafe'
    },
    {
      label: '地址管理',
      icon: 'user',
      path: '/packages/setting/addressManage'
    },
    {
      label: '我的优惠券',
      icon: 'user',
      path: '/packages/coupon/discounts'
    }
  ]
  // settingArr2.value = [
  //   {
  //     slotTxt: 'v1.0.0',
  //     label: '关于商城',
  //     icon: 'user',
  //     path: '/packages/setting/userInfo'
  //   },
  //   {
  //     label: '意见反馈',
  //     icon: 'user',
  //     path: '/packages/setting/accountSafe'
  //   }
  // ]
})
</script>

<template>
  <view class="user-setting">
    <ZSetTitle
      :list="settingArr"
      @click="handleClick"
    ></ZSetTitle>
    <!-- <ZSetTitle
      :list="settingArr2"
      @click="handleClick"
    ></ZSetTitle> -->

    <!-- <view class="theme-config flex-center">主题切换</view> -->
    <view
      class="login-out primary-color flex-center"
      @click="logOut()"
    >
      退出登录
    </view>
  </view>
</template>

<style lang="scss" scoped>
.user-setting {
  width: 100vw;
  height: 100vh;
  background-color: #f8f8f8;
  .theme-config,
  .login-out {
    padding: 30rpx;
    margin-top: 20rpx;
    background-color: #ffffff;
  }
}
</style>
