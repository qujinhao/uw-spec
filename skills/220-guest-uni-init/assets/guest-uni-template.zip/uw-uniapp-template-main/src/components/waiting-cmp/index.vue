<template>
  <view class="waiting flex-center">
    <view class="waiting-text">组件放置区域</view>
  </view>
</template>

<script lang="ts" setup></script>

<style lang="scss">
.waiting {
  width: 100%;
  height: 39px /*no*/;
  background-image: url('./waiting.jpg');

  .waiting-text {
    padding: 8px 30px /*no*/;
    background: #5487df;
    font-size: 12px /*no*/;
    color: #fff;
    pointer-events: none;
  }
}
</style>
