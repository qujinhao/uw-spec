// 定义语言国际化内容
import { createI18n } from 'vue-i18n'
import pinia from '../store'
import { useMainStore } from '../store/main'

export const messages = {}

// 引入i18n文件夹下所有集合index.ts文件
const modules: Record<string, any> = import.meta.glob(
  ['./*/index.ts', '!./*/type.ts', '!./type.d.ts'],
  {
    eager: true
  }
)

// https://vitejs.cn/vite3-cn/guide/features.html#glob-import
for (const path in modules) {
  const match = path.match(/\.\/([\w-]+)\//)
  const key = match ? match[1] : null //  取出文件夹名的 en、zh-cn、zh-tw ... 作为key
  // @ts-expect-error
  messages[key] = modules[path].default
}

const useI18n = () => {
  const mainStore = useMainStore(pinia)
  return createI18n({
    legacy: false, // 表示不使用 Vue 2 的传统 API，而是使用 Vue 3 的新 API。
    locale: mainStore.i18n || mainStore.curBrownerLang.toLocaleLowerCase(), // 默认使用本地存储语言标识 || 浏览器默认语言标识
    fallbackLocale: 'zh-CN', // 没有定义的文件包 默认使用中文
    messages
  })
}

// 导出类型已锁定的 t 函数，避免在使用处触发 createI18n 泛型递归推断 (TS2589)
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const getT = (): ((key: string, ...args: any[]) => string) => {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const instance = useI18n() as any
  return instance.global.t
}

export default useI18n
