<script lang="ts" setup>
import Icon from './Icon.vue'

export interface MenuType {
  label: string
  value: string | number
  icon?: string
}

const props = withDefaults(
  defineProps<{
    list: MenuType[]
  }>(),
  {
    list: () => []
  }
)

const emits = defineEmits<{
  (e: 'click', menu: MenuType): void
}>()

const ctm = ref<HTMLElement>()
const show = ref(false)
// 鼠标点击的 x 轴 y 轴
const place = reactive({
  x: '0px',
  y: '0px'
})

const contextmenu = (event: MouseEvent) => {
  if (event.clientX && event.clientY) {
    place.x = event.clientX + 20 + 'px'
    place.y = event.clientY + 20 + 'px'
  }
  show.value = true
}

const clickItem = (item: MenuType) => {
  show.value = false
  emits('click', item)
}
</script>

<template>
  <div
    ref="ctm"
    class="context-menu"
    @contextmenu.prevent="contextmenu"
  >
    <slot></slot>
  </div>
  <Transition name="context">
    <div
      class="context-menu__box"
      :style="{
        left: place.x,
        top: place.y
      }"
      v-if="show"
    >
      <div
        v-for="item in props.list"
        :key="item.value"
        class="context-menu__item cursor-p"
        @click="clickItem(item)"
      >
        <template v-if="item.icon">
          <Icon
            :icon-name="item.icon"
            :size="12"
          />
        </template>
        <span class="context-menu__name">{{ item.label }}</span>
      </div>
    </div>
  </Transition>
  <div
    v-if="show"
    class="context-menu__mask"
    @click.self="show = false"
    @contextmenu.prevent="show = false"
  ></div>
</template>

<style lang="scss" scoped>
.context-enter-active,
.context-leave-active {
  transition: all 0.15s ease-out;
}

.context-enter-from,
.context-leave-to {
  transform: scaleX(0.01);
  opacity: 0;
}

.context-menu {
  display: inline-block;
  margin: 0 2px;
}

.context-menu__box {
  position: fixed;
  z-index: 19999;
  padding: 2px 0;
  border-radius: 4px;
  overflow: hidden;
  box-shadow: 2px 2px 3px 0 rgba(0, 0, 0, 0.3);
  background-color: var(--el-bg-color-overlay);

  .context-menu__item {
    display: flex;
    align-items: center;
    padding: 8px 16px;
    font-size: 12px;
    transition: background-color 0.2s;
    color: var(--el-text-color-regular);

    &:hover {
      background: var(--el-color-primary-light-9);
      color: var(--el-color-primary);
    }

    .context-menu__name {
      margin-left: 4px;
    }
  }
}

.context-menu__mask {
  position: fixed;
  top: 0;
  left: 0;
  z-index: 19998;
  width: 100%;
  height: 100%;
  // background-color: rgba($color: #000000, $alpha: 0.1);
}
</style>
