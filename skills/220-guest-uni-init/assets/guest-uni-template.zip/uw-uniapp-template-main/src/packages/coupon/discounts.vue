<template>
  <GbLoading v-model="showLoading" />
  <view v-if="!showLoading">
    <up-sticky offset-top="0">
      <up-tabs
        :list="list"
        :scrollable="false"
        :activeStyle="{
          color: '#f58c1c'
        }"
        lineColor="#f58c1c"
        @click="handleTabChange"
      ></up-tabs>
    </up-sticky>
    <view
      class="coupon_list"
      v-if="couponData.length > 0"
    >
      <up-list
        :style="{
          height: `calc(100vh - 50px)`
        }"
        @scrolltolower="scrolltolower"
      >
        <up-list-item
          v-for="(item, index) in couponData"
          :key="index"
        >
          <view class="coupon_card_list">
            <CouponCard
              :status="couponStatus"
              :data="{
                title: item.couponInfo?.couponName as string,
                desc: item.couponInfo?.couponDesc,
                time: `${getDate(item.couponInfo?.startDate)} - ${getDate(item.couponInfo?.endDate)}` as string,
                rules: item.couponInfo?.couponDesc as string,
                price: item.couponInfo?.couponValue as number
              }"
            ></CouponCard>
          </view>
        </up-list-item>
        <up-loadmore :status="state.loading ? 'loading' : 'nomore'" />
      </up-list>
    </view>
    <view
      v-else
      class="not_coupon"
    >
      <img
        class="item-image"
        :src="img"
        lazy-load
      />
      <view class="item-text">你还没有该优惠券哦~</view>
      <button
        class="item-receive-btn"
        @click="navToUrl('/packages/coupon/center')"
      >
        去领券
      </button>
    </view>
  </view>
</template>

<script lang="ts" setup>
import { ref, reactive, onMounted, computed } from 'vue'
import {
  type GuestCouponEx,
  guestCouponInfoList
} from '@/api/saasMallAppGuestApi'
import CouponCard from './components/CouponCard/CouponCard.vue'
import GbLoading from '@/components/GbLoading/index.vue'
import { useUserStore } from '@/store/user'
import { navToUrl } from '@/utils/tool'
import { getDate } from '@/utils/coupon/tool'

const userStore = useUserStore()

// test data
//  {
//     title: '满100减50',
//     desc: '限时优惠',
//     time: '2021-08-01 00:00:00',
//     rules: '满100减50，仅限本店使用',
//     price: 50
//   },

const img = 'https://qnimg.zowoyoo.com/img/84826/1612420953106.png'
const couponData = ref<GuestCouponEx[]>([])
const showLoading = ref(true) // 是否显示加载

const list = reactive([
  { name: '待使用', value: 0 },
  { name: '已使用', value: 1 },
  { name: '已过期', value: 2 }
])

const state = reactive({
  $pg: 1,
  loading: false,
  current: 0
})

// 优惠券状态
const couponStatus = computed(() => {
  const statusMap = ['use', 'used', 'expired']
  return statusMap[state.current]
})

// 获取优惠券列表
const getGuestCouponInfoList = async () => {
  state.loading = true
  const res = await guestCouponInfoList({
    $pg: state.$pg,
    $rn: 10,
    guestId: userStore.userInfo.id,
    state: state.current
  })
  if (res.state === 'success') {
    if (res.data?.results) {
      couponData.value = [...couponData.value, ...res.data.results]
      state.$pg++
    }
  }
  state.loading = false
  showLoading.value = false
}
const scrolltolower = () => {
  getGuestCouponInfoList()
}

// tab切换
const handleTabChange = (item: any) => {
  state.current = item.index
  state.$pg = 1
  couponData.value = []
  getGuestCouponInfoList()
}

onMounted(() => {
  showLoading.value = true
  getGuestCouponInfoList()
})
</script>

<style lang="scss" scoped>
:deep(.u-sticky) {
  top: 0 !important;
}
:deep(.u-tabs__wrapper__nav) {
  background-color: #fff;
}
.coupon_list {
  .coupon_card_list {
    padding: 10rpx 0;
  }
}
.not_coupon {
  display: flex;
  flex-direction: column;
  align-content: center;
  height: 100%;
  padding-top: 30%;
  text-align: center;
  .item-image {
    width: 122.5;
    height: 105.5px;
    margin: 0 auto;
  }
  .item-text {
    margin: 11.5px 0 32px;
    color: #666;
    font-size: 14px;
    text-align: center;
  }
  button {
    background-color: #fff;
    margin: 0 auto;
    width: 110px;
    height: 33px;
    line-height: 33px;
    font-size: 14px;
    color: #f47f02;
    border: 1px solid #f47f02;
    border-radius: 7.5px;
    &::after {
      display: none;
    }
  }
}
</style>
