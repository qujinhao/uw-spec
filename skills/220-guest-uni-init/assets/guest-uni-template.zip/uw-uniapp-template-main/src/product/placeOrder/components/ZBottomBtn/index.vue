<script lang="ts" setup>
import { onMounted } from 'vue'

withDefaults(
  defineProps<{
    num?: number // 数量
    btnLoading?: boolean // 按钮loading
    priceTotal?: number
  }>(),
  {
    num: 1,
    priceTotal: 0,
    btnLoading: false
  }
)
const emits = defineEmits<{
  (e: 'click'): void
}>()
const submit = () => {
  emits('click')
}

onMounted(() => {
  console.log('createOrder-footer ---')
})
</script>

<template>
  <view class="createOrder-footer">
    <view class="createOrder-footer__priceBox color-white space-between">
      <view class="flex-row flex-align">
        <text class="price-box__paySum">合计</text>
        <view class="price-box__payPrice ml20">￥{{ priceTotal }}</view>
      </view>
    </view>
    <view class="flex-end flex-align">
      <text class="createOrder-footer__detailBtn mr20">
        明细
        <text class="iconfont r5"></text>
      </text>
      <view
        class="createOrder-footer__submitBtn"
        :disabled="btnLoading"
        :loading="btnLoading"
        @tap="submit"
      >
        提交订单
      </view>
    </view>
  </view>
</template>

<style lang="scss" scoped>
.createOrder-footer {
  position: fixed;
  left: 0;
  bottom: 0;
  z-index: 98;
  display: flex;
  align-items: center;
  width: 100%;
  justify-content: space-between;
  font-size: 30rpx;
  background-color: #fff;
  box-shadow: 0 -1px 5px rgba(0, 0, 0, 0.05);
  padding: 16rpx 20rpx calc(env(safe-area-inset-bottom) / 2 + 16rpx);
  box-sizing: border-box;
  &__priceBox {
    .price-box__paySum {
      color: #4a4a4a;
    }
    .price-box__payPrice {
      color: #f58c1c;
      font-size: 36rpx;
      font-weight: bold;
    }
  }
  &__detailBtn {
    color: #acacac;
  }
  &__submitBtn {
    color: #ffffff;
    background-color: #f58c1c;
    border-radius: 40rpx;
    padding: 10rpx 20rpx;
  }
}
</style>
