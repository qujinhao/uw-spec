import { UploadUserFile } from 'element-plus'
import { uploadFileUrl } from '@/components/UploadFile/type'
import { useMainStore } from '@/store/main'
/* ```js
 * formatDate();
 * formatDate(1603264465956);
 * formatDate(1603264465956, 'h:m:s');
 * formatDate(1603264465956, 'Y年M月D日');
 * ```
 */
export function formatDate(number: number, format = 'Y-M-D h:m:s'): string {
  if (!number) return ''

  // 数据转化
  function formatNumber(n: number): string {
    const str = n.toString()
    return str[1] ? str : '0' + str
  }

  const formateArr = ['Y', 'M', 'D', 'h', 'm', 's']
  const returnArr: any[] = []

  const date = new Date(number)

  returnArr.push(date.getFullYear())
  returnArr.push(formatNumber(date.getMonth() + 1))
  returnArr.push(formatNumber(date.getDate()))

  returnArr.push(formatNumber(date.getHours()))
  returnArr.push(formatNumber(date.getMinutes()))
  returnArr.push(formatNumber(date.getSeconds()))

  for (const i in returnArr) {
    format = format.replace(formateArr[i], returnArr[i])
  }
  return format
}

// 时间格式化带T传参给后端
export function formattedDateForParam(date: Date) {
  const year = date.getFullYear()
  const month = (date.getMonth() + 1).toString().padStart(2, '0')
  const day = date.getDate().toString().padStart(2, '0')
  const hour = date.getHours().toString().padStart(2, '0')
  const minute = date.getMinutes().toString().padStart(2, '0')
  const second = date.getSeconds().toString().padStart(2, '0')
  const formattedDate = `${year}-${month}-${day}T${hour}:${minute}:${second}`
  return formattedDate
}

// 字符串中划线转驼峰
export const formatToHump = (value: string) => {
  return value.replace(/-(\w)/g, (_, letter) => letter.toUpperCase())
}

// 过滤对象数据
export function removeProperty(obj: Record<string, any>) {
  Object.keys(obj).forEach(item => {
    if (obj[item] === '') {
      delete obj[item]
    }
  })
  return obj
}

/**
 * 设置CSS颜色变量
 * @param prop  颜色变量名 一般是--开头
 * @param val   颜色值
 * @param dom   作用范围，一般是全局css变量，可不传
 */
export const setCssVar = (
  prop: string,
  val: any,
  dom = document.documentElement
) => {
  dom.style.setProperty(prop, val)
}

/**
 * 判断是否文本溢出
 * @param e 事件对象
 * @returns  返回true为未溢出  false溢出
 */
export const isBeyond = (e: any) => {
  const ev = window.event || e // 浏览器兼容，最好写一下
  const textRange = (el: any) => {
    const textContent = el
    const targetW = textContent.getBoundingClientRect().width
    const range = document.createRange()
    range.setStart(textContent, 0)
    range.setEnd(textContent, textContent.childNodes.length)
    const rangeWidth = range.getBoundingClientRect().width
    return rangeWidth > targetW
  }
  return !textRange(ev.target) // target可以保证当前划过的dom节点一直保持是:el-tooltip__trigger
}

/**
 * 解决js计算精度问题 f:计算的价格 如: CalculationPrice(0.1+0.2)
 */
export function CalculationPrice(f: number): number {
  const num = Math.round(f * 100)
  return num / 100
}

/**
 * 数组元素交换位置
 * @param {array} arr 数组
 * @param {number} index1 添加项目的位置
 * @param {number} index2 删除项目的位置
 * index1和index2分别是两个数组的索引值，即是两个要交换元素位置的索引值，如1，5就是数组中下标为1和5的两个元素交换位置
 */
export function swapArray(arr: any[], index1: number, index2: number) {
  arr[index1] = arr.splice(index2, 1, arr[index1])[0]
  return arr
}

/**
 * 判断是否是JSON格式字符串
 * @param str
 * @returns
 */
export const isJSON = (str: any) => {
  if (typeof str === 'string') {
    try {
      JSON.parse(str)
      return true
    } catch (e) {
      console.log(e)
      return false
    }
  } else {
    return false
  }
}

/**
 * 深度克隆
 * @param value 任意值（被拷贝对象）
 * @returns 返回深度拷贝后值
 */
export const clone = <T>(value: T): T => {
  /** 空 */
  if (!value) return value
  /** 数组 */
  if (Array.isArray(value))
    return value.map(item => clone(item)) as unknown as T
  /** 日期 */
  if (value instanceof Date) return new Date(value) as unknown as T
  /** 普通对象 */
  if (typeof value === 'object') {
    return Object.fromEntries(
      Object.entries(value).map(([k, v]: [string, any]) => {
        return [k, clone(v)]
      })
    ) as unknown as T
  }
  /** 基本类型 */
  return value
}

/**
 * 字节转换为 M、G、T
 * @param size 需要被转换的数据
 * @param needUnit 是否需要返回单位
 */
export const convertBytes = (
  size: number,
  needUnit = true
): string | number => {
  if (!size) return ''
  const num = 1024.0 //byte
  if (size < num) return needUnit ? size + 'B' : size
  if (size < Math.pow(num, 2))
    return needUnit
      ? (size / num).toFixed(2) + 'K'
      : Number((size / num).toFixed(2)) //kb
  if (size < Math.pow(num, 3))
    return needUnit
      ? (size / Math.pow(num, 2)).toFixed(2) + 'M'
      : Number((size / Math.pow(num, 2)).toFixed(2)) //M
  if (size < Math.pow(num, 4))
    return needUnit
      ? (size / Math.pow(num, 3)).toFixed(2) + 'G'
      : Number(size / Math.pow(num, 3)) //G
  return needUnit
    ? (size / Math.pow(num, 4)).toFixed(2) + 'T'
    : Number((size / Math.pow(num, 4)).toFixed(2)) //T
}

/**
 *
 * @param str 要替换的字符串[xxx内容1]，a,b,c [xxx内容2]
 * @returns [xxx内容1， xxx内容2]
 */
export const extractContentFromBrackets = (str: string): string[] => {
  if (!str) return []
  /**
   * 使用正则表达式匹配字符串中所有形如 [任意内容] 的内容
   * 注意：这里使用了捕获组来提取方括号内的实际文本
   */
  const regex = /\[(.*?)\]/g
  // 使用matchAll迭代匹配结果，这将给出所有匹配项及其捕获组
  const matchesIterator = str.matchAll(regex)
  // 将匹配到的所有内容（即括号内的文本）收集到一个数组中
  const extractedContents: string[] = []
  for (const match of matchesIterator) {
    if (match.length > 1) {
      // 确保有捕获组匹配到内容
      extractedContents.push(match[1])
    }
  }
  return extractedContents
}
// 示例
// const exampleStr =
//   '您的IP[192.168.1.1]已经在[5]分钟内连续[3]次登录失败! 请[10]分钟后再试!'
// console.log(extractContentFromBrackets(exampleStr)) // 输出: ['192.168.1.1', '5', '3', '10']

/**
 *
 * @param i18nMsg t(接口返回的code)
 * @param resMsg 接口返回的msg信息
 * @returns 替换了占位符的msg信息
 */
export const replacePlaceholders = (
  i18nMsg: string,
  resMsg: string
): string => {
  const args = extractContentFromBrackets(resMsg)
  if (args.length === 0) return i18nMsg
  // 使用正则表达式匹配模板中的[%s]，并提供一个回调函数用于替换
  // @ts-expect-error
  return i18nMsg.replace(/\[%s\]/g, () => {
    // 确保args数组中有足够的元素供替换，如果没有则抛出错误或返回某个默认值
    if (args.length === 0) {
      throw new Error('Not enough arguments to replace placeholders')
    }
    // 从args数组中取出第一个元素用于替换，并移除它，确保下次迭代时不会重复使用
    return args.shift()
  })
}
// const replacedStr = replacePlaceholders(t('ERR-0013'), exampleStr)
// console.log(replacedStr)
// 输出对应国际化的msg: 您的IP[192.168.1.1]已经在[5]分钟内连续[3]次登录失败! 请[10]分钟后再试!

/**
 * 处理 Blob 文件流 下载
 * @param blob
 * @param name
 */
export const handleBlob = (
  blob: Blob,
  name: string,
  type = 'application/vnd.ms-excel;charset=utf-8'
) => {
  const data = new Blob([blob], {
    type
    // type: 'application/force-download' // zip
    // type: 'application/zip'
    // type: 'application/vnd.ms-excel'
    // type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
  })
  const downloadUrl = window.URL.createObjectURL(data)
  const anchor = document.createElement('a')
  anchor.href = downloadUrl
  anchor.download = `${name}` // 后缀需要重新定义
  anchor.click()
  window.URL.revokeObjectURL(downloadUrl)
}

/**
 * 暂停执行指定毫秒数的时间
 * 此函数通过返回一个Promise对象，该对象在指定的毫秒数后解决，从而实现异步的延迟
 *
 * @param ms {number} 需要暂停的毫秒数
 * @returns {Promise<void>} 没有返回值，Promise对象在指定时间后解决
 */
export const sleep = (ms = 500) => {
  return new Promise(resolve => {
    setTimeout(() => {
      resolve(null)
    }, ms)
  })
}

/**
 * 二进制转十进制
 * @param binaryString  二进制数据
 * @returns
 */
export const decimalNumberFn = (binaryString: string): number => {
  return parseInt(binaryString, 2)
}

/**
 * 十进制转二进制
 * @param binaryString  二进制数据
 * @returns
 */
export const decimalToBinary = (decimal: number): string => {
  return decimal.toString(2)
}

interface AreaNode {
  areaCode: string // 地区代码
  areaName: string // 地区名称
  children?: AreaNode[]
}

/**
 * 反向推导地区代码
 * @param tree
 * @param code
 * @returns
 */
export function findAreaPath(tree: AreaNode[], code: string): string[] | null {
  const dfs = (nodes: AreaNode[], path: string[]): string[] | null => {
    for (const node of nodes) {
      const cur = [...path, node.areaCode]
      if (node.areaCode === code) return cur
      if (node.children) {
        const hit = dfs(node.children, cur)
        if (hit) return hit
      }
    }
    return null
  }
  return dfs(tree, [])
}

/**
 * 根据最后一级地区代码，反查完整地区名称路径
 * @param tree  完整的地区树
 * @param code  最后一级地区代码
 * @returns     完整名称路径，如 ["北京市","市辖区","东城区"]；找不到返回 null
 */
export function findAreaLabelPath(
  tree: AreaNode[],
  code: string
): string[] | null {
  const dfs = (nodes: AreaNode[], path: string[]): string[] | null => {
    for (const node of nodes) {
      const cur = [...path, node.areaName]
      if (node.areaCode === code) return cur
      if (node.children) {
        const hit = dfs(node.children, cur)
        if (hit) return hit
      }
    }
    return null
  }
  return dfs(tree, [])
}

interface ImageFileInfo {
  name: string
  url: string
}

interface UploadedFileInfo {
  id: number
  realUrl: string
}

interface ImageFeedbackResult {
  fileByShow: ImageFileInfo[]
  fileByUpload: UploadedFileInfo[]
}

/**
 * 图片回显方法 - 将JSON格式的图片数据解析为显示和上传所需的格式
 * @param data JSON格式的图片数据，键为ID，值为URL
 * @returns 包含显示和上传格式的图片信息对象
 */
export const handleImageFeedBack = (data?: string): ImageFeedbackResult => {
  // 如果没有数据或不是有效的JSON格式，返回空数组
  if (!data || !isJSON(data)) {
    return {
      fileByShow: [],
      fileByUpload: []
    }
  }
  try {
    const result: Record<string, string> = JSON.parse(data)
    // 使用Object.entries同时获取键值对，提高代码可读性和性能
    const entries = Object.entries(result)
    // 过滤掉无效的URL
    const validEntries = entries.filter(
      ([_, url]) => url && typeof url === 'string'
    )
    // 构建显示用的文件信息数组
    const fileByShow: ImageFileInfo[] = validEntries.map(([_, url]) => ({
      name: url.split('/').pop() || '', // 使用pop替代slice(-1)[0]更直观
      url
    }))
    // 构建上传用的文件信息数组
    const fileByUpload: UploadedFileInfo[] = validEntries.map(([id, url]) => ({
      id: Number(id),
      realUrl: url
    }))
    return {
      fileByShow,
      fileByUpload
    }
  } catch (error) {
    console.warn('Failed to parse image feedback data:', error)
    return {
      fileByShow: [],
      fileByUpload: []
    }
  }
}

/* 获取CMs组件图片映射
 * 数据结构：创建一个包含 pc 和 wap 两个属性的对象 imageMap，分别存储 PC 和 WAP 端的图片。
 */
export const createCmsComponentImageMap = () => {
  // 获取所有 PNG 图片
  const images = import.meta.glob('@/assets/cmsComponent/*.png', {
    eager: true,
    import: 'default'
  })

  // 初始化 PC 和 WAP 图片的映射
  const imageMap: {
    pc: Record<string, string>
    wap: Record<string, string>
  } = {
    pc: {},
    wap: {}
  }

  // 转换为 { 文件名: URL } 格式
  Object.entries(images).forEach(([path, module]) => {
    const name = path.split('/').pop()?.replace('.png', '') || ''
    // 根据文件名判断是 PC 端还是 WAP 端
    if (name.startsWith('pc_')) {
      imageMap.pc[name.replace('pc_', '')] = module as string
    } else if (name.startsWith('wap_')) {
      imageMap.wap[name.replace('wap_', '')] = module as string
    }
  })
  console.log('imageMap', imageMap)
  return imageMap
}

/**
 * 格式化价格
 * @param price
 * @returns
 */
export const formatPrice = (price: number | undefined | null): string => {
  if (price === undefined || price === null) return '--'
  return price.toLocaleString('zh-CN', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  })
}

// ------------------统一格式 上传文件组件的图片回显处理------------- start
// 处理当前上传组件的图片回显
export const handleSingleUploadFileFeedBack = (
  imgMapData: Record<string, string>,
  fileListForShow: UploadUserFile[],
  fileListForUpload: uploadFileUrl[]
) => {
  Object.keys(imgMapData).forEach(key => {
    const realUrl = imgMapData[key]
    const fileName = realUrl.split('/').slice(-1)[0]
    fileListForShow.push({
      name: fileName,
      url: realUrl
    })
    fileListForUpload.push({
      id: Number(key),
      realUrl: realUrl
    })
  })
}

// 处理老saas的http图片数据
export const handleOldSaasImgDataFeedBack = (
  imgStrData: string,
  fileListForShow: UploadUserFile[],
  fileListForUpload: uploadFileUrl[]
) => {
  // 存在数据，但是是之前老saas的产品数据，图片格式异常需要处理
  // 老saas图片数据格式 "https://dimg04.c-ctrip.com/images/0104h1200082ks5fk1EC1.jpg,https://dimg04.c-ctrip.com/images/0102l120008b39l1lD096.jpg"
  const imgArray = imgStrData?.split(',') || []
  imgArray.forEach(item => {
    const fileName = item.split('/').slice(-1)[0]
    fileListForShow.push({
      name: fileName,
      url: item
    })
    fileListForUpload.push({
      id: Date.now(), // 老saas导过来的http链接没有上传记录ID，所以用时间戳标记
      realUrl: item
    })
  })
}

// 处理pc和wap的图片回显(兼容老saas)
export const handleImgPCandWapFeedBack = (
  imgData: string,
  fileListForShowPc: UploadUserFile[],
  fileListForUploadPc: uploadFileUrl[],
  fileListForShowWap: UploadUserFile[],
  fileListForUploadWap: uploadFileUrl[]
) => {
  if (isJSON(imgData)) {
    // imgData格式: "{\"pc\":{\"0\":\"0/poi_info/328571_3507.jpeg\",\"3616\":\"0/poi_info/328571_3616.jpg\"},\"wap\":{\"0\":\"0/poi_info/328571_3509.jpg\"}}"
    const imgMainData = JSON.parse(imgData)
    if (Object.prototype.toString.call(imgMainData.pc) === '[object Object]') {
      // pc端主图回显
      handleSingleUploadFileFeedBack(
        imgMainData.pc,
        fileListForShowPc,
        fileListForUploadPc
      )

      // wap端主图回显
      handleSingleUploadFileFeedBack(
        imgMainData.wap,
        fileListForShowWap,
        fileListForUploadWap
      )
    }
  } else if (imgData) {
    // imgData格式: "http://qnimg.zowoyoo.com/img/15463/1385177153222.jpg"
    // PC 老saas主图回显
    handleOldSaasImgDataFeedBack(
      imgData,
      fileListForShowPc,
      fileListForUploadPc
    )
    // wap 老saas主图回显
    handleOldSaasImgDataFeedBack(
      imgData,
      fileListForShowWap,
      fileListForUploadWap
    )
  }
}
// ------------------上传文件组件的图片回显处理------------- end

// ------------------上传组件内部的通用方法-----------------start
// 从URL提取文件ID
// url示例：https://yanshiqn.zowoyoo.com/8821909/poi_info/0_3663.jpg
// → {filePath: 8821909/poi_info/0_3663.jpg, id: 3663}
export const extractFileId = (
  fileUrl: string
): { filePath: string; id: number } | undefined => {
  const mainStore = useMainStore()
  const saasId = mainStore.loginInfo.saasId || 0
  const domain = mainStore.saasDomain || mainStore.sysDomain
  const url = fileUrl.replace(`${domain}`, '')
  // 兼容第三方同步过来的资源 只有本系统的资源才需要解绑或绑定
  if (!url.startsWith(`${saasId}/`)) return undefined
  const lastIndex = url.lastIndexOf('/')
  const id = Number(
    url
      .slice(lastIndex + 1)
      .split('.')[0]
      .split('_')[1]
  )
  if (isNaN(id)) return undefined // 增加对非法 ID 的判断
  return {
    filePath: url,
    id
  }
}
// 处理文件后缀
// 文件名示例：xxx.JPG→{lowerName:xxx， ext:jpg} 等
export const getLowerExtName = (fileName: string) => {
  const lastDotIndex = fileName.lastIndexOf('.')
  const nameWithoutExt = fileName.substring(0, lastDotIndex)
  //  文件后缀带.，并转换为小写
  const lowerExt = fileName.substring(lastDotIndex).toLowerCase()
  // 处理文件名，将后缀转换为小写
  const lowerFileName = nameWithoutExt + lowerExt
  return {
    lowerName: lowerFileName, // 文件名
    ext: lowerExt // 文件后缀
  }
}

/** 创建隐藏 input 并触发选择文件 */
export function pickFile(accept: string, onPick: (f: File) => void) {
  const input = document.createElement('input')
  input.type = 'file'
  input.accept = accept
  input.onchange = () => {
    const file = input.files?.[0]
    file && onPick(file)
    input.remove()
  }
  input.click()
}
// ------------------上传组件内部的通用方法-----------------end
