export default [
  {
    id: 1434,
    parentId: 1,
    areaName: '北京',
    areaPath: '中国,北京',
    areaCode: '100001100000000000',
    children: [
      {
        id: 3475,
        parentId: 1434,
        areaName: '北京市',
        areaPath: '中国,北京,北京市',
        areaCode: '100001100010000000',
        children: [
          {
            id: 9620,
            parentId: 3475,
            areaName: '东城区',
            areaPath: '中国,北京,北京市,东城区',
            areaCode: '100001100010010000'
          },
          {
            id: 9621,
            parentId: 3475,
            areaName: '西城区',
            areaPath: '中国,北京,北京市,西城区',
            areaCode: '100001100010020000'
          },
          {
            id: 9622,
            parentId: 3475,
            areaName: '朝阳区',
            areaPath: '中国,北京,北京市,朝阳区',
            areaCode: '100001100010050000'
          },
          {
            id: 9623,
            parentId: 3475,
            areaName: '丰台区',
            areaPath: '中国,北京,北京市,丰台区',
            areaCode: '100001100010060000'
          },
          {
            id: 9624,
            parentId: 3475,
            areaName: '石景山区',
            areaPath: '中国,北京,北京市,石景山区',
            areaCode: '100001100010070000'
          },
          {
            id: 9625,
            parentId: 3475,
            areaName: '海淀区',
            areaPath: '中国,北京,北京市,海淀区',
            areaCode: '100001100010080000'
          },
          {
            id: 9626,
            parentId: 3475,
            areaName: '门头沟区',
            areaPath: '中国,北京,北京市,门头沟区',
            areaCode: '100001100010090000'
          },
          {
            id: 9627,
            parentId: 3475,
            areaName: '房山区',
            areaPath: '中国,北京,北京市,房山区',
            areaCode: '100001100010110000'
          },
          {
            id: 9628,
            parentId: 3475,
            areaName: '通州区',
            areaPath: '中国,北京,北京市,通州区',
            areaCode: '100001100010120000'
          },
          {
            id: 9629,
            parentId: 3475,
            areaName: '顺义区',
            areaPath: '中国,北京,北京市,顺义区',
            areaCode: '100001100010130000'
          },
          {
            id: 9630,
            parentId: 3475,
            areaName: '昌平区',
            areaPath: '中国,北京,北京市,昌平区',
            areaCode: '100001100010140000'
          },
          {
            id: 9631,
            parentId: 3475,
            areaName: '大兴区',
            areaPath: '中国,北京,北京市,大兴区',
            areaCode: '100001100010150000'
          },
          {
            id: 9632,
            parentId: 3475,
            areaName: '怀柔区',
            areaPath: '中国,北京,北京市,怀柔区',
            areaCode: '100001100010160000'
          },
          {
            id: 9633,
            parentId: 3475,
            areaName: '平谷区',
            areaPath: '中国,北京,北京市,平谷区',
            areaCode: '100001100010170000'
          },
          {
            id: 9634,
            parentId: 3475,
            areaName: '密云区',
            areaPath: '中国,北京,北京市,密云区',
            areaCode: '100001100010180000'
          },
          {
            id: 9635,
            parentId: 3475,
            areaName: '延庆区',
            areaPath: '中国,北京,北京市,延庆区',
            areaCode: '100001100010190000'
          }
        ]
      }
    ]
  },
  {
    id: 1435,
    parentId: 1,
    areaName: '天津',
    areaPath: '中国,天津',
    areaCode: '100001200000000000',
    children: [
      {
        id: 3476,
        parentId: 1435,
        areaName: '天津市',
        areaPath: '中国,天津,天津市',
        areaCode: '100001200010000000',
        children: [
          {
            id: 9636,
            parentId: 3476,
            areaName: '和平区',
            areaPath: '中国,天津,天津市,和平区',
            areaCode: '100001200010010000'
          },
          {
            id: 9637,
            parentId: 3476,
            areaName: '河东区',
            areaPath: '中国,天津,天津市,河东区',
            areaCode: '100001200010020000'
          },
          {
            id: 9638,
            parentId: 3476,
            areaName: '河西区',
            areaPath: '中国,天津,天津市,河西区',
            areaCode: '100001200010030000'
          },
          {
            id: 9639,
            parentId: 3476,
            areaName: '南开区',
            areaPath: '中国,天津,天津市,南开区',
            areaCode: '100001200010040000'
          },
          {
            id: 9640,
            parentId: 3476,
            areaName: '河北区',
            areaPath: '中国,天津,天津市,河北区',
            areaCode: '100001200010050000'
          },
          {
            id: 9641,
            parentId: 3476,
            areaName: '红桥区',
            areaPath: '中国,天津,天津市,红桥区',
            areaCode: '100001200010060000'
          },
          {
            id: 9642,
            parentId: 3476,
            areaName: '东丽区',
            areaPath: '中国,天津,天津市,东丽区',
            areaCode: '100001200010100000'
          },
          {
            id: 9643,
            parentId: 3476,
            areaName: '西青区',
            areaPath: '中国,天津,天津市,西青区',
            areaCode: '100001200010110000'
          },
          {
            id: 9644,
            parentId: 3476,
            areaName: '津南区',
            areaPath: '中国,天津,天津市,津南区',
            areaCode: '100001200010120000'
          },
          {
            id: 9645,
            parentId: 3476,
            areaName: '北辰区',
            areaPath: '中国,天津,天津市,北辰区',
            areaCode: '100001200010130000'
          },
          {
            id: 9646,
            parentId: 3476,
            areaName: '武清区',
            areaPath: '中国,天津,天津市,武清区',
            areaCode: '100001200010140000'
          },
          {
            id: 9647,
            parentId: 3476,
            areaName: '宝坻区',
            areaPath: '中国,天津,天津市,宝坻区',
            areaCode: '100001200010150000'
          },
          {
            id: 9648,
            parentId: 3476,
            areaName: '滨海新区',
            areaPath: '中国,天津,天津市,滨海新区',
            areaCode: '100001200010160000'
          },
          {
            id: 9649,
            parentId: 3476,
            areaName: '宁河区',
            areaPath: '中国,天津,天津市,宁河区',
            areaCode: '100001200010170000'
          },
          {
            id: 9650,
            parentId: 3476,
            areaName: '静海区',
            areaPath: '中国,天津,天津市,静海区',
            areaCode: '100001200010180000'
          },
          {
            id: 9651,
            parentId: 3476,
            areaName: '蓟州区',
            areaPath: '中国,天津,天津市,蓟州区',
            areaCode: '100001200010190000'
          }
        ]
      }
    ]
  },
  {
    id: 1436,
    parentId: 1,
    areaName: '河北省',
    areaPath: '中国,河北省',
    areaCode: '100001300000000000',
    children: [
      {
        id: 3477,
        parentId: 1436,
        areaName: '石家庄市',
        areaPath: '中国,河北省,石家庄市',
        areaCode: '100001300010000000',
        children: [
          {
            id: 9652,
            parentId: 3477,
            areaName: '长安区',
            areaPath: '中国,河北省,石家庄市,长安区',
            areaCode: '100001300010020000'
          },
          {
            id: 9653,
            parentId: 3477,
            areaName: '桥西区',
            areaPath: '中国,河北省,石家庄市,桥西区',
            areaCode: '100001300010040000'
          },
          {
            id: 9654,
            parentId: 3477,
            areaName: '新华区',
            areaPath: '中国,河北省,石家庄市,新华区',
            areaCode: '100001300010050000'
          },
          {
            id: 9655,
            parentId: 3477,
            areaName: '井陉矿区',
            areaPath: '中国,河北省,石家庄市,井陉矿区',
            areaCode: '100001300010070000'
          },
          {
            id: 9656,
            parentId: 3477,
            areaName: '裕华区',
            areaPath: '中国,河北省,石家庄市,裕华区',
            areaCode: '100001300010080000'
          },
          {
            id: 9657,
            parentId: 3477,
            areaName: '藁城区',
            areaPath: '中国,河北省,石家庄市,藁城区',
            areaCode: '100001300010090000'
          },
          {
            id: 9658,
            parentId: 3477,
            areaName: '鹿泉区',
            areaPath: '中国,河北省,石家庄市,鹿泉区',
            areaCode: '100001300010100000'
          },
          {
            id: 9659,
            parentId: 3477,
            areaName: '栾城区',
            areaPath: '中国,河北省,石家庄市,栾城区',
            areaCode: '100001300010110000'
          },
          {
            id: 9660,
            parentId: 3477,
            areaName: '井陉县',
            areaPath: '中国,河北省,石家庄市,井陉县',
            areaCode: '100001300010210000'
          },
          {
            id: 9661,
            parentId: 3477,
            areaName: '正定县',
            areaPath: '中国,河北省,石家庄市,正定县',
            areaCode: '100001300010230000'
          },
          {
            id: 9662,
            parentId: 3477,
            areaName: '行唐县',
            areaPath: '中国,河北省,石家庄市,行唐县',
            areaCode: '100001300010250000'
          },
          {
            id: 9663,
            parentId: 3477,
            areaName: '灵寿县',
            areaPath: '中国,河北省,石家庄市,灵寿县',
            areaCode: '100001300010260000'
          },
          {
            id: 9664,
            parentId: 3477,
            areaName: '高邑县',
            areaPath: '中国,河北省,石家庄市,高邑县',
            areaCode: '100001300010270000'
          },
          {
            id: 9665,
            parentId: 3477,
            areaName: '深泽县',
            areaPath: '中国,河北省,石家庄市,深泽县',
            areaCode: '100001300010280000'
          },
          {
            id: 9666,
            parentId: 3477,
            areaName: '赞皇县',
            areaPath: '中国,河北省,石家庄市,赞皇县',
            areaCode: '100001300010290000'
          },
          {
            id: 9667,
            parentId: 3477,
            areaName: '无极县',
            areaPath: '中国,河北省,石家庄市,无极县',
            areaCode: '100001300010300000'
          },
          {
            id: 9668,
            parentId: 3477,
            areaName: '平山县',
            areaPath: '中国,河北省,石家庄市,平山县',
            areaCode: '100001300010310000'
          },
          {
            id: 9669,
            parentId: 3477,
            areaName: '元氏县',
            areaPath: '中国,河北省,石家庄市,元氏县',
            areaCode: '100001300010320000'
          },
          {
            id: 9670,
            parentId: 3477,
            areaName: '赵县',
            areaPath: '中国,河北省,石家庄市,赵县',
            areaCode: '100001300010330000'
          },
          {
            id: 9671,
            parentId: 3477,
            areaName: '辛集市',
            areaPath: '中国,河北省,石家庄市,辛集市',
            areaCode: '100001300010810000'
          },
          {
            id: 9672,
            parentId: 3477,
            areaName: '晋州市',
            areaPath: '中国,河北省,石家庄市,晋州市',
            areaCode: '100001300010830000'
          },
          {
            id: 9673,
            parentId: 3477,
            areaName: '新乐市',
            areaPath: '中国,河北省,石家庄市,新乐市',
            areaCode: '100001300010840000'
          }
        ]
      },
      {
        id: 3478,
        parentId: 1436,
        areaName: '唐山市',
        areaPath: '中国,河北省,唐山市',
        areaCode: '100001300020000000',
        children: [
          {
            id: 9674,
            parentId: 3478,
            areaName: '路南区',
            areaPath: '中国,河北省,唐山市,路南区',
            areaCode: '100001300020020000'
          },
          {
            id: 9675,
            parentId: 3478,
            areaName: '路北区',
            areaPath: '中国,河北省,唐山市,路北区',
            areaCode: '100001300020030000'
          },
          {
            id: 9676,
            parentId: 3478,
            areaName: '古冶区',
            areaPath: '中国,河北省,唐山市,古冶区',
            areaCode: '100001300020040000'
          },
          {
            id: 9677,
            parentId: 3478,
            areaName: '开平区',
            areaPath: '中国,河北省,唐山市,开平区',
            areaCode: '100001300020050000'
          },
          {
            id: 9678,
            parentId: 3478,
            areaName: '丰南区',
            areaPath: '中国,河北省,唐山市,丰南区',
            areaCode: '100001300020070000'
          },
          {
            id: 9679,
            parentId: 3478,
            areaName: '丰润区',
            areaPath: '中国,河北省,唐山市,丰润区',
            areaCode: '100001300020080000'
          },
          {
            id: 9680,
            parentId: 3478,
            areaName: '曹妃甸区',
            areaPath: '中国,河北省,唐山市,曹妃甸区',
            areaCode: '100001300020090000'
          },
          {
            id: 9681,
            parentId: 3478,
            areaName: '滦县',
            areaPath: '中国,河北省,唐山市,滦县',
            areaCode: '100001300020230000'
          },
          {
            id: 9682,
            parentId: 3478,
            areaName: '滦南县',
            areaPath: '中国,河北省,唐山市,滦南县',
            areaCode: '100001300020240000'
          },
          {
            id: 9683,
            parentId: 3478,
            areaName: '乐亭县',
            areaPath: '中国,河北省,唐山市,乐亭县',
            areaCode: '100001300020250000'
          },
          {
            id: 9684,
            parentId: 3478,
            areaName: '迁西县',
            areaPath: '中国,河北省,唐山市,迁西县',
            areaCode: '100001300020270000'
          },
          {
            id: 9685,
            parentId: 3478,
            areaName: '玉田县',
            areaPath: '中国,河北省,唐山市,玉田县',
            areaCode: '100001300020290000'
          },
          {
            id: 9686,
            parentId: 3478,
            areaName: '遵化市',
            areaPath: '中国,河北省,唐山市,遵化市',
            areaCode: '100001300020810000'
          },
          {
            id: 9687,
            parentId: 3478,
            areaName: '迁安市',
            areaPath: '中国,河北省,唐山市,迁安市',
            areaCode: '100001300020830000'
          }
        ]
      },
      {
        id: 3479,
        parentId: 1436,
        areaName: '秦皇岛市',
        areaPath: '中国,河北省,秦皇岛市',
        areaCode: '100001300030000000',
        children: [
          {
            id: 9688,
            parentId: 3479,
            areaName: '海港区',
            areaPath: '中国,河北省,秦皇岛市,海港区',
            areaCode: '100001300030020000'
          },
          {
            id: 9689,
            parentId: 3479,
            areaName: '山海关区',
            areaPath: '中国,河北省,秦皇岛市,山海关区',
            areaCode: '100001300030030000'
          },
          {
            id: 9690,
            parentId: 3479,
            areaName: '北戴河区',
            areaPath: '中国,河北省,秦皇岛市,北戴河区',
            areaCode: '100001300030040000'
          },
          {
            id: 9691,
            parentId: 3479,
            areaName: '抚宁区',
            areaPath: '中国,河北省,秦皇岛市,抚宁区',
            areaCode: '100001300030060000'
          },
          {
            id: 9692,
            parentId: 3479,
            areaName: '青龙满族自治县',
            areaPath: '中国,河北省,秦皇岛市,青龙满族自治县',
            areaCode: '100001300030210000'
          },
          {
            id: 9693,
            parentId: 3479,
            areaName: '昌黎县',
            areaPath: '中国,河北省,秦皇岛市,昌黎县',
            areaCode: '100001300030220000'
          },
          {
            id: 9694,
            parentId: 3479,
            areaName: '卢龙县',
            areaPath: '中国,河北省,秦皇岛市,卢龙县',
            areaCode: '100001300030240000'
          }
        ]
      },
      {
        id: 3480,
        parentId: 1436,
        areaName: '邯郸市',
        areaPath: '中国,河北省,邯郸市',
        areaCode: '100001300040000000',
        children: [
          {
            id: 9695,
            parentId: 3480,
            areaName: '邯山区',
            areaPath: '中国,河北省,邯郸市,邯山区',
            areaCode: '100001300040020000'
          },
          {
            id: 9696,
            parentId: 3480,
            areaName: '丛台区',
            areaPath: '中国,河北省,邯郸市,丛台区',
            areaCode: '100001300040030000'
          },
          {
            id: 9697,
            parentId: 3480,
            areaName: '复兴区',
            areaPath: '中国,河北省,邯郸市,复兴区',
            areaCode: '100001300040040000'
          },
          {
            id: 9698,
            parentId: 3480,
            areaName: '峰峰矿区',
            areaPath: '中国,河北省,邯郸市,峰峰矿区',
            areaCode: '100001300040060000'
          },
          {
            id: 9699,
            parentId: 3480,
            areaName: '肥乡区',
            areaPath: '中国,河北省,邯郸市,肥乡区',
            areaCode: '100001300040070000'
          },
          {
            id: 9700,
            parentId: 3480,
            areaName: '永年区',
            areaPath: '中国,河北省,邯郸市,永年区',
            areaCode: '100001300040080000'
          },
          {
            id: 9701,
            parentId: 3480,
            areaName: '临漳县',
            areaPath: '中国,河北省,邯郸市,临漳县',
            areaCode: '100001300040230000'
          },
          {
            id: 9702,
            parentId: 3480,
            areaName: '成安县',
            areaPath: '中国,河北省,邯郸市,成安县',
            areaCode: '100001300040240000'
          },
          {
            id: 9703,
            parentId: 3480,
            areaName: '大名县',
            areaPath: '中国,河北省,邯郸市,大名县',
            areaCode: '100001300040250000'
          },
          {
            id: 9704,
            parentId: 3480,
            areaName: '涉县',
            areaPath: '中国,河北省,邯郸市,涉县',
            areaCode: '100001300040260000'
          },
          {
            id: 9705,
            parentId: 3480,
            areaName: '磁县',
            areaPath: '中国,河北省,邯郸市,磁县',
            areaCode: '100001300040270000'
          },
          {
            id: 9706,
            parentId: 3480,
            areaName: '邱县',
            areaPath: '中国,河北省,邯郸市,邱县',
            areaCode: '100001300040300000'
          },
          {
            id: 9707,
            parentId: 3480,
            areaName: '鸡泽县',
            areaPath: '中国,河北省,邯郸市,鸡泽县',
            areaCode: '100001300040310000'
          },
          {
            id: 9708,
            parentId: 3480,
            areaName: '广平县',
            areaPath: '中国,河北省,邯郸市,广平县',
            areaCode: '100001300040320000'
          },
          {
            id: 9709,
            parentId: 3480,
            areaName: '馆陶县',
            areaPath: '中国,河北省,邯郸市,馆陶县',
            areaCode: '100001300040330000'
          },
          {
            id: 9710,
            parentId: 3480,
            areaName: '魏县',
            areaPath: '中国,河北省,邯郸市,魏县',
            areaCode: '100001300040340000'
          },
          {
            id: 9711,
            parentId: 3480,
            areaName: '曲周县',
            areaPath: '中国,河北省,邯郸市,曲周县',
            areaCode: '100001300040350000'
          },
          {
            id: 9712,
            parentId: 3480,
            areaName: '武安市',
            areaPath: '中国,河北省,邯郸市,武安市',
            areaCode: '100001300040810000'
          }
        ]
      },
      {
        id: 3481,
        parentId: 1436,
        areaName: '邢台市',
        areaPath: '中国,河北省,邢台市',
        areaCode: '100001300050000000',
        children: [
          {
            id: 9713,
            parentId: 3481,
            areaName: '桥东区',
            areaPath: '中国,河北省,邢台市,桥东区',
            areaCode: '100001300050020000'
          },
          {
            id: 9714,
            parentId: 3481,
            areaName: '桥西区',
            areaPath: '中国,河北省,邢台市,桥西区',
            areaCode: '100001300050030000'
          },
          {
            id: 9715,
            parentId: 3481,
            areaName: '邢台县',
            areaPath: '中国,河北省,邢台市,邢台县',
            areaCode: '100001300050210000'
          },
          {
            id: 9716,
            parentId: 3481,
            areaName: '临城县',
            areaPath: '中国,河北省,邢台市,临城县',
            areaCode: '100001300050220000'
          },
          {
            id: 9717,
            parentId: 3481,
            areaName: '内丘县',
            areaPath: '中国,河北省,邢台市,内丘县',
            areaCode: '100001300050230000'
          },
          {
            id: 9718,
            parentId: 3481,
            areaName: '柏乡县',
            areaPath: '中国,河北省,邢台市,柏乡县',
            areaCode: '100001300050240000'
          },
          {
            id: 9719,
            parentId: 3481,
            areaName: '隆尧县',
            areaPath: '中国,河北省,邢台市,隆尧县',
            areaCode: '100001300050250000'
          },
          {
            id: 9720,
            parentId: 3481,
            areaName: '任县',
            areaPath: '中国,河北省,邢台市,任县',
            areaCode: '100001300050260000'
          },
          {
            id: 9721,
            parentId: 3481,
            areaName: '南和县',
            areaPath: '中国,河北省,邢台市,南和县',
            areaCode: '100001300050270000'
          },
          {
            id: 9722,
            parentId: 3481,
            areaName: '宁晋县',
            areaPath: '中国,河北省,邢台市,宁晋县',
            areaCode: '100001300050280000'
          },
          {
            id: 9723,
            parentId: 3481,
            areaName: '巨鹿县',
            areaPath: '中国,河北省,邢台市,巨鹿县',
            areaCode: '100001300050290000'
          },
          {
            id: 9724,
            parentId: 3481,
            areaName: '新河县',
            areaPath: '中国,河北省,邢台市,新河县',
            areaCode: '100001300050300000'
          },
          {
            id: 9725,
            parentId: 3481,
            areaName: '广宗县',
            areaPath: '中国,河北省,邢台市,广宗县',
            areaCode: '100001300050310000'
          },
          {
            id: 9726,
            parentId: 3481,
            areaName: '平乡县',
            areaPath: '中国,河北省,邢台市,平乡县',
            areaCode: '100001300050320000'
          },
          {
            id: 9727,
            parentId: 3481,
            areaName: '威县',
            areaPath: '中国,河北省,邢台市,威县',
            areaCode: '100001300050330000'
          },
          {
            id: 9728,
            parentId: 3481,
            areaName: '清河县',
            areaPath: '中国,河北省,邢台市,清河县',
            areaCode: '100001300050340000'
          },
          {
            id: 9729,
            parentId: 3481,
            areaName: '临西县',
            areaPath: '中国,河北省,邢台市,临西县',
            areaCode: '100001300050350000'
          },
          {
            id: 9730,
            parentId: 3481,
            areaName: '南宫市',
            areaPath: '中国,河北省,邢台市,南宫市',
            areaCode: '100001300050810000'
          },
          {
            id: 9731,
            parentId: 3481,
            areaName: '沙河市',
            areaPath: '中国,河北省,邢台市,沙河市',
            areaCode: '100001300050820000'
          }
        ]
      },
      {
        id: 3482,
        parentId: 1436,
        areaName: '保定市',
        areaPath: '中国,河北省,保定市',
        areaCode: '100001300060000000',
        children: [
          {
            id: 9732,
            parentId: 3482,
            areaName: '竞秀区',
            areaPath: '中国,河北省,保定市,竞秀区',
            areaCode: '100001300060020000'
          },
          {
            id: 9733,
            parentId: 3482,
            areaName: '莲池区',
            areaPath: '中国,河北省,保定市,莲池区',
            areaCode: '100001300060060000'
          },
          {
            id: 9734,
            parentId: 3482,
            areaName: '满城区',
            areaPath: '中国,河北省,保定市,满城区',
            areaCode: '100001300060070000'
          },
          {
            id: 9735,
            parentId: 3482,
            areaName: '清苑区',
            areaPath: '中国,河北省,保定市,清苑区',
            areaCode: '100001300060080000'
          },
          {
            id: 9736,
            parentId: 3482,
            areaName: '徐水区',
            areaPath: '中国,河北省,保定市,徐水区',
            areaCode: '100001300060090000'
          },
          {
            id: 9737,
            parentId: 3482,
            areaName: '涞水县',
            areaPath: '中国,河北省,保定市,涞水县',
            areaCode: '100001300060230000'
          },
          {
            id: 9738,
            parentId: 3482,
            areaName: '阜平县',
            areaPath: '中国,河北省,保定市,阜平县',
            areaCode: '100001300060240000'
          },
          {
            id: 9739,
            parentId: 3482,
            areaName: '定兴县',
            areaPath: '中国,河北省,保定市,定兴县',
            areaCode: '100001300060260000'
          },
          {
            id: 9740,
            parentId: 3482,
            areaName: '唐县',
            areaPath: '中国,河北省,保定市,唐县',
            areaCode: '100001300060270000'
          },
          {
            id: 9741,
            parentId: 3482,
            areaName: '高阳县',
            areaPath: '中国,河北省,保定市,高阳县',
            areaCode: '100001300060280000'
          },
          {
            id: 9742,
            parentId: 3482,
            areaName: '容城县',
            areaPath: '中国,河北省,保定市,容城县',
            areaCode: '100001300060290000'
          },
          {
            id: 9743,
            parentId: 3482,
            areaName: '涞源县',
            areaPath: '中国,河北省,保定市,涞源县',
            areaCode: '100001300060300000'
          },
          {
            id: 9744,
            parentId: 3482,
            areaName: '望都县',
            areaPath: '中国,河北省,保定市,望都县',
            areaCode: '100001300060310000'
          },
          {
            id: 9745,
            parentId: 3482,
            areaName: '安新县',
            areaPath: '中国,河北省,保定市,安新县',
            areaCode: '100001300060320000'
          },
          {
            id: 9746,
            parentId: 3482,
            areaName: '易县',
            areaPath: '中国,河北省,保定市,易县',
            areaCode: '100001300060330000'
          },
          {
            id: 9747,
            parentId: 3482,
            areaName: '曲阳县',
            areaPath: '中国,河北省,保定市,曲阳县',
            areaCode: '100001300060340000'
          },
          {
            id: 9748,
            parentId: 3482,
            areaName: '蠡县',
            areaPath: '中国,河北省,保定市,蠡县',
            areaCode: '100001300060350000'
          },
          {
            id: 9749,
            parentId: 3482,
            areaName: '顺平县',
            areaPath: '中国,河北省,保定市,顺平县',
            areaCode: '100001300060360000'
          },
          {
            id: 9750,
            parentId: 3482,
            areaName: '博野县',
            areaPath: '中国,河北省,保定市,博野县',
            areaCode: '100001300060370000'
          },
          {
            id: 9751,
            parentId: 3482,
            areaName: '雄县',
            areaPath: '中国,河北省,保定市,雄县',
            areaCode: '100001300060380000'
          },
          {
            id: 9752,
            parentId: 3482,
            areaName: '涿州市',
            areaPath: '中国,河北省,保定市,涿州市',
            areaCode: '100001300060810000'
          },
          {
            id: 9753,
            parentId: 3482,
            areaName: '定州市',
            areaPath: '中国,河北省,保定市,定州市',
            areaCode: '100001300060820000'
          },
          {
            id: 9754,
            parentId: 3482,
            areaName: '安国市',
            areaPath: '中国,河北省,保定市,安国市',
            areaCode: '100001300060830000'
          },
          {
            id: 9755,
            parentId: 3482,
            areaName: '高碑店市',
            areaPath: '中国,河北省,保定市,高碑店市',
            areaCode: '100001300060840000'
          }
        ]
      },
      {
        id: 3483,
        parentId: 1436,
        areaName: '张家口市',
        areaPath: '中国,河北省,张家口市',
        areaCode: '100001300070000000',
        children: [
          {
            id: 9756,
            parentId: 3483,
            areaName: '桥东区',
            areaPath: '中国,河北省,张家口市,桥东区',
            areaCode: '100001300070020000'
          },
          {
            id: 9757,
            parentId: 3483,
            areaName: '桥西区',
            areaPath: '中国,河北省,张家口市,桥西区',
            areaCode: '100001300070030000'
          },
          {
            id: 9758,
            parentId: 3483,
            areaName: '宣化区',
            areaPath: '中国,河北省,张家口市,宣化区',
            areaCode: '100001300070050000'
          },
          {
            id: 9759,
            parentId: 3483,
            areaName: '下花园区',
            areaPath: '中国,河北省,张家口市,下花园区',
            areaCode: '100001300070060000'
          },
          {
            id: 9760,
            parentId: 3483,
            areaName: '万全区',
            areaPath: '中国,河北省,张家口市,万全区',
            areaCode: '100001300070080000'
          },
          {
            id: 9761,
            parentId: 3483,
            areaName: '崇礼区',
            areaPath: '中国,河北省,张家口市,崇礼区',
            areaCode: '100001300070090000'
          },
          {
            id: 9762,
            parentId: 3483,
            areaName: '张北县',
            areaPath: '中国,河北省,张家口市,张北县',
            areaCode: '100001300070220000'
          },
          {
            id: 9763,
            parentId: 3483,
            areaName: '康保县',
            areaPath: '中国,河北省,张家口市,康保县',
            areaCode: '100001300070230000'
          },
          {
            id: 9764,
            parentId: 3483,
            areaName: '沽源县',
            areaPath: '中国,河北省,张家口市,沽源县',
            areaCode: '100001300070240000'
          },
          {
            id: 9765,
            parentId: 3483,
            areaName: '尚义县',
            areaPath: '中国,河北省,张家口市,尚义县',
            areaCode: '100001300070250000'
          },
          {
            id: 9766,
            parentId: 3483,
            areaName: '蔚县',
            areaPath: '中国,河北省,张家口市,蔚县',
            areaCode: '100001300070260000'
          },
          {
            id: 9767,
            parentId: 3483,
            areaName: '阳原县',
            areaPath: '中国,河北省,张家口市,阳原县',
            areaCode: '100001300070270000'
          },
          {
            id: 9768,
            parentId: 3483,
            areaName: '怀安县',
            areaPath: '中国,河北省,张家口市,怀安县',
            areaCode: '100001300070280000'
          },
          {
            id: 9769,
            parentId: 3483,
            areaName: '怀来县',
            areaPath: '中国,河北省,张家口市,怀来县',
            areaCode: '100001300070300000'
          },
          {
            id: 9770,
            parentId: 3483,
            areaName: '涿鹿县',
            areaPath: '中国,河北省,张家口市,涿鹿县',
            areaCode: '100001300070310000'
          },
          {
            id: 9771,
            parentId: 3483,
            areaName: '赤城县',
            areaPath: '中国,河北省,张家口市,赤城县',
            areaCode: '100001300070320000'
          }
        ]
      },
      {
        id: 3484,
        parentId: 1436,
        areaName: '承德市',
        areaPath: '中国,河北省,承德市',
        areaCode: '100001300080000000',
        children: [
          {
            id: 9772,
            parentId: 3484,
            areaName: '双桥区',
            areaPath: '中国,河北省,承德市,双桥区',
            areaCode: '100001300080020000'
          },
          {
            id: 9773,
            parentId: 3484,
            areaName: '双滦区',
            areaPath: '中国,河北省,承德市,双滦区',
            areaCode: '100001300080030000'
          },
          {
            id: 9774,
            parentId: 3484,
            areaName: '鹰手营子矿区',
            areaPath: '中国,河北省,承德市,鹰手营子矿区',
            areaCode: '100001300080040000'
          },
          {
            id: 9775,
            parentId: 3484,
            areaName: '承德县',
            areaPath: '中国,河北省,承德市,承德县',
            areaCode: '100001300080210000'
          },
          {
            id: 9776,
            parentId: 3484,
            areaName: '兴隆县',
            areaPath: '中国,河北省,承德市,兴隆县',
            areaCode: '100001300080220000'
          },
          {
            id: 9777,
            parentId: 3484,
            areaName: '滦平县',
            areaPath: '中国,河北省,承德市,滦平县',
            areaCode: '100001300080240000'
          },
          {
            id: 9778,
            parentId: 3484,
            areaName: '隆化县',
            areaPath: '中国,河北省,承德市,隆化县',
            areaCode: '100001300080250000'
          },
          {
            id: 9779,
            parentId: 3484,
            areaName: '丰宁满族自治县',
            areaPath: '中国,河北省,承德市,丰宁满族自治县',
            areaCode: '100001300080260000'
          },
          {
            id: 9780,
            parentId: 3484,
            areaName: '宽城满族自治县',
            areaPath: '中国,河北省,承德市,宽城满族自治县',
            areaCode: '100001300080270000'
          },
          {
            id: 9781,
            parentId: 3484,
            areaName: '围场满族蒙古族自治县',
            areaPath: '中国,河北省,承德市,围场满族蒙古族自治县',
            areaCode: '100001300080280000'
          },
          {
            id: 9782,
            parentId: 3484,
            areaName: '平泉市',
            areaPath: '中国,河北省,承德市,平泉市',
            areaCode: '100001300080810000'
          }
        ]
      },
      {
        id: 3485,
        parentId: 1436,
        areaName: '沧州市',
        areaPath: '中国,河北省,沧州市',
        areaCode: '100001300090000000',
        children: [
          {
            id: 9783,
            parentId: 3485,
            areaName: '新华区',
            areaPath: '中国,河北省,沧州市,新华区',
            areaCode: '100001300090020000'
          },
          {
            id: 9784,
            parentId: 3485,
            areaName: '运河区',
            areaPath: '中国,河北省,沧州市,运河区',
            areaCode: '100001300090030000'
          },
          {
            id: 9785,
            parentId: 3485,
            areaName: '沧县',
            areaPath: '中国,河北省,沧州市,沧县',
            areaCode: '100001300090210000'
          },
          {
            id: 9786,
            parentId: 3485,
            areaName: '青县',
            areaPath: '中国,河北省,沧州市,青县',
            areaCode: '100001300090220000'
          },
          {
            id: 9787,
            parentId: 3485,
            areaName: '东光县',
            areaPath: '中国,河北省,沧州市,东光县',
            areaCode: '100001300090230000'
          },
          {
            id: 9788,
            parentId: 3485,
            areaName: '海兴县',
            areaPath: '中国,河北省,沧州市,海兴县',
            areaCode: '100001300090240000'
          },
          {
            id: 9789,
            parentId: 3485,
            areaName: '盐山县',
            areaPath: '中国,河北省,沧州市,盐山县',
            areaCode: '100001300090250000'
          },
          {
            id: 9790,
            parentId: 3485,
            areaName: '肃宁县',
            areaPath: '中国,河北省,沧州市,肃宁县',
            areaCode: '100001300090260000'
          },
          {
            id: 9791,
            parentId: 3485,
            areaName: '南皮县',
            areaPath: '中国,河北省,沧州市,南皮县',
            areaCode: '100001300090270000'
          },
          {
            id: 9792,
            parentId: 3485,
            areaName: '吴桥县',
            areaPath: '中国,河北省,沧州市,吴桥县',
            areaCode: '100001300090280000'
          },
          {
            id: 9793,
            parentId: 3485,
            areaName: '献县',
            areaPath: '中国,河北省,沧州市,献县',
            areaCode: '100001300090290000'
          },
          {
            id: 9794,
            parentId: 3485,
            areaName: '孟村回族自治县',
            areaPath: '中国,河北省,沧州市,孟村回族自治县',
            areaCode: '100001300090300000'
          },
          {
            id: 9795,
            parentId: 3485,
            areaName: '泊头市',
            areaPath: '中国,河北省,沧州市,泊头市',
            areaCode: '100001300090810000'
          },
          {
            id: 9796,
            parentId: 3485,
            areaName: '任丘市',
            areaPath: '中国,河北省,沧州市,任丘市',
            areaCode: '100001300090820000'
          },
          {
            id: 9797,
            parentId: 3485,
            areaName: '黄骅市',
            areaPath: '中国,河北省,沧州市,黄骅市',
            areaCode: '100001300090830000'
          },
          {
            id: 9798,
            parentId: 3485,
            areaName: '河间市',
            areaPath: '中国,河北省,沧州市,河间市',
            areaCode: '100001300090840000'
          }
        ]
      },
      {
        id: 3486,
        parentId: 1436,
        areaName: '廊坊市',
        areaPath: '中国,河北省,廊坊市',
        areaCode: '100001300100000000',
        children: [
          {
            id: 9799,
            parentId: 3486,
            areaName: '安次区',
            areaPath: '中国,河北省,廊坊市,安次区',
            areaCode: '100001300100020000'
          },
          {
            id: 9800,
            parentId: 3486,
            areaName: '广阳区',
            areaPath: '中国,河北省,廊坊市,广阳区',
            areaCode: '100001300100030000'
          },
          {
            id: 9801,
            parentId: 3486,
            areaName: '固安县',
            areaPath: '中国,河北省,廊坊市,固安县',
            areaCode: '100001300100220000'
          },
          {
            id: 9802,
            parentId: 3486,
            areaName: '永清县',
            areaPath: '中国,河北省,廊坊市,永清县',
            areaCode: '100001300100230000'
          },
          {
            id: 9803,
            parentId: 3486,
            areaName: '香河县',
            areaPath: '中国,河北省,廊坊市,香河县',
            areaCode: '100001300100240000'
          },
          {
            id: 9804,
            parentId: 3486,
            areaName: '大城县',
            areaPath: '中国,河北省,廊坊市,大城县',
            areaCode: '100001300100250000'
          },
          {
            id: 9805,
            parentId: 3486,
            areaName: '文安县',
            areaPath: '中国,河北省,廊坊市,文安县',
            areaCode: '100001300100260000'
          },
          {
            id: 9806,
            parentId: 3486,
            areaName: '大厂回族自治县',
            areaPath: '中国,河北省,廊坊市,大厂回族自治县',
            areaCode: '100001300100280000'
          },
          {
            id: 9807,
            parentId: 3486,
            areaName: '霸州市',
            areaPath: '中国,河北省,廊坊市,霸州市',
            areaCode: '100001300100810000'
          },
          {
            id: 9808,
            parentId: 3486,
            areaName: '三河市',
            areaPath: '中国,河北省,廊坊市,三河市',
            areaCode: '100001300100820000'
          }
        ]
      },
      {
        id: 3487,
        parentId: 1436,
        areaName: '衡水市',
        areaPath: '中国,河北省,衡水市',
        areaCode: '100001300110000000',
        children: [
          {
            id: 9809,
            parentId: 3487,
            areaName: '桃城区',
            areaPath: '中国,河北省,衡水市,桃城区',
            areaCode: '100001300110020000'
          },
          {
            id: 9810,
            parentId: 3487,
            areaName: '冀州区',
            areaPath: '中国,河北省,衡水市,冀州区',
            areaCode: '100001300110030000'
          },
          {
            id: 9811,
            parentId: 3487,
            areaName: '枣强县',
            areaPath: '中国,河北省,衡水市,枣强县',
            areaCode: '100001300110210000'
          },
          {
            id: 9812,
            parentId: 3487,
            areaName: '武邑县',
            areaPath: '中国,河北省,衡水市,武邑县',
            areaCode: '100001300110220000'
          },
          {
            id: 9813,
            parentId: 3487,
            areaName: '武强县',
            areaPath: '中国,河北省,衡水市,武强县',
            areaCode: '100001300110230000'
          },
          {
            id: 9814,
            parentId: 3487,
            areaName: '饶阳县',
            areaPath: '中国,河北省,衡水市,饶阳县',
            areaCode: '100001300110240000'
          },
          {
            id: 9815,
            parentId: 3487,
            areaName: '安平县',
            areaPath: '中国,河北省,衡水市,安平县',
            areaCode: '100001300110250000'
          },
          {
            id: 9816,
            parentId: 3487,
            areaName: '故城县',
            areaPath: '中国,河北省,衡水市,故城县',
            areaCode: '100001300110260000'
          },
          {
            id: 9817,
            parentId: 3487,
            areaName: '景县',
            areaPath: '中国,河北省,衡水市,景县',
            areaCode: '100001300110270000'
          },
          {
            id: 9818,
            parentId: 3487,
            areaName: '阜城县',
            areaPath: '中国,河北省,衡水市,阜城县',
            areaCode: '100001300110280000'
          },
          {
            id: 9819,
            parentId: 3487,
            areaName: '深州市',
            areaPath: '中国,河北省,衡水市,深州市',
            areaCode: '100001300110820000'
          }
        ]
      }
    ]
  },
  {
    id: 1437,
    parentId: 1,
    areaName: '山西省',
    areaPath: '中国,山西省',
    areaCode: '100001400000000000',
    children: [
      {
        id: 3488,
        parentId: 1437,
        areaName: '太原市',
        areaPath: '中国,山西省,太原市',
        areaCode: '100001400010000000',
        children: [
          {
            id: 9820,
            parentId: 3488,
            areaName: '小店区',
            areaPath: '中国,山西省,太原市,小店区',
            areaCode: '100001400010050000'
          },
          {
            id: 9821,
            parentId: 3488,
            areaName: '迎泽区',
            areaPath: '中国,山西省,太原市,迎泽区',
            areaCode: '100001400010060000'
          },
          {
            id: 9822,
            parentId: 3488,
            areaName: '杏花岭区',
            areaPath: '中国,山西省,太原市,杏花岭区',
            areaCode: '100001400010070000'
          },
          {
            id: 9823,
            parentId: 3488,
            areaName: '尖草坪区',
            areaPath: '中国,山西省,太原市,尖草坪区',
            areaCode: '100001400010080000'
          },
          {
            id: 9824,
            parentId: 3488,
            areaName: '万柏林区',
            areaPath: '中国,山西省,太原市,万柏林区',
            areaCode: '100001400010090000'
          },
          {
            id: 9825,
            parentId: 3488,
            areaName: '晋源区',
            areaPath: '中国,山西省,太原市,晋源区',
            areaCode: '100001400010100000'
          },
          {
            id: 9826,
            parentId: 3488,
            areaName: '清徐县',
            areaPath: '中国,山西省,太原市,清徐县',
            areaCode: '100001400010210000'
          },
          {
            id: 9827,
            parentId: 3488,
            areaName: '阳曲县',
            areaPath: '中国,山西省,太原市,阳曲县',
            areaCode: '100001400010220000'
          },
          {
            id: 9828,
            parentId: 3488,
            areaName: '娄烦县',
            areaPath: '中国,山西省,太原市,娄烦县',
            areaCode: '100001400010230000'
          },
          {
            id: 9829,
            parentId: 3488,
            areaName: '古交市',
            areaPath: '中国,山西省,太原市,古交市',
            areaCode: '100001400010810000'
          }
        ]
      },
      {
        id: 3489,
        parentId: 1437,
        areaName: '大同市',
        areaPath: '中国,山西省,大同市',
        areaCode: '100001400020000000',
        children: [
          {
            id: 9830,
            parentId: 3489,
            areaName: '城区',
            areaPath: '中国,山西省,大同市,城区',
            areaCode: '100001400020020000'
          },
          {
            id: 9831,
            parentId: 3489,
            areaName: '矿区',
            areaPath: '中国,山西省,大同市,矿区',
            areaCode: '100001400020030000'
          },
          {
            id: 9832,
            parentId: 3489,
            areaName: '南郊区',
            areaPath: '中国,山西省,大同市,南郊区',
            areaCode: '100001400020110000'
          },
          {
            id: 9833,
            parentId: 3489,
            areaName: '新荣区',
            areaPath: '中国,山西省,大同市,新荣区',
            areaCode: '100001400020120000'
          },
          {
            id: 9834,
            parentId: 3489,
            areaName: '阳高县',
            areaPath: '中国,山西省,大同市,阳高县',
            areaCode: '100001400020210000'
          },
          {
            id: 9835,
            parentId: 3489,
            areaName: '天镇县',
            areaPath: '中国,山西省,大同市,天镇县',
            areaCode: '100001400020220000'
          },
          {
            id: 9836,
            parentId: 3489,
            areaName: '广灵县',
            areaPath: '中国,山西省,大同市,广灵县',
            areaCode: '100001400020230000'
          },
          {
            id: 9837,
            parentId: 3489,
            areaName: '灵丘县',
            areaPath: '中国,山西省,大同市,灵丘县',
            areaCode: '100001400020240000'
          },
          {
            id: 9838,
            parentId: 3489,
            areaName: '浑源县',
            areaPath: '中国,山西省,大同市,浑源县',
            areaCode: '100001400020250000'
          },
          {
            id: 9839,
            parentId: 3489,
            areaName: '左云县',
            areaPath: '中国,山西省,大同市,左云县',
            areaCode: '100001400020260000'
          },
          {
            id: 9840,
            parentId: 3489,
            areaName: '大同县',
            areaPath: '中国,山西省,大同市,大同县',
            areaCode: '100001400020270000'
          }
        ]
      },
      {
        id: 3490,
        parentId: 1437,
        areaName: '阳泉市',
        areaPath: '中国,山西省,阳泉市',
        areaCode: '100001400030000000',
        children: [
          {
            id: 9841,
            parentId: 3490,
            areaName: '城区',
            areaPath: '中国,山西省,阳泉市,城区',
            areaCode: '100001400030020000'
          },
          {
            id: 9842,
            parentId: 3490,
            areaName: '矿区',
            areaPath: '中国,山西省,阳泉市,矿区',
            areaCode: '100001400030030000'
          },
          {
            id: 9843,
            parentId: 3490,
            areaName: '郊区',
            areaPath: '中国,山西省,阳泉市,郊区',
            areaCode: '100001400030110000'
          },
          {
            id: 9844,
            parentId: 3490,
            areaName: '平定县',
            areaPath: '中国,山西省,阳泉市,平定县',
            areaCode: '100001400030210000'
          },
          {
            id: 9845,
            parentId: 3490,
            areaName: '盂县',
            areaPath: '中国,山西省,阳泉市,盂县',
            areaCode: '100001400030220000'
          }
        ]
      },
      {
        id: 3491,
        parentId: 1437,
        areaName: '长治市',
        areaPath: '中国,山西省,长治市',
        areaCode: '100001400040000000',
        children: [
          {
            id: 9846,
            parentId: 3491,
            areaName: '城区',
            areaPath: '中国,山西省,长治市,城区',
            areaCode: '100001400040020000'
          },
          {
            id: 9847,
            parentId: 3491,
            areaName: '郊区',
            areaPath: '中国,山西省,长治市,郊区',
            areaCode: '100001400040110000'
          },
          {
            id: 9848,
            parentId: 3491,
            areaName: '长治县',
            areaPath: '中国,山西省,长治市,长治县',
            areaCode: '100001400040210000'
          },
          {
            id: 9849,
            parentId: 3491,
            areaName: '襄垣县',
            areaPath: '中国,山西省,长治市,襄垣县',
            areaCode: '100001400040230000'
          },
          {
            id: 9850,
            parentId: 3491,
            areaName: '屯留县',
            areaPath: '中国,山西省,长治市,屯留县',
            areaCode: '100001400040240000'
          },
          {
            id: 9851,
            parentId: 3491,
            areaName: '平顺县',
            areaPath: '中国,山西省,长治市,平顺县',
            areaCode: '100001400040250000'
          },
          {
            id: 9852,
            parentId: 3491,
            areaName: '黎城县',
            areaPath: '中国,山西省,长治市,黎城县',
            areaCode: '100001400040260000'
          },
          {
            id: 9853,
            parentId: 3491,
            areaName: '壶关县',
            areaPath: '中国,山西省,长治市,壶关县',
            areaCode: '100001400040270000'
          },
          {
            id: 9854,
            parentId: 3491,
            areaName: '长子县',
            areaPath: '中国,山西省,长治市,长子县',
            areaCode: '100001400040280000'
          },
          {
            id: 9855,
            parentId: 3491,
            areaName: '武乡县',
            areaPath: '中国,山西省,长治市,武乡县',
            areaCode: '100001400040290000'
          },
          {
            id: 9856,
            parentId: 3491,
            areaName: '沁县',
            areaPath: '中国,山西省,长治市,沁县',
            areaCode: '100001400040300000'
          },
          {
            id: 9857,
            parentId: 3491,
            areaName: '沁源县',
            areaPath: '中国,山西省,长治市,沁源县',
            areaCode: '100001400040310000'
          },
          {
            id: 9858,
            parentId: 3491,
            areaName: '潞城市',
            areaPath: '中国,山西省,长治市,潞城市',
            areaCode: '100001400040810000'
          }
        ]
      },
      {
        id: 3492,
        parentId: 1437,
        areaName: '晋城市',
        areaPath: '中国,山西省,晋城市',
        areaCode: '100001400050000000',
        children: [
          {
            id: 9859,
            parentId: 3492,
            areaName: '城区',
            areaPath: '中国,山西省,晋城市,城区',
            areaCode: '100001400050020000'
          },
          {
            id: 9860,
            parentId: 3492,
            areaName: '沁水县',
            areaPath: '中国,山西省,晋城市,沁水县',
            areaCode: '100001400050210000'
          },
          {
            id: 9861,
            parentId: 3492,
            areaName: '阳城县',
            areaPath: '中国,山西省,晋城市,阳城县',
            areaCode: '100001400050220000'
          },
          {
            id: 9862,
            parentId: 3492,
            areaName: '陵川县',
            areaPath: '中国,山西省,晋城市,陵川县',
            areaCode: '100001400050240000'
          },
          {
            id: 9863,
            parentId: 3492,
            areaName: '泽州县',
            areaPath: '中国,山西省,晋城市,泽州县',
            areaCode: '100001400050250000'
          },
          {
            id: 9864,
            parentId: 3492,
            areaName: '高平市',
            areaPath: '中国,山西省,晋城市,高平市',
            areaCode: '100001400050810000'
          }
        ]
      },
      {
        id: 3493,
        parentId: 1437,
        areaName: '朔州市',
        areaPath: '中国,山西省,朔州市',
        areaCode: '100001400060000000',
        children: [
          {
            id: 9865,
            parentId: 3493,
            areaName: '朔城区',
            areaPath: '中国,山西省,朔州市,朔城区',
            areaCode: '100001400060020000'
          },
          {
            id: 9866,
            parentId: 3493,
            areaName: '平鲁区',
            areaPath: '中国,山西省,朔州市,平鲁区',
            areaCode: '100001400060030000'
          },
          {
            id: 9867,
            parentId: 3493,
            areaName: '山阴县',
            areaPath: '中国,山西省,朔州市,山阴县',
            areaCode: '100001400060210000'
          },
          {
            id: 9868,
            parentId: 3493,
            areaName: '应县',
            areaPath: '中国,山西省,朔州市,应县',
            areaCode: '100001400060220000'
          },
          {
            id: 9869,
            parentId: 3493,
            areaName: '右玉县',
            areaPath: '中国,山西省,朔州市,右玉县',
            areaCode: '100001400060230000'
          },
          {
            id: 9870,
            parentId: 3493,
            areaName: '怀仁县',
            areaPath: '中国,山西省,朔州市,怀仁县',
            areaCode: '100001400060240000'
          }
        ]
      },
      {
        id: 3494,
        parentId: 1437,
        areaName: '晋中市',
        areaPath: '中国,山西省,晋中市',
        areaCode: '100001400070000000',
        children: [
          {
            id: 9871,
            parentId: 3494,
            areaName: '榆次区',
            areaPath: '中国,山西省,晋中市,榆次区',
            areaCode: '100001400070020000'
          },
          {
            id: 9872,
            parentId: 3494,
            areaName: '榆社县',
            areaPath: '中国,山西省,晋中市,榆社县',
            areaCode: '100001400070210000'
          },
          {
            id: 9873,
            parentId: 3494,
            areaName: '左权县',
            areaPath: '中国,山西省,晋中市,左权县',
            areaCode: '100001400070220000'
          },
          {
            id: 9874,
            parentId: 3494,
            areaName: '和顺县',
            areaPath: '中国,山西省,晋中市,和顺县',
            areaCode: '100001400070230000'
          },
          {
            id: 9875,
            parentId: 3494,
            areaName: '昔阳县',
            areaPath: '中国,山西省,晋中市,昔阳县',
            areaCode: '100001400070240000'
          },
          {
            id: 9876,
            parentId: 3494,
            areaName: '寿阳县',
            areaPath: '中国,山西省,晋中市,寿阳县',
            areaCode: '100001400070250000'
          },
          {
            id: 9877,
            parentId: 3494,
            areaName: '太谷县',
            areaPath: '中国,山西省,晋中市,太谷县',
            areaCode: '100001400070260000'
          },
          {
            id: 9878,
            parentId: 3494,
            areaName: '祁县',
            areaPath: '中国,山西省,晋中市,祁县',
            areaCode: '100001400070270000'
          },
          {
            id: 9879,
            parentId: 3494,
            areaName: '平遥县',
            areaPath: '中国,山西省,晋中市,平遥县',
            areaCode: '100001400070280000'
          },
          {
            id: 9880,
            parentId: 3494,
            areaName: '灵石县',
            areaPath: '中国,山西省,晋中市,灵石县',
            areaCode: '100001400070290000'
          },
          {
            id: 9881,
            parentId: 3494,
            areaName: '介休市',
            areaPath: '中国,山西省,晋中市,介休市',
            areaCode: '100001400070810000'
          }
        ]
      },
      {
        id: 3495,
        parentId: 1437,
        areaName: '运城市',
        areaPath: '中国,山西省,运城市',
        areaCode: '100001400080000000',
        children: [
          {
            id: 9882,
            parentId: 3495,
            areaName: '盐湖区',
            areaPath: '中国,山西省,运城市,盐湖区',
            areaCode: '100001400080020000'
          },
          {
            id: 9883,
            parentId: 3495,
            areaName: '临猗县',
            areaPath: '中国,山西省,运城市,临猗县',
            areaCode: '100001400080210000'
          },
          {
            id: 9884,
            parentId: 3495,
            areaName: '万荣县',
            areaPath: '中国,山西省,运城市,万荣县',
            areaCode: '100001400080220000'
          },
          {
            id: 9885,
            parentId: 3495,
            areaName: '闻喜县',
            areaPath: '中国,山西省,运城市,闻喜县',
            areaCode: '100001400080230000'
          },
          {
            id: 9886,
            parentId: 3495,
            areaName: '稷山县',
            areaPath: '中国,山西省,运城市,稷山县',
            areaCode: '100001400080240000'
          },
          {
            id: 9887,
            parentId: 3495,
            areaName: '新绛县',
            areaPath: '中国,山西省,运城市,新绛县',
            areaCode: '100001400080250000'
          },
          {
            id: 9888,
            parentId: 3495,
            areaName: '绛县',
            areaPath: '中国,山西省,运城市,绛县',
            areaCode: '100001400080260000'
          },
          {
            id: 9889,
            parentId: 3495,
            areaName: '垣曲县',
            areaPath: '中国,山西省,运城市,垣曲县',
            areaCode: '100001400080270000'
          },
          {
            id: 9890,
            parentId: 3495,
            areaName: '夏县',
            areaPath: '中国,山西省,运城市,夏县',
            areaCode: '100001400080280000'
          },
          {
            id: 9891,
            parentId: 3495,
            areaName: '平陆县',
            areaPath: '中国,山西省,运城市,平陆县',
            areaCode: '100001400080290000'
          },
          {
            id: 9892,
            parentId: 3495,
            areaName: '芮城县',
            areaPath: '中国,山西省,运城市,芮城县',
            areaCode: '100001400080300000'
          },
          {
            id: 9893,
            parentId: 3495,
            areaName: '永济市',
            areaPath: '中国,山西省,运城市,永济市',
            areaCode: '100001400080810000'
          },
          {
            id: 9894,
            parentId: 3495,
            areaName: '河津市',
            areaPath: '中国,山西省,运城市,河津市',
            areaCode: '100001400080820000'
          }
        ]
      },
      {
        id: 3496,
        parentId: 1437,
        areaName: '忻州市',
        areaPath: '中国,山西省,忻州市',
        areaCode: '100001400090000000',
        children: [
          {
            id: 9895,
            parentId: 3496,
            areaName: '忻府区',
            areaPath: '中国,山西省,忻州市,忻府区',
            areaCode: '100001400090020000'
          },
          {
            id: 9896,
            parentId: 3496,
            areaName: '定襄县',
            areaPath: '中国,山西省,忻州市,定襄县',
            areaCode: '100001400090210000'
          },
          {
            id: 9897,
            parentId: 3496,
            areaName: '五台县',
            areaPath: '中国,山西省,忻州市,五台县',
            areaCode: '100001400090220000'
          },
          {
            id: 9898,
            parentId: 3496,
            areaName: '代县',
            areaPath: '中国,山西省,忻州市,代县',
            areaCode: '100001400090230000'
          },
          {
            id: 9899,
            parentId: 3496,
            areaName: '繁峙县',
            areaPath: '中国,山西省,忻州市,繁峙县',
            areaCode: '100001400090240000'
          },
          {
            id: 9900,
            parentId: 3496,
            areaName: '宁武县',
            areaPath: '中国,山西省,忻州市,宁武县',
            areaCode: '100001400090250000'
          },
          {
            id: 9901,
            parentId: 3496,
            areaName: '静乐县',
            areaPath: '中国,山西省,忻州市,静乐县',
            areaCode: '100001400090260000'
          },
          {
            id: 9902,
            parentId: 3496,
            areaName: '神池县',
            areaPath: '中国,山西省,忻州市,神池县',
            areaCode: '100001400090270000'
          },
          {
            id: 9903,
            parentId: 3496,
            areaName: '五寨县',
            areaPath: '中国,山西省,忻州市,五寨县',
            areaCode: '100001400090280000'
          },
          {
            id: 9904,
            parentId: 3496,
            areaName: '岢岚县',
            areaPath: '中国,山西省,忻州市,岢岚县',
            areaCode: '100001400090290000'
          },
          {
            id: 9905,
            parentId: 3496,
            areaName: '河曲县',
            areaPath: '中国,山西省,忻州市,河曲县',
            areaCode: '100001400090300000'
          },
          {
            id: 9906,
            parentId: 3496,
            areaName: '保德县',
            areaPath: '中国,山西省,忻州市,保德县',
            areaCode: '100001400090310000'
          },
          {
            id: 9907,
            parentId: 3496,
            areaName: '偏关县',
            areaPath: '中国,山西省,忻州市,偏关县',
            areaCode: '100001400090320000'
          },
          {
            id: 9908,
            parentId: 3496,
            areaName: '原平市',
            areaPath: '中国,山西省,忻州市,原平市',
            areaCode: '100001400090810000'
          }
        ]
      },
      {
        id: 3497,
        parentId: 1437,
        areaName: '临汾市',
        areaPath: '中国,山西省,临汾市',
        areaCode: '100001400100000000',
        children: [
          {
            id: 9909,
            parentId: 3497,
            areaName: '尧都区',
            areaPath: '中国,山西省,临汾市,尧都区',
            areaCode: '100001400100020000'
          },
          {
            id: 9910,
            parentId: 3497,
            areaName: '曲沃县',
            areaPath: '中国,山西省,临汾市,曲沃县',
            areaCode: '100001400100210000'
          },
          {
            id: 9911,
            parentId: 3497,
            areaName: '翼城县',
            areaPath: '中国,山西省,临汾市,翼城县',
            areaCode: '100001400100220000'
          },
          {
            id: 9912,
            parentId: 3497,
            areaName: '襄汾县',
            areaPath: '中国,山西省,临汾市,襄汾县',
            areaCode: '100001400100230000'
          },
          {
            id: 9913,
            parentId: 3497,
            areaName: '洪洞县',
            areaPath: '中国,山西省,临汾市,洪洞县',
            areaCode: '100001400100240000'
          },
          {
            id: 9914,
            parentId: 3497,
            areaName: '古县',
            areaPath: '中国,山西省,临汾市,古县',
            areaCode: '100001400100250000'
          },
          {
            id: 9915,
            parentId: 3497,
            areaName: '安泽县',
            areaPath: '中国,山西省,临汾市,安泽县',
            areaCode: '100001400100260000'
          },
          {
            id: 9916,
            parentId: 3497,
            areaName: '浮山县',
            areaPath: '中国,山西省,临汾市,浮山县',
            areaCode: '100001400100270000'
          },
          {
            id: 9917,
            parentId: 3497,
            areaName: '吉县',
            areaPath: '中国,山西省,临汾市,吉县',
            areaCode: '100001400100280000'
          },
          {
            id: 9918,
            parentId: 3497,
            areaName: '乡宁县',
            areaPath: '中国,山西省,临汾市,乡宁县',
            areaCode: '100001400100290000'
          },
          {
            id: 9919,
            parentId: 3497,
            areaName: '大宁县',
            areaPath: '中国,山西省,临汾市,大宁县',
            areaCode: '100001400100300000'
          },
          {
            id: 9920,
            parentId: 3497,
            areaName: '隰县',
            areaPath: '中国,山西省,临汾市,隰县',
            areaCode: '100001400100310000'
          },
          {
            id: 9921,
            parentId: 3497,
            areaName: '永和县',
            areaPath: '中国,山西省,临汾市,永和县',
            areaCode: '100001400100320000'
          },
          {
            id: 9922,
            parentId: 3497,
            areaName: '蒲县',
            areaPath: '中国,山西省,临汾市,蒲县',
            areaCode: '100001400100330000'
          },
          {
            id: 9923,
            parentId: 3497,
            areaName: '汾西县',
            areaPath: '中国,山西省,临汾市,汾西县',
            areaCode: '100001400100340000'
          },
          {
            id: 9924,
            parentId: 3497,
            areaName: '侯马市',
            areaPath: '中国,山西省,临汾市,侯马市',
            areaCode: '100001400100810000'
          },
          {
            id: 9925,
            parentId: 3497,
            areaName: '霍州市',
            areaPath: '中国,山西省,临汾市,霍州市',
            areaCode: '100001400100820000'
          }
        ]
      },
      {
        id: 3498,
        parentId: 1437,
        areaName: '吕梁市',
        areaPath: '中国,山西省,吕梁市',
        areaCode: '100001400110000000',
        children: [
          {
            id: 9926,
            parentId: 3498,
            areaName: '离石区',
            areaPath: '中国,山西省,吕梁市,离石区',
            areaCode: '100001400110020000'
          },
          {
            id: 9927,
            parentId: 3498,
            areaName: '文水县',
            areaPath: '中国,山西省,吕梁市,文水县',
            areaCode: '100001400110210000'
          },
          {
            id: 9928,
            parentId: 3498,
            areaName: '交城县',
            areaPath: '中国,山西省,吕梁市,交城县',
            areaCode: '100001400110220000'
          },
          {
            id: 9929,
            parentId: 3498,
            areaName: '兴县',
            areaPath: '中国,山西省,吕梁市,兴县',
            areaCode: '100001400110230000'
          },
          {
            id: 9930,
            parentId: 3498,
            areaName: '临县',
            areaPath: '中国,山西省,吕梁市,临县',
            areaCode: '100001400110240000'
          },
          {
            id: 9931,
            parentId: 3498,
            areaName: '柳林县',
            areaPath: '中国,山西省,吕梁市,柳林县',
            areaCode: '100001400110250000'
          },
          {
            id: 9932,
            parentId: 3498,
            areaName: '石楼县',
            areaPath: '中国,山西省,吕梁市,石楼县',
            areaCode: '100001400110260000'
          },
          {
            id: 9933,
            parentId: 3498,
            areaName: '岚县',
            areaPath: '中国,山西省,吕梁市,岚县',
            areaCode: '100001400110270000'
          },
          {
            id: 9934,
            parentId: 3498,
            areaName: '方山县',
            areaPath: '中国,山西省,吕梁市,方山县',
            areaCode: '100001400110280000'
          },
          {
            id: 9935,
            parentId: 3498,
            areaName: '中阳县',
            areaPath: '中国,山西省,吕梁市,中阳县',
            areaCode: '100001400110290000'
          },
          {
            id: 9936,
            parentId: 3498,
            areaName: '交口县',
            areaPath: '中国,山西省,吕梁市,交口县',
            areaCode: '100001400110300000'
          },
          {
            id: 9937,
            parentId: 3498,
            areaName: '孝义市',
            areaPath: '中国,山西省,吕梁市,孝义市',
            areaCode: '100001400110810000'
          },
          {
            id: 9938,
            parentId: 3498,
            areaName: '汾阳市',
            areaPath: '中国,山西省,吕梁市,汾阳市',
            areaCode: '100001400110820000'
          }
        ]
      }
    ]
  },
  {
    id: 1438,
    parentId: 1,
    areaName: '内蒙古自治区',
    areaPath: '中国,内蒙古自治区',
    areaCode: '100001500000000000',
    children: [
      {
        id: 3499,
        parentId: 1438,
        areaName: '呼和浩特市',
        areaPath: '中国,内蒙古自治区,呼和浩特市',
        areaCode: '100001500010000000',
        children: [
          {
            id: 9939,
            parentId: 3499,
            areaName: '新城区',
            areaPath: '中国,内蒙古自治区,呼和浩特市,新城区',
            areaCode: '100001500010020000'
          },
          {
            id: 9940,
            parentId: 3499,
            areaName: '回民区',
            areaPath: '中国,内蒙古自治区,呼和浩特市,回民区',
            areaCode: '100001500010030000'
          },
          {
            id: 9941,
            parentId: 3499,
            areaName: '玉泉区',
            areaPath: '中国,内蒙古自治区,呼和浩特市,玉泉区',
            areaCode: '100001500010040000'
          },
          {
            id: 9942,
            parentId: 3499,
            areaName: '赛罕区',
            areaPath: '中国,内蒙古自治区,呼和浩特市,赛罕区',
            areaCode: '100001500010050000'
          },
          {
            id: 9943,
            parentId: 3499,
            areaName: '土默特左旗',
            areaPath: '中国,内蒙古自治区,呼和浩特市,土默特左旗',
            areaCode: '100001500010210000'
          },
          {
            id: 9944,
            parentId: 3499,
            areaName: '托克托县',
            areaPath: '中国,内蒙古自治区,呼和浩特市,托克托县',
            areaCode: '100001500010220000'
          },
          {
            id: 9945,
            parentId: 3499,
            areaName: '和林格尔县',
            areaPath: '中国,内蒙古自治区,呼和浩特市,和林格尔县',
            areaCode: '100001500010230000'
          },
          {
            id: 9946,
            parentId: 3499,
            areaName: '清水河县',
            areaPath: '中国,内蒙古自治区,呼和浩特市,清水河县',
            areaCode: '100001500010240000'
          },
          {
            id: 9947,
            parentId: 3499,
            areaName: '武川县',
            areaPath: '中国,内蒙古自治区,呼和浩特市,武川县',
            areaCode: '100001500010250000'
          }
        ]
      },
      {
        id: 3500,
        parentId: 1438,
        areaName: '包头市',
        areaPath: '中国,内蒙古自治区,包头市',
        areaCode: '100001500020000000',
        children: [
          {
            id: 9948,
            parentId: 3500,
            areaName: '东河区',
            areaPath: '中国,内蒙古自治区,包头市,东河区',
            areaCode: '100001500020020000'
          },
          {
            id: 9949,
            parentId: 3500,
            areaName: '昆都仑区',
            areaPath: '中国,内蒙古自治区,包头市,昆都仑区',
            areaCode: '100001500020030000'
          },
          {
            id: 9950,
            parentId: 3500,
            areaName: '青山区',
            areaPath: '中国,内蒙古自治区,包头市,青山区',
            areaCode: '100001500020040000'
          },
          {
            id: 9951,
            parentId: 3500,
            areaName: '石拐区',
            areaPath: '中国,内蒙古自治区,包头市,石拐区',
            areaCode: '100001500020050000'
          },
          {
            id: 9952,
            parentId: 3500,
            areaName: '白云鄂博矿区',
            areaPath: '中国,内蒙古自治区,包头市,白云鄂博矿区',
            areaCode: '100001500020060000'
          },
          {
            id: 9953,
            parentId: 3500,
            areaName: '九原区',
            areaPath: '中国,内蒙古自治区,包头市,九原区',
            areaCode: '100001500020070000'
          },
          {
            id: 9954,
            parentId: 3500,
            areaName: '土默特右旗',
            areaPath: '中国,内蒙古自治区,包头市,土默特右旗',
            areaCode: '100001500020210000'
          },
          {
            id: 9955,
            parentId: 3500,
            areaName: '固阳县',
            areaPath: '中国,内蒙古自治区,包头市,固阳县',
            areaCode: '100001500020220000'
          },
          {
            id: 9956,
            parentId: 3500,
            areaName: '达尔罕茂明安联合旗',
            areaPath: '中国,内蒙古自治区,包头市,达尔罕茂明安联合旗',
            areaCode: '100001500020230000'
          }
        ]
      },
      {
        id: 3501,
        parentId: 1438,
        areaName: '乌海市',
        areaPath: '中国,内蒙古自治区,乌海市',
        areaCode: '100001500030000000',
        children: [
          {
            id: 9957,
            parentId: 3501,
            areaName: '海勃湾区',
            areaPath: '中国,内蒙古自治区,乌海市,海勃湾区',
            areaCode: '100001500030020000'
          },
          {
            id: 9958,
            parentId: 3501,
            areaName: '海南区',
            areaPath: '中国,内蒙古自治区,乌海市,海南区',
            areaCode: '100001500030030000'
          },
          {
            id: 9959,
            parentId: 3501,
            areaName: '乌达区',
            areaPath: '中国,内蒙古自治区,乌海市,乌达区',
            areaCode: '100001500030040000'
          }
        ]
      },
      {
        id: 3502,
        parentId: 1438,
        areaName: '赤峰市',
        areaPath: '中国,内蒙古自治区,赤峰市',
        areaCode: '100001500040000000',
        children: [
          {
            id: 9960,
            parentId: 3502,
            areaName: '红山区',
            areaPath: '中国,内蒙古自治区,赤峰市,红山区',
            areaCode: '100001500040020000'
          },
          {
            id: 9961,
            parentId: 3502,
            areaName: '元宝山区',
            areaPath: '中国,内蒙古自治区,赤峰市,元宝山区',
            areaCode: '100001500040030000'
          },
          {
            id: 9962,
            parentId: 3502,
            areaName: '松山区',
            areaPath: '中国,内蒙古自治区,赤峰市,松山区',
            areaCode: '100001500040040000'
          },
          {
            id: 9963,
            parentId: 3502,
            areaName: '阿鲁科尔沁旗',
            areaPath: '中国,内蒙古自治区,赤峰市,阿鲁科尔沁旗',
            areaCode: '100001500040210000'
          },
          {
            id: 9964,
            parentId: 3502,
            areaName: '巴林左旗',
            areaPath: '中国,内蒙古自治区,赤峰市,巴林左旗',
            areaCode: '100001500040220000'
          },
          {
            id: 9965,
            parentId: 3502,
            areaName: '巴林右旗',
            areaPath: '中国,内蒙古自治区,赤峰市,巴林右旗',
            areaCode: '100001500040230000'
          },
          {
            id: 9966,
            parentId: 3502,
            areaName: '林西县',
            areaPath: '中国,内蒙古自治区,赤峰市,林西县',
            areaCode: '100001500040240000'
          },
          {
            id: 9967,
            parentId: 3502,
            areaName: '克什克腾旗',
            areaPath: '中国,内蒙古自治区,赤峰市,克什克腾旗',
            areaCode: '100001500040250000'
          },
          {
            id: 9968,
            parentId: 3502,
            areaName: '翁牛特旗',
            areaPath: '中国,内蒙古自治区,赤峰市,翁牛特旗',
            areaCode: '100001500040260000'
          },
          {
            id: 9969,
            parentId: 3502,
            areaName: '喀喇沁旗',
            areaPath: '中国,内蒙古自治区,赤峰市,喀喇沁旗',
            areaCode: '100001500040280000'
          },
          {
            id: 9970,
            parentId: 3502,
            areaName: '宁城县',
            areaPath: '中国,内蒙古自治区,赤峰市,宁城县',
            areaCode: '100001500040290000'
          },
          {
            id: 9971,
            parentId: 3502,
            areaName: '敖汉旗',
            areaPath: '中国,内蒙古自治区,赤峰市,敖汉旗',
            areaCode: '100001500040300000'
          }
        ]
      },
      {
        id: 3503,
        parentId: 1438,
        areaName: '通辽市',
        areaPath: '中国,内蒙古自治区,通辽市',
        areaCode: '100001500050000000',
        children: [
          {
            id: 9972,
            parentId: 3503,
            areaName: '科尔沁区',
            areaPath: '中国,内蒙古自治区,通辽市,科尔沁区',
            areaCode: '100001500050020000'
          },
          {
            id: 9973,
            parentId: 3503,
            areaName: '科尔沁左翼中旗',
            areaPath: '中国,内蒙古自治区,通辽市,科尔沁左翼中旗',
            areaCode: '100001500050210000'
          },
          {
            id: 9974,
            parentId: 3503,
            areaName: '科尔沁左翼后旗',
            areaPath: '中国,内蒙古自治区,通辽市,科尔沁左翼后旗',
            areaCode: '100001500050220000'
          },
          {
            id: 9975,
            parentId: 3503,
            areaName: '开鲁县',
            areaPath: '中国,内蒙古自治区,通辽市,开鲁县',
            areaCode: '100001500050230000'
          },
          {
            id: 9976,
            parentId: 3503,
            areaName: '库伦旗',
            areaPath: '中国,内蒙古自治区,通辽市,库伦旗',
            areaCode: '100001500050240000'
          },
          {
            id: 9977,
            parentId: 3503,
            areaName: '奈曼旗',
            areaPath: '中国,内蒙古自治区,通辽市,奈曼旗',
            areaCode: '100001500050250000'
          },
          {
            id: 9978,
            parentId: 3503,
            areaName: '扎鲁特旗',
            areaPath: '中国,内蒙古自治区,通辽市,扎鲁特旗',
            areaCode: '100001500050260000'
          },
          {
            id: 9979,
            parentId: 3503,
            areaName: '霍林郭勒市',
            areaPath: '中国,内蒙古自治区,通辽市,霍林郭勒市',
            areaCode: '100001500050810000'
          }
        ]
      },
      {
        id: 3504,
        parentId: 1438,
        areaName: '鄂尔多斯市',
        areaPath: '中国,内蒙古自治区,鄂尔多斯市',
        areaCode: '100001500060000000',
        children: [
          {
            id: 9980,
            parentId: 3504,
            areaName: '东胜区',
            areaPath: '中国,内蒙古自治区,鄂尔多斯市,东胜区',
            areaCode: '100001500060020000'
          },
          {
            id: 9981,
            parentId: 3504,
            areaName: '康巴什区',
            areaPath: '中国,内蒙古自治区,鄂尔多斯市,康巴什区',
            areaCode: '100001500060030000'
          },
          {
            id: 9982,
            parentId: 3504,
            areaName: '达拉特旗',
            areaPath: '中国,内蒙古自治区,鄂尔多斯市,达拉特旗',
            areaCode: '100001500060210000'
          },
          {
            id: 9983,
            parentId: 3504,
            areaName: '准格尔旗',
            areaPath: '中国,内蒙古自治区,鄂尔多斯市,准格尔旗',
            areaCode: '100001500060220000'
          },
          {
            id: 9984,
            parentId: 3504,
            areaName: '鄂托克前旗',
            areaPath: '中国,内蒙古自治区,鄂尔多斯市,鄂托克前旗',
            areaCode: '100001500060230000'
          },
          {
            id: 9985,
            parentId: 3504,
            areaName: '鄂托克旗',
            areaPath: '中国,内蒙古自治区,鄂尔多斯市,鄂托克旗',
            areaCode: '100001500060240000'
          },
          {
            id: 9986,
            parentId: 3504,
            areaName: '杭锦旗',
            areaPath: '中国,内蒙古自治区,鄂尔多斯市,杭锦旗',
            areaCode: '100001500060250000'
          },
          {
            id: 9987,
            parentId: 3504,
            areaName: '乌审旗',
            areaPath: '中国,内蒙古自治区,鄂尔多斯市,乌审旗',
            areaCode: '100001500060260000'
          },
          {
            id: 9988,
            parentId: 3504,
            areaName: '伊金霍洛旗',
            areaPath: '中国,内蒙古自治区,鄂尔多斯市,伊金霍洛旗',
            areaCode: '100001500060270000'
          }
        ]
      },
      {
        id: 3505,
        parentId: 1438,
        areaName: '呼伦贝尔市',
        areaPath: '中国,内蒙古自治区,呼伦贝尔市',
        areaCode: '100001500070000000',
        children: [
          {
            id: 9989,
            parentId: 3505,
            areaName: '海拉尔区',
            areaPath: '中国,内蒙古自治区,呼伦贝尔市,海拉尔区',
            areaCode: '100001500070020000'
          },
          {
            id: 9990,
            parentId: 3505,
            areaName: '扎赉诺尔区',
            areaPath: '中国,内蒙古自治区,呼伦贝尔市,扎赉诺尔区',
            areaCode: '100001500070030000'
          },
          {
            id: 9991,
            parentId: 3505,
            areaName: '阿荣旗',
            areaPath: '中国,内蒙古自治区,呼伦贝尔市,阿荣旗',
            areaCode: '100001500070210000'
          },
          {
            id: 9992,
            parentId: 3505,
            areaName: '莫力达瓦达斡尔族自治旗',
            areaPath: '中国,内蒙古自治区,呼伦贝尔市,莫力达瓦达斡尔族自治旗',
            areaCode: '100001500070220000'
          },
          {
            id: 9993,
            parentId: 3505,
            areaName: '鄂伦春自治旗',
            areaPath: '中国,内蒙古自治区,呼伦贝尔市,鄂伦春自治旗',
            areaCode: '100001500070230000'
          },
          {
            id: 9994,
            parentId: 3505,
            areaName: '鄂温克族自治旗',
            areaPath: '中国,内蒙古自治区,呼伦贝尔市,鄂温克族自治旗',
            areaCode: '100001500070240000'
          },
          {
            id: 9995,
            parentId: 3505,
            areaName: '陈巴尔虎旗',
            areaPath: '中国,内蒙古自治区,呼伦贝尔市,陈巴尔虎旗',
            areaCode: '100001500070250000'
          },
          {
            id: 9996,
            parentId: 3505,
            areaName: '新巴尔虎左旗',
            areaPath: '中国,内蒙古自治区,呼伦贝尔市,新巴尔虎左旗',
            areaCode: '100001500070260000'
          },
          {
            id: 9997,
            parentId: 3505,
            areaName: '新巴尔虎右旗',
            areaPath: '中国,内蒙古自治区,呼伦贝尔市,新巴尔虎右旗',
            areaCode: '100001500070270000'
          },
          {
            id: 9998,
            parentId: 3505,
            areaName: '满洲里市',
            areaPath: '中国,内蒙古自治区,呼伦贝尔市,满洲里市',
            areaCode: '100001500070810000'
          },
          {
            id: 9999,
            parentId: 3505,
            areaName: '牙克石市',
            areaPath: '中国,内蒙古自治区,呼伦贝尔市,牙克石市',
            areaCode: '100001500070820000'
          },
          {
            id: 10000,
            parentId: 3505,
            areaName: '扎兰屯市',
            areaPath: '中国,内蒙古自治区,呼伦贝尔市,扎兰屯市',
            areaCode: '100001500070830000'
          },
          {
            id: 10001,
            parentId: 3505,
            areaName: '额尔古纳市',
            areaPath: '中国,内蒙古自治区,呼伦贝尔市,额尔古纳市',
            areaCode: '100001500070840000'
          },
          {
            id: 10002,
            parentId: 3505,
            areaName: '根河市',
            areaPath: '中国,内蒙古自治区,呼伦贝尔市,根河市',
            areaCode: '100001500070850000'
          }
        ]
      },
      {
        id: 3506,
        parentId: 1438,
        areaName: '巴彦淖尔市',
        areaPath: '中国,内蒙古自治区,巴彦淖尔市',
        areaCode: '100001500080000000',
        children: [
          {
            id: 10003,
            parentId: 3506,
            areaName: '临河区',
            areaPath: '中国,内蒙古自治区,巴彦淖尔市,临河区',
            areaCode: '100001500080020000'
          },
          {
            id: 10004,
            parentId: 3506,
            areaName: '五原县',
            areaPath: '中国,内蒙古自治区,巴彦淖尔市,五原县',
            areaCode: '100001500080210000'
          },
          {
            id: 10005,
            parentId: 3506,
            areaName: '磴口县',
            areaPath: '中国,内蒙古自治区,巴彦淖尔市,磴口县',
            areaCode: '100001500080220000'
          },
          {
            id: 10006,
            parentId: 3506,
            areaName: '乌拉特前旗',
            areaPath: '中国,内蒙古自治区,巴彦淖尔市,乌拉特前旗',
            areaCode: '100001500080230000'
          },
          {
            id: 10007,
            parentId: 3506,
            areaName: '乌拉特中旗',
            areaPath: '中国,内蒙古自治区,巴彦淖尔市,乌拉特中旗',
            areaCode: '100001500080240000'
          },
          {
            id: 10008,
            parentId: 3506,
            areaName: '乌拉特后旗',
            areaPath: '中国,内蒙古自治区,巴彦淖尔市,乌拉特后旗',
            areaCode: '100001500080250000'
          },
          {
            id: 10009,
            parentId: 3506,
            areaName: '杭锦后旗',
            areaPath: '中国,内蒙古自治区,巴彦淖尔市,杭锦后旗',
            areaCode: '100001500080260000'
          }
        ]
      },
      {
        id: 3507,
        parentId: 1438,
        areaName: '乌兰察布市',
        areaPath: '中国,内蒙古自治区,乌兰察布市',
        areaCode: '100001500090000000',
        children: [
          {
            id: 10010,
            parentId: 3507,
            areaName: '集宁区',
            areaPath: '中国,内蒙古自治区,乌兰察布市,集宁区',
            areaCode: '100001500090020000'
          },
          {
            id: 10011,
            parentId: 3507,
            areaName: '卓资县',
            areaPath: '中国,内蒙古自治区,乌兰察布市,卓资县',
            areaCode: '100001500090210000'
          },
          {
            id: 10012,
            parentId: 3507,
            areaName: '化德县',
            areaPath: '中国,内蒙古自治区,乌兰察布市,化德县',
            areaCode: '100001500090220000'
          },
          {
            id: 10013,
            parentId: 3507,
            areaName: '商都县',
            areaPath: '中国,内蒙古自治区,乌兰察布市,商都县',
            areaCode: '100001500090230000'
          },
          {
            id: 10014,
            parentId: 3507,
            areaName: '兴和县',
            areaPath: '中国,内蒙古自治区,乌兰察布市,兴和县',
            areaCode: '100001500090240000'
          },
          {
            id: 10015,
            parentId: 3507,
            areaName: '凉城县',
            areaPath: '中国,内蒙古自治区,乌兰察布市,凉城县',
            areaCode: '100001500090250000'
          },
          {
            id: 10016,
            parentId: 3507,
            areaName: '察哈尔右翼前旗',
            areaPath: '中国,内蒙古自治区,乌兰察布市,察哈尔右翼前旗',
            areaCode: '100001500090260000'
          },
          {
            id: 10017,
            parentId: 3507,
            areaName: '察哈尔右翼中旗',
            areaPath: '中国,内蒙古自治区,乌兰察布市,察哈尔右翼中旗',
            areaCode: '100001500090270000'
          },
          {
            id: 10018,
            parentId: 3507,
            areaName: '察哈尔右翼后旗',
            areaPath: '中国,内蒙古自治区,乌兰察布市,察哈尔右翼后旗',
            areaCode: '100001500090280000'
          },
          {
            id: 10019,
            parentId: 3507,
            areaName: '四子王旗',
            areaPath: '中国,内蒙古自治区,乌兰察布市,四子王旗',
            areaCode: '100001500090290000'
          },
          {
            id: 10020,
            parentId: 3507,
            areaName: '丰镇市',
            areaPath: '中国,内蒙古自治区,乌兰察布市,丰镇市',
            areaCode: '100001500090810000'
          }
        ]
      },
      {
        id: 3508,
        parentId: 1438,
        areaName: '兴安盟',
        areaPath: '中国,内蒙古自治区,兴安盟',
        areaCode: '100001500220000000',
        children: [
          {
            id: 10021,
            parentId: 3508,
            areaName: '乌兰浩特市',
            areaPath: '中国,内蒙古自治区,兴安盟,乌兰浩特市',
            areaCode: '100001500220010000'
          },
          {
            id: 10022,
            parentId: 3508,
            areaName: '阿尔山市',
            areaPath: '中国,内蒙古自治区,兴安盟,阿尔山市',
            areaCode: '100001500220020000'
          },
          {
            id: 10023,
            parentId: 3508,
            areaName: '科尔沁右翼前旗',
            areaPath: '中国,内蒙古自治区,兴安盟,科尔沁右翼前旗',
            areaCode: '100001500220210000'
          },
          {
            id: 10024,
            parentId: 3508,
            areaName: '科尔沁右翼中旗',
            areaPath: '中国,内蒙古自治区,兴安盟,科尔沁右翼中旗',
            areaCode: '100001500220220000'
          },
          {
            id: 10025,
            parentId: 3508,
            areaName: '扎赉特旗',
            areaPath: '中国,内蒙古自治区,兴安盟,扎赉特旗',
            areaCode: '100001500220230000'
          },
          {
            id: 10026,
            parentId: 3508,
            areaName: '突泉县',
            areaPath: '中国,内蒙古自治区,兴安盟,突泉县',
            areaCode: '100001500220240000'
          }
        ]
      },
      {
        id: 3509,
        parentId: 1438,
        areaName: '锡林郭勒盟',
        areaPath: '中国,内蒙古自治区,锡林郭勒盟',
        areaCode: '100001500250000000',
        children: [
          {
            id: 10027,
            parentId: 3509,
            areaName: '二连浩特市',
            areaPath: '中国,内蒙古自治区,锡林郭勒盟,二连浩特市',
            areaCode: '100001500250010000'
          },
          {
            id: 10028,
            parentId: 3509,
            areaName: '锡林浩特市',
            areaPath: '中国,内蒙古自治区,锡林郭勒盟,锡林浩特市',
            areaCode: '100001500250020000'
          },
          {
            id: 10029,
            parentId: 3509,
            areaName: '阿巴嘎旗',
            areaPath: '中国,内蒙古自治区,锡林郭勒盟,阿巴嘎旗',
            areaCode: '100001500250220000'
          },
          {
            id: 10030,
            parentId: 3509,
            areaName: '苏尼特左旗',
            areaPath: '中国,内蒙古自治区,锡林郭勒盟,苏尼特左旗',
            areaCode: '100001500250230000'
          },
          {
            id: 10031,
            parentId: 3509,
            areaName: '苏尼特右旗',
            areaPath: '中国,内蒙古自治区,锡林郭勒盟,苏尼特右旗',
            areaCode: '100001500250240000'
          },
          {
            id: 10032,
            parentId: 3509,
            areaName: '东乌珠穆沁旗',
            areaPath: '中国,内蒙古自治区,锡林郭勒盟,东乌珠穆沁旗',
            areaCode: '100001500250250000'
          },
          {
            id: 10033,
            parentId: 3509,
            areaName: '西乌珠穆沁旗',
            areaPath: '中国,内蒙古自治区,锡林郭勒盟,西乌珠穆沁旗',
            areaCode: '100001500250260000'
          },
          {
            id: 10034,
            parentId: 3509,
            areaName: '太仆寺旗',
            areaPath: '中国,内蒙古自治区,锡林郭勒盟,太仆寺旗',
            areaCode: '100001500250270000'
          },
          {
            id: 10035,
            parentId: 3509,
            areaName: '镶黄旗',
            areaPath: '中国,内蒙古自治区,锡林郭勒盟,镶黄旗',
            areaCode: '100001500250280000'
          },
          {
            id: 10036,
            parentId: 3509,
            areaName: '正镶白旗',
            areaPath: '中国,内蒙古自治区,锡林郭勒盟,正镶白旗',
            areaCode: '100001500250290000'
          },
          {
            id: 10037,
            parentId: 3509,
            areaName: '正蓝旗',
            areaPath: '中国,内蒙古自治区,锡林郭勒盟,正蓝旗',
            areaCode: '100001500250300000'
          },
          {
            id: 10038,
            parentId: 3509,
            areaName: '多伦县',
            areaPath: '中国,内蒙古自治区,锡林郭勒盟,多伦县',
            areaCode: '100001500250310000'
          }
        ]
      },
      {
        id: 3510,
        parentId: 1438,
        areaName: '阿拉善盟',
        areaPath: '中国,内蒙古自治区,阿拉善盟',
        areaCode: '100001500290000000',
        children: [
          {
            id: 10039,
            parentId: 3510,
            areaName: '阿拉善左旗',
            areaPath: '中国,内蒙古自治区,阿拉善盟,阿拉善左旗',
            areaCode: '100001500290210000'
          },
          {
            id: 10040,
            parentId: 3510,
            areaName: '阿拉善右旗',
            areaPath: '中国,内蒙古自治区,阿拉善盟,阿拉善右旗',
            areaCode: '100001500290220000'
          },
          {
            id: 10041,
            parentId: 3510,
            areaName: '额济纳旗',
            areaPath: '中国,内蒙古自治区,阿拉善盟,额济纳旗',
            areaCode: '100001500290230000'
          }
        ]
      }
    ]
  },
  {
    id: 1439,
    parentId: 1,
    areaName: '辽宁省',
    areaPath: '中国,辽宁省',
    areaCode: '100002100000000000',
    children: [
      {
        id: 3511,
        parentId: 1439,
        areaName: '沈阳市',
        areaPath: '中国,辽宁省,沈阳市',
        areaCode: '100002100010000000',
        children: [
          {
            id: 10042,
            parentId: 3511,
            areaName: '和平区',
            areaPath: '中国,辽宁省,沈阳市,和平区',
            areaCode: '100002100010020000'
          },
          {
            id: 10043,
            parentId: 3511,
            areaName: '沈河区',
            areaPath: '中国,辽宁省,沈阳市,沈河区',
            areaCode: '100002100010030000'
          },
          {
            id: 10044,
            parentId: 3511,
            areaName: '大东区',
            areaPath: '中国,辽宁省,沈阳市,大东区',
            areaCode: '100002100010040000'
          },
          {
            id: 10045,
            parentId: 3511,
            areaName: '皇姑区',
            areaPath: '中国,辽宁省,沈阳市,皇姑区',
            areaCode: '100002100010050000'
          },
          {
            id: 10046,
            parentId: 3511,
            areaName: '铁西区',
            areaPath: '中国,辽宁省,沈阳市,铁西区',
            areaCode: '100002100010060000'
          },
          {
            id: 10047,
            parentId: 3511,
            areaName: '苏家屯区',
            areaPath: '中国,辽宁省,沈阳市,苏家屯区',
            areaCode: '100002100010110000'
          },
          {
            id: 10048,
            parentId: 3511,
            areaName: '浑南区',
            areaPath: '中国,辽宁省,沈阳市,浑南区',
            areaCode: '100002100010120000'
          },
          {
            id: 10049,
            parentId: 3511,
            areaName: '沈北新区',
            areaPath: '中国,辽宁省,沈阳市,沈北新区',
            areaCode: '100002100010130000'
          },
          {
            id: 10050,
            parentId: 3511,
            areaName: '于洪区',
            areaPath: '中国,辽宁省,沈阳市,于洪区',
            areaCode: '100002100010140000'
          },
          {
            id: 10051,
            parentId: 3511,
            areaName: '辽中区',
            areaPath: '中国,辽宁省,沈阳市,辽中区',
            areaCode: '100002100010150000'
          },
          {
            id: 10052,
            parentId: 3511,
            areaName: '康平县',
            areaPath: '中国,辽宁省,沈阳市,康平县',
            areaCode: '100002100010230000'
          },
          {
            id: 10053,
            parentId: 3511,
            areaName: '法库县',
            areaPath: '中国,辽宁省,沈阳市,法库县',
            areaCode: '100002100010240000'
          },
          {
            id: 10054,
            parentId: 3511,
            areaName: '新民市',
            areaPath: '中国,辽宁省,沈阳市,新民市',
            areaCode: '100002100010810000'
          }
        ]
      },
      {
        id: 3512,
        parentId: 1439,
        areaName: '大连市',
        areaPath: '中国,辽宁省,大连市',
        areaCode: '100002100020000000',
        children: [
          {
            id: 10055,
            parentId: 3512,
            areaName: '中山区',
            areaPath: '中国,辽宁省,大连市,中山区',
            areaCode: '100002100020020000'
          },
          {
            id: 10056,
            parentId: 3512,
            areaName: '西岗区',
            areaPath: '中国,辽宁省,大连市,西岗区',
            areaCode: '100002100020030000'
          },
          {
            id: 10057,
            parentId: 3512,
            areaName: '沙河口区',
            areaPath: '中国,辽宁省,大连市,沙河口区',
            areaCode: '100002100020040000'
          },
          {
            id: 10058,
            parentId: 3512,
            areaName: '甘井子区',
            areaPath: '中国,辽宁省,大连市,甘井子区',
            areaCode: '100002100020110000'
          },
          {
            id: 10059,
            parentId: 3512,
            areaName: '旅顺口区',
            areaPath: '中国,辽宁省,大连市,旅顺口区',
            areaCode: '100002100020120000'
          },
          {
            id: 10060,
            parentId: 3512,
            areaName: '金州区',
            areaPath: '中国,辽宁省,大连市,金州区',
            areaCode: '100002100020130000'
          },
          {
            id: 10061,
            parentId: 3512,
            areaName: '普兰店区',
            areaPath: '中国,辽宁省,大连市,普兰店区',
            areaCode: '100002100020140000'
          },
          {
            id: 10062,
            parentId: 3512,
            areaName: '长海县',
            areaPath: '中国,辽宁省,大连市,长海县',
            areaCode: '100002100020240000'
          },
          {
            id: 10063,
            parentId: 3512,
            areaName: '瓦房店市',
            areaPath: '中国,辽宁省,大连市,瓦房店市',
            areaCode: '100002100020810000'
          },
          {
            id: 10064,
            parentId: 3512,
            areaName: '庄河市',
            areaPath: '中国,辽宁省,大连市,庄河市',
            areaCode: '100002100020830000'
          }
        ]
      },
      {
        id: 3513,
        parentId: 1439,
        areaName: '鞍山市',
        areaPath: '中国,辽宁省,鞍山市',
        areaCode: '100002100030000000',
        children: [
          {
            id: 10065,
            parentId: 3513,
            areaName: '铁东区',
            areaPath: '中国,辽宁省,鞍山市,铁东区',
            areaCode: '100002100030020000'
          },
          {
            id: 10066,
            parentId: 3513,
            areaName: '铁西区',
            areaPath: '中国,辽宁省,鞍山市,铁西区',
            areaCode: '100002100030030000'
          },
          {
            id: 10067,
            parentId: 3513,
            areaName: '立山区',
            areaPath: '中国,辽宁省,鞍山市,立山区',
            areaCode: '100002100030040000'
          },
          {
            id: 10068,
            parentId: 3513,
            areaName: '千山区',
            areaPath: '中国,辽宁省,鞍山市,千山区',
            areaCode: '100002100030110000'
          },
          {
            id: 10069,
            parentId: 3513,
            areaName: '台安县',
            areaPath: '中国,辽宁省,鞍山市,台安县',
            areaCode: '100002100030210000'
          },
          {
            id: 10070,
            parentId: 3513,
            areaName: '岫岩满族自治县',
            areaPath: '中国,辽宁省,鞍山市,岫岩满族自治县',
            areaCode: '100002100030230000'
          },
          {
            id: 10071,
            parentId: 3513,
            areaName: '海城市',
            areaPath: '中国,辽宁省,鞍山市,海城市',
            areaCode: '100002100030810000'
          }
        ]
      },
      {
        id: 3514,
        parentId: 1439,
        areaName: '抚顺市',
        areaPath: '中国,辽宁省,抚顺市',
        areaCode: '100002100040000000',
        children: [
          {
            id: 10072,
            parentId: 3514,
            areaName: '新抚区',
            areaPath: '中国,辽宁省,抚顺市,新抚区',
            areaCode: '100002100040020000'
          },
          {
            id: 10073,
            parentId: 3514,
            areaName: '东洲区',
            areaPath: '中国,辽宁省,抚顺市,东洲区',
            areaCode: '100002100040030000'
          },
          {
            id: 10074,
            parentId: 3514,
            areaName: '望花区',
            areaPath: '中国,辽宁省,抚顺市,望花区',
            areaCode: '100002100040040000'
          },
          {
            id: 10075,
            parentId: 3514,
            areaName: '顺城区',
            areaPath: '中国,辽宁省,抚顺市,顺城区',
            areaCode: '100002100040110000'
          },
          {
            id: 10076,
            parentId: 3514,
            areaName: '抚顺县',
            areaPath: '中国,辽宁省,抚顺市,抚顺县',
            areaCode: '100002100040210000'
          },
          {
            id: 10077,
            parentId: 3514,
            areaName: '新宾满族自治县',
            areaPath: '中国,辽宁省,抚顺市,新宾满族自治县',
            areaCode: '100002100040220000'
          },
          {
            id: 10078,
            parentId: 3514,
            areaName: '清原满族自治县',
            areaPath: '中国,辽宁省,抚顺市,清原满族自治县',
            areaCode: '100002100040230000'
          }
        ]
      },
      {
        id: 3515,
        parentId: 1439,
        areaName: '本溪市',
        areaPath: '中国,辽宁省,本溪市',
        areaCode: '100002100050000000',
        children: [
          {
            id: 10079,
            parentId: 3515,
            areaName: '平山区',
            areaPath: '中国,辽宁省,本溪市,平山区',
            areaCode: '100002100050020000'
          },
          {
            id: 10080,
            parentId: 3515,
            areaName: '溪湖区',
            areaPath: '中国,辽宁省,本溪市,溪湖区',
            areaCode: '100002100050030000'
          },
          {
            id: 10081,
            parentId: 3515,
            areaName: '明山区',
            areaPath: '中国,辽宁省,本溪市,明山区',
            areaCode: '100002100050040000'
          },
          {
            id: 10082,
            parentId: 3515,
            areaName: '南芬区',
            areaPath: '中国,辽宁省,本溪市,南芬区',
            areaCode: '100002100050050000'
          },
          {
            id: 10083,
            parentId: 3515,
            areaName: '本溪满族自治县',
            areaPath: '中国,辽宁省,本溪市,本溪满族自治县',
            areaCode: '100002100050210000'
          },
          {
            id: 10084,
            parentId: 3515,
            areaName: '桓仁满族自治县',
            areaPath: '中国,辽宁省,本溪市,桓仁满族自治县',
            areaCode: '100002100050220000'
          }
        ]
      },
      {
        id: 3516,
        parentId: 1439,
        areaName: '丹东市',
        areaPath: '中国,辽宁省,丹东市',
        areaCode: '100002100060000000',
        children: [
          {
            id: 10085,
            parentId: 3516,
            areaName: '元宝区',
            areaPath: '中国,辽宁省,丹东市,元宝区',
            areaCode: '100002100060020000'
          },
          {
            id: 10086,
            parentId: 3516,
            areaName: '振兴区',
            areaPath: '中国,辽宁省,丹东市,振兴区',
            areaCode: '100002100060030000'
          },
          {
            id: 10087,
            parentId: 3516,
            areaName: '振安区',
            areaPath: '中国,辽宁省,丹东市,振安区',
            areaCode: '100002100060040000'
          },
          {
            id: 10088,
            parentId: 3516,
            areaName: '宽甸满族自治县',
            areaPath: '中国,辽宁省,丹东市,宽甸满族自治县',
            areaCode: '100002100060240000'
          },
          {
            id: 10089,
            parentId: 3516,
            areaName: '东港市',
            areaPath: '中国,辽宁省,丹东市,东港市',
            areaCode: '100002100060810000'
          },
          {
            id: 10090,
            parentId: 3516,
            areaName: '凤城市',
            areaPath: '中国,辽宁省,丹东市,凤城市',
            areaCode: '100002100060820000'
          }
        ]
      },
      {
        id: 3517,
        parentId: 1439,
        areaName: '锦州市',
        areaPath: '中国,辽宁省,锦州市',
        areaCode: '100002100070000000',
        children: [
          {
            id: 10091,
            parentId: 3517,
            areaName: '古塔区',
            areaPath: '中国,辽宁省,锦州市,古塔区',
            areaCode: '100002100070020000'
          },
          {
            id: 10092,
            parentId: 3517,
            areaName: '凌河区',
            areaPath: '中国,辽宁省,锦州市,凌河区',
            areaCode: '100002100070030000'
          },
          {
            id: 10093,
            parentId: 3517,
            areaName: '太和区',
            areaPath: '中国,辽宁省,锦州市,太和区',
            areaCode: '100002100070110000'
          },
          {
            id: 10094,
            parentId: 3517,
            areaName: '黑山县',
            areaPath: '中国,辽宁省,锦州市,黑山县',
            areaCode: '100002100070260000'
          },
          {
            id: 10095,
            parentId: 3517,
            areaName: '义县',
            areaPath: '中国,辽宁省,锦州市,义县',
            areaCode: '100002100070270000'
          },
          {
            id: 10096,
            parentId: 3517,
            areaName: '凌海市',
            areaPath: '中国,辽宁省,锦州市,凌海市',
            areaCode: '100002100070810000'
          },
          {
            id: 10097,
            parentId: 3517,
            areaName: '北镇市',
            areaPath: '中国,辽宁省,锦州市,北镇市',
            areaCode: '100002100070820000'
          }
        ]
      },
      {
        id: 3518,
        parentId: 1439,
        areaName: '营口市',
        areaPath: '中国,辽宁省,营口市',
        areaCode: '100002100080000000',
        children: [
          {
            id: 10098,
            parentId: 3518,
            areaName: '站前区',
            areaPath: '中国,辽宁省,营口市,站前区',
            areaCode: '100002100080020000'
          },
          {
            id: 10099,
            parentId: 3518,
            areaName: '西市区',
            areaPath: '中国,辽宁省,营口市,西市区',
            areaCode: '100002100080030000'
          },
          {
            id: 10100,
            parentId: 3518,
            areaName: '鲅鱼圈区',
            areaPath: '中国,辽宁省,营口市,鲅鱼圈区',
            areaCode: '100002100080040000'
          },
          {
            id: 10101,
            parentId: 3518,
            areaName: '老边区',
            areaPath: '中国,辽宁省,营口市,老边区',
            areaCode: '100002100080110000'
          },
          {
            id: 10102,
            parentId: 3518,
            areaName: '盖州市',
            areaPath: '中国,辽宁省,营口市,盖州市',
            areaCode: '100002100080810000'
          },
          {
            id: 10103,
            parentId: 3518,
            areaName: '大石桥市',
            areaPath: '中国,辽宁省,营口市,大石桥市',
            areaCode: '100002100080820000'
          }
        ]
      },
      {
        id: 3519,
        parentId: 1439,
        areaName: '阜新市',
        areaPath: '中国,辽宁省,阜新市',
        areaCode: '100002100090000000',
        children: [
          {
            id: 10104,
            parentId: 3519,
            areaName: '海州区',
            areaPath: '中国,辽宁省,阜新市,海州区',
            areaCode: '100002100090020000'
          },
          {
            id: 10105,
            parentId: 3519,
            areaName: '新邱区',
            areaPath: '中国,辽宁省,阜新市,新邱区',
            areaCode: '100002100090030000'
          },
          {
            id: 10106,
            parentId: 3519,
            areaName: '太平区',
            areaPath: '中国,辽宁省,阜新市,太平区',
            areaCode: '100002100090040000'
          },
          {
            id: 10107,
            parentId: 3519,
            areaName: '清河门区',
            areaPath: '中国,辽宁省,阜新市,清河门区',
            areaCode: '100002100090050000'
          },
          {
            id: 10108,
            parentId: 3519,
            areaName: '细河区',
            areaPath: '中国,辽宁省,阜新市,细河区',
            areaCode: '100002100090110000'
          },
          {
            id: 10109,
            parentId: 3519,
            areaName: '阜新蒙古族自治县',
            areaPath: '中国,辽宁省,阜新市,阜新蒙古族自治县',
            areaCode: '100002100090210000'
          },
          {
            id: 10110,
            parentId: 3519,
            areaName: '彰武县',
            areaPath: '中国,辽宁省,阜新市,彰武县',
            areaCode: '100002100090220000'
          }
        ]
      },
      {
        id: 3520,
        parentId: 1439,
        areaName: '辽阳市',
        areaPath: '中国,辽宁省,辽阳市',
        areaCode: '100002100100000000',
        children: [
          {
            id: 10111,
            parentId: 3520,
            areaName: '白塔区',
            areaPath: '中国,辽宁省,辽阳市,白塔区',
            areaCode: '100002100100020000'
          },
          {
            id: 10112,
            parentId: 3520,
            areaName: '文圣区',
            areaPath: '中国,辽宁省,辽阳市,文圣区',
            areaCode: '100002100100030000'
          },
          {
            id: 10113,
            parentId: 3520,
            areaName: '宏伟区',
            areaPath: '中国,辽宁省,辽阳市,宏伟区',
            areaCode: '100002100100040000'
          },
          {
            id: 10114,
            parentId: 3520,
            areaName: '弓长岭区',
            areaPath: '中国,辽宁省,辽阳市,弓长岭区',
            areaCode: '100002100100050000'
          },
          {
            id: 10115,
            parentId: 3520,
            areaName: '太子河区',
            areaPath: '中国,辽宁省,辽阳市,太子河区',
            areaCode: '100002100100110000'
          },
          {
            id: 10116,
            parentId: 3520,
            areaName: '辽阳县',
            areaPath: '中国,辽宁省,辽阳市,辽阳县',
            areaCode: '100002100100210000'
          },
          {
            id: 10117,
            parentId: 3520,
            areaName: '灯塔市',
            areaPath: '中国,辽宁省,辽阳市,灯塔市',
            areaCode: '100002100100810000'
          }
        ]
      },
      {
        id: 3521,
        parentId: 1439,
        areaName: '盘锦市',
        areaPath: '中国,辽宁省,盘锦市',
        areaCode: '100002100110000000',
        children: [
          {
            id: 10118,
            parentId: 3521,
            areaName: '双台子区',
            areaPath: '中国,辽宁省,盘锦市,双台子区',
            areaCode: '100002100110020000'
          },
          {
            id: 10119,
            parentId: 3521,
            areaName: '兴隆台区',
            areaPath: '中国,辽宁省,盘锦市,兴隆台区',
            areaCode: '100002100110030000'
          },
          {
            id: 10120,
            parentId: 3521,
            areaName: '大洼区',
            areaPath: '中国,辽宁省,盘锦市,大洼区',
            areaCode: '100002100110040000'
          },
          {
            id: 10121,
            parentId: 3521,
            areaName: '盘山县',
            areaPath: '中国,辽宁省,盘锦市,盘山县',
            areaCode: '100002100110220000'
          }
        ]
      },
      {
        id: 3522,
        parentId: 1439,
        areaName: '铁岭市',
        areaPath: '中国,辽宁省,铁岭市',
        areaCode: '100002100120000000',
        children: [
          {
            id: 10122,
            parentId: 3522,
            areaName: '银州区',
            areaPath: '中国,辽宁省,铁岭市,银州区',
            areaCode: '100002100120020000'
          },
          {
            id: 10123,
            parentId: 3522,
            areaName: '清河区',
            areaPath: '中国,辽宁省,铁岭市,清河区',
            areaCode: '100002100120040000'
          },
          {
            id: 10124,
            parentId: 3522,
            areaName: '铁岭县',
            areaPath: '中国,辽宁省,铁岭市,铁岭县',
            areaCode: '100002100120210000'
          },
          {
            id: 10125,
            parentId: 3522,
            areaName: '西丰县',
            areaPath: '中国,辽宁省,铁岭市,西丰县',
            areaCode: '100002100120230000'
          },
          {
            id: 10126,
            parentId: 3522,
            areaName: '昌图县',
            areaPath: '中国,辽宁省,铁岭市,昌图县',
            areaCode: '100002100120240000'
          },
          {
            id: 10127,
            parentId: 3522,
            areaName: '调兵山市',
            areaPath: '中国,辽宁省,铁岭市,调兵山市',
            areaCode: '100002100120810000'
          },
          {
            id: 10128,
            parentId: 3522,
            areaName: '开原市',
            areaPath: '中国,辽宁省,铁岭市,开原市',
            areaCode: '100002100120820000'
          }
        ]
      },
      {
        id: 3523,
        parentId: 1439,
        areaName: '朝阳市',
        areaPath: '中国,辽宁省,朝阳市',
        areaCode: '100002100130000000',
        children: [
          {
            id: 10129,
            parentId: 3523,
            areaName: '双塔区',
            areaPath: '中国,辽宁省,朝阳市,双塔区',
            areaCode: '100002100130020000'
          },
          {
            id: 10130,
            parentId: 3523,
            areaName: '龙城区',
            areaPath: '中国,辽宁省,朝阳市,龙城区',
            areaCode: '100002100130030000'
          },
          {
            id: 10131,
            parentId: 3523,
            areaName: '朝阳县',
            areaPath: '中国,辽宁省,朝阳市,朝阳县',
            areaCode: '100002100130210000'
          },
          {
            id: 10132,
            parentId: 3523,
            areaName: '建平县',
            areaPath: '中国,辽宁省,朝阳市,建平县',
            areaCode: '100002100130220000'
          },
          {
            id: 10133,
            parentId: 3523,
            areaName: '喀喇沁左翼蒙古族自治县',
            areaPath: '中国,辽宁省,朝阳市,喀喇沁左翼蒙古族自治县',
            areaCode: '100002100130240000'
          },
          {
            id: 10134,
            parentId: 3523,
            areaName: '北票市',
            areaPath: '中国,辽宁省,朝阳市,北票市',
            areaCode: '100002100130810000'
          },
          {
            id: 10135,
            parentId: 3523,
            areaName: '凌源市',
            areaPath: '中国,辽宁省,朝阳市,凌源市',
            areaCode: '100002100130820000'
          }
        ]
      },
      {
        id: 3524,
        parentId: 1439,
        areaName: '葫芦岛市',
        areaPath: '中国,辽宁省,葫芦岛市',
        areaCode: '100002100140000000',
        children: [
          {
            id: 10136,
            parentId: 3524,
            areaName: '连山区',
            areaPath: '中国,辽宁省,葫芦岛市,连山区',
            areaCode: '100002100140020000'
          },
          {
            id: 10137,
            parentId: 3524,
            areaName: '龙港区',
            areaPath: '中国,辽宁省,葫芦岛市,龙港区',
            areaCode: '100002100140030000'
          },
          {
            id: 10138,
            parentId: 3524,
            areaName: '南票区',
            areaPath: '中国,辽宁省,葫芦岛市,南票区',
            areaCode: '100002100140040000'
          },
          {
            id: 10139,
            parentId: 3524,
            areaName: '绥中县',
            areaPath: '中国,辽宁省,葫芦岛市,绥中县',
            areaCode: '100002100140210000'
          },
          {
            id: 10140,
            parentId: 3524,
            areaName: '建昌县',
            areaPath: '中国,辽宁省,葫芦岛市,建昌县',
            areaCode: '100002100140220000'
          },
          {
            id: 10141,
            parentId: 3524,
            areaName: '兴城市',
            areaPath: '中国,辽宁省,葫芦岛市,兴城市',
            areaCode: '100002100140810000'
          }
        ]
      }
    ]
  },
  {
    id: 1440,
    parentId: 1,
    areaName: '吉林省',
    areaPath: '中国,吉林省',
    areaCode: '100002200000000000',
    children: [
      {
        id: 3525,
        parentId: 1440,
        areaName: '长春市',
        areaPath: '中国,吉林省,长春市',
        areaCode: '100002200010000000',
        children: [
          {
            id: 10142,
            parentId: 3525,
            areaName: '南关区',
            areaPath: '中国,吉林省,长春市,南关区',
            areaCode: '100002200010020000'
          },
          {
            id: 10143,
            parentId: 3525,
            areaName: '宽城区',
            areaPath: '中国,吉林省,长春市,宽城区',
            areaCode: '100002200010030000'
          },
          {
            id: 10144,
            parentId: 3525,
            areaName: '朝阳区',
            areaPath: '中国,吉林省,长春市,朝阳区',
            areaCode: '100002200010040000'
          },
          {
            id: 10145,
            parentId: 3525,
            areaName: '二道区',
            areaPath: '中国,吉林省,长春市,二道区',
            areaCode: '100002200010050000'
          },
          {
            id: 10146,
            parentId: 3525,
            areaName: '绿园区',
            areaPath: '中国,吉林省,长春市,绿园区',
            areaCode: '100002200010060000'
          },
          {
            id: 10147,
            parentId: 3525,
            areaName: '双阳区',
            areaPath: '中国,吉林省,长春市,双阳区',
            areaCode: '100002200010120000'
          },
          {
            id: 10148,
            parentId: 3525,
            areaName: '九台区',
            areaPath: '中国,吉林省,长春市,九台区',
            areaCode: '100002200010130000'
          },
          {
            id: 10149,
            parentId: 3525,
            areaName: '农安县',
            areaPath: '中国,吉林省,长春市,农安县',
            areaCode: '100002200010220000'
          },
          {
            id: 10150,
            parentId: 3525,
            areaName: '榆树市',
            areaPath: '中国,吉林省,长春市,榆树市',
            areaCode: '100002200010820000'
          },
          {
            id: 10151,
            parentId: 3525,
            areaName: '德惠市',
            areaPath: '中国,吉林省,长春市,德惠市',
            areaCode: '100002200010830000'
          }
        ]
      },
      {
        id: 3526,
        parentId: 1440,
        areaName: '吉林市',
        areaPath: '中国,吉林省,吉林市',
        areaCode: '100002200020000000',
        children: [
          {
            id: 10152,
            parentId: 3526,
            areaName: '昌邑区',
            areaPath: '中国,吉林省,吉林市,昌邑区',
            areaCode: '100002200020020000'
          },
          {
            id: 10153,
            parentId: 3526,
            areaName: '龙潭区',
            areaPath: '中国,吉林省,吉林市,龙潭区',
            areaCode: '100002200020030000'
          },
          {
            id: 10154,
            parentId: 3526,
            areaName: '船营区',
            areaPath: '中国,吉林省,吉林市,船营区',
            areaCode: '100002200020040000'
          },
          {
            id: 10155,
            parentId: 3526,
            areaName: '丰满区',
            areaPath: '中国,吉林省,吉林市,丰满区',
            areaCode: '100002200020110000'
          },
          {
            id: 10156,
            parentId: 3526,
            areaName: '永吉县',
            areaPath: '中国,吉林省,吉林市,永吉县',
            areaCode: '100002200020210000'
          },
          {
            id: 10157,
            parentId: 3526,
            areaName: '蛟河市',
            areaPath: '中国,吉林省,吉林市,蛟河市',
            areaCode: '100002200020810000'
          },
          {
            id: 10158,
            parentId: 3526,
            areaName: '桦甸市',
            areaPath: '中国,吉林省,吉林市,桦甸市',
            areaCode: '100002200020820000'
          },
          {
            id: 10159,
            parentId: 3526,
            areaName: '舒兰市',
            areaPath: '中国,吉林省,吉林市,舒兰市',
            areaCode: '100002200020830000'
          },
          {
            id: 10160,
            parentId: 3526,
            areaName: '磐石市',
            areaPath: '中国,吉林省,吉林市,磐石市',
            areaCode: '100002200020840000'
          }
        ]
      },
      {
        id: 3527,
        parentId: 1440,
        areaName: '四平市',
        areaPath: '中国,吉林省,四平市',
        areaCode: '100002200030000000',
        children: [
          {
            id: 10161,
            parentId: 3527,
            areaName: '铁西区',
            areaPath: '中国,吉林省,四平市,铁西区',
            areaCode: '100002200030020000'
          },
          {
            id: 10162,
            parentId: 3527,
            areaName: '铁东区',
            areaPath: '中国,吉林省,四平市,铁东区',
            areaCode: '100002200030030000'
          },
          {
            id: 10163,
            parentId: 3527,
            areaName: '梨树县',
            areaPath: '中国,吉林省,四平市,梨树县',
            areaCode: '100002200030220000'
          },
          {
            id: 10164,
            parentId: 3527,
            areaName: '伊通满族自治县',
            areaPath: '中国,吉林省,四平市,伊通满族自治县',
            areaCode: '100002200030230000'
          },
          {
            id: 10165,
            parentId: 3527,
            areaName: '公主岭市',
            areaPath: '中国,吉林省,四平市,公主岭市',
            areaCode: '100002200030810000'
          },
          {
            id: 10166,
            parentId: 3527,
            areaName: '双辽市',
            areaPath: '中国,吉林省,四平市,双辽市',
            areaCode: '100002200030820000'
          }
        ]
      },
      {
        id: 3528,
        parentId: 1440,
        areaName: '辽源市',
        areaPath: '中国,吉林省,辽源市',
        areaCode: '100002200040000000',
        children: [
          {
            id: 10167,
            parentId: 3528,
            areaName: '龙山区',
            areaPath: '中国,吉林省,辽源市,龙山区',
            areaCode: '100002200040020000'
          },
          {
            id: 10168,
            parentId: 3528,
            areaName: '西安区',
            areaPath: '中国,吉林省,辽源市,西安区',
            areaCode: '100002200040030000'
          },
          {
            id: 10169,
            parentId: 3528,
            areaName: '东丰县',
            areaPath: '中国,吉林省,辽源市,东丰县',
            areaCode: '100002200040210000'
          },
          {
            id: 10170,
            parentId: 3528,
            areaName: '东辽县',
            areaPath: '中国,吉林省,辽源市,东辽县',
            areaCode: '100002200040220000'
          }
        ]
      },
      {
        id: 3529,
        parentId: 1440,
        areaName: '通化市',
        areaPath: '中国,吉林省,通化市',
        areaCode: '100002200050000000',
        children: [
          {
            id: 10171,
            parentId: 3529,
            areaName: '东昌区',
            areaPath: '中国,吉林省,通化市,东昌区',
            areaCode: '100002200050020000'
          },
          {
            id: 10172,
            parentId: 3529,
            areaName: '二道江区',
            areaPath: '中国,吉林省,通化市,二道江区',
            areaCode: '100002200050030000'
          },
          {
            id: 10173,
            parentId: 3529,
            areaName: '通化县',
            areaPath: '中国,吉林省,通化市,通化县',
            areaCode: '100002200050210000'
          },
          {
            id: 10174,
            parentId: 3529,
            areaName: '辉南县',
            areaPath: '中国,吉林省,通化市,辉南县',
            areaCode: '100002200050230000'
          },
          {
            id: 10175,
            parentId: 3529,
            areaName: '柳河县',
            areaPath: '中国,吉林省,通化市,柳河县',
            areaCode: '100002200050240000'
          },
          {
            id: 10176,
            parentId: 3529,
            areaName: '梅河口市',
            areaPath: '中国,吉林省,通化市,梅河口市',
            areaCode: '100002200050810000'
          },
          {
            id: 10177,
            parentId: 3529,
            areaName: '集安市',
            areaPath: '中国,吉林省,通化市,集安市',
            areaCode: '100002200050820000'
          }
        ]
      },
      {
        id: 3530,
        parentId: 1440,
        areaName: '白山市',
        areaPath: '中国,吉林省,白山市',
        areaCode: '100002200060000000',
        children: [
          {
            id: 10178,
            parentId: 3530,
            areaName: '浑江区',
            areaPath: '中国,吉林省,白山市,浑江区',
            areaCode: '100002200060020000'
          },
          {
            id: 10179,
            parentId: 3530,
            areaName: '江源区',
            areaPath: '中国,吉林省,白山市,江源区',
            areaCode: '100002200060050000'
          },
          {
            id: 10180,
            parentId: 3530,
            areaName: '抚松县',
            areaPath: '中国,吉林省,白山市,抚松县',
            areaCode: '100002200060210000'
          },
          {
            id: 10181,
            parentId: 3530,
            areaName: '靖宇县',
            areaPath: '中国,吉林省,白山市,靖宇县',
            areaCode: '100002200060220000'
          },
          {
            id: 10182,
            parentId: 3530,
            areaName: '长白朝鲜族自治县',
            areaPath: '中国,吉林省,白山市,长白朝鲜族自治县',
            areaCode: '100002200060230000'
          },
          {
            id: 10183,
            parentId: 3530,
            areaName: '临江市',
            areaPath: '中国,吉林省,白山市,临江市',
            areaCode: '100002200060810000'
          }
        ]
      },
      {
        id: 3531,
        parentId: 1440,
        areaName: '松原市',
        areaPath: '中国,吉林省,松原市',
        areaCode: '100002200070000000',
        children: [
          {
            id: 10184,
            parentId: 3531,
            areaName: '宁江区',
            areaPath: '中国,吉林省,松原市,宁江区',
            areaCode: '100002200070020000'
          },
          {
            id: 10185,
            parentId: 3531,
            areaName: '前郭尔罗斯蒙古族自治县',
            areaPath: '中国,吉林省,松原市,前郭尔罗斯蒙古族自治县',
            areaCode: '100002200070210000'
          },
          {
            id: 10186,
            parentId: 3531,
            areaName: '长岭县',
            areaPath: '中国,吉林省,松原市,长岭县',
            areaCode: '100002200070220000'
          },
          {
            id: 10187,
            parentId: 3531,
            areaName: '乾安县',
            areaPath: '中国,吉林省,松原市,乾安县',
            areaCode: '100002200070230000'
          },
          {
            id: 10188,
            parentId: 3531,
            areaName: '扶余市',
            areaPath: '中国,吉林省,松原市,扶余市',
            areaCode: '100002200070810000'
          }
        ]
      },
      {
        id: 3532,
        parentId: 1440,
        areaName: '白城市',
        areaPath: '中国,吉林省,白城市',
        areaCode: '100002200080000000',
        children: [
          {
            id: 10189,
            parentId: 3532,
            areaName: '洮北区',
            areaPath: '中国,吉林省,白城市,洮北区',
            areaCode: '100002200080020000'
          },
          {
            id: 10190,
            parentId: 3532,
            areaName: '镇赉县',
            areaPath: '中国,吉林省,白城市,镇赉县',
            areaCode: '100002200080210000'
          },
          {
            id: 10191,
            parentId: 3532,
            areaName: '通榆县',
            areaPath: '中国,吉林省,白城市,通榆县',
            areaCode: '100002200080220000'
          },
          {
            id: 10192,
            parentId: 3532,
            areaName: '洮南市',
            areaPath: '中国,吉林省,白城市,洮南市',
            areaCode: '100002200080810000'
          },
          {
            id: 10193,
            parentId: 3532,
            areaName: '大安市',
            areaPath: '中国,吉林省,白城市,大安市',
            areaCode: '100002200080820000'
          }
        ]
      },
      {
        id: 3533,
        parentId: 1440,
        areaName: '延边朝鲜族自治州',
        areaPath: '中国,吉林省,延边朝鲜族自治州',
        areaCode: '100002200240000000',
        children: [
          {
            id: 10194,
            parentId: 3533,
            areaName: '延吉市',
            areaPath: '中国,吉林省,延边朝鲜族自治州,延吉市',
            areaCode: '100002200240010000'
          },
          {
            id: 10195,
            parentId: 3533,
            areaName: '图们市',
            areaPath: '中国,吉林省,延边朝鲜族自治州,图们市',
            areaCode: '100002200240020000'
          },
          {
            id: 10196,
            parentId: 3533,
            areaName: '敦化市',
            areaPath: '中国,吉林省,延边朝鲜族自治州,敦化市',
            areaCode: '100002200240030000'
          },
          {
            id: 10197,
            parentId: 3533,
            areaName: '珲春市',
            areaPath: '中国,吉林省,延边朝鲜族自治州,珲春市',
            areaCode: '100002200240040000'
          },
          {
            id: 10198,
            parentId: 3533,
            areaName: '龙井市',
            areaPath: '中国,吉林省,延边朝鲜族自治州,龙井市',
            areaCode: '100002200240050000'
          },
          {
            id: 10199,
            parentId: 3533,
            areaName: '和龙市',
            areaPath: '中国,吉林省,延边朝鲜族自治州,和龙市',
            areaCode: '100002200240060000'
          },
          {
            id: 10200,
            parentId: 3533,
            areaName: '汪清县',
            areaPath: '中国,吉林省,延边朝鲜族自治州,汪清县',
            areaCode: '100002200240240000'
          },
          {
            id: 10201,
            parentId: 3533,
            areaName: '安图县',
            areaPath: '中国,吉林省,延边朝鲜族自治州,安图县',
            areaCode: '100002200240260000'
          }
        ]
      }
    ]
  },
  {
    id: 1441,
    parentId: 1,
    areaName: '黑龙江省',
    areaPath: '中国,黑龙江省',
    areaCode: '100002300000000000',
    children: [
      {
        id: 3534,
        parentId: 1441,
        areaName: '哈尔滨市',
        areaPath: '中国,黑龙江省,哈尔滨市',
        areaCode: '100002300010000000',
        children: [
          {
            id: 10202,
            parentId: 3534,
            areaName: '道里区',
            areaPath: '中国,黑龙江省,哈尔滨市,道里区',
            areaCode: '100002300010020000'
          },
          {
            id: 10203,
            parentId: 3534,
            areaName: '南岗区',
            areaPath: '中国,黑龙江省,哈尔滨市,南岗区',
            areaCode: '100002300010030000'
          },
          {
            id: 10204,
            parentId: 3534,
            areaName: '道外区',
            areaPath: '中国,黑龙江省,哈尔滨市,道外区',
            areaCode: '100002300010040000'
          },
          {
            id: 10205,
            parentId: 3534,
            areaName: '平房区',
            areaPath: '中国,黑龙江省,哈尔滨市,平房区',
            areaCode: '100002300010080000'
          },
          {
            id: 10206,
            parentId: 3534,
            areaName: '松北区',
            areaPath: '中国,黑龙江省,哈尔滨市,松北区',
            areaCode: '100002300010090000'
          },
          {
            id: 10207,
            parentId: 3534,
            areaName: '香坊区',
            areaPath: '中国,黑龙江省,哈尔滨市,香坊区',
            areaCode: '100002300010100000'
          },
          {
            id: 10208,
            parentId: 3534,
            areaName: '呼兰区',
            areaPath: '中国,黑龙江省,哈尔滨市,呼兰区',
            areaCode: '100002300010110000'
          },
          {
            id: 10209,
            parentId: 3534,
            areaName: '阿城区',
            areaPath: '中国,黑龙江省,哈尔滨市,阿城区',
            areaCode: '100002300010120000'
          },
          {
            id: 10210,
            parentId: 3534,
            areaName: '双城区',
            areaPath: '中国,黑龙江省,哈尔滨市,双城区',
            areaCode: '100002300010130000'
          },
          {
            id: 10211,
            parentId: 3534,
            areaName: '依兰县',
            areaPath: '中国,黑龙江省,哈尔滨市,依兰县',
            areaCode: '100002300010230000'
          },
          {
            id: 10212,
            parentId: 3534,
            areaName: '方正县',
            areaPath: '中国,黑龙江省,哈尔滨市,方正县',
            areaCode: '100002300010240000'
          },
          {
            id: 10213,
            parentId: 3534,
            areaName: '宾县',
            areaPath: '中国,黑龙江省,哈尔滨市,宾县',
            areaCode: '100002300010250000'
          },
          {
            id: 10214,
            parentId: 3534,
            areaName: '巴彦县',
            areaPath: '中国,黑龙江省,哈尔滨市,巴彦县',
            areaCode: '100002300010260000'
          },
          {
            id: 10215,
            parentId: 3534,
            areaName: '木兰县',
            areaPath: '中国,黑龙江省,哈尔滨市,木兰县',
            areaCode: '100002300010270000'
          },
          {
            id: 10216,
            parentId: 3534,
            areaName: '通河县',
            areaPath: '中国,黑龙江省,哈尔滨市,通河县',
            areaCode: '100002300010280000'
          },
          {
            id: 10217,
            parentId: 3534,
            areaName: '延寿县',
            areaPath: '中国,黑龙江省,哈尔滨市,延寿县',
            areaCode: '100002300010290000'
          },
          {
            id: 10218,
            parentId: 3534,
            areaName: '尚志市',
            areaPath: '中国,黑龙江省,哈尔滨市,尚志市',
            areaCode: '100002300010830000'
          },
          {
            id: 10219,
            parentId: 3534,
            areaName: '五常市',
            areaPath: '中国,黑龙江省,哈尔滨市,五常市',
            areaCode: '100002300010840000'
          }
        ]
      },
      {
        id: 3535,
        parentId: 1441,
        areaName: '齐齐哈尔市',
        areaPath: '中国,黑龙江省,齐齐哈尔市',
        areaCode: '100002300020000000',
        children: [
          {
            id: 10220,
            parentId: 3535,
            areaName: '龙沙区',
            areaPath: '中国,黑龙江省,齐齐哈尔市,龙沙区',
            areaCode: '100002300020020000'
          },
          {
            id: 10221,
            parentId: 3535,
            areaName: '建华区',
            areaPath: '中国,黑龙江省,齐齐哈尔市,建华区',
            areaCode: '100002300020030000'
          },
          {
            id: 10222,
            parentId: 3535,
            areaName: '铁锋区',
            areaPath: '中国,黑龙江省,齐齐哈尔市,铁锋区',
            areaCode: '100002300020040000'
          },
          {
            id: 10223,
            parentId: 3535,
            areaName: '昂昂溪区',
            areaPath: '中国,黑龙江省,齐齐哈尔市,昂昂溪区',
            areaCode: '100002300020050000'
          },
          {
            id: 10224,
            parentId: 3535,
            areaName: '富拉尔基区',
            areaPath: '中国,黑龙江省,齐齐哈尔市,富拉尔基区',
            areaCode: '100002300020060000'
          },
          {
            id: 10225,
            parentId: 3535,
            areaName: '碾子山区',
            areaPath: '中国,黑龙江省,齐齐哈尔市,碾子山区',
            areaCode: '100002300020070000'
          },
          {
            id: 10226,
            parentId: 3535,
            areaName: '梅里斯达斡尔族区',
            areaPath: '中国,黑龙江省,齐齐哈尔市,梅里斯达斡尔族区',
            areaCode: '100002300020080000'
          },
          {
            id: 10227,
            parentId: 3535,
            areaName: '龙江县',
            areaPath: '中国,黑龙江省,齐齐哈尔市,龙江县',
            areaCode: '100002300020210000'
          },
          {
            id: 10228,
            parentId: 3535,
            areaName: '依安县',
            areaPath: '中国,黑龙江省,齐齐哈尔市,依安县',
            areaCode: '100002300020230000'
          },
          {
            id: 10229,
            parentId: 3535,
            areaName: '泰来县',
            areaPath: '中国,黑龙江省,齐齐哈尔市,泰来县',
            areaCode: '100002300020240000'
          },
          {
            id: 10230,
            parentId: 3535,
            areaName: '甘南县',
            areaPath: '中国,黑龙江省,齐齐哈尔市,甘南县',
            areaCode: '100002300020250000'
          },
          {
            id: 10231,
            parentId: 3535,
            areaName: '富裕县',
            areaPath: '中国,黑龙江省,齐齐哈尔市,富裕县',
            areaCode: '100002300020270000'
          },
          {
            id: 10232,
            parentId: 3535,
            areaName: '克山县',
            areaPath: '中国,黑龙江省,齐齐哈尔市,克山县',
            areaCode: '100002300020290000'
          },
          {
            id: 10233,
            parentId: 3535,
            areaName: '克东县',
            areaPath: '中国,黑龙江省,齐齐哈尔市,克东县',
            areaCode: '100002300020300000'
          },
          {
            id: 10234,
            parentId: 3535,
            areaName: '拜泉县',
            areaPath: '中国,黑龙江省,齐齐哈尔市,拜泉县',
            areaCode: '100002300020310000'
          },
          {
            id: 10235,
            parentId: 3535,
            areaName: '讷河市',
            areaPath: '中国,黑龙江省,齐齐哈尔市,讷河市',
            areaCode: '100002300020810000'
          }
        ]
      },
      {
        id: 3536,
        parentId: 1441,
        areaName: '鸡西市',
        areaPath: '中国,黑龙江省,鸡西市',
        areaCode: '100002300030000000',
        children: [
          {
            id: 10236,
            parentId: 3536,
            areaName: '鸡冠区',
            areaPath: '中国,黑龙江省,鸡西市,鸡冠区',
            areaCode: '100002300030020000'
          },
          {
            id: 10237,
            parentId: 3536,
            areaName: '恒山区',
            areaPath: '中国,黑龙江省,鸡西市,恒山区',
            areaCode: '100002300030030000'
          },
          {
            id: 10238,
            parentId: 3536,
            areaName: '滴道区',
            areaPath: '中国,黑龙江省,鸡西市,滴道区',
            areaCode: '100002300030040000'
          },
          {
            id: 10239,
            parentId: 3536,
            areaName: '梨树区',
            areaPath: '中国,黑龙江省,鸡西市,梨树区',
            areaCode: '100002300030050000'
          },
          {
            id: 10240,
            parentId: 3536,
            areaName: '城子河区',
            areaPath: '中国,黑龙江省,鸡西市,城子河区',
            areaCode: '100002300030060000'
          },
          {
            id: 10241,
            parentId: 3536,
            areaName: '麻山区',
            areaPath: '中国,黑龙江省,鸡西市,麻山区',
            areaCode: '100002300030070000'
          },
          {
            id: 10242,
            parentId: 3536,
            areaName: '鸡东县',
            areaPath: '中国,黑龙江省,鸡西市,鸡东县',
            areaCode: '100002300030210000'
          },
          {
            id: 10243,
            parentId: 3536,
            areaName: '虎林市',
            areaPath: '中国,黑龙江省,鸡西市,虎林市',
            areaCode: '100002300030810000'
          },
          {
            id: 10244,
            parentId: 3536,
            areaName: '密山市',
            areaPath: '中国,黑龙江省,鸡西市,密山市',
            areaCode: '100002300030820000'
          }
        ]
      },
      {
        id: 3537,
        parentId: 1441,
        areaName: '鹤岗市',
        areaPath: '中国,黑龙江省,鹤岗市',
        areaCode: '100002300040000000',
        children: [
          {
            id: 10245,
            parentId: 3537,
            areaName: '向阳区',
            areaPath: '中国,黑龙江省,鹤岗市,向阳区',
            areaCode: '100002300040020000'
          },
          {
            id: 10246,
            parentId: 3537,
            areaName: '工农区',
            areaPath: '中国,黑龙江省,鹤岗市,工农区',
            areaCode: '100002300040030000'
          },
          {
            id: 10247,
            parentId: 3537,
            areaName: '南山区',
            areaPath: '中国,黑龙江省,鹤岗市,南山区',
            areaCode: '100002300040040000'
          },
          {
            id: 10248,
            parentId: 3537,
            areaName: '兴安区',
            areaPath: '中国,黑龙江省,鹤岗市,兴安区',
            areaCode: '100002300040050000'
          },
          {
            id: 10249,
            parentId: 3537,
            areaName: '东山区',
            areaPath: '中国,黑龙江省,鹤岗市,东山区',
            areaCode: '100002300040060000'
          },
          {
            id: 10250,
            parentId: 3537,
            areaName: '兴山区',
            areaPath: '中国,黑龙江省,鹤岗市,兴山区',
            areaCode: '100002300040070000'
          },
          {
            id: 10251,
            parentId: 3537,
            areaName: '萝北县',
            areaPath: '中国,黑龙江省,鹤岗市,萝北县',
            areaCode: '100002300040210000'
          },
          {
            id: 10252,
            parentId: 3537,
            areaName: '绥滨县',
            areaPath: '中国,黑龙江省,鹤岗市,绥滨县',
            areaCode: '100002300040220000'
          }
        ]
      },
      {
        id: 3538,
        parentId: 1441,
        areaName: '双鸭山市',
        areaPath: '中国,黑龙江省,双鸭山市',
        areaCode: '100002300050000000',
        children: [
          {
            id: 10253,
            parentId: 3538,
            areaName: '尖山区',
            areaPath: '中国,黑龙江省,双鸭山市,尖山区',
            areaCode: '100002300050020000'
          },
          {
            id: 10254,
            parentId: 3538,
            areaName: '岭东区',
            areaPath: '中国,黑龙江省,双鸭山市,岭东区',
            areaCode: '100002300050030000'
          },
          {
            id: 10255,
            parentId: 3538,
            areaName: '四方台区',
            areaPath: '中国,黑龙江省,双鸭山市,四方台区',
            areaCode: '100002300050050000'
          },
          {
            id: 10256,
            parentId: 3538,
            areaName: '宝山区',
            areaPath: '中国,黑龙江省,双鸭山市,宝山区',
            areaCode: '100002300050060000'
          },
          {
            id: 10257,
            parentId: 3538,
            areaName: '集贤县',
            areaPath: '中国,黑龙江省,双鸭山市,集贤县',
            areaCode: '100002300050210000'
          },
          {
            id: 10258,
            parentId: 3538,
            areaName: '友谊县',
            areaPath: '中国,黑龙江省,双鸭山市,友谊县',
            areaCode: '100002300050220000'
          },
          {
            id: 10259,
            parentId: 3538,
            areaName: '宝清县',
            areaPath: '中国,黑龙江省,双鸭山市,宝清县',
            areaCode: '100002300050230000'
          },
          {
            id: 10260,
            parentId: 3538,
            areaName: '饶河县',
            areaPath: '中国,黑龙江省,双鸭山市,饶河县',
            areaCode: '100002300050240000'
          }
        ]
      },
      {
        id: 3539,
        parentId: 1441,
        areaName: '大庆市',
        areaPath: '中国,黑龙江省,大庆市',
        areaCode: '100002300060000000',
        children: [
          {
            id: 10261,
            parentId: 3539,
            areaName: '萨尔图区',
            areaPath: '中国,黑龙江省,大庆市,萨尔图区',
            areaCode: '100002300060020000'
          },
          {
            id: 10262,
            parentId: 3539,
            areaName: '龙凤区',
            areaPath: '中国,黑龙江省,大庆市,龙凤区',
            areaCode: '100002300060030000'
          },
          {
            id: 10263,
            parentId: 3539,
            areaName: '让胡路区',
            areaPath: '中国,黑龙江省,大庆市,让胡路区',
            areaCode: '100002300060040000'
          },
          {
            id: 10264,
            parentId: 3539,
            areaName: '红岗区',
            areaPath: '中国,黑龙江省,大庆市,红岗区',
            areaCode: '100002300060050000'
          },
          {
            id: 10265,
            parentId: 3539,
            areaName: '大同区',
            areaPath: '中国,黑龙江省,大庆市,大同区',
            areaCode: '100002300060060000'
          },
          {
            id: 10266,
            parentId: 3539,
            areaName: '肇州县',
            areaPath: '中国,黑龙江省,大庆市,肇州县',
            areaCode: '100002300060210000'
          },
          {
            id: 10267,
            parentId: 3539,
            areaName: '肇源县',
            areaPath: '中国,黑龙江省,大庆市,肇源县',
            areaCode: '100002300060220000'
          },
          {
            id: 10268,
            parentId: 3539,
            areaName: '林甸县',
            areaPath: '中国,黑龙江省,大庆市,林甸县',
            areaCode: '100002300060230000'
          },
          {
            id: 10269,
            parentId: 3539,
            areaName: '杜尔伯特蒙古族自治县',
            areaPath: '中国,黑龙江省,大庆市,杜尔伯特蒙古族自治县',
            areaCode: '100002300060240000'
          }
        ]
      },
      {
        id: 3540,
        parentId: 1441,
        areaName: '伊春市',
        areaPath: '中国,黑龙江省,伊春市',
        areaCode: '100002300070000000',
        children: [
          {
            id: 10270,
            parentId: 3540,
            areaName: '伊春区',
            areaPath: '中国,黑龙江省,伊春市,伊春区',
            areaCode: '100002300070020000'
          },
          {
            id: 10271,
            parentId: 3540,
            areaName: '南岔区',
            areaPath: '中国,黑龙江省,伊春市,南岔区',
            areaCode: '100002300070030000'
          },
          {
            id: 10272,
            parentId: 3540,
            areaName: '友好区',
            areaPath: '中国,黑龙江省,伊春市,友好区',
            areaCode: '100002300070040000'
          },
          {
            id: 10273,
            parentId: 3540,
            areaName: '西林区',
            areaPath: '中国,黑龙江省,伊春市,西林区',
            areaCode: '100002300070050000'
          },
          {
            id: 10274,
            parentId: 3540,
            areaName: '翠峦区',
            areaPath: '中国,黑龙江省,伊春市,翠峦区',
            areaCode: '100002300070060000'
          },
          {
            id: 10275,
            parentId: 3540,
            areaName: '新青区',
            areaPath: '中国,黑龙江省,伊春市,新青区',
            areaCode: '100002300070070000'
          },
          {
            id: 10276,
            parentId: 3540,
            areaName: '美溪区',
            areaPath: '中国,黑龙江省,伊春市,美溪区',
            areaCode: '100002300070080000'
          },
          {
            id: 10277,
            parentId: 3540,
            areaName: '金山屯区',
            areaPath: '中国,黑龙江省,伊春市,金山屯区',
            areaCode: '100002300070090000'
          },
          {
            id: 10278,
            parentId: 3540,
            areaName: '五营区',
            areaPath: '中国,黑龙江省,伊春市,五营区',
            areaCode: '100002300070100000'
          },
          {
            id: 10279,
            parentId: 3540,
            areaName: '乌马河区',
            areaPath: '中国,黑龙江省,伊春市,乌马河区',
            areaCode: '100002300070110000'
          },
          {
            id: 10280,
            parentId: 3540,
            areaName: '汤旺河区',
            areaPath: '中国,黑龙江省,伊春市,汤旺河区',
            areaCode: '100002300070120000'
          },
          {
            id: 10281,
            parentId: 3540,
            areaName: '带岭区',
            areaPath: '中国,黑龙江省,伊春市,带岭区',
            areaCode: '100002300070130000'
          },
          {
            id: 10282,
            parentId: 3540,
            areaName: '乌伊岭区',
            areaPath: '中国,黑龙江省,伊春市,乌伊岭区',
            areaCode: '100002300070140000'
          },
          {
            id: 10283,
            parentId: 3540,
            areaName: '红星区',
            areaPath: '中国,黑龙江省,伊春市,红星区',
            areaCode: '100002300070150000'
          },
          {
            id: 10284,
            parentId: 3540,
            areaName: '上甘岭区',
            areaPath: '中国,黑龙江省,伊春市,上甘岭区',
            areaCode: '100002300070160000'
          },
          {
            id: 10285,
            parentId: 3540,
            areaName: '嘉荫县',
            areaPath: '中国,黑龙江省,伊春市,嘉荫县',
            areaCode: '100002300070220000'
          },
          {
            id: 10286,
            parentId: 3540,
            areaName: '铁力市',
            areaPath: '中国,黑龙江省,伊春市,铁力市',
            areaCode: '100002300070810000'
          }
        ]
      },
      {
        id: 3541,
        parentId: 1441,
        areaName: '佳木斯市',
        areaPath: '中国,黑龙江省,佳木斯市',
        areaCode: '100002300080000000',
        children: [
          {
            id: 10287,
            parentId: 3541,
            areaName: '向阳区',
            areaPath: '中国,黑龙江省,佳木斯市,向阳区',
            areaCode: '100002300080030000'
          },
          {
            id: 10288,
            parentId: 3541,
            areaName: '前进区',
            areaPath: '中国,黑龙江省,佳木斯市,前进区',
            areaCode: '100002300080040000'
          },
          {
            id: 10289,
            parentId: 3541,
            areaName: '东风区',
            areaPath: '中国,黑龙江省,佳木斯市,东风区',
            areaCode: '100002300080050000'
          },
          {
            id: 10290,
            parentId: 3541,
            areaName: '郊区',
            areaPath: '中国,黑龙江省,佳木斯市,郊区',
            areaCode: '100002300080110000'
          },
          {
            id: 10291,
            parentId: 3541,
            areaName: '桦南县',
            areaPath: '中国,黑龙江省,佳木斯市,桦南县',
            areaCode: '100002300080220000'
          },
          {
            id: 10292,
            parentId: 3541,
            areaName: '桦川县',
            areaPath: '中国,黑龙江省,佳木斯市,桦川县',
            areaCode: '100002300080260000'
          },
          {
            id: 10293,
            parentId: 3541,
            areaName: '汤原县',
            areaPath: '中国,黑龙江省,佳木斯市,汤原县',
            areaCode: '100002300080280000'
          },
          {
            id: 10294,
            parentId: 3541,
            areaName: '同江市',
            areaPath: '中国,黑龙江省,佳木斯市,同江市',
            areaCode: '100002300080810000'
          },
          {
            id: 10295,
            parentId: 3541,
            areaName: '富锦市',
            areaPath: '中国,黑龙江省,佳木斯市,富锦市',
            areaCode: '100002300080820000'
          },
          {
            id: 10296,
            parentId: 3541,
            areaName: '抚远市',
            areaPath: '中国,黑龙江省,佳木斯市,抚远市',
            areaCode: '100002300080830000'
          }
        ]
      },
      {
        id: 3542,
        parentId: 1441,
        areaName: '七台河市',
        areaPath: '中国,黑龙江省,七台河市',
        areaCode: '100002300090000000',
        children: [
          {
            id: 10297,
            parentId: 3542,
            areaName: '新兴区',
            areaPath: '中国,黑龙江省,七台河市,新兴区',
            areaCode: '100002300090020000'
          },
          {
            id: 10298,
            parentId: 3542,
            areaName: '桃山区',
            areaPath: '中国,黑龙江省,七台河市,桃山区',
            areaCode: '100002300090030000'
          },
          {
            id: 10299,
            parentId: 3542,
            areaName: '茄子河区',
            areaPath: '中国,黑龙江省,七台河市,茄子河区',
            areaCode: '100002300090040000'
          },
          {
            id: 10300,
            parentId: 3542,
            areaName: '勃利县',
            areaPath: '中国,黑龙江省,七台河市,勃利县',
            areaCode: '100002300090210000'
          }
        ]
      },
      {
        id: 3543,
        parentId: 1441,
        areaName: '牡丹江市',
        areaPath: '中国,黑龙江省,牡丹江市',
        areaCode: '100002300100000000',
        children: [
          {
            id: 10301,
            parentId: 3543,
            areaName: '东安区',
            areaPath: '中国,黑龙江省,牡丹江市,东安区',
            areaCode: '100002300100020000'
          },
          {
            id: 10302,
            parentId: 3543,
            areaName: '阳明区',
            areaPath: '中国,黑龙江省,牡丹江市,阳明区',
            areaCode: '100002300100030000'
          },
          {
            id: 10303,
            parentId: 3543,
            areaName: '爱民区',
            areaPath: '中国,黑龙江省,牡丹江市,爱民区',
            areaCode: '100002300100040000'
          },
          {
            id: 10304,
            parentId: 3543,
            areaName: '西安区',
            areaPath: '中国,黑龙江省,牡丹江市,西安区',
            areaCode: '100002300100050000'
          },
          {
            id: 10305,
            parentId: 3543,
            areaName: '林口县',
            areaPath: '中国,黑龙江省,牡丹江市,林口县',
            areaCode: '100002300100250000'
          },
          {
            id: 10306,
            parentId: 3543,
            areaName: '绥芬河市',
            areaPath: '中国,黑龙江省,牡丹江市,绥芬河市',
            areaCode: '100002300100810000'
          },
          {
            id: 10307,
            parentId: 3543,
            areaName: '海林市',
            areaPath: '中国,黑龙江省,牡丹江市,海林市',
            areaCode: '100002300100830000'
          },
          {
            id: 10308,
            parentId: 3543,
            areaName: '宁安市',
            areaPath: '中国,黑龙江省,牡丹江市,宁安市',
            areaCode: '100002300100840000'
          },
          {
            id: 10309,
            parentId: 3543,
            areaName: '穆棱市',
            areaPath: '中国,黑龙江省,牡丹江市,穆棱市',
            areaCode: '100002300100850000'
          },
          {
            id: 10310,
            parentId: 3543,
            areaName: '东宁市',
            areaPath: '中国,黑龙江省,牡丹江市,东宁市',
            areaCode: '100002300100860000'
          }
        ]
      },
      {
        id: 3544,
        parentId: 1441,
        areaName: '黑河市',
        areaPath: '中国,黑龙江省,黑河市',
        areaCode: '100002300110000000',
        children: [
          {
            id: 10311,
            parentId: 3544,
            areaName: '爱辉区',
            areaPath: '中国,黑龙江省,黑河市,爱辉区',
            areaCode: '100002300110020000'
          },
          {
            id: 10312,
            parentId: 3544,
            areaName: '嫩江县',
            areaPath: '中国,黑龙江省,黑河市,嫩江县',
            areaCode: '100002300110210000'
          },
          {
            id: 10313,
            parentId: 3544,
            areaName: '逊克县',
            areaPath: '中国,黑龙江省,黑河市,逊克县',
            areaCode: '100002300110230000'
          },
          {
            id: 10314,
            parentId: 3544,
            areaName: '孙吴县',
            areaPath: '中国,黑龙江省,黑河市,孙吴县',
            areaCode: '100002300110240000'
          },
          {
            id: 10315,
            parentId: 3544,
            areaName: '北安市',
            areaPath: '中国,黑龙江省,黑河市,北安市',
            areaCode: '100002300110810000'
          },
          {
            id: 10316,
            parentId: 3544,
            areaName: '五大连池市',
            areaPath: '中国,黑龙江省,黑河市,五大连池市',
            areaCode: '100002300110820000'
          }
        ]
      },
      {
        id: 3545,
        parentId: 1441,
        areaName: '绥化市',
        areaPath: '中国,黑龙江省,绥化市',
        areaCode: '100002300120000000',
        children: [
          {
            id: 10317,
            parentId: 3545,
            areaName: '北林区',
            areaPath: '中国,黑龙江省,绥化市,北林区',
            areaCode: '100002300120020000'
          },
          {
            id: 10318,
            parentId: 3545,
            areaName: '望奎县',
            areaPath: '中国,黑龙江省,绥化市,望奎县',
            areaCode: '100002300120210000'
          },
          {
            id: 10319,
            parentId: 3545,
            areaName: '兰西县',
            areaPath: '中国,黑龙江省,绥化市,兰西县',
            areaCode: '100002300120220000'
          },
          {
            id: 10320,
            parentId: 3545,
            areaName: '青冈县',
            areaPath: '中国,黑龙江省,绥化市,青冈县',
            areaCode: '100002300120230000'
          },
          {
            id: 10321,
            parentId: 3545,
            areaName: '庆安县',
            areaPath: '中国,黑龙江省,绥化市,庆安县',
            areaCode: '100002300120240000'
          },
          {
            id: 10322,
            parentId: 3545,
            areaName: '明水县',
            areaPath: '中国,黑龙江省,绥化市,明水县',
            areaCode: '100002300120250000'
          },
          {
            id: 10323,
            parentId: 3545,
            areaName: '绥棱县',
            areaPath: '中国,黑龙江省,绥化市,绥棱县',
            areaCode: '100002300120260000'
          },
          {
            id: 10324,
            parentId: 3545,
            areaName: '安达市',
            areaPath: '中国,黑龙江省,绥化市,安达市',
            areaCode: '100002300120810000'
          },
          {
            id: 10325,
            parentId: 3545,
            areaName: '肇东市',
            areaPath: '中国,黑龙江省,绥化市,肇东市',
            areaCode: '100002300120820000'
          },
          {
            id: 10326,
            parentId: 3545,
            areaName: '海伦市',
            areaPath: '中国,黑龙江省,绥化市,海伦市',
            areaCode: '100002300120830000'
          }
        ]
      },
      {
        id: 3546,
        parentId: 1441,
        areaName: '大兴安岭地区',
        areaPath: '中国,黑龙江省,大兴安岭地区',
        areaCode: '100002300270000000',
        children: [
          {
            id: 10327,
            parentId: 3546,
            areaName: '呼玛县',
            areaPath: '中国,黑龙江省,大兴安岭地区,呼玛县',
            areaCode: '100002300270210000'
          },
          {
            id: 10328,
            parentId: 3546,
            areaName: '塔河县',
            areaPath: '中国,黑龙江省,大兴安岭地区,塔河县',
            areaCode: '100002300270220000'
          },
          {
            id: 10329,
            parentId: 3546,
            areaName: '漠河县',
            areaPath: '中国,黑龙江省,大兴安岭地区,漠河县',
            areaCode: '100002300270230000'
          }
        ]
      }
    ]
  },
  {
    id: 1442,
    parentId: 1,
    areaName: '上海',
    areaPath: '中国,上海',
    areaCode: '100003100000000000',
    children: [
      {
        id: 3547,
        parentId: 1442,
        areaName: '上海市',
        areaPath: '中国,上海,上海市',
        areaCode: '100003100010000000',
        children: [
          {
            id: 10330,
            parentId: 3547,
            areaName: '黄浦区',
            areaPath: '中国,上海,上海市,黄浦区',
            areaCode: '100003100010010000'
          },
          {
            id: 10331,
            parentId: 3547,
            areaName: '徐汇区',
            areaPath: '中国,上海,上海市,徐汇区',
            areaCode: '100003100010040000'
          },
          {
            id: 10332,
            parentId: 3547,
            areaName: '长宁区',
            areaPath: '中国,上海,上海市,长宁区',
            areaCode: '100003100010050000'
          },
          {
            id: 10333,
            parentId: 3547,
            areaName: '静安区',
            areaPath: '中国,上海,上海市,静安区',
            areaCode: '100003100010060000'
          },
          {
            id: 10334,
            parentId: 3547,
            areaName: '普陀区',
            areaPath: '中国,上海,上海市,普陀区',
            areaCode: '100003100010070000'
          },
          {
            id: 10335,
            parentId: 3547,
            areaName: '虹口区',
            areaPath: '中国,上海,上海市,虹口区',
            areaCode: '100003100010090000'
          },
          {
            id: 10336,
            parentId: 3547,
            areaName: '杨浦区',
            areaPath: '中国,上海,上海市,杨浦区',
            areaCode: '100003100010100000'
          },
          {
            id: 10337,
            parentId: 3547,
            areaName: '闵行区',
            areaPath: '中国,上海,上海市,闵行区',
            areaCode: '100003100010120000'
          },
          {
            id: 10338,
            parentId: 3547,
            areaName: '宝山区',
            areaPath: '中国,上海,上海市,宝山区',
            areaCode: '100003100010130000'
          },
          {
            id: 10339,
            parentId: 3547,
            areaName: '嘉定区',
            areaPath: '中国,上海,上海市,嘉定区',
            areaCode: '100003100010140000'
          },
          {
            id: 10340,
            parentId: 3547,
            areaName: '浦东新区',
            areaPath: '中国,上海,上海市,浦东新区',
            areaCode: '100003100010150000'
          },
          {
            id: 10341,
            parentId: 3547,
            areaName: '金山区',
            areaPath: '中国,上海,上海市,金山区',
            areaCode: '100003100010160000'
          },
          {
            id: 10342,
            parentId: 3547,
            areaName: '松江区',
            areaPath: '中国,上海,上海市,松江区',
            areaCode: '100003100010170000'
          },
          {
            id: 10343,
            parentId: 3547,
            areaName: '青浦区',
            areaPath: '中国,上海,上海市,青浦区',
            areaCode: '100003100010180000'
          },
          {
            id: 10344,
            parentId: 3547,
            areaName: '奉贤区',
            areaPath: '中国,上海,上海市,奉贤区',
            areaCode: '100003100010200000'
          },
          {
            id: 10345,
            parentId: 3547,
            areaName: '崇明区',
            areaPath: '中国,上海,上海市,崇明区',
            areaCode: '100003100010510000'
          }
        ]
      }
    ]
  },
  {
    id: 1443,
    parentId: 1,
    areaName: '江苏省',
    areaPath: '中国,江苏省',
    areaCode: '100003200000000000',
    children: [
      {
        id: 3548,
        parentId: 1443,
        areaName: '南京市',
        areaPath: '中国,江苏省,南京市',
        areaCode: '100003200010000000',
        children: [
          {
            id: 10346,
            parentId: 3548,
            areaName: '玄武区',
            areaPath: '中国,江苏省,南京市,玄武区',
            areaCode: '100003200010020000'
          },
          {
            id: 10347,
            parentId: 3548,
            areaName: '秦淮区',
            areaPath: '中国,江苏省,南京市,秦淮区',
            areaCode: '100003200010040000'
          },
          {
            id: 10348,
            parentId: 3548,
            areaName: '建邺区',
            areaPath: '中国,江苏省,南京市,建邺区',
            areaCode: '100003200010050000'
          },
          {
            id: 10349,
            parentId: 3548,
            areaName: '鼓楼区',
            areaPath: '中国,江苏省,南京市,鼓楼区',
            areaCode: '100003200010060000'
          },
          {
            id: 10350,
            parentId: 3548,
            areaName: '浦口区',
            areaPath: '中国,江苏省,南京市,浦口区',
            areaCode: '100003200010110000'
          },
          {
            id: 10351,
            parentId: 3548,
            areaName: '栖霞区',
            areaPath: '中国,江苏省,南京市,栖霞区',
            areaCode: '100003200010130000'
          },
          {
            id: 10352,
            parentId: 3548,
            areaName: '雨花台区',
            areaPath: '中国,江苏省,南京市,雨花台区',
            areaCode: '100003200010140000'
          },
          {
            id: 10353,
            parentId: 3548,
            areaName: '江宁区',
            areaPath: '中国,江苏省,南京市,江宁区',
            areaCode: '100003200010150000'
          },
          {
            id: 10354,
            parentId: 3548,
            areaName: '六合区',
            areaPath: '中国,江苏省,南京市,六合区',
            areaCode: '100003200010160000'
          },
          {
            id: 10355,
            parentId: 3548,
            areaName: '溧水区',
            areaPath: '中国,江苏省,南京市,溧水区',
            areaCode: '100003200010170000'
          },
          {
            id: 10356,
            parentId: 3548,
            areaName: '高淳区',
            areaPath: '中国,江苏省,南京市,高淳区',
            areaCode: '100003200010180000'
          }
        ]
      },
      {
        id: 3549,
        parentId: 1443,
        areaName: '无锡市',
        areaPath: '中国,江苏省,无锡市',
        areaCode: '100003200020000000',
        children: [
          {
            id: 10357,
            parentId: 3549,
            areaName: '锡山区',
            areaPath: '中国,江苏省,无锡市,锡山区',
            areaCode: '100003200020050000'
          },
          {
            id: 10358,
            parentId: 3549,
            areaName: '惠山区',
            areaPath: '中国,江苏省,无锡市,惠山区',
            areaCode: '100003200020060000'
          },
          {
            id: 10359,
            parentId: 3549,
            areaName: '滨湖区',
            areaPath: '中国,江苏省,无锡市,滨湖区',
            areaCode: '100003200020110000'
          },
          {
            id: 10360,
            parentId: 3549,
            areaName: '梁溪区',
            areaPath: '中国,江苏省,无锡市,梁溪区',
            areaCode: '100003200020130000'
          },
          {
            id: 10361,
            parentId: 3549,
            areaName: '新吴区',
            areaPath: '中国,江苏省,无锡市,新吴区',
            areaCode: '100003200020140000'
          },
          {
            id: 10362,
            parentId: 3549,
            areaName: '江阴市',
            areaPath: '中国,江苏省,无锡市,江阴市',
            areaCode: '100003200020810000'
          },
          {
            id: 10363,
            parentId: 3549,
            areaName: '宜兴市',
            areaPath: '中国,江苏省,无锡市,宜兴市',
            areaCode: '100003200020820000'
          }
        ]
      },
      {
        id: 3550,
        parentId: 1443,
        areaName: '徐州市',
        areaPath: '中国,江苏省,徐州市',
        areaCode: '100003200030000000',
        children: [
          {
            id: 10364,
            parentId: 3550,
            areaName: '鼓楼区',
            areaPath: '中国,江苏省,徐州市,鼓楼区',
            areaCode: '100003200030020000'
          },
          {
            id: 10365,
            parentId: 3550,
            areaName: '云龙区',
            areaPath: '中国,江苏省,徐州市,云龙区',
            areaCode: '100003200030030000'
          },
          {
            id: 10366,
            parentId: 3550,
            areaName: '贾汪区',
            areaPath: '中国,江苏省,徐州市,贾汪区',
            areaCode: '100003200030050000'
          },
          {
            id: 10367,
            parentId: 3550,
            areaName: '泉山区',
            areaPath: '中国,江苏省,徐州市,泉山区',
            areaCode: '100003200030110000'
          },
          {
            id: 10368,
            parentId: 3550,
            areaName: '铜山区',
            areaPath: '中国,江苏省,徐州市,铜山区',
            areaCode: '100003200030120000'
          },
          {
            id: 10369,
            parentId: 3550,
            areaName: '丰县',
            areaPath: '中国,江苏省,徐州市,丰县',
            areaCode: '100003200030210000'
          },
          {
            id: 10370,
            parentId: 3550,
            areaName: '沛县',
            areaPath: '中国,江苏省,徐州市,沛县',
            areaCode: '100003200030220000'
          },
          {
            id: 10371,
            parentId: 3550,
            areaName: '睢宁县',
            areaPath: '中国,江苏省,徐州市,睢宁县',
            areaCode: '100003200030240000'
          },
          {
            id: 10372,
            parentId: 3550,
            areaName: '新沂市',
            areaPath: '中国,江苏省,徐州市,新沂市',
            areaCode: '100003200030810000'
          },
          {
            id: 10373,
            parentId: 3550,
            areaName: '邳州市',
            areaPath: '中国,江苏省,徐州市,邳州市',
            areaCode: '100003200030820000'
          }
        ]
      },
      {
        id: 3551,
        parentId: 1443,
        areaName: '常州市',
        areaPath: '中国,江苏省,常州市',
        areaCode: '100003200040000000',
        children: [
          {
            id: 10374,
            parentId: 3551,
            areaName: '天宁区',
            areaPath: '中国,江苏省,常州市,天宁区',
            areaCode: '100003200040020000'
          },
          {
            id: 10375,
            parentId: 3551,
            areaName: '钟楼区',
            areaPath: '中国,江苏省,常州市,钟楼区',
            areaCode: '100003200040040000'
          },
          {
            id: 10376,
            parentId: 3551,
            areaName: '新北区',
            areaPath: '中国,江苏省,常州市,新北区',
            areaCode: '100003200040110000'
          },
          {
            id: 10377,
            parentId: 3551,
            areaName: '武进区',
            areaPath: '中国,江苏省,常州市,武进区',
            areaCode: '100003200040120000'
          },
          {
            id: 10378,
            parentId: 3551,
            areaName: '金坛区',
            areaPath: '中国,江苏省,常州市,金坛区',
            areaCode: '100003200040130000'
          },
          {
            id: 10379,
            parentId: 3551,
            areaName: '溧阳市',
            areaPath: '中国,江苏省,常州市,溧阳市',
            areaCode: '100003200040810000'
          }
        ]
      },
      {
        id: 3552,
        parentId: 1443,
        areaName: '苏州市',
        areaPath: '中国,江苏省,苏州市',
        areaCode: '100003200050000000',
        children: [
          {
            id: 10380,
            parentId: 3552,
            areaName: '虎丘区',
            areaPath: '中国,江苏省,苏州市,虎丘区',
            areaCode: '100003200050050000'
          },
          {
            id: 10381,
            parentId: 3552,
            areaName: '吴中区',
            areaPath: '中国,江苏省,苏州市,吴中区',
            areaCode: '100003200050060000'
          },
          {
            id: 10382,
            parentId: 3552,
            areaName: '相城区',
            areaPath: '中国,江苏省,苏州市,相城区',
            areaCode: '100003200050070000'
          },
          {
            id: 10383,
            parentId: 3552,
            areaName: '姑苏区',
            areaPath: '中国,江苏省,苏州市,姑苏区',
            areaCode: '100003200050080000'
          },
          {
            id: 10384,
            parentId: 3552,
            areaName: '吴江区',
            areaPath: '中国,江苏省,苏州市,吴江区',
            areaCode: '100003200050090000'
          },
          {
            id: 10385,
            parentId: 3552,
            areaName: '常熟市',
            areaPath: '中国,江苏省,苏州市,常熟市',
            areaCode: '100003200050810000'
          },
          {
            id: 10386,
            parentId: 3552,
            areaName: '张家港市',
            areaPath: '中国,江苏省,苏州市,张家港市',
            areaCode: '100003200050820000'
          },
          {
            id: 10387,
            parentId: 3552,
            areaName: '昆山市',
            areaPath: '中国,江苏省,苏州市,昆山市',
            areaCode: '100003200050830000'
          },
          {
            id: 10388,
            parentId: 3552,
            areaName: '太仓市',
            areaPath: '中国,江苏省,苏州市,太仓市',
            areaCode: '100003200050850000'
          }
        ]
      },
      {
        id: 3553,
        parentId: 1443,
        areaName: '南通市',
        areaPath: '中国,江苏省,南通市',
        areaCode: '100003200060000000',
        children: [
          {
            id: 10389,
            parentId: 3553,
            areaName: '崇川区',
            areaPath: '中国,江苏省,南通市,崇川区',
            areaCode: '100003200060020000'
          },
          {
            id: 10390,
            parentId: 3553,
            areaName: '港闸区',
            areaPath: '中国,江苏省,南通市,港闸区',
            areaCode: '100003200060110000'
          },
          {
            id: 10391,
            parentId: 3553,
            areaName: '通州区',
            areaPath: '中国,江苏省,南通市,通州区',
            areaCode: '100003200060120000'
          },
          {
            id: 10392,
            parentId: 3553,
            areaName: '海安县',
            areaPath: '中国,江苏省,南通市,海安县',
            areaCode: '100003200060210000'
          },
          {
            id: 10393,
            parentId: 3553,
            areaName: '如东县',
            areaPath: '中国,江苏省,南通市,如东县',
            areaCode: '100003200060230000'
          },
          {
            id: 10394,
            parentId: 3553,
            areaName: '启东市',
            areaPath: '中国,江苏省,南通市,启东市',
            areaCode: '100003200060810000'
          },
          {
            id: 10395,
            parentId: 3553,
            areaName: '如皋市',
            areaPath: '中国,江苏省,南通市,如皋市',
            areaCode: '100003200060820000'
          },
          {
            id: 10396,
            parentId: 3553,
            areaName: '海门市',
            areaPath: '中国,江苏省,南通市,海门市',
            areaCode: '100003200060840000'
          }
        ]
      },
      {
        id: 3554,
        parentId: 1443,
        areaName: '连云港市',
        areaPath: '中国,江苏省,连云港市',
        areaCode: '100003200070000000',
        children: [
          {
            id: 10397,
            parentId: 3554,
            areaName: '连云区',
            areaPath: '中国,江苏省,连云港市,连云区',
            areaCode: '100003200070030000'
          },
          {
            id: 10398,
            parentId: 3554,
            areaName: '海州区',
            areaPath: '中国,江苏省,连云港市,海州区',
            areaCode: '100003200070060000'
          },
          {
            id: 10399,
            parentId: 3554,
            areaName: '赣榆区',
            areaPath: '中国,江苏省,连云港市,赣榆区',
            areaCode: '100003200070070000'
          },
          {
            id: 10400,
            parentId: 3554,
            areaName: '东海县',
            areaPath: '中国,江苏省,连云港市,东海县',
            areaCode: '100003200070220000'
          },
          {
            id: 10401,
            parentId: 3554,
            areaName: '灌云县',
            areaPath: '中国,江苏省,连云港市,灌云县',
            areaCode: '100003200070230000'
          },
          {
            id: 10402,
            parentId: 3554,
            areaName: '灌南县',
            areaPath: '中国,江苏省,连云港市,灌南县',
            areaCode: '100003200070240000'
          }
        ]
      },
      {
        id: 3555,
        parentId: 1443,
        areaName: '淮安市',
        areaPath: '中国,江苏省,淮安市',
        areaCode: '100003200080000000',
        children: [
          {
            id: 10403,
            parentId: 3555,
            areaName: '淮安区',
            areaPath: '中国,江苏省,淮安市,淮安区',
            areaCode: '100003200080030000'
          },
          {
            id: 10404,
            parentId: 3555,
            areaName: '淮阴区',
            areaPath: '中国,江苏省,淮安市,淮阴区',
            areaCode: '100003200080040000'
          },
          {
            id: 10405,
            parentId: 3555,
            areaName: '清江浦区',
            areaPath: '中国,江苏省,淮安市,清江浦区',
            areaCode: '100003200080120000'
          },
          {
            id: 10406,
            parentId: 3555,
            areaName: '洪泽区',
            areaPath: '中国,江苏省,淮安市,洪泽区',
            areaCode: '100003200080130000'
          },
          {
            id: 10407,
            parentId: 3555,
            areaName: '涟水县',
            areaPath: '中国,江苏省,淮安市,涟水县',
            areaCode: '100003200080260000'
          },
          {
            id: 10408,
            parentId: 3555,
            areaName: '盱眙县',
            areaPath: '中国,江苏省,淮安市,盱眙县',
            areaCode: '100003200080300000'
          },
          {
            id: 10409,
            parentId: 3555,
            areaName: '金湖县',
            areaPath: '中国,江苏省,淮安市,金湖县',
            areaCode: '100003200080310000'
          }
        ]
      },
      {
        id: 3556,
        parentId: 1443,
        areaName: '盐城市',
        areaPath: '中国,江苏省,盐城市',
        areaCode: '100003200090000000',
        children: [
          {
            id: 10410,
            parentId: 3556,
            areaName: '亭湖区',
            areaPath: '中国,江苏省,盐城市,亭湖区',
            areaCode: '100003200090020000'
          },
          {
            id: 10411,
            parentId: 3556,
            areaName: '盐都区',
            areaPath: '中国,江苏省,盐城市,盐都区',
            areaCode: '100003200090030000'
          },
          {
            id: 10412,
            parentId: 3556,
            areaName: '大丰区',
            areaPath: '中国,江苏省,盐城市,大丰区',
            areaCode: '100003200090040000'
          },
          {
            id: 10413,
            parentId: 3556,
            areaName: '响水县',
            areaPath: '中国,江苏省,盐城市,响水县',
            areaCode: '100003200090210000'
          },
          {
            id: 10414,
            parentId: 3556,
            areaName: '滨海县',
            areaPath: '中国,江苏省,盐城市,滨海县',
            areaCode: '100003200090220000'
          },
          {
            id: 10415,
            parentId: 3556,
            areaName: '阜宁县',
            areaPath: '中国,江苏省,盐城市,阜宁县',
            areaCode: '100003200090230000'
          },
          {
            id: 10416,
            parentId: 3556,
            areaName: '射阳县',
            areaPath: '中国,江苏省,盐城市,射阳县',
            areaCode: '100003200090240000'
          },
          {
            id: 10417,
            parentId: 3556,
            areaName: '建湖县',
            areaPath: '中国,江苏省,盐城市,建湖县',
            areaCode: '100003200090250000'
          },
          {
            id: 10418,
            parentId: 3556,
            areaName: '东台市',
            areaPath: '中国,江苏省,盐城市,东台市',
            areaCode: '100003200090810000'
          }
        ]
      },
      {
        id: 3557,
        parentId: 1443,
        areaName: '扬州市',
        areaPath: '中国,江苏省,扬州市',
        areaCode: '100003200100000000',
        children: [
          {
            id: 10419,
            parentId: 3557,
            areaName: '广陵区',
            areaPath: '中国,江苏省,扬州市,广陵区',
            areaCode: '100003200100020000'
          },
          {
            id: 10420,
            parentId: 3557,
            areaName: '邗江区',
            areaPath: '中国,江苏省,扬州市,邗江区',
            areaCode: '100003200100030000'
          },
          {
            id: 10421,
            parentId: 3557,
            areaName: '江都区',
            areaPath: '中国,江苏省,扬州市,江都区',
            areaCode: '100003200100120000'
          },
          {
            id: 10422,
            parentId: 3557,
            areaName: '宝应县',
            areaPath: '中国,江苏省,扬州市,宝应县',
            areaCode: '100003200100230000'
          },
          {
            id: 10423,
            parentId: 3557,
            areaName: '仪征市',
            areaPath: '中国,江苏省,扬州市,仪征市',
            areaCode: '100003200100810000'
          },
          {
            id: 10424,
            parentId: 3557,
            areaName: '高邮市',
            areaPath: '中国,江苏省,扬州市,高邮市',
            areaCode: '100003200100840000'
          }
        ]
      },
      {
        id: 3558,
        parentId: 1443,
        areaName: '镇江市',
        areaPath: '中国,江苏省,镇江市',
        areaCode: '100003200110000000',
        children: [
          {
            id: 10425,
            parentId: 3558,
            areaName: '京口区',
            areaPath: '中国,江苏省,镇江市,京口区',
            areaCode: '100003200110020000'
          },
          {
            id: 10426,
            parentId: 3558,
            areaName: '润州区',
            areaPath: '中国,江苏省,镇江市,润州区',
            areaCode: '100003200110110000'
          },
          {
            id: 10427,
            parentId: 3558,
            areaName: '丹徒区',
            areaPath: '中国,江苏省,镇江市,丹徒区',
            areaCode: '100003200110120000'
          },
          {
            id: 10428,
            parentId: 3558,
            areaName: '丹阳市',
            areaPath: '中国,江苏省,镇江市,丹阳市',
            areaCode: '100003200110810000'
          },
          {
            id: 10429,
            parentId: 3558,
            areaName: '扬中市',
            areaPath: '中国,江苏省,镇江市,扬中市',
            areaCode: '100003200110820000'
          },
          {
            id: 10430,
            parentId: 3558,
            areaName: '句容市',
            areaPath: '中国,江苏省,镇江市,句容市',
            areaCode: '100003200110830000'
          }
        ]
      },
      {
        id: 3559,
        parentId: 1443,
        areaName: '泰州市',
        areaPath: '中国,江苏省,泰州市',
        areaCode: '100003200120000000',
        children: [
          {
            id: 10431,
            parentId: 3559,
            areaName: '海陵区',
            areaPath: '中国,江苏省,泰州市,海陵区',
            areaCode: '100003200120020000'
          },
          {
            id: 10432,
            parentId: 3559,
            areaName: '高港区',
            areaPath: '中国,江苏省,泰州市,高港区',
            areaCode: '100003200120030000'
          },
          {
            id: 10433,
            parentId: 3559,
            areaName: '姜堰区',
            areaPath: '中国,江苏省,泰州市,姜堰区',
            areaCode: '100003200120040000'
          },
          {
            id: 10434,
            parentId: 3559,
            areaName: '兴化市',
            areaPath: '中国,江苏省,泰州市,兴化市',
            areaCode: '100003200120810000'
          },
          {
            id: 10435,
            parentId: 3559,
            areaName: '靖江市',
            areaPath: '中国,江苏省,泰州市,靖江市',
            areaCode: '100003200120820000'
          },
          {
            id: 10436,
            parentId: 3559,
            areaName: '泰兴市',
            areaPath: '中国,江苏省,泰州市,泰兴市',
            areaCode: '100003200120830000'
          }
        ]
      },
      {
        id: 3560,
        parentId: 1443,
        areaName: '宿迁市',
        areaPath: '中国,江苏省,宿迁市',
        areaCode: '100003200130000000',
        children: [
          {
            id: 10437,
            parentId: 3560,
            areaName: '宿城区',
            areaPath: '中国,江苏省,宿迁市,宿城区',
            areaCode: '100003200130020000'
          },
          {
            id: 10438,
            parentId: 3560,
            areaName: '宿豫区',
            areaPath: '中国,江苏省,宿迁市,宿豫区',
            areaCode: '100003200130110000'
          },
          {
            id: 10439,
            parentId: 3560,
            areaName: '沭阳县',
            areaPath: '中国,江苏省,宿迁市,沭阳县',
            areaCode: '100003200130220000'
          },
          {
            id: 10440,
            parentId: 3560,
            areaName: '泗阳县',
            areaPath: '中国,江苏省,宿迁市,泗阳县',
            areaCode: '100003200130230000'
          },
          {
            id: 10441,
            parentId: 3560,
            areaName: '泗洪县',
            areaPath: '中国,江苏省,宿迁市,泗洪县',
            areaCode: '100003200130240000'
          }
        ]
      }
    ]
  },
  {
    id: 1444,
    parentId: 1,
    areaName: '浙江省',
    areaPath: '中国,浙江省',
    areaCode: '100003300000000000',
    children: [
      {
        id: 3561,
        parentId: 1444,
        areaName: '杭州市',
        areaPath: '中国,浙江省,杭州市',
        areaCode: '100003300010000000',
        children: [
          {
            id: 10442,
            parentId: 3561,
            areaName: '上城区',
            areaPath: '中国,浙江省,杭州市,上城区',
            areaCode: '100003300010020000'
          },
          {
            id: 10443,
            parentId: 3561,
            areaName: '下城区',
            areaPath: '中国,浙江省,杭州市,下城区',
            areaCode: '100003300010030000'
          },
          {
            id: 10444,
            parentId: 3561,
            areaName: '江干区',
            areaPath: '中国,浙江省,杭州市,江干区',
            areaCode: '100003300010040000'
          },
          {
            id: 10445,
            parentId: 3561,
            areaName: '拱墅区',
            areaPath: '中国,浙江省,杭州市,拱墅区',
            areaCode: '100003300010050000'
          },
          {
            id: 10446,
            parentId: 3561,
            areaName: '西湖区',
            areaPath: '中国,浙江省,杭州市,西湖区',
            areaCode: '100003300010060000'
          },
          {
            id: 10447,
            parentId: 3561,
            areaName: '滨江区',
            areaPath: '中国,浙江省,杭州市,滨江区',
            areaCode: '100003300010080000'
          },
          {
            id: 10448,
            parentId: 3561,
            areaName: '萧山区',
            areaPath: '中国,浙江省,杭州市,萧山区',
            areaCode: '100003300010090000'
          },
          {
            id: 10449,
            parentId: 3561,
            areaName: '余杭区',
            areaPath: '中国,浙江省,杭州市,余杭区',
            areaCode: '100003300010100000'
          },
          {
            id: 10450,
            parentId: 3561,
            areaName: '富阳区',
            areaPath: '中国,浙江省,杭州市,富阳区',
            areaCode: '100003300010110000'
          },
          {
            id: 10451,
            parentId: 3561,
            areaName: '临安区',
            areaPath: '中国,浙江省,杭州市,临安区',
            areaCode: '100003300010120000'
          },
          {
            id: 10452,
            parentId: 3561,
            areaName: '桐庐县',
            areaPath: '中国,浙江省,杭州市,桐庐县',
            areaCode: '100003300010220000'
          },
          {
            id: 10453,
            parentId: 3561,
            areaName: '淳安县',
            areaPath: '中国,浙江省,杭州市,淳安县',
            areaCode: '100003300010270000'
          },
          {
            id: 10454,
            parentId: 3561,
            areaName: '建德市',
            areaPath: '中国,浙江省,杭州市,建德市',
            areaCode: '100003300010820000'
          }
        ]
      },
      {
        id: 3562,
        parentId: 1444,
        areaName: '宁波市',
        areaPath: '中国,浙江省,宁波市',
        areaCode: '100003300020000000',
        children: [
          {
            id: 10455,
            parentId: 3562,
            areaName: '海曙区',
            areaPath: '中国,浙江省,宁波市,海曙区',
            areaCode: '100003300020030000'
          },
          {
            id: 10456,
            parentId: 3562,
            areaName: '江北区',
            areaPath: '中国,浙江省,宁波市,江北区',
            areaCode: '100003300020050000'
          },
          {
            id: 10457,
            parentId: 3562,
            areaName: '北仑区',
            areaPath: '中国,浙江省,宁波市,北仑区',
            areaCode: '100003300020060000'
          },
          {
            id: 10458,
            parentId: 3562,
            areaName: '镇海区',
            areaPath: '中国,浙江省,宁波市,镇海区',
            areaCode: '100003300020110000'
          },
          {
            id: 10459,
            parentId: 3562,
            areaName: '鄞州区',
            areaPath: '中国,浙江省,宁波市,鄞州区',
            areaCode: '100003300020120000'
          },
          {
            id: 10460,
            parentId: 3562,
            areaName: '奉化区',
            areaPath: '中国,浙江省,宁波市,奉化区',
            areaCode: '100003300020130000'
          },
          {
            id: 10461,
            parentId: 3562,
            areaName: '象山县',
            areaPath: '中国,浙江省,宁波市,象山县',
            areaCode: '100003300020250000'
          },
          {
            id: 10462,
            parentId: 3562,
            areaName: '宁海县',
            areaPath: '中国,浙江省,宁波市,宁海县',
            areaCode: '100003300020260000'
          },
          {
            id: 10463,
            parentId: 3562,
            areaName: '余姚市',
            areaPath: '中国,浙江省,宁波市,余姚市',
            areaCode: '100003300020810000'
          },
          {
            id: 10464,
            parentId: 3562,
            areaName: '慈溪市',
            areaPath: '中国,浙江省,宁波市,慈溪市',
            areaCode: '100003300020820000'
          }
        ]
      },
      {
        id: 3563,
        parentId: 1444,
        areaName: '温州市',
        areaPath: '中国,浙江省,温州市',
        areaCode: '100003300030000000',
        children: [
          {
            id: 10465,
            parentId: 3563,
            areaName: '鹿城区',
            areaPath: '中国,浙江省,温州市,鹿城区',
            areaCode: '100003300030020000'
          },
          {
            id: 10466,
            parentId: 3563,
            areaName: '龙湾区',
            areaPath: '中国,浙江省,温州市,龙湾区',
            areaCode: '100003300030030000'
          },
          {
            id: 10467,
            parentId: 3563,
            areaName: '瓯海区',
            areaPath: '中国,浙江省,温州市,瓯海区',
            areaCode: '100003300030040000'
          },
          {
            id: 10468,
            parentId: 3563,
            areaName: '洞头区',
            areaPath: '中国,浙江省,温州市,洞头区',
            areaCode: '100003300030050000'
          },
          {
            id: 10469,
            parentId: 3563,
            areaName: '永嘉县',
            areaPath: '中国,浙江省,温州市,永嘉县',
            areaCode: '100003300030240000'
          },
          {
            id: 10470,
            parentId: 3563,
            areaName: '平阳县',
            areaPath: '中国,浙江省,温州市,平阳县',
            areaCode: '100003300030260000'
          },
          {
            id: 10471,
            parentId: 3563,
            areaName: '苍南县',
            areaPath: '中国,浙江省,温州市,苍南县',
            areaCode: '100003300030270000'
          },
          {
            id: 10472,
            parentId: 3563,
            areaName: '文成县',
            areaPath: '中国,浙江省,温州市,文成县',
            areaCode: '100003300030280000'
          },
          {
            id: 10473,
            parentId: 3563,
            areaName: '泰顺县',
            areaPath: '中国,浙江省,温州市,泰顺县',
            areaCode: '100003300030290000'
          },
          {
            id: 10474,
            parentId: 3563,
            areaName: '瑞安市',
            areaPath: '中国,浙江省,温州市,瑞安市',
            areaCode: '100003300030810000'
          },
          {
            id: 10475,
            parentId: 3563,
            areaName: '乐清市',
            areaPath: '中国,浙江省,温州市,乐清市',
            areaCode: '100003300030820000'
          }
        ]
      },
      {
        id: 3564,
        parentId: 1444,
        areaName: '嘉兴市',
        areaPath: '中国,浙江省,嘉兴市',
        areaCode: '100003300040000000',
        children: [
          {
            id: 10476,
            parentId: 3564,
            areaName: '南湖区',
            areaPath: '中国,浙江省,嘉兴市,南湖区',
            areaCode: '100003300040020000'
          },
          {
            id: 10477,
            parentId: 3564,
            areaName: '秀洲区',
            areaPath: '中国,浙江省,嘉兴市,秀洲区',
            areaCode: '100003300040110000'
          },
          {
            id: 10478,
            parentId: 3564,
            areaName: '嘉善县',
            areaPath: '中国,浙江省,嘉兴市,嘉善县',
            areaCode: '100003300040210000'
          },
          {
            id: 10479,
            parentId: 3564,
            areaName: '海盐县',
            areaPath: '中国,浙江省,嘉兴市,海盐县',
            areaCode: '100003300040240000'
          },
          {
            id: 10480,
            parentId: 3564,
            areaName: '海宁市',
            areaPath: '中国,浙江省,嘉兴市,海宁市',
            areaCode: '100003300040810000'
          },
          {
            id: 10481,
            parentId: 3564,
            areaName: '平湖市',
            areaPath: '中国,浙江省,嘉兴市,平湖市',
            areaCode: '100003300040820000'
          },
          {
            id: 10482,
            parentId: 3564,
            areaName: '桐乡市',
            areaPath: '中国,浙江省,嘉兴市,桐乡市',
            areaCode: '100003300040830000'
          }
        ]
      },
      {
        id: 3565,
        parentId: 1444,
        areaName: '湖州市',
        areaPath: '中国,浙江省,湖州市',
        areaCode: '100003300050000000',
        children: [
          {
            id: 10483,
            parentId: 3565,
            areaName: '吴兴区',
            areaPath: '中国,浙江省,湖州市,吴兴区',
            areaCode: '100003300050020000'
          },
          {
            id: 10484,
            parentId: 3565,
            areaName: '南浔区',
            areaPath: '中国,浙江省,湖州市,南浔区',
            areaCode: '100003300050030000'
          },
          {
            id: 10485,
            parentId: 3565,
            areaName: '德清县',
            areaPath: '中国,浙江省,湖州市,德清县',
            areaCode: '100003300050210000'
          },
          {
            id: 10486,
            parentId: 3565,
            areaName: '长兴县',
            areaPath: '中国,浙江省,湖州市,长兴县',
            areaCode: '100003300050220000'
          },
          {
            id: 10487,
            parentId: 3565,
            areaName: '安吉县',
            areaPath: '中国,浙江省,湖州市,安吉县',
            areaCode: '100003300050230000'
          }
        ]
      },
      {
        id: 3566,
        parentId: 1444,
        areaName: '绍兴市',
        areaPath: '中国,浙江省,绍兴市',
        areaCode: '100003300060000000',
        children: [
          {
            id: 10488,
            parentId: 3566,
            areaName: '越城区',
            areaPath: '中国,浙江省,绍兴市,越城区',
            areaCode: '100003300060020000'
          },
          {
            id: 10489,
            parentId: 3566,
            areaName: '柯桥区',
            areaPath: '中国,浙江省,绍兴市,柯桥区',
            areaCode: '100003300060030000'
          },
          {
            id: 10490,
            parentId: 3566,
            areaName: '上虞区',
            areaPath: '中国,浙江省,绍兴市,上虞区',
            areaCode: '100003300060040000'
          },
          {
            id: 10491,
            parentId: 3566,
            areaName: '新昌县',
            areaPath: '中国,浙江省,绍兴市,新昌县',
            areaCode: '100003300060240000'
          },
          {
            id: 10492,
            parentId: 3566,
            areaName: '诸暨市',
            areaPath: '中国,浙江省,绍兴市,诸暨市',
            areaCode: '100003300060810000'
          },
          {
            id: 10493,
            parentId: 3566,
            areaName: '嵊州市',
            areaPath: '中国,浙江省,绍兴市,嵊州市',
            areaCode: '100003300060830000'
          }
        ]
      },
      {
        id: 3567,
        parentId: 1444,
        areaName: '金华市',
        areaPath: '中国,浙江省,金华市',
        areaCode: '100003300070000000',
        children: [
          {
            id: 10494,
            parentId: 3567,
            areaName: '婺城区',
            areaPath: '中国,浙江省,金华市,婺城区',
            areaCode: '100003300070020000'
          },
          {
            id: 10495,
            parentId: 3567,
            areaName: '金东区',
            areaPath: '中国,浙江省,金华市,金东区',
            areaCode: '100003300070030000'
          },
          {
            id: 10496,
            parentId: 3567,
            areaName: '武义县',
            areaPath: '中国,浙江省,金华市,武义县',
            areaCode: '100003300070230000'
          },
          {
            id: 10497,
            parentId: 3567,
            areaName: '浦江县',
            areaPath: '中国,浙江省,金华市,浦江县',
            areaCode: '100003300070260000'
          },
          {
            id: 10498,
            parentId: 3567,
            areaName: '磐安县',
            areaPath: '中国,浙江省,金华市,磐安县',
            areaCode: '100003300070270000'
          },
          {
            id: 10499,
            parentId: 3567,
            areaName: '兰溪市',
            areaPath: '中国,浙江省,金华市,兰溪市',
            areaCode: '100003300070810000'
          },
          {
            id: 10500,
            parentId: 3567,
            areaName: '义乌市',
            areaPath: '中国,浙江省,金华市,义乌市',
            areaCode: '100003300070820000'
          },
          {
            id: 10501,
            parentId: 3567,
            areaName: '东阳市',
            areaPath: '中国,浙江省,金华市,东阳市',
            areaCode: '100003300070830000'
          },
          {
            id: 10502,
            parentId: 3567,
            areaName: '永康市',
            areaPath: '中国,浙江省,金华市,永康市',
            areaCode: '100003300070840000'
          }
        ]
      },
      {
        id: 3568,
        parentId: 1444,
        areaName: '衢州市',
        areaPath: '中国,浙江省,衢州市',
        areaCode: '100003300080000000',
        children: [
          {
            id: 10503,
            parentId: 3568,
            areaName: '柯城区',
            areaPath: '中国,浙江省,衢州市,柯城区',
            areaCode: '100003300080020000'
          },
          {
            id: 10504,
            parentId: 3568,
            areaName: '衢江区',
            areaPath: '中国,浙江省,衢州市,衢江区',
            areaCode: '100003300080030000'
          },
          {
            id: 10505,
            parentId: 3568,
            areaName: '常山县',
            areaPath: '中国,浙江省,衢州市,常山县',
            areaCode: '100003300080220000'
          },
          {
            id: 10506,
            parentId: 3568,
            areaName: '开化县',
            areaPath: '中国,浙江省,衢州市,开化县',
            areaCode: '100003300080240000'
          },
          {
            id: 10507,
            parentId: 3568,
            areaName: '龙游县',
            areaPath: '中国,浙江省,衢州市,龙游县',
            areaCode: '100003300080250000'
          },
          {
            id: 10508,
            parentId: 3568,
            areaName: '江山市',
            areaPath: '中国,浙江省,衢州市,江山市',
            areaCode: '100003300080810000'
          }
        ]
      },
      {
        id: 3569,
        parentId: 1444,
        areaName: '舟山市',
        areaPath: '中国,浙江省,舟山市',
        areaCode: '100003300090000000',
        children: [
          {
            id: 10509,
            parentId: 3569,
            areaName: '定海区',
            areaPath: '中国,浙江省,舟山市,定海区',
            areaCode: '100003300090020000'
          },
          {
            id: 10510,
            parentId: 3569,
            areaName: '普陀区',
            areaPath: '中国,浙江省,舟山市,普陀区',
            areaCode: '100003300090030000'
          },
          {
            id: 10511,
            parentId: 3569,
            areaName: '岱山县',
            areaPath: '中国,浙江省,舟山市,岱山县',
            areaCode: '100003300090210000'
          },
          {
            id: 10512,
            parentId: 3569,
            areaName: '嵊泗县',
            areaPath: '中国,浙江省,舟山市,嵊泗县',
            areaCode: '100003300090220000'
          }
        ]
      },
      {
        id: 3570,
        parentId: 1444,
        areaName: '台州市',
        areaPath: '中国,浙江省,台州市',
        areaCode: '100003300100000000',
        children: [
          {
            id: 10513,
            parentId: 3570,
            areaName: '椒江区',
            areaPath: '中国,浙江省,台州市,椒江区',
            areaCode: '100003300100020000'
          },
          {
            id: 10514,
            parentId: 3570,
            areaName: '黄岩区',
            areaPath: '中国,浙江省,台州市,黄岩区',
            areaCode: '100003300100030000'
          },
          {
            id: 10515,
            parentId: 3570,
            areaName: '路桥区',
            areaPath: '中国,浙江省,台州市,路桥区',
            areaCode: '100003300100040000'
          },
          {
            id: 10516,
            parentId: 3570,
            areaName: '三门县',
            areaPath: '中国,浙江省,台州市,三门县',
            areaCode: '100003300100220000'
          },
          {
            id: 10517,
            parentId: 3570,
            areaName: '天台县',
            areaPath: '中国,浙江省,台州市,天台县',
            areaCode: '100003300100230000'
          },
          {
            id: 10518,
            parentId: 3570,
            areaName: '仙居县',
            areaPath: '中国,浙江省,台州市,仙居县',
            areaCode: '100003300100240000'
          },
          {
            id: 10519,
            parentId: 3570,
            areaName: '温岭市',
            areaPath: '中国,浙江省,台州市,温岭市',
            areaCode: '100003300100810000'
          },
          {
            id: 10520,
            parentId: 3570,
            areaName: '临海市',
            areaPath: '中国,浙江省,台州市,临海市',
            areaCode: '100003300100820000'
          },
          {
            id: 10521,
            parentId: 3570,
            areaName: '玉环市',
            areaPath: '中国,浙江省,台州市,玉环市',
            areaCode: '100003300100830000'
          }
        ]
      },
      {
        id: 3571,
        parentId: 1444,
        areaName: '丽水市',
        areaPath: '中国,浙江省,丽水市',
        areaCode: '100003300110000000',
        children: [
          {
            id: 10522,
            parentId: 3571,
            areaName: '莲都区',
            areaPath: '中国,浙江省,丽水市,莲都区',
            areaCode: '100003300110020000'
          },
          {
            id: 10523,
            parentId: 3571,
            areaName: '青田县',
            areaPath: '中国,浙江省,丽水市,青田县',
            areaCode: '100003300110210000'
          },
          {
            id: 10524,
            parentId: 3571,
            areaName: '缙云县',
            areaPath: '中国,浙江省,丽水市,缙云县',
            areaCode: '100003300110220000'
          },
          {
            id: 10525,
            parentId: 3571,
            areaName: '遂昌县',
            areaPath: '中国,浙江省,丽水市,遂昌县',
            areaCode: '100003300110230000'
          },
          {
            id: 10526,
            parentId: 3571,
            areaName: '松阳县',
            areaPath: '中国,浙江省,丽水市,松阳县',
            areaCode: '100003300110240000'
          },
          {
            id: 10527,
            parentId: 3571,
            areaName: '云和县',
            areaPath: '中国,浙江省,丽水市,云和县',
            areaCode: '100003300110250000'
          },
          {
            id: 10528,
            parentId: 3571,
            areaName: '庆元县',
            areaPath: '中国,浙江省,丽水市,庆元县',
            areaCode: '100003300110260000'
          },
          {
            id: 10529,
            parentId: 3571,
            areaName: '景宁畲族自治县',
            areaPath: '中国,浙江省,丽水市,景宁畲族自治县',
            areaCode: '100003300110270000'
          },
          {
            id: 10530,
            parentId: 3571,
            areaName: '龙泉市',
            areaPath: '中国,浙江省,丽水市,龙泉市',
            areaCode: '100003300110810000'
          }
        ]
      }
    ]
  },
  {
    id: 1445,
    parentId: 1,
    areaName: '安徽省',
    areaPath: '中国,安徽省',
    areaCode: '100003400000000000',
    children: [
      {
        id: 3572,
        parentId: 1445,
        areaName: '合肥市',
        areaPath: '中国,安徽省,合肥市',
        areaCode: '100003400010000000',
        children: [
          {
            id: 10531,
            parentId: 3572,
            areaName: '瑶海区',
            areaPath: '中国,安徽省,合肥市,瑶海区',
            areaCode: '100003400010020000'
          },
          {
            id: 10532,
            parentId: 3572,
            areaName: '庐阳区',
            areaPath: '中国,安徽省,合肥市,庐阳区',
            areaCode: '100003400010030000'
          },
          {
            id: 10533,
            parentId: 3572,
            areaName: '蜀山区',
            areaPath: '中国,安徽省,合肥市,蜀山区',
            areaCode: '100003400010040000'
          },
          {
            id: 10534,
            parentId: 3572,
            areaName: '包河区',
            areaPath: '中国,安徽省,合肥市,包河区',
            areaCode: '100003400010110000'
          },
          {
            id: 10535,
            parentId: 3572,
            areaName: '长丰县',
            areaPath: '中国,安徽省,合肥市,长丰县',
            areaCode: '100003400010210000'
          },
          {
            id: 10536,
            parentId: 3572,
            areaName: '肥东县',
            areaPath: '中国,安徽省,合肥市,肥东县',
            areaCode: '100003400010220000'
          },
          {
            id: 10537,
            parentId: 3572,
            areaName: '肥西县',
            areaPath: '中国,安徽省,合肥市,肥西县',
            areaCode: '100003400010230000'
          },
          {
            id: 10538,
            parentId: 3572,
            areaName: '庐江县',
            areaPath: '中国,安徽省,合肥市,庐江县',
            areaCode: '100003400010240000'
          },
          {
            id: 10539,
            parentId: 3572,
            areaName: '巢湖市',
            areaPath: '中国,安徽省,合肥市,巢湖市',
            areaCode: '100003400010810000'
          }
        ]
      },
      {
        id: 3573,
        parentId: 1445,
        areaName: '芜湖市',
        areaPath: '中国,安徽省,芜湖市',
        areaCode: '100003400020000000',
        children: [
          {
            id: 10540,
            parentId: 3573,
            areaName: '镜湖区',
            areaPath: '中国,安徽省,芜湖市,镜湖区',
            areaCode: '100003400020020000'
          },
          {
            id: 10541,
            parentId: 3573,
            areaName: '弋江区',
            areaPath: '中国,安徽省,芜湖市,弋江区',
            areaCode: '100003400020030000'
          },
          {
            id: 10542,
            parentId: 3573,
            areaName: '鸠江区',
            areaPath: '中国,安徽省,芜湖市,鸠江区',
            areaCode: '100003400020070000'
          },
          {
            id: 10543,
            parentId: 3573,
            areaName: '三山区',
            areaPath: '中国,安徽省,芜湖市,三山区',
            areaCode: '100003400020080000'
          },
          {
            id: 10544,
            parentId: 3573,
            areaName: '芜湖县',
            areaPath: '中国,安徽省,芜湖市,芜湖县',
            areaCode: '100003400020210000'
          },
          {
            id: 10545,
            parentId: 3573,
            areaName: '繁昌县',
            areaPath: '中国,安徽省,芜湖市,繁昌县',
            areaCode: '100003400020220000'
          },
          {
            id: 10546,
            parentId: 3573,
            areaName: '南陵县',
            areaPath: '中国,安徽省,芜湖市,南陵县',
            areaCode: '100003400020230000'
          },
          {
            id: 10547,
            parentId: 3573,
            areaName: '无为县',
            areaPath: '中国,安徽省,芜湖市,无为县',
            areaCode: '100003400020250000'
          }
        ]
      },
      {
        id: 3574,
        parentId: 1445,
        areaName: '蚌埠市',
        areaPath: '中国,安徽省,蚌埠市',
        areaCode: '100003400030000000',
        children: [
          {
            id: 10548,
            parentId: 3574,
            areaName: '龙子湖区',
            areaPath: '中国,安徽省,蚌埠市,龙子湖区',
            areaCode: '100003400030020000'
          },
          {
            id: 10549,
            parentId: 3574,
            areaName: '蚌山区',
            areaPath: '中国,安徽省,蚌埠市,蚌山区',
            areaCode: '100003400030030000'
          },
          {
            id: 10550,
            parentId: 3574,
            areaName: '禹会区',
            areaPath: '中国,安徽省,蚌埠市,禹会区',
            areaCode: '100003400030040000'
          },
          {
            id: 10551,
            parentId: 3574,
            areaName: '淮上区',
            areaPath: '中国,安徽省,蚌埠市,淮上区',
            areaCode: '100003400030110000'
          },
          {
            id: 10552,
            parentId: 3574,
            areaName: '怀远县',
            areaPath: '中国,安徽省,蚌埠市,怀远县',
            areaCode: '100003400030210000'
          },
          {
            id: 10553,
            parentId: 3574,
            areaName: '五河县',
            areaPath: '中国,安徽省,蚌埠市,五河县',
            areaCode: '100003400030220000'
          },
          {
            id: 10554,
            parentId: 3574,
            areaName: '固镇县',
            areaPath: '中国,安徽省,蚌埠市,固镇县',
            areaCode: '100003400030230000'
          }
        ]
      },
      {
        id: 3575,
        parentId: 1445,
        areaName: '淮南市',
        areaPath: '中国,安徽省,淮南市',
        areaCode: '100003400040000000',
        children: [
          {
            id: 10555,
            parentId: 3575,
            areaName: '大通区',
            areaPath: '中国,安徽省,淮南市,大通区',
            areaCode: '100003400040020000'
          },
          {
            id: 10556,
            parentId: 3575,
            areaName: '田家庵区',
            areaPath: '中国,安徽省,淮南市,田家庵区',
            areaCode: '100003400040030000'
          },
          {
            id: 10557,
            parentId: 3575,
            areaName: '谢家集区',
            areaPath: '中国,安徽省,淮南市,谢家集区',
            areaCode: '100003400040040000'
          },
          {
            id: 10558,
            parentId: 3575,
            areaName: '八公山区',
            areaPath: '中国,安徽省,淮南市,八公山区',
            areaCode: '100003400040050000'
          },
          {
            id: 10559,
            parentId: 3575,
            areaName: '潘集区',
            areaPath: '中国,安徽省,淮南市,潘集区',
            areaCode: '100003400040060000'
          },
          {
            id: 10560,
            parentId: 3575,
            areaName: '凤台县',
            areaPath: '中国,安徽省,淮南市,凤台县',
            areaCode: '100003400040210000'
          },
          {
            id: 10561,
            parentId: 3575,
            areaName: '寿县',
            areaPath: '中国,安徽省,淮南市,寿县',
            areaCode: '100003400040220000'
          }
        ]
      },
      {
        id: 3576,
        parentId: 1445,
        areaName: '马鞍山市',
        areaPath: '中国,安徽省,马鞍山市',
        areaCode: '100003400050000000',
        children: [
          {
            id: 10562,
            parentId: 3576,
            areaName: '花山区',
            areaPath: '中国,安徽省,马鞍山市,花山区',
            areaCode: '100003400050030000'
          },
          {
            id: 10563,
            parentId: 3576,
            areaName: '雨山区',
            areaPath: '中国,安徽省,马鞍山市,雨山区',
            areaCode: '100003400050040000'
          },
          {
            id: 10564,
            parentId: 3576,
            areaName: '博望区',
            areaPath: '中国,安徽省,马鞍山市,博望区',
            areaCode: '100003400050060000'
          },
          {
            id: 10565,
            parentId: 3576,
            areaName: '当涂县',
            areaPath: '中国,安徽省,马鞍山市,当涂县',
            areaCode: '100003400050210000'
          },
          {
            id: 10566,
            parentId: 3576,
            areaName: '含山县',
            areaPath: '中国,安徽省,马鞍山市,含山县',
            areaCode: '100003400050220000'
          },
          {
            id: 10567,
            parentId: 3576,
            areaName: '和县',
            areaPath: '中国,安徽省,马鞍山市,和县',
            areaCode: '100003400050230000'
          }
        ]
      },
      {
        id: 3577,
        parentId: 1445,
        areaName: '淮北市',
        areaPath: '中国,安徽省,淮北市',
        areaCode: '100003400060000000',
        children: [
          {
            id: 10568,
            parentId: 3577,
            areaName: '杜集区',
            areaPath: '中国,安徽省,淮北市,杜集区',
            areaCode: '100003400060020000'
          },
          {
            id: 10569,
            parentId: 3577,
            areaName: '相山区',
            areaPath: '中国,安徽省,淮北市,相山区',
            areaCode: '100003400060030000'
          },
          {
            id: 10570,
            parentId: 3577,
            areaName: '烈山区',
            areaPath: '中国,安徽省,淮北市,烈山区',
            areaCode: '100003400060040000'
          },
          {
            id: 10571,
            parentId: 3577,
            areaName: '濉溪县',
            areaPath: '中国,安徽省,淮北市,濉溪县',
            areaCode: '100003400060210000'
          }
        ]
      },
      {
        id: 3578,
        parentId: 1445,
        areaName: '铜陵市',
        areaPath: '中国,安徽省,铜陵市',
        areaCode: '100003400070000000',
        children: [
          {
            id: 10572,
            parentId: 3578,
            areaName: '铜官区',
            areaPath: '中国,安徽省,铜陵市,铜官区',
            areaCode: '100003400070050000'
          },
          {
            id: 10573,
            parentId: 3578,
            areaName: '义安区',
            areaPath: '中国,安徽省,铜陵市,义安区',
            areaCode: '100003400070060000'
          },
          {
            id: 10574,
            parentId: 3578,
            areaName: '郊区',
            areaPath: '中国,安徽省,铜陵市,郊区',
            areaCode: '100003400070110000'
          },
          {
            id: 10575,
            parentId: 3578,
            areaName: '枞阳县',
            areaPath: '中国,安徽省,铜陵市,枞阳县',
            areaCode: '100003400070220000'
          }
        ]
      },
      {
        id: 3579,
        parentId: 1445,
        areaName: '安庆市',
        areaPath: '中国,安徽省,安庆市',
        areaCode: '100003400080000000',
        children: [
          {
            id: 10576,
            parentId: 3579,
            areaName: '迎江区',
            areaPath: '中国,安徽省,安庆市,迎江区',
            areaCode: '100003400080020000'
          },
          {
            id: 10577,
            parentId: 3579,
            areaName: '大观区',
            areaPath: '中国,安徽省,安庆市,大观区',
            areaCode: '100003400080030000'
          },
          {
            id: 10578,
            parentId: 3579,
            areaName: '宜秀区',
            areaPath: '中国,安徽省,安庆市,宜秀区',
            areaCode: '100003400080110000'
          },
          {
            id: 10579,
            parentId: 3579,
            areaName: '怀宁县',
            areaPath: '中国,安徽省,安庆市,怀宁县',
            areaCode: '100003400080220000'
          },
          {
            id: 10580,
            parentId: 3579,
            areaName: '潜山县',
            areaPath: '中国,安徽省,安庆市,潜山县',
            areaCode: '100003400080240000'
          },
          {
            id: 10581,
            parentId: 3579,
            areaName: '太湖县',
            areaPath: '中国,安徽省,安庆市,太湖县',
            areaCode: '100003400080250000'
          },
          {
            id: 10582,
            parentId: 3579,
            areaName: '宿松县',
            areaPath: '中国,安徽省,安庆市,宿松县',
            areaCode: '100003400080260000'
          },
          {
            id: 10583,
            parentId: 3579,
            areaName: '望江县',
            areaPath: '中国,安徽省,安庆市,望江县',
            areaCode: '100003400080270000'
          },
          {
            id: 10584,
            parentId: 3579,
            areaName: '岳西县',
            areaPath: '中国,安徽省,安庆市,岳西县',
            areaCode: '100003400080280000'
          },
          {
            id: 10585,
            parentId: 3579,
            areaName: '桐城市',
            areaPath: '中国,安徽省,安庆市,桐城市',
            areaCode: '100003400080810000'
          }
        ]
      },
      {
        id: 3580,
        parentId: 1445,
        areaName: '黄山市',
        areaPath: '中国,安徽省,黄山市',
        areaCode: '100003400100000000',
        children: [
          {
            id: 10586,
            parentId: 3580,
            areaName: '屯溪区',
            areaPath: '中国,安徽省,黄山市,屯溪区',
            areaCode: '100003400100020000'
          },
          {
            id: 10587,
            parentId: 3580,
            areaName: '黄山区',
            areaPath: '中国,安徽省,黄山市,黄山区',
            areaCode: '100003400100030000'
          },
          {
            id: 10588,
            parentId: 3580,
            areaName: '徽州区',
            areaPath: '中国,安徽省,黄山市,徽州区',
            areaCode: '100003400100040000'
          },
          {
            id: 10589,
            parentId: 3580,
            areaName: '歙县',
            areaPath: '中国,安徽省,黄山市,歙县',
            areaCode: '100003400100210000'
          },
          {
            id: 10590,
            parentId: 3580,
            areaName: '休宁县',
            areaPath: '中国,安徽省,黄山市,休宁县',
            areaCode: '100003400100220000'
          },
          {
            id: 10591,
            parentId: 3580,
            areaName: '黟县',
            areaPath: '中国,安徽省,黄山市,黟县',
            areaCode: '100003400100230000'
          },
          {
            id: 10592,
            parentId: 3580,
            areaName: '祁门县',
            areaPath: '中国,安徽省,黄山市,祁门县',
            areaCode: '100003400100240000'
          }
        ]
      },
      {
        id: 3581,
        parentId: 1445,
        areaName: '滁州市',
        areaPath: '中国,安徽省,滁州市',
        areaCode: '100003400110000000',
        children: [
          {
            id: 10593,
            parentId: 3581,
            areaName: '琅琊区',
            areaPath: '中国,安徽省,滁州市,琅琊区',
            areaCode: '100003400110020000'
          },
          {
            id: 10594,
            parentId: 3581,
            areaName: '南谯区',
            areaPath: '中国,安徽省,滁州市,南谯区',
            areaCode: '100003400110030000'
          },
          {
            id: 10595,
            parentId: 3581,
            areaName: '来安县',
            areaPath: '中国,安徽省,滁州市,来安县',
            areaCode: '100003400110220000'
          },
          {
            id: 10596,
            parentId: 3581,
            areaName: '全椒县',
            areaPath: '中国,安徽省,滁州市,全椒县',
            areaCode: '100003400110240000'
          },
          {
            id: 10597,
            parentId: 3581,
            areaName: '定远县',
            areaPath: '中国,安徽省,滁州市,定远县',
            areaCode: '100003400110250000'
          },
          {
            id: 10598,
            parentId: 3581,
            areaName: '凤阳县',
            areaPath: '中国,安徽省,滁州市,凤阳县',
            areaCode: '100003400110260000'
          },
          {
            id: 10599,
            parentId: 3581,
            areaName: '天长市',
            areaPath: '中国,安徽省,滁州市,天长市',
            areaCode: '100003400110810000'
          },
          {
            id: 10600,
            parentId: 3581,
            areaName: '明光市',
            areaPath: '中国,安徽省,滁州市,明光市',
            areaCode: '100003400110820000'
          }
        ]
      },
      {
        id: 3582,
        parentId: 1445,
        areaName: '阜阳市',
        areaPath: '中国,安徽省,阜阳市',
        areaCode: '100003400120000000',
        children: [
          {
            id: 10601,
            parentId: 3582,
            areaName: '颍州区',
            areaPath: '中国,安徽省,阜阳市,颍州区',
            areaCode: '100003400120020000'
          },
          {
            id: 10602,
            parentId: 3582,
            areaName: '颍东区',
            areaPath: '中国,安徽省,阜阳市,颍东区',
            areaCode: '100003400120030000'
          },
          {
            id: 10603,
            parentId: 3582,
            areaName: '颍泉区',
            areaPath: '中国,安徽省,阜阳市,颍泉区',
            areaCode: '100003400120040000'
          },
          {
            id: 10604,
            parentId: 3582,
            areaName: '临泉县',
            areaPath: '中国,安徽省,阜阳市,临泉县',
            areaCode: '100003400120210000'
          },
          {
            id: 10605,
            parentId: 3582,
            areaName: '太和县',
            areaPath: '中国,安徽省,阜阳市,太和县',
            areaCode: '100003400120220000'
          },
          {
            id: 10606,
            parentId: 3582,
            areaName: '阜南县',
            areaPath: '中国,安徽省,阜阳市,阜南县',
            areaCode: '100003400120250000'
          },
          {
            id: 10607,
            parentId: 3582,
            areaName: '颍上县',
            areaPath: '中国,安徽省,阜阳市,颍上县',
            areaCode: '100003400120260000'
          },
          {
            id: 10608,
            parentId: 3582,
            areaName: '界首市',
            areaPath: '中国,安徽省,阜阳市,界首市',
            areaCode: '100003400120820000'
          }
        ]
      },
      {
        id: 3583,
        parentId: 1445,
        areaName: '宿州市',
        areaPath: '中国,安徽省,宿州市',
        areaCode: '100003400130000000',
        children: [
          {
            id: 10609,
            parentId: 3583,
            areaName: '埇桥区',
            areaPath: '中国,安徽省,宿州市,埇桥区',
            areaCode: '100003400130020000'
          },
          {
            id: 10610,
            parentId: 3583,
            areaName: '砀山县',
            areaPath: '中国,安徽省,宿州市,砀山县',
            areaCode: '100003400130210000'
          },
          {
            id: 10611,
            parentId: 3583,
            areaName: '萧县',
            areaPath: '中国,安徽省,宿州市,萧县',
            areaCode: '100003400130220000'
          },
          {
            id: 10612,
            parentId: 3583,
            areaName: '灵璧县',
            areaPath: '中国,安徽省,宿州市,灵璧县',
            areaCode: '100003400130230000'
          },
          {
            id: 10613,
            parentId: 3583,
            areaName: '泗县',
            areaPath: '中国,安徽省,宿州市,泗县',
            areaCode: '100003400130240000'
          }
        ]
      },
      {
        id: 3584,
        parentId: 1445,
        areaName: '六安市',
        areaPath: '中国,安徽省,六安市',
        areaCode: '100003400150000000',
        children: [
          {
            id: 10614,
            parentId: 3584,
            areaName: '金安区',
            areaPath: '中国,安徽省,六安市,金安区',
            areaCode: '100003400150020000'
          },
          {
            id: 10615,
            parentId: 3584,
            areaName: '裕安区',
            areaPath: '中国,安徽省,六安市,裕安区',
            areaCode: '100003400150030000'
          },
          {
            id: 10616,
            parentId: 3584,
            areaName: '叶集区',
            areaPath: '中国,安徽省,六安市,叶集区',
            areaCode: '100003400150040000'
          },
          {
            id: 10617,
            parentId: 3584,
            areaName: '霍邱县',
            areaPath: '中国,安徽省,六安市,霍邱县',
            areaCode: '100003400150220000'
          },
          {
            id: 10618,
            parentId: 3584,
            areaName: '舒城县',
            areaPath: '中国,安徽省,六安市,舒城县',
            areaCode: '100003400150230000'
          },
          {
            id: 10619,
            parentId: 3584,
            areaName: '金寨县',
            areaPath: '中国,安徽省,六安市,金寨县',
            areaCode: '100003400150240000'
          },
          {
            id: 10620,
            parentId: 3584,
            areaName: '霍山县',
            areaPath: '中国,安徽省,六安市,霍山县',
            areaCode: '100003400150250000'
          }
        ]
      },
      {
        id: 3585,
        parentId: 1445,
        areaName: '亳州市',
        areaPath: '中国,安徽省,亳州市',
        areaCode: '100003400160000000',
        children: [
          {
            id: 10621,
            parentId: 3585,
            areaName: '谯城区',
            areaPath: '中国,安徽省,亳州市,谯城区',
            areaCode: '100003400160020000'
          },
          {
            id: 10622,
            parentId: 3585,
            areaName: '涡阳县',
            areaPath: '中国,安徽省,亳州市,涡阳县',
            areaCode: '100003400160210000'
          },
          {
            id: 10623,
            parentId: 3585,
            areaName: '蒙城县',
            areaPath: '中国,安徽省,亳州市,蒙城县',
            areaCode: '100003400160220000'
          },
          {
            id: 10624,
            parentId: 3585,
            areaName: '利辛县',
            areaPath: '中国,安徽省,亳州市,利辛县',
            areaCode: '100003400160230000'
          }
        ]
      },
      {
        id: 3586,
        parentId: 1445,
        areaName: '池州市',
        areaPath: '中国,安徽省,池州市',
        areaCode: '100003400170000000',
        children: [
          {
            id: 10625,
            parentId: 3586,
            areaName: '贵池区',
            areaPath: '中国,安徽省,池州市,贵池区',
            areaCode: '100003400170020000'
          },
          {
            id: 10626,
            parentId: 3586,
            areaName: '东至县',
            areaPath: '中国,安徽省,池州市,东至县',
            areaCode: '100003400170210000'
          },
          {
            id: 10627,
            parentId: 3586,
            areaName: '石台县',
            areaPath: '中国,安徽省,池州市,石台县',
            areaCode: '100003400170220000'
          },
          {
            id: 10628,
            parentId: 3586,
            areaName: '青阳县',
            areaPath: '中国,安徽省,池州市,青阳县',
            areaCode: '100003400170230000'
          }
        ]
      },
      {
        id: 3587,
        parentId: 1445,
        areaName: '宣城市',
        areaPath: '中国,安徽省,宣城市',
        areaCode: '100003400180000000',
        children: [
          {
            id: 10629,
            parentId: 3587,
            areaName: '宣州区',
            areaPath: '中国,安徽省,宣城市,宣州区',
            areaCode: '100003400180020000'
          },
          {
            id: 10630,
            parentId: 3587,
            areaName: '郎溪县',
            areaPath: '中国,安徽省,宣城市,郎溪县',
            areaCode: '100003400180210000'
          },
          {
            id: 10631,
            parentId: 3587,
            areaName: '广德县',
            areaPath: '中国,安徽省,宣城市,广德县',
            areaCode: '100003400180220000'
          },
          {
            id: 10632,
            parentId: 3587,
            areaName: '泾县',
            areaPath: '中国,安徽省,宣城市,泾县',
            areaCode: '100003400180230000'
          },
          {
            id: 10633,
            parentId: 3587,
            areaName: '绩溪县',
            areaPath: '中国,安徽省,宣城市,绩溪县',
            areaCode: '100003400180240000'
          },
          {
            id: 10634,
            parentId: 3587,
            areaName: '旌德县',
            areaPath: '中国,安徽省,宣城市,旌德县',
            areaCode: '100003400180250000'
          },
          {
            id: 10635,
            parentId: 3587,
            areaName: '宁国市',
            areaPath: '中国,安徽省,宣城市,宁国市',
            areaCode: '100003400180810000'
          }
        ]
      }
    ]
  },
  {
    id: 1446,
    parentId: 1,
    areaName: '福建省',
    areaPath: '中国,福建省',
    areaCode: '100003500000000000',
    children: [
      {
        id: 3588,
        parentId: 1446,
        areaName: '福州市',
        areaPath: '中国,福建省,福州市',
        areaCode: '100003500010000000',
        children: [
          {
            id: 10636,
            parentId: 3588,
            areaName: '鼓楼区',
            areaPath: '中国,福建省,福州市,鼓楼区',
            areaCode: '100003500010020000'
          },
          {
            id: 10637,
            parentId: 3588,
            areaName: '台江区',
            areaPath: '中国,福建省,福州市,台江区',
            areaCode: '100003500010030000'
          },
          {
            id: 10638,
            parentId: 3588,
            areaName: '仓山区',
            areaPath: '中国,福建省,福州市,仓山区',
            areaCode: '100003500010040000'
          },
          {
            id: 10639,
            parentId: 3588,
            areaName: '马尾区',
            areaPath: '中国,福建省,福州市,马尾区',
            areaCode: '100003500010050000'
          },
          {
            id: 10640,
            parentId: 3588,
            areaName: '晋安区',
            areaPath: '中国,福建省,福州市,晋安区',
            areaCode: '100003500010110000'
          },
          {
            id: 10641,
            parentId: 3588,
            areaName: '长乐区',
            areaPath: '中国,福建省,福州市,长乐区',
            areaCode: '100003500010820000'
          },
          {
            id: 10642,
            parentId: 3588,
            areaName: '闽侯县',
            areaPath: '中国,福建省,福州市,闽侯县',
            areaCode: '100003500010210000'
          },
          {
            id: 10643,
            parentId: 3588,
            areaName: '连江县',
            areaPath: '中国,福建省,福州市,连江县',
            areaCode: '100003500010220000'
          },
          {
            id: 10644,
            parentId: 3588,
            areaName: '罗源县',
            areaPath: '中国,福建省,福州市,罗源县',
            areaCode: '100003500010230000'
          },
          {
            id: 10645,
            parentId: 3588,
            areaName: '闽清县',
            areaPath: '中国,福建省,福州市,闽清县',
            areaCode: '100003500010240000'
          },
          {
            id: 10646,
            parentId: 3588,
            areaName: '永泰县',
            areaPath: '中国,福建省,福州市,永泰县',
            areaCode: '100003500010250000'
          },
          {
            id: 10647,
            parentId: 3588,
            areaName: '平潭县',
            areaPath: '中国,福建省,福州市,平潭县',
            areaCode: '100003500010280000'
          },
          {
            id: 10648,
            parentId: 3588,
            areaName: '福清市',
            areaPath: '中国,福建省,福州市,福清市',
            areaCode: '100003500010810000'
          }
        ]
      },
      {
        id: 3589,
        parentId: 1446,
        areaName: '厦门市',
        areaPath: '中国,福建省,厦门市',
        areaCode: '100003500020000000',
        children: [
          {
            id: 10649,
            parentId: 3589,
            areaName: '思明区',
            areaPath: '中国,福建省,厦门市,思明区',
            areaCode: '100003500020030000'
          },
          {
            id: 10650,
            parentId: 3589,
            areaName: '海沧区',
            areaPath: '中国,福建省,厦门市,海沧区',
            areaCode: '100003500020050000'
          },
          {
            id: 10651,
            parentId: 3589,
            areaName: '湖里区',
            areaPath: '中国,福建省,厦门市,湖里区',
            areaCode: '100003500020060000'
          },
          {
            id: 10652,
            parentId: 3589,
            areaName: '集美区',
            areaPath: '中国,福建省,厦门市,集美区',
            areaCode: '100003500020110000'
          },
          {
            id: 10653,
            parentId: 3589,
            areaName: '同安区',
            areaPath: '中国,福建省,厦门市,同安区',
            areaCode: '100003500020120000'
          },
          {
            id: 10654,
            parentId: 3589,
            areaName: '翔安区',
            areaPath: '中国,福建省,厦门市,翔安区',
            areaCode: '100003500020130000'
          }
        ]
      },
      {
        id: 3590,
        parentId: 1446,
        areaName: '莆田市',
        areaPath: '中国,福建省,莆田市',
        areaCode: '100003500030000000',
        children: [
          {
            id: 10655,
            parentId: 3590,
            areaName: '城厢区',
            areaPath: '中国,福建省,莆田市,城厢区',
            areaCode: '100003500030020000'
          },
          {
            id: 10656,
            parentId: 3590,
            areaName: '涵江区',
            areaPath: '中国,福建省,莆田市,涵江区',
            areaCode: '100003500030030000'
          },
          {
            id: 10657,
            parentId: 3590,
            areaName: '荔城区',
            areaPath: '中国,福建省,莆田市,荔城区',
            areaCode: '100003500030040000'
          },
          {
            id: 10658,
            parentId: 3590,
            areaName: '秀屿区',
            areaPath: '中国,福建省,莆田市,秀屿区',
            areaCode: '100003500030050000'
          },
          {
            id: 10659,
            parentId: 3590,
            areaName: '仙游县',
            areaPath: '中国,福建省,莆田市,仙游县',
            areaCode: '100003500030220000'
          }
        ]
      },
      {
        id: 3591,
        parentId: 1446,
        areaName: '三明市',
        areaPath: '中国,福建省,三明市',
        areaCode: '100003500040000000',
        children: [
          {
            id: 10660,
            parentId: 3591,
            areaName: '梅列区',
            areaPath: '中国,福建省,三明市,梅列区',
            areaCode: '100003500040020000'
          },
          {
            id: 10661,
            parentId: 3591,
            areaName: '三元区',
            areaPath: '中国,福建省,三明市,三元区',
            areaCode: '100003500040030000'
          },
          {
            id: 10662,
            parentId: 3591,
            areaName: '明溪县',
            areaPath: '中国,福建省,三明市,明溪县',
            areaCode: '100003500040210000'
          },
          {
            id: 10663,
            parentId: 3591,
            areaName: '清流县',
            areaPath: '中国,福建省,三明市,清流县',
            areaCode: '100003500040230000'
          },
          {
            id: 10664,
            parentId: 3591,
            areaName: '宁化县',
            areaPath: '中国,福建省,三明市,宁化县',
            areaCode: '100003500040240000'
          },
          {
            id: 10665,
            parentId: 3591,
            areaName: '大田县',
            areaPath: '中国,福建省,三明市,大田县',
            areaCode: '100003500040250000'
          },
          {
            id: 10666,
            parentId: 3591,
            areaName: '尤溪县',
            areaPath: '中国,福建省,三明市,尤溪县',
            areaCode: '100003500040260000'
          },
          {
            id: 10667,
            parentId: 3591,
            areaName: '沙县',
            areaPath: '中国,福建省,三明市,沙县',
            areaCode: '100003500040270000'
          },
          {
            id: 10668,
            parentId: 3591,
            areaName: '将乐县',
            areaPath: '中国,福建省,三明市,将乐县',
            areaCode: '100003500040280000'
          },
          {
            id: 10669,
            parentId: 3591,
            areaName: '泰宁县',
            areaPath: '中国,福建省,三明市,泰宁县',
            areaCode: '100003500040290000'
          },
          {
            id: 10670,
            parentId: 3591,
            areaName: '建宁县',
            areaPath: '中国,福建省,三明市,建宁县',
            areaCode: '100003500040300000'
          },
          {
            id: 10671,
            parentId: 3591,
            areaName: '永安市',
            areaPath: '中国,福建省,三明市,永安市',
            areaCode: '100003500040810000'
          }
        ]
      },
      {
        id: 3592,
        parentId: 1446,
        areaName: '泉州市',
        areaPath: '中国,福建省,泉州市',
        areaCode: '100003500050000000',
        children: [
          {
            id: 10672,
            parentId: 3592,
            areaName: '鲤城区',
            areaPath: '中国,福建省,泉州市,鲤城区',
            areaCode: '100003500050020000'
          },
          {
            id: 10673,
            parentId: 3592,
            areaName: '丰泽区',
            areaPath: '中国,福建省,泉州市,丰泽区',
            areaCode: '100003500050030000'
          },
          {
            id: 10674,
            parentId: 3592,
            areaName: '洛江区',
            areaPath: '中国,福建省,泉州市,洛江区',
            areaCode: '100003500050040000'
          },
          {
            id: 10675,
            parentId: 3592,
            areaName: '泉港区',
            areaPath: '中国,福建省,泉州市,泉港区',
            areaCode: '100003500050050000'
          },
          {
            id: 10676,
            parentId: 3592,
            areaName: '惠安县',
            areaPath: '中国,福建省,泉州市,惠安县',
            areaCode: '100003500050210000'
          },
          {
            id: 10677,
            parentId: 3592,
            areaName: '安溪县',
            areaPath: '中国,福建省,泉州市,安溪县',
            areaCode: '100003500050240000'
          },
          {
            id: 10678,
            parentId: 3592,
            areaName: '永春县',
            areaPath: '中国,福建省,泉州市,永春县',
            areaCode: '100003500050250000'
          },
          {
            id: 10679,
            parentId: 3592,
            areaName: '德化县',
            areaPath: '中国,福建省,泉州市,德化县',
            areaCode: '100003500050260000'
          },
          {
            id: 10680,
            parentId: 3592,
            areaName: '金门县',
            areaPath: '中国,福建省,泉州市,金门县',
            areaCode: '100003500050270000'
          },
          {
            id: 10681,
            parentId: 3592,
            areaName: '石狮市',
            areaPath: '中国,福建省,泉州市,石狮市',
            areaCode: '100003500050810000'
          },
          {
            id: 10682,
            parentId: 3592,
            areaName: '晋江市',
            areaPath: '中国,福建省,泉州市,晋江市',
            areaCode: '100003500050820000'
          },
          {
            id: 10683,
            parentId: 3592,
            areaName: '南安市',
            areaPath: '中国,福建省,泉州市,南安市',
            areaCode: '100003500050830000'
          }
        ]
      },
      {
        id: 3593,
        parentId: 1446,
        areaName: '漳州市',
        areaPath: '中国,福建省,漳州市',
        areaCode: '100003500060000000',
        children: [
          {
            id: 10684,
            parentId: 3593,
            areaName: '芗城区',
            areaPath: '中国,福建省,漳州市,芗城区',
            areaCode: '100003500060020000'
          },
          {
            id: 10685,
            parentId: 3593,
            areaName: '龙文区',
            areaPath: '中国,福建省,漳州市,龙文区',
            areaCode: '100003500060030000'
          },
          {
            id: 10686,
            parentId: 3593,
            areaName: '云霄县',
            areaPath: '中国,福建省,漳州市,云霄县',
            areaCode: '100003500060220000'
          },
          {
            id: 10687,
            parentId: 3593,
            areaName: '漳浦县',
            areaPath: '中国,福建省,漳州市,漳浦县',
            areaCode: '100003500060230000'
          },
          {
            id: 10688,
            parentId: 3593,
            areaName: '诏安县',
            areaPath: '中国,福建省,漳州市,诏安县',
            areaCode: '100003500060240000'
          },
          {
            id: 10689,
            parentId: 3593,
            areaName: '长泰县',
            areaPath: '中国,福建省,漳州市,长泰县',
            areaCode: '100003500060250000'
          },
          {
            id: 10690,
            parentId: 3593,
            areaName: '东山县',
            areaPath: '中国,福建省,漳州市,东山县',
            areaCode: '100003500060260000'
          },
          {
            id: 10691,
            parentId: 3593,
            areaName: '南靖县',
            areaPath: '中国,福建省,漳州市,南靖县',
            areaCode: '100003500060270000'
          },
          {
            id: 10692,
            parentId: 3593,
            areaName: '平和县',
            areaPath: '中国,福建省,漳州市,平和县',
            areaCode: '100003500060280000'
          },
          {
            id: 10693,
            parentId: 3593,
            areaName: '华安县',
            areaPath: '中国,福建省,漳州市,华安县',
            areaCode: '100003500060290000'
          },
          {
            id: 10694,
            parentId: 3593,
            areaName: '龙海市',
            areaPath: '中国,福建省,漳州市,龙海市',
            areaCode: '100003500060810000'
          }
        ]
      },
      {
        id: 3594,
        parentId: 1446,
        areaName: '南平市',
        areaPath: '中国,福建省,南平市',
        areaCode: '100003500070000000',
        children: [
          {
            id: 10695,
            parentId: 3594,
            areaName: '延平区',
            areaPath: '中国,福建省,南平市,延平区',
            areaCode: '100003500070020000'
          },
          {
            id: 10696,
            parentId: 3594,
            areaName: '建阳区',
            areaPath: '中国,福建省,南平市,建阳区',
            areaCode: '100003500070030000'
          },
          {
            id: 10697,
            parentId: 3594,
            areaName: '顺昌县',
            areaPath: '中国,福建省,南平市,顺昌县',
            areaCode: '100003500070210000'
          },
          {
            id: 10698,
            parentId: 3594,
            areaName: '浦城县',
            areaPath: '中国,福建省,南平市,浦城县',
            areaCode: '100003500070220000'
          },
          {
            id: 10699,
            parentId: 3594,
            areaName: '光泽县',
            areaPath: '中国,福建省,南平市,光泽县',
            areaCode: '100003500070230000'
          },
          {
            id: 10700,
            parentId: 3594,
            areaName: '松溪县',
            areaPath: '中国,福建省,南平市,松溪县',
            areaCode: '100003500070240000'
          },
          {
            id: 10701,
            parentId: 3594,
            areaName: '政和县',
            areaPath: '中国,福建省,南平市,政和县',
            areaCode: '100003500070250000'
          },
          {
            id: 10702,
            parentId: 3594,
            areaName: '邵武市',
            areaPath: '中国,福建省,南平市,邵武市',
            areaCode: '100003500070810000'
          },
          {
            id: 10703,
            parentId: 3594,
            areaName: '武夷山市',
            areaPath: '中国,福建省,南平市,武夷山市',
            areaCode: '100003500070820000'
          },
          {
            id: 10704,
            parentId: 3594,
            areaName: '建瓯市',
            areaPath: '中国,福建省,南平市,建瓯市',
            areaCode: '100003500070830000'
          }
        ]
      },
      {
        id: 3595,
        parentId: 1446,
        areaName: '龙岩市',
        areaPath: '中国,福建省,龙岩市',
        areaCode: '100003500080000000',
        children: [
          {
            id: 10705,
            parentId: 3595,
            areaName: '新罗区',
            areaPath: '中国,福建省,龙岩市,新罗区',
            areaCode: '100003500080020000'
          },
          {
            id: 10706,
            parentId: 3595,
            areaName: '永定区',
            areaPath: '中国,福建省,龙岩市,永定区',
            areaCode: '100003500080030000'
          },
          {
            id: 10707,
            parentId: 3595,
            areaName: '长汀县',
            areaPath: '中国,福建省,龙岩市,长汀县',
            areaCode: '100003500080210000'
          },
          {
            id: 10708,
            parentId: 3595,
            areaName: '上杭县',
            areaPath: '中国,福建省,龙岩市,上杭县',
            areaCode: '100003500080230000'
          },
          {
            id: 10709,
            parentId: 3595,
            areaName: '武平县',
            areaPath: '中国,福建省,龙岩市,武平县',
            areaCode: '100003500080240000'
          },
          {
            id: 10710,
            parentId: 3595,
            areaName: '连城县',
            areaPath: '中国,福建省,龙岩市,连城县',
            areaCode: '100003500080250000'
          },
          {
            id: 10711,
            parentId: 3595,
            areaName: '漳平市',
            areaPath: '中国,福建省,龙岩市,漳平市',
            areaCode: '100003500080810000'
          }
        ]
      },
      {
        id: 3596,
        parentId: 1446,
        areaName: '宁德市',
        areaPath: '中国,福建省,宁德市',
        areaCode: '100003500090000000',
        children: [
          {
            id: 10712,
            parentId: 3596,
            areaName: '蕉城区',
            areaPath: '中国,福建省,宁德市,蕉城区',
            areaCode: '100003500090020000'
          },
          {
            id: 10713,
            parentId: 3596,
            areaName: '霞浦县',
            areaPath: '中国,福建省,宁德市,霞浦县',
            areaCode: '100003500090210000'
          },
          {
            id: 10714,
            parentId: 3596,
            areaName: '古田县',
            areaPath: '中国,福建省,宁德市,古田县',
            areaCode: '100003500090220000'
          },
          {
            id: 10715,
            parentId: 3596,
            areaName: '屏南县',
            areaPath: '中国,福建省,宁德市,屏南县',
            areaCode: '100003500090230000'
          },
          {
            id: 10716,
            parentId: 3596,
            areaName: '寿宁县',
            areaPath: '中国,福建省,宁德市,寿宁县',
            areaCode: '100003500090240000'
          },
          {
            id: 10717,
            parentId: 3596,
            areaName: '周宁县',
            areaPath: '中国,福建省,宁德市,周宁县',
            areaCode: '100003500090250000'
          },
          {
            id: 10718,
            parentId: 3596,
            areaName: '柘荣县',
            areaPath: '中国,福建省,宁德市,柘荣县',
            areaCode: '100003500090260000'
          },
          {
            id: 10719,
            parentId: 3596,
            areaName: '福安市',
            areaPath: '中国,福建省,宁德市,福安市',
            areaCode: '100003500090810000'
          },
          {
            id: 10720,
            parentId: 3596,
            areaName: '福鼎市',
            areaPath: '中国,福建省,宁德市,福鼎市',
            areaCode: '100003500090820000'
          }
        ]
      }
    ]
  },
  {
    id: 1447,
    parentId: 1,
    areaName: '江西省',
    areaPath: '中国,江西省',
    areaCode: '100003600000000000',
    children: [
      {
        id: 3597,
        parentId: 1447,
        areaName: '南昌市',
        areaPath: '中国,江西省,南昌市',
        areaCode: '100003600010000000',
        children: [
          {
            id: 10721,
            parentId: 3597,
            areaName: '东湖区',
            areaPath: '中国,江西省,南昌市,东湖区',
            areaCode: '100003600010020000'
          },
          {
            id: 10722,
            parentId: 3597,
            areaName: '西湖区',
            areaPath: '中国,江西省,南昌市,西湖区',
            areaCode: '100003600010030000'
          },
          {
            id: 10723,
            parentId: 3597,
            areaName: '青云谱区',
            areaPath: '中国,江西省,南昌市,青云谱区',
            areaCode: '100003600010040000'
          },
          {
            id: 10724,
            parentId: 3597,
            areaName: '湾里区',
            areaPath: '中国,江西省,南昌市,湾里区',
            areaCode: '100003600010050000'
          },
          {
            id: 10725,
            parentId: 3597,
            areaName: '青山湖区',
            areaPath: '中国,江西省,南昌市,青山湖区',
            areaCode: '100003600010110000'
          },
          {
            id: 10726,
            parentId: 3597,
            areaName: '新建区',
            areaPath: '中国,江西省,南昌市,新建区',
            areaCode: '100003600010120000'
          },
          {
            id: 10727,
            parentId: 3597,
            areaName: '南昌县',
            areaPath: '中国,江西省,南昌市,南昌县',
            areaCode: '100003600010210000'
          },
          {
            id: 10728,
            parentId: 3597,
            areaName: '安义县',
            areaPath: '中国,江西省,南昌市,安义县',
            areaCode: '100003600010230000'
          },
          {
            id: 10729,
            parentId: 3597,
            areaName: '进贤县',
            areaPath: '中国,江西省,南昌市,进贤县',
            areaCode: '100003600010240000'
          }
        ]
      },
      {
        id: 3598,
        parentId: 1447,
        areaName: '景德镇市',
        areaPath: '中国,江西省,景德镇市',
        areaCode: '100003600020000000',
        children: [
          {
            id: 10730,
            parentId: 3598,
            areaName: '昌江区',
            areaPath: '中国,江西省,景德镇市,昌江区',
            areaCode: '100003600020020000'
          },
          {
            id: 10731,
            parentId: 3598,
            areaName: '珠山区',
            areaPath: '中国,江西省,景德镇市,珠山区',
            areaCode: '100003600020030000'
          },
          {
            id: 10732,
            parentId: 3598,
            areaName: '浮梁县',
            areaPath: '中国,江西省,景德镇市,浮梁县',
            areaCode: '100003600020220000'
          },
          {
            id: 10733,
            parentId: 3598,
            areaName: '乐平市',
            areaPath: '中国,江西省,景德镇市,乐平市',
            areaCode: '100003600020810000'
          }
        ]
      },
      {
        id: 3599,
        parentId: 1447,
        areaName: '萍乡市',
        areaPath: '中国,江西省,萍乡市',
        areaCode: '100003600030000000',
        children: [
          {
            id: 10734,
            parentId: 3599,
            areaName: '安源区',
            areaPath: '中国,江西省,萍乡市,安源区',
            areaCode: '100003600030020000'
          },
          {
            id: 10735,
            parentId: 3599,
            areaName: '湘东区',
            areaPath: '中国,江西省,萍乡市,湘东区',
            areaCode: '100003600030130000'
          },
          {
            id: 10736,
            parentId: 3599,
            areaName: '莲花县',
            areaPath: '中国,江西省,萍乡市,莲花县',
            areaCode: '100003600030210000'
          },
          {
            id: 10737,
            parentId: 3599,
            areaName: '上栗县',
            areaPath: '中国,江西省,萍乡市,上栗县',
            areaCode: '100003600030220000'
          },
          {
            id: 10738,
            parentId: 3599,
            areaName: '芦溪县',
            areaPath: '中国,江西省,萍乡市,芦溪县',
            areaCode: '100003600030230000'
          }
        ]
      },
      {
        id: 3600,
        parentId: 1447,
        areaName: '九江市',
        areaPath: '中国,江西省,九江市',
        areaCode: '100003600040000000',
        children: [
          {
            id: 10739,
            parentId: 3600,
            areaName: '濂溪区',
            areaPath: '中国,江西省,九江市,濂溪区',
            areaCode: '100003600040020000'
          },
          {
            id: 10740,
            parentId: 3600,
            areaName: '浔阳区',
            areaPath: '中国,江西省,九江市,浔阳区',
            areaCode: '100003600040030000'
          },
          {
            id: 10741,
            parentId: 3600,
            areaName: '柴桑区',
            areaPath: '中国,江西省,九江市,柴桑区',
            areaCode: '100003600040040000'
          },
          {
            id: 10742,
            parentId: 3600,
            areaName: '武宁县',
            areaPath: '中国,江西省,九江市,武宁县',
            areaCode: '100003600040230000'
          },
          {
            id: 10743,
            parentId: 3600,
            areaName: '修水县',
            areaPath: '中国,江西省,九江市,修水县',
            areaCode: '100003600040240000'
          },
          {
            id: 10744,
            parentId: 3600,
            areaName: '永修县',
            areaPath: '中国,江西省,九江市,永修县',
            areaCode: '100003600040250000'
          },
          {
            id: 10745,
            parentId: 3600,
            areaName: '德安县',
            areaPath: '中国,江西省,九江市,德安县',
            areaCode: '100003600040260000'
          },
          {
            id: 10746,
            parentId: 3600,
            areaName: '都昌县',
            areaPath: '中国,江西省,九江市,都昌县',
            areaCode: '100003600040280000'
          },
          {
            id: 10747,
            parentId: 3600,
            areaName: '湖口县',
            areaPath: '中国,江西省,九江市,湖口县',
            areaCode: '100003600040290000'
          },
          {
            id: 10748,
            parentId: 3600,
            areaName: '彭泽县',
            areaPath: '中国,江西省,九江市,彭泽县',
            areaCode: '100003600040300000'
          },
          {
            id: 10749,
            parentId: 3600,
            areaName: '瑞昌市',
            areaPath: '中国,江西省,九江市,瑞昌市',
            areaCode: '100003600040810000'
          },
          {
            id: 10750,
            parentId: 3600,
            areaName: '共青城市',
            areaPath: '中国,江西省,九江市,共青城市',
            areaCode: '100003600040820000'
          },
          {
            id: 10751,
            parentId: 3600,
            areaName: '庐山市',
            areaPath: '中国,江西省,九江市,庐山市',
            areaCode: '100003600040830000'
          }
        ]
      },
      {
        id: 3601,
        parentId: 1447,
        areaName: '新余市',
        areaPath: '中国,江西省,新余市',
        areaCode: '100003600050000000',
        children: [
          {
            id: 10752,
            parentId: 3601,
            areaName: '渝水区',
            areaPath: '中国,江西省,新余市,渝水区',
            areaCode: '100003600050020000'
          },
          {
            id: 10753,
            parentId: 3601,
            areaName: '分宜县',
            areaPath: '中国,江西省,新余市,分宜县',
            areaCode: '100003600050210000'
          }
        ]
      },
      {
        id: 3602,
        parentId: 1447,
        areaName: '鹰潭市',
        areaPath: '中国,江西省,鹰潭市',
        areaCode: '100003600060000000',
        children: [
          {
            id: 10754,
            parentId: 3602,
            areaName: '月湖区',
            areaPath: '中国,江西省,鹰潭市,月湖区',
            areaCode: '100003600060020000'
          },
          {
            id: 10755,
            parentId: 3602,
            areaName: '余江县',
            areaPath: '中国,江西省,鹰潭市,余江县',
            areaCode: '100003600060220000'
          },
          {
            id: 10756,
            parentId: 3602,
            areaName: '贵溪市',
            areaPath: '中国,江西省,鹰潭市,贵溪市',
            areaCode: '100003600060810000'
          }
        ]
      },
      {
        id: 3603,
        parentId: 1447,
        areaName: '赣州市',
        areaPath: '中国,江西省,赣州市',
        areaCode: '100003600070000000',
        children: [
          {
            id: 10757,
            parentId: 3603,
            areaName: '章贡区',
            areaPath: '中国,江西省,赣州市,章贡区',
            areaCode: '100003600070020000'
          },
          {
            id: 10758,
            parentId: 3603,
            areaName: '南康区',
            areaPath: '中国,江西省,赣州市,南康区',
            areaCode: '100003600070030000'
          },
          {
            id: 10759,
            parentId: 3603,
            areaName: '赣县区',
            areaPath: '中国,江西省,赣州市,赣县区',
            areaCode: '100003600070040000'
          },
          {
            id: 10760,
            parentId: 3603,
            areaName: '信丰县',
            areaPath: '中国,江西省,赣州市,信丰县',
            areaCode: '100003600070220000'
          },
          {
            id: 10761,
            parentId: 3603,
            areaName: '大余县',
            areaPath: '中国,江西省,赣州市,大余县',
            areaCode: '100003600070230000'
          },
          {
            id: 10762,
            parentId: 3603,
            areaName: '上犹县',
            areaPath: '中国,江西省,赣州市,上犹县',
            areaCode: '100003600070240000'
          },
          {
            id: 10763,
            parentId: 3603,
            areaName: '崇义县',
            areaPath: '中国,江西省,赣州市,崇义县',
            areaCode: '100003600070250000'
          },
          {
            id: 10764,
            parentId: 3603,
            areaName: '安远县',
            areaPath: '中国,江西省,赣州市,安远县',
            areaCode: '100003600070260000'
          },
          {
            id: 10765,
            parentId: 3603,
            areaName: '龙南县',
            areaPath: '中国,江西省,赣州市,龙南县',
            areaCode: '100003600070270000'
          },
          {
            id: 10766,
            parentId: 3603,
            areaName: '定南县',
            areaPath: '中国,江西省,赣州市,定南县',
            areaCode: '100003600070280000'
          },
          {
            id: 10767,
            parentId: 3603,
            areaName: '全南县',
            areaPath: '中国,江西省,赣州市,全南县',
            areaCode: '100003600070290000'
          },
          {
            id: 10768,
            parentId: 3603,
            areaName: '宁都县',
            areaPath: '中国,江西省,赣州市,宁都县',
            areaCode: '100003600070300000'
          },
          {
            id: 10769,
            parentId: 3603,
            areaName: '于都县',
            areaPath: '中国,江西省,赣州市,于都县',
            areaCode: '100003600070310000'
          },
          {
            id: 10770,
            parentId: 3603,
            areaName: '兴国县',
            areaPath: '中国,江西省,赣州市,兴国县',
            areaCode: '100003600070320000'
          },
          {
            id: 10771,
            parentId: 3603,
            areaName: '会昌县',
            areaPath: '中国,江西省,赣州市,会昌县',
            areaCode: '100003600070330000'
          },
          {
            id: 10772,
            parentId: 3603,
            areaName: '寻乌县',
            areaPath: '中国,江西省,赣州市,寻乌县',
            areaCode: '100003600070340000'
          },
          {
            id: 10773,
            parentId: 3603,
            areaName: '石城县',
            areaPath: '中国,江西省,赣州市,石城县',
            areaCode: '100003600070350000'
          },
          {
            id: 10774,
            parentId: 3603,
            areaName: '瑞金市',
            areaPath: '中国,江西省,赣州市,瑞金市',
            areaCode: '100003600070810000'
          }
        ]
      },
      {
        id: 3604,
        parentId: 1447,
        areaName: '吉安市',
        areaPath: '中国,江西省,吉安市',
        areaCode: '100003600080000000',
        children: [
          {
            id: 10775,
            parentId: 3604,
            areaName: '吉州区',
            areaPath: '中国,江西省,吉安市,吉州区',
            areaCode: '100003600080020000'
          },
          {
            id: 10776,
            parentId: 3604,
            areaName: '青原区',
            areaPath: '中国,江西省,吉安市,青原区',
            areaCode: '100003600080030000'
          },
          {
            id: 10777,
            parentId: 3604,
            areaName: '吉安县',
            areaPath: '中国,江西省,吉安市,吉安县',
            areaCode: '100003600080210000'
          },
          {
            id: 10778,
            parentId: 3604,
            areaName: '吉水县',
            areaPath: '中国,江西省,吉安市,吉水县',
            areaCode: '100003600080220000'
          },
          {
            id: 10779,
            parentId: 3604,
            areaName: '峡江县',
            areaPath: '中国,江西省,吉安市,峡江县',
            areaCode: '100003600080230000'
          },
          {
            id: 10780,
            parentId: 3604,
            areaName: '新干县',
            areaPath: '中国,江西省,吉安市,新干县',
            areaCode: '100003600080240000'
          },
          {
            id: 10781,
            parentId: 3604,
            areaName: '永丰县',
            areaPath: '中国,江西省,吉安市,永丰县',
            areaCode: '100003600080250000'
          },
          {
            id: 10782,
            parentId: 3604,
            areaName: '泰和县',
            areaPath: '中国,江西省,吉安市,泰和县',
            areaCode: '100003600080260000'
          },
          {
            id: 10783,
            parentId: 3604,
            areaName: '遂川县',
            areaPath: '中国,江西省,吉安市,遂川县',
            areaCode: '100003600080270000'
          },
          {
            id: 10784,
            parentId: 3604,
            areaName: '万安县',
            areaPath: '中国,江西省,吉安市,万安县',
            areaCode: '100003600080280000'
          },
          {
            id: 10785,
            parentId: 3604,
            areaName: '安福县',
            areaPath: '中国,江西省,吉安市,安福县',
            areaCode: '100003600080290000'
          },
          {
            id: 10786,
            parentId: 3604,
            areaName: '永新县',
            areaPath: '中国,江西省,吉安市,永新县',
            areaCode: '100003600080300000'
          },
          {
            id: 10787,
            parentId: 3604,
            areaName: '井冈山市',
            areaPath: '中国,江西省,吉安市,井冈山市',
            areaCode: '100003600080810000'
          }
        ]
      },
      {
        id: 3605,
        parentId: 1447,
        areaName: '宜春市',
        areaPath: '中国,江西省,宜春市',
        areaCode: '100003600090000000',
        children: [
          {
            id: 10788,
            parentId: 3605,
            areaName: '袁州区',
            areaPath: '中国,江西省,宜春市,袁州区',
            areaCode: '100003600090020000'
          },
          {
            id: 10789,
            parentId: 3605,
            areaName: '奉新县',
            areaPath: '中国,江西省,宜春市,奉新县',
            areaCode: '100003600090210000'
          },
          {
            id: 10790,
            parentId: 3605,
            areaName: '万载县',
            areaPath: '中国,江西省,宜春市,万载县',
            areaCode: '100003600090220000'
          },
          {
            id: 10791,
            parentId: 3605,
            areaName: '上高县',
            areaPath: '中国,江西省,宜春市,上高县',
            areaCode: '100003600090230000'
          },
          {
            id: 10792,
            parentId: 3605,
            areaName: '宜丰县',
            areaPath: '中国,江西省,宜春市,宜丰县',
            areaCode: '100003600090240000'
          },
          {
            id: 10793,
            parentId: 3605,
            areaName: '靖安县',
            areaPath: '中国,江西省,宜春市,靖安县',
            areaCode: '100003600090250000'
          },
          {
            id: 10794,
            parentId: 3605,
            areaName: '铜鼓县',
            areaPath: '中国,江西省,宜春市,铜鼓县',
            areaCode: '100003600090260000'
          },
          {
            id: 10795,
            parentId: 3605,
            areaName: '丰城市',
            areaPath: '中国,江西省,宜春市,丰城市',
            areaCode: '100003600090810000'
          },
          {
            id: 10796,
            parentId: 3605,
            areaName: '樟树市',
            areaPath: '中国,江西省,宜春市,樟树市',
            areaCode: '100003600090820000'
          },
          {
            id: 10797,
            parentId: 3605,
            areaName: '高安市',
            areaPath: '中国,江西省,宜春市,高安市',
            areaCode: '100003600090830000'
          }
        ]
      },
      {
        id: 3606,
        parentId: 1447,
        areaName: '抚州市',
        areaPath: '中国,江西省,抚州市',
        areaCode: '100003600100000000',
        children: [
          {
            id: 10798,
            parentId: 3606,
            areaName: '临川区',
            areaPath: '中国,江西省,抚州市,临川区',
            areaCode: '100003600100020000'
          },
          {
            id: 10799,
            parentId: 3606,
            areaName: '东乡区',
            areaPath: '中国,江西省,抚州市,东乡区',
            areaCode: '100003600100030000'
          },
          {
            id: 10800,
            parentId: 3606,
            areaName: '南城县',
            areaPath: '中国,江西省,抚州市,南城县',
            areaCode: '100003600100210000'
          },
          {
            id: 10801,
            parentId: 3606,
            areaName: '黎川县',
            areaPath: '中国,江西省,抚州市,黎川县',
            areaCode: '100003600100220000'
          },
          {
            id: 10802,
            parentId: 3606,
            areaName: '南丰县',
            areaPath: '中国,江西省,抚州市,南丰县',
            areaCode: '100003600100230000'
          },
          {
            id: 10803,
            parentId: 3606,
            areaName: '崇仁县',
            areaPath: '中国,江西省,抚州市,崇仁县',
            areaCode: '100003600100240000'
          },
          {
            id: 10804,
            parentId: 3606,
            areaName: '乐安县',
            areaPath: '中国,江西省,抚州市,乐安县',
            areaCode: '100003600100250000'
          },
          {
            id: 10805,
            parentId: 3606,
            areaName: '宜黄县',
            areaPath: '中国,江西省,抚州市,宜黄县',
            areaCode: '100003600100260000'
          },
          {
            id: 10806,
            parentId: 3606,
            areaName: '金溪县',
            areaPath: '中国,江西省,抚州市,金溪县',
            areaCode: '100003600100270000'
          },
          {
            id: 10807,
            parentId: 3606,
            areaName: '资溪县',
            areaPath: '中国,江西省,抚州市,资溪县',
            areaCode: '100003600100280000'
          },
          {
            id: 10808,
            parentId: 3606,
            areaName: '广昌县',
            areaPath: '中国,江西省,抚州市,广昌县',
            areaCode: '100003600100300000'
          }
        ]
      },
      {
        id: 3607,
        parentId: 1447,
        areaName: '上饶市',
        areaPath: '中国,江西省,上饶市',
        areaCode: '100003600110000000',
        children: [
          {
            id: 10809,
            parentId: 3607,
            areaName: '信州区',
            areaPath: '中国,江西省,上饶市,信州区',
            areaCode: '100003600110020000'
          },
          {
            id: 10810,
            parentId: 3607,
            areaName: '广丰区',
            areaPath: '中国,江西省,上饶市,广丰区',
            areaCode: '100003600110030000'
          },
          {
            id: 10811,
            parentId: 3607,
            areaName: '上饶县',
            areaPath: '中国,江西省,上饶市,上饶县',
            areaCode: '100003600110210000'
          },
          {
            id: 10812,
            parentId: 3607,
            areaName: '玉山县',
            areaPath: '中国,江西省,上饶市,玉山县',
            areaCode: '100003600110230000'
          },
          {
            id: 10813,
            parentId: 3607,
            areaName: '铅山县',
            areaPath: '中国,江西省,上饶市,铅山县',
            areaCode: '100003600110240000'
          },
          {
            id: 10814,
            parentId: 3607,
            areaName: '横峰县',
            areaPath: '中国,江西省,上饶市,横峰县',
            areaCode: '100003600110250000'
          },
          {
            id: 10815,
            parentId: 3607,
            areaName: '弋阳县',
            areaPath: '中国,江西省,上饶市,弋阳县',
            areaCode: '100003600110260000'
          },
          {
            id: 10816,
            parentId: 3607,
            areaName: '余干县',
            areaPath: '中国,江西省,上饶市,余干县',
            areaCode: '100003600110270000'
          },
          {
            id: 10817,
            parentId: 3607,
            areaName: '鄱阳县',
            areaPath: '中国,江西省,上饶市,鄱阳县',
            areaCode: '100003600110280000'
          },
          {
            id: 10818,
            parentId: 3607,
            areaName: '万年县',
            areaPath: '中国,江西省,上饶市,万年县',
            areaCode: '100003600110290000'
          },
          {
            id: 10819,
            parentId: 3607,
            areaName: '婺源县',
            areaPath: '中国,江西省,上饶市,婺源县',
            areaCode: '100003600110300000'
          },
          {
            id: 10820,
            parentId: 3607,
            areaName: '德兴市',
            areaPath: '中国,江西省,上饶市,德兴市',
            areaCode: '100003600110810000'
          }
        ]
      }
    ]
  },
  {
    id: 1448,
    parentId: 1,
    areaName: '山东省',
    areaPath: '中国,山东省',
    areaCode: '100003700000000000',
    children: [
      {
        id: 3608,
        parentId: 1448,
        areaName: '济南市',
        areaPath: '中国,山东省,济南市',
        areaCode: '100003700010000000',
        children: [
          {
            id: 10821,
            parentId: 3608,
            areaName: '历下区',
            areaPath: '中国,山东省,济南市,历下区',
            areaCode: '100003700010020000'
          },
          {
            id: 10822,
            parentId: 3608,
            areaName: '市中区',
            areaPath: '中国,山东省,济南市,市中区',
            areaCode: '100003700010030000'
          },
          {
            id: 10823,
            parentId: 3608,
            areaName: '槐荫区',
            areaPath: '中国,山东省,济南市,槐荫区',
            areaCode: '100003700010040000'
          },
          {
            id: 10824,
            parentId: 3608,
            areaName: '天桥区',
            areaPath: '中国,山东省,济南市,天桥区',
            areaCode: '100003700010050000'
          },
          {
            id: 10825,
            parentId: 3608,
            areaName: '历城区',
            areaPath: '中国,山东省,济南市,历城区',
            areaCode: '100003700010120000'
          },
          {
            id: 10826,
            parentId: 3608,
            areaName: '长清区',
            areaPath: '中国,山东省,济南市,长清区',
            areaCode: '100003700010130000'
          },
          {
            id: 10827,
            parentId: 3608,
            areaName: '章丘区',
            areaPath: '中国,山东省,济南市,章丘区',
            areaCode: '100003700010140000'
          },
          {
            id: 10828,
            parentId: 3608,
            areaName: '平阴县',
            areaPath: '中国,山东省,济南市,平阴县',
            areaCode: '100003700010240000'
          },
          {
            id: 10829,
            parentId: 3608,
            areaName: '济阳县',
            areaPath: '中国,山东省,济南市,济阳县',
            areaCode: '100003700010250000'
          },
          {
            id: 10830,
            parentId: 3608,
            areaName: '商河县',
            areaPath: '中国,山东省,济南市,商河县',
            areaCode: '100003700010260000'
          }
        ]
      },
      {
        id: 3609,
        parentId: 1448,
        areaName: '青岛市',
        areaPath: '中国,山东省,青岛市',
        areaCode: '100003700020000000',
        children: [
          {
            id: 10831,
            parentId: 3609,
            areaName: '市南区',
            areaPath: '中国,山东省,青岛市,市南区',
            areaCode: '100003700020020000'
          },
          {
            id: 10832,
            parentId: 3609,
            areaName: '市北区',
            areaPath: '中国,山东省,青岛市,市北区',
            areaCode: '100003700020030000'
          },
          {
            id: 10833,
            parentId: 3609,
            areaName: '黄岛区',
            areaPath: '中国,山东省,青岛市,黄岛区',
            areaCode: '100003700020110000'
          },
          {
            id: 10834,
            parentId: 3609,
            areaName: '崂山区',
            areaPath: '中国,山东省,青岛市,崂山区',
            areaCode: '100003700020120000'
          },
          {
            id: 10835,
            parentId: 3609,
            areaName: '李沧区',
            areaPath: '中国,山东省,青岛市,李沧区',
            areaCode: '100003700020130000'
          },
          {
            id: 10836,
            parentId: 3609,
            areaName: '城阳区',
            areaPath: '中国,山东省,青岛市,城阳区',
            areaCode: '100003700020140000'
          },
          {
            id: 10837,
            parentId: 3609,
            areaName: '即墨区',
            areaPath: '中国,山东省,青岛市,即墨区',
            areaCode: '100003700020150000'
          },
          {
            id: 10838,
            parentId: 3609,
            areaName: '胶州市',
            areaPath: '中国,山东省,青岛市,胶州市',
            areaCode: '100003700020810000'
          },
          {
            id: 10839,
            parentId: 3609,
            areaName: '平度市',
            areaPath: '中国,山东省,青岛市,平度市',
            areaCode: '100003700020830000'
          },
          {
            id: 10840,
            parentId: 3609,
            areaName: '莱西市',
            areaPath: '中国,山东省,青岛市,莱西市',
            areaCode: '100003700020850000'
          }
        ]
      },
      {
        id: 3610,
        parentId: 1448,
        areaName: '淄博市',
        areaPath: '中国,山东省,淄博市',
        areaCode: '100003700030000000',
        children: [
          {
            id: 10841,
            parentId: 3610,
            areaName: '淄川区',
            areaPath: '中国,山东省,淄博市,淄川区',
            areaCode: '100003700030020000'
          },
          {
            id: 10842,
            parentId: 3610,
            areaName: '张店区',
            areaPath: '中国,山东省,淄博市,张店区',
            areaCode: '100003700030030000'
          },
          {
            id: 10843,
            parentId: 3610,
            areaName: '博山区',
            areaPath: '中国,山东省,淄博市,博山区',
            areaCode: '100003700030040000'
          },
          {
            id: 10844,
            parentId: 3610,
            areaName: '临淄区',
            areaPath: '中国,山东省,淄博市,临淄区',
            areaCode: '100003700030050000'
          },
          {
            id: 10845,
            parentId: 3610,
            areaName: '周村区',
            areaPath: '中国,山东省,淄博市,周村区',
            areaCode: '100003700030060000'
          },
          {
            id: 10846,
            parentId: 3610,
            areaName: '桓台县',
            areaPath: '中国,山东省,淄博市,桓台县',
            areaCode: '100003700030210000'
          },
          {
            id: 10847,
            parentId: 3610,
            areaName: '高青县',
            areaPath: '中国,山东省,淄博市,高青县',
            areaCode: '100003700030220000'
          },
          {
            id: 10848,
            parentId: 3610,
            areaName: '沂源县',
            areaPath: '中国,山东省,淄博市,沂源县',
            areaCode: '100003700030230000'
          }
        ]
      },
      {
        id: 3611,
        parentId: 1448,
        areaName: '枣庄市',
        areaPath: '中国,山东省,枣庄市',
        areaCode: '100003700040000000',
        children: [
          {
            id: 10849,
            parentId: 3611,
            areaName: '市中区',
            areaPath: '中国,山东省,枣庄市,市中区',
            areaCode: '100003700040020000'
          },
          {
            id: 10850,
            parentId: 3611,
            areaName: '薛城区',
            areaPath: '中国,山东省,枣庄市,薛城区',
            areaCode: '100003700040030000'
          },
          {
            id: 10851,
            parentId: 3611,
            areaName: '峄城区',
            areaPath: '中国,山东省,枣庄市,峄城区',
            areaCode: '100003700040040000'
          },
          {
            id: 10852,
            parentId: 3611,
            areaName: '台儿庄区',
            areaPath: '中国,山东省,枣庄市,台儿庄区',
            areaCode: '100003700040050000'
          },
          {
            id: 10853,
            parentId: 3611,
            areaName: '山亭区',
            areaPath: '中国,山东省,枣庄市,山亭区',
            areaCode: '100003700040060000'
          },
          {
            id: 10854,
            parentId: 3611,
            areaName: '滕州市',
            areaPath: '中国,山东省,枣庄市,滕州市',
            areaCode: '100003700040810000'
          }
        ]
      },
      {
        id: 3612,
        parentId: 1448,
        areaName: '东营市',
        areaPath: '中国,山东省,东营市',
        areaCode: '100003700050000000',
        children: [
          {
            id: 10855,
            parentId: 3612,
            areaName: '东营区',
            areaPath: '中国,山东省,东营市,东营区',
            areaCode: '100003700050020000'
          },
          {
            id: 10856,
            parentId: 3612,
            areaName: '河口区',
            areaPath: '中国,山东省,东营市,河口区',
            areaCode: '100003700050030000'
          },
          {
            id: 10857,
            parentId: 3612,
            areaName: '垦利区',
            areaPath: '中国,山东省,东营市,垦利区',
            areaCode: '100003700050050000'
          },
          {
            id: 10858,
            parentId: 3612,
            areaName: '利津县',
            areaPath: '中国,山东省,东营市,利津县',
            areaCode: '100003700050220000'
          },
          {
            id: 10859,
            parentId: 3612,
            areaName: '广饶县',
            areaPath: '中国,山东省,东营市,广饶县',
            areaCode: '100003700050230000'
          }
        ]
      },
      {
        id: 3613,
        parentId: 1448,
        areaName: '烟台市',
        areaPath: '中国,山东省,烟台市',
        areaCode: '100003700060000000',
        children: [
          {
            id: 10860,
            parentId: 3613,
            areaName: '芝罘区',
            areaPath: '中国,山东省,烟台市,芝罘区',
            areaCode: '100003700060020000'
          },
          {
            id: 10861,
            parentId: 3613,
            areaName: '福山区',
            areaPath: '中国,山东省,烟台市,福山区',
            areaCode: '100003700060110000'
          },
          {
            id: 10862,
            parentId: 3613,
            areaName: '牟平区',
            areaPath: '中国,山东省,烟台市,牟平区',
            areaCode: '100003700060120000'
          },
          {
            id: 10863,
            parentId: 3613,
            areaName: '莱山区',
            areaPath: '中国,山东省,烟台市,莱山区',
            areaCode: '100003700060130000'
          },
          {
            id: 10864,
            parentId: 3613,
            areaName: '蓬莱区',
            areaPath: '中国,山东省,烟台市,蓬莱区',
            areaCode: '100003700060840000'
          },
          {
            id: 10865,
            parentId: 3613,
            areaName: '龙口市',
            areaPath: '中国,山东省,烟台市,龙口市',
            areaCode: '100003700060810000'
          },
          {
            id: 10866,
            parentId: 3613,
            areaName: '莱阳市',
            areaPath: '中国,山东省,烟台市,莱阳市',
            areaCode: '100003700060820000'
          },
          {
            id: 10867,
            parentId: 3613,
            areaName: '莱州市',
            areaPath: '中国,山东省,烟台市,莱州市',
            areaCode: '100003700060830000'
          },
          {
            id: 10868,
            parentId: 3613,
            areaName: '招远市',
            areaPath: '中国,山东省,烟台市,招远市',
            areaCode: '100003700060850000'
          },
          {
            id: 10869,
            parentId: 3613,
            areaName: '栖霞市',
            areaPath: '中国,山东省,烟台市,栖霞市',
            areaCode: '100003700060860000'
          },
          {
            id: 10870,
            parentId: 3613,
            areaName: '海阳市',
            areaPath: '中国,山东省,烟台市,海阳市',
            areaCode: '100003700060870000'
          }
        ]
      },
      {
        id: 3614,
        parentId: 1448,
        areaName: '潍坊市',
        areaPath: '中国,山东省,潍坊市',
        areaCode: '100003700070000000',
        children: [
          {
            id: 10871,
            parentId: 3614,
            areaName: '潍城区',
            areaPath: '中国,山东省,潍坊市,潍城区',
            areaCode: '100003700070020000'
          },
          {
            id: 10872,
            parentId: 3614,
            areaName: '寒亭区',
            areaPath: '中国,山东省,潍坊市,寒亭区',
            areaCode: '100003700070030000'
          },
          {
            id: 10873,
            parentId: 3614,
            areaName: '坊子区',
            areaPath: '中国,山东省,潍坊市,坊子区',
            areaCode: '100003700070040000'
          },
          {
            id: 10874,
            parentId: 3614,
            areaName: '奎文区',
            areaPath: '中国,山东省,潍坊市,奎文区',
            areaCode: '100003700070050000'
          },
          {
            id: 10875,
            parentId: 3614,
            areaName: '临朐县',
            areaPath: '中国,山东省,潍坊市,临朐县',
            areaCode: '100003700070240000'
          },
          {
            id: 10876,
            parentId: 3614,
            areaName: '昌乐县',
            areaPath: '中国,山东省,潍坊市,昌乐县',
            areaCode: '100003700070250000'
          },
          {
            id: 10877,
            parentId: 3614,
            areaName: '青州市',
            areaPath: '中国,山东省,潍坊市,青州市',
            areaCode: '100003700070810000'
          },
          {
            id: 10878,
            parentId: 3614,
            areaName: '诸城市',
            areaPath: '中国,山东省,潍坊市,诸城市',
            areaCode: '100003700070820000'
          },
          {
            id: 10879,
            parentId: 3614,
            areaName: '寿光市',
            areaPath: '中国,山东省,潍坊市,寿光市',
            areaCode: '100003700070830000'
          },
          {
            id: 10880,
            parentId: 3614,
            areaName: '安丘市',
            areaPath: '中国,山东省,潍坊市,安丘市',
            areaCode: '100003700070840000'
          },
          {
            id: 10881,
            parentId: 3614,
            areaName: '高密市',
            areaPath: '中国,山东省,潍坊市,高密市',
            areaCode: '100003700070850000'
          },
          {
            id: 10882,
            parentId: 3614,
            areaName: '昌邑市',
            areaPath: '中国,山东省,潍坊市,昌邑市',
            areaCode: '100003700070860000'
          }
        ]
      },
      {
        id: 3615,
        parentId: 1448,
        areaName: '济宁市',
        areaPath: '中国,山东省,济宁市',
        areaCode: '100003700080000000',
        children: [
          {
            id: 10883,
            parentId: 3615,
            areaName: '任城区',
            areaPath: '中国,山东省,济宁市,任城区',
            areaCode: '100003700080110000'
          },
          {
            id: 10884,
            parentId: 3615,
            areaName: '兖州区',
            areaPath: '中国,山东省,济宁市,兖州区',
            areaCode: '100003700080120000'
          },
          {
            id: 10885,
            parentId: 3615,
            areaName: '微山县',
            areaPath: '中国,山东省,济宁市,微山县',
            areaCode: '100003700080260000'
          },
          {
            id: 10886,
            parentId: 3615,
            areaName: '鱼台县',
            areaPath: '中国,山东省,济宁市,鱼台县',
            areaCode: '100003700080270000'
          },
          {
            id: 10887,
            parentId: 3615,
            areaName: '金乡县',
            areaPath: '中国,山东省,济宁市,金乡县',
            areaCode: '100003700080280000'
          },
          {
            id: 10888,
            parentId: 3615,
            areaName: '嘉祥县',
            areaPath: '中国,山东省,济宁市,嘉祥县',
            areaCode: '100003700080290000'
          },
          {
            id: 10889,
            parentId: 3615,
            areaName: '汶上县',
            areaPath: '中国,山东省,济宁市,汶上县',
            areaCode: '100003700080300000'
          },
          {
            id: 10890,
            parentId: 3615,
            areaName: '泗水县',
            areaPath: '中国,山东省,济宁市,泗水县',
            areaCode: '100003700080310000'
          },
          {
            id: 10891,
            parentId: 3615,
            areaName: '梁山县',
            areaPath: '中国,山东省,济宁市,梁山县',
            areaCode: '100003700080320000'
          },
          {
            id: 10892,
            parentId: 3615,
            areaName: '曲阜市',
            areaPath: '中国,山东省,济宁市,曲阜市',
            areaCode: '100003700080810000'
          },
          {
            id: 10893,
            parentId: 3615,
            areaName: '邹城市',
            areaPath: '中国,山东省,济宁市,邹城市',
            areaCode: '100003700080830000'
          }
        ]
      },
      {
        id: 3616,
        parentId: 1448,
        areaName: '泰安市',
        areaPath: '中国,山东省,泰安市',
        areaCode: '100003700090000000',
        children: [
          {
            id: 10894,
            parentId: 3616,
            areaName: '泰山区',
            areaPath: '中国,山东省,泰安市,泰山区',
            areaCode: '100003700090020000'
          },
          {
            id: 10895,
            parentId: 3616,
            areaName: '岱岳区',
            areaPath: '中国,山东省,泰安市,岱岳区',
            areaCode: '100003700090110000'
          },
          {
            id: 10896,
            parentId: 3616,
            areaName: '宁阳县',
            areaPath: '中国,山东省,泰安市,宁阳县',
            areaCode: '100003700090210000'
          },
          {
            id: 10897,
            parentId: 3616,
            areaName: '东平县',
            areaPath: '中国,山东省,泰安市,东平县',
            areaCode: '100003700090230000'
          },
          {
            id: 10898,
            parentId: 3616,
            areaName: '新泰市',
            areaPath: '中国,山东省,泰安市,新泰市',
            areaCode: '100003700090820000'
          },
          {
            id: 10899,
            parentId: 3616,
            areaName: '肥城市',
            areaPath: '中国,山东省,泰安市,肥城市',
            areaCode: '100003700090830000'
          }
        ]
      },
      {
        id: 3617,
        parentId: 1448,
        areaName: '威海市',
        areaPath: '中国,山东省,威海市',
        areaCode: '100003700100000000',
        children: [
          {
            id: 10900,
            parentId: 3617,
            areaName: '环翠区',
            areaPath: '中国,山东省,威海市,环翠区',
            areaCode: '100003700100020000'
          },
          {
            id: 10901,
            parentId: 3617,
            areaName: '文登区',
            areaPath: '中国,山东省,威海市,文登区',
            areaCode: '100003700100030000'
          },
          {
            id: 10902,
            parentId: 3617,
            areaName: '荣成市',
            areaPath: '中国,山东省,威海市,荣成市',
            areaCode: '100003700100820000'
          },
          {
            id: 10903,
            parentId: 3617,
            areaName: '乳山市',
            areaPath: '中国,山东省,威海市,乳山市',
            areaCode: '100003700100830000'
          }
        ]
      },
      {
        id: 3618,
        parentId: 1448,
        areaName: '日照市',
        areaPath: '中国,山东省,日照市',
        areaCode: '100003700110000000',
        children: [
          {
            id: 10904,
            parentId: 3618,
            areaName: '东港区',
            areaPath: '中国,山东省,日照市,东港区',
            areaCode: '100003700110020000'
          },
          {
            id: 10905,
            parentId: 3618,
            areaName: '岚山区',
            areaPath: '中国,山东省,日照市,岚山区',
            areaCode: '100003700110030000'
          },
          {
            id: 10906,
            parentId: 3618,
            areaName: '五莲县',
            areaPath: '中国,山东省,日照市,五莲县',
            areaCode: '100003700110210000'
          },
          {
            id: 10907,
            parentId: 3618,
            areaName: '莒县',
            areaPath: '中国,山东省,日照市,莒县',
            areaCode: '100003700110220000'
          }
        ]
      },
      {
        id: 3619,
        parentId: 1448,
        areaName: '莱芜市',
        areaPath: '中国,山东省,莱芜市',
        areaCode: '100003700120000000',
        children: [
          {
            id: 10908,
            parentId: 3619,
            areaName: '莱城区',
            areaPath: '中国,山东省,莱芜市,莱城区',
            areaCode: '100003700120020000'
          },
          {
            id: 10909,
            parentId: 3619,
            areaName: '钢城区',
            areaPath: '中国,山东省,莱芜市,钢城区',
            areaCode: '100003700120030000'
          }
        ]
      },
      {
        id: 3620,
        parentId: 1448,
        areaName: '临沂市',
        areaPath: '中国,山东省,临沂市',
        areaCode: '100003700130000000',
        children: [
          {
            id: 10910,
            parentId: 3620,
            areaName: '兰山区',
            areaPath: '中国,山东省,临沂市,兰山区',
            areaCode: '100003700130020000'
          },
          {
            id: 10911,
            parentId: 3620,
            areaName: '罗庄区',
            areaPath: '中国,山东省,临沂市,罗庄区',
            areaCode: '100003700130110000'
          },
          {
            id: 10912,
            parentId: 3620,
            areaName: '河东区',
            areaPath: '中国,山东省,临沂市,河东区',
            areaCode: '100003700130120000'
          },
          {
            id: 10913,
            parentId: 3620,
            areaName: '沂南县',
            areaPath: '中国,山东省,临沂市,沂南县',
            areaCode: '100003700130210000'
          },
          {
            id: 10914,
            parentId: 3620,
            areaName: '郯城县',
            areaPath: '中国,山东省,临沂市,郯城县',
            areaCode: '100003700130220000'
          },
          {
            id: 10915,
            parentId: 3620,
            areaName: '沂水县',
            areaPath: '中国,山东省,临沂市,沂水县',
            areaCode: '100003700130230000'
          },
          {
            id: 10916,
            parentId: 3620,
            areaName: '兰陵县',
            areaPath: '中国,山东省,临沂市,兰陵县',
            areaCode: '100003700130240000'
          },
          {
            id: 10917,
            parentId: 3620,
            areaName: '费县',
            areaPath: '中国,山东省,临沂市,费县',
            areaCode: '100003700130250000'
          },
          {
            id: 10918,
            parentId: 3620,
            areaName: '平邑县',
            areaPath: '中国,山东省,临沂市,平邑县',
            areaCode: '100003700130260000'
          },
          {
            id: 10919,
            parentId: 3620,
            areaName: '莒南县',
            areaPath: '中国,山东省,临沂市,莒南县',
            areaCode: '100003700130270000'
          },
          {
            id: 10920,
            parentId: 3620,
            areaName: '蒙阴县',
            areaPath: '中国,山东省,临沂市,蒙阴县',
            areaCode: '100003700130280000'
          },
          {
            id: 10921,
            parentId: 3620,
            areaName: '临沭县',
            areaPath: '中国,山东省,临沂市,临沭县',
            areaCode: '100003700130290000'
          }
        ]
      },
      {
        id: 3621,
        parentId: 1448,
        areaName: '德州市',
        areaPath: '中国,山东省,德州市',
        areaCode: '100003700140000000',
        children: [
          {
            id: 10922,
            parentId: 3621,
            areaName: '德城区',
            areaPath: '中国,山东省,德州市,德城区',
            areaCode: '100003700140020000'
          },
          {
            id: 10923,
            parentId: 3621,
            areaName: '陵城区',
            areaPath: '中国,山东省,德州市,陵城区',
            areaCode: '100003700140030000'
          },
          {
            id: 10924,
            parentId: 3621,
            areaName: '宁津县',
            areaPath: '中国,山东省,德州市,宁津县',
            areaCode: '100003700140220000'
          },
          {
            id: 10925,
            parentId: 3621,
            areaName: '庆云县',
            areaPath: '中国,山东省,德州市,庆云县',
            areaCode: '100003700140230000'
          },
          {
            id: 10926,
            parentId: 3621,
            areaName: '临邑县',
            areaPath: '中国,山东省,德州市,临邑县',
            areaCode: '100003700140240000'
          },
          {
            id: 10927,
            parentId: 3621,
            areaName: '齐河县',
            areaPath: '中国,山东省,德州市,齐河县',
            areaCode: '100003700140250000'
          },
          {
            id: 10928,
            parentId: 3621,
            areaName: '平原县',
            areaPath: '中国,山东省,德州市,平原县',
            areaCode: '100003700140260000'
          },
          {
            id: 10929,
            parentId: 3621,
            areaName: '夏津县',
            areaPath: '中国,山东省,德州市,夏津县',
            areaCode: '100003700140270000'
          },
          {
            id: 10930,
            parentId: 3621,
            areaName: '武城县',
            areaPath: '中国,山东省,德州市,武城县',
            areaCode: '100003700140280000'
          },
          {
            id: 10931,
            parentId: 3621,
            areaName: '乐陵市',
            areaPath: '中国,山东省,德州市,乐陵市',
            areaCode: '100003700140810000'
          },
          {
            id: 10932,
            parentId: 3621,
            areaName: '禹城市',
            areaPath: '中国,山东省,德州市,禹城市',
            areaCode: '100003700140820000'
          }
        ]
      },
      {
        id: 3622,
        parentId: 1448,
        areaName: '聊城市',
        areaPath: '中国,山东省,聊城市',
        areaCode: '100003700150000000',
        children: [
          {
            id: 10933,
            parentId: 3622,
            areaName: '东昌府区',
            areaPath: '中国,山东省,聊城市,东昌府区',
            areaCode: '100003700150020000'
          },
          {
            id: 10934,
            parentId: 3622,
            areaName: '阳谷县',
            areaPath: '中国,山东省,聊城市,阳谷县',
            areaCode: '100003700150210000'
          },
          {
            id: 10935,
            parentId: 3622,
            areaName: '莘县',
            areaPath: '中国,山东省,聊城市,莘县',
            areaCode: '100003700150220000'
          },
          {
            id: 10936,
            parentId: 3622,
            areaName: '茌平县',
            areaPath: '中国,山东省,聊城市,茌平县',
            areaCode: '100003700150230000'
          },
          {
            id: 10937,
            parentId: 3622,
            areaName: '东阿县',
            areaPath: '中国,山东省,聊城市,东阿县',
            areaCode: '100003700150240000'
          },
          {
            id: 10938,
            parentId: 3622,
            areaName: '冠县',
            areaPath: '中国,山东省,聊城市,冠县',
            areaCode: '100003700150250000'
          },
          {
            id: 10939,
            parentId: 3622,
            areaName: '高唐县',
            areaPath: '中国,山东省,聊城市,高唐县',
            areaCode: '100003700150260000'
          },
          {
            id: 10940,
            parentId: 3622,
            areaName: '临清市',
            areaPath: '中国,山东省,聊城市,临清市',
            areaCode: '100003700150810000'
          }
        ]
      },
      {
        id: 3623,
        parentId: 1448,
        areaName: '滨州市',
        areaPath: '中国,山东省,滨州市',
        areaCode: '100003700160000000',
        children: [
          {
            id: 10941,
            parentId: 3623,
            areaName: '滨城区',
            areaPath: '中国,山东省,滨州市,滨城区',
            areaCode: '100003700160020000'
          },
          {
            id: 10942,
            parentId: 3623,
            areaName: '沾化区',
            areaPath: '中国,山东省,滨州市,沾化区',
            areaCode: '100003700160030000'
          },
          {
            id: 10943,
            parentId: 3623,
            areaName: '惠民县',
            areaPath: '中国,山东省,滨州市,惠民县',
            areaCode: '100003700160210000'
          },
          {
            id: 10944,
            parentId: 3623,
            areaName: '阳信县',
            areaPath: '中国,山东省,滨州市,阳信县',
            areaCode: '100003700160220000'
          },
          {
            id: 10945,
            parentId: 3623,
            areaName: '无棣县',
            areaPath: '中国,山东省,滨州市,无棣县',
            areaCode: '100003700160230000'
          },
          {
            id: 10946,
            parentId: 3623,
            areaName: '博兴县',
            areaPath: '中国,山东省,滨州市,博兴县',
            areaCode: '100003700160250000'
          },
          {
            id: 10947,
            parentId: 3623,
            areaName: '邹平县',
            areaPath: '中国,山东省,滨州市,邹平县',
            areaCode: '100003700160260000'
          }
        ]
      },
      {
        id: 3624,
        parentId: 1448,
        areaName: '菏泽市',
        areaPath: '中国,山东省,菏泽市',
        areaCode: '100003700170000000',
        children: [
          {
            id: 10948,
            parentId: 3624,
            areaName: '牡丹区',
            areaPath: '中国,山东省,菏泽市,牡丹区',
            areaCode: '100003700170020000'
          },
          {
            id: 10949,
            parentId: 3624,
            areaName: '定陶区',
            areaPath: '中国,山东省,菏泽市,定陶区',
            areaCode: '100003700170030000'
          },
          {
            id: 10950,
            parentId: 3624,
            areaName: '曹县',
            areaPath: '中国,山东省,菏泽市,曹县',
            areaCode: '100003700170210000'
          },
          {
            id: 10951,
            parentId: 3624,
            areaName: '单县',
            areaPath: '中国,山东省,菏泽市,单县',
            areaCode: '100003700170220000'
          },
          {
            id: 10952,
            parentId: 3624,
            areaName: '成武县',
            areaPath: '中国,山东省,菏泽市,成武县',
            areaCode: '100003700170230000'
          },
          {
            id: 10953,
            parentId: 3624,
            areaName: '巨野县',
            areaPath: '中国,山东省,菏泽市,巨野县',
            areaCode: '100003700170240000'
          },
          {
            id: 10954,
            parentId: 3624,
            areaName: '郓城县',
            areaPath: '中国,山东省,菏泽市,郓城县',
            areaCode: '100003700170250000'
          },
          {
            id: 10955,
            parentId: 3624,
            areaName: '鄄城县',
            areaPath: '中国,山东省,菏泽市,鄄城县',
            areaCode: '100003700170260000'
          },
          {
            id: 10956,
            parentId: 3624,
            areaName: '东明县',
            areaPath: '中国,山东省,菏泽市,东明县',
            areaCode: '100003700170280000'
          }
        ]
      }
    ]
  },
  {
    id: 1449,
    parentId: 1,
    areaName: '河南省',
    areaPath: '中国,河南省',
    areaCode: '100004100000000000',
    children: [
      {
        id: 3625,
        parentId: 1449,
        areaName: '郑州市',
        areaPath: '中国,河南省,郑州市',
        areaCode: '100004100010000000',
        children: [
          {
            id: 10957,
            parentId: 3625,
            areaName: '中原区',
            areaPath: '中国,河南省,郑州市,中原区',
            areaCode: '100004100010020000'
          },
          {
            id: 10958,
            parentId: 3625,
            areaName: '二七区',
            areaPath: '中国,河南省,郑州市,二七区',
            areaCode: '100004100010030000'
          },
          {
            id: 10959,
            parentId: 3625,
            areaName: '管城回族区',
            areaPath: '中国,河南省,郑州市,管城回族区',
            areaCode: '100004100010040000'
          },
          {
            id: 10960,
            parentId: 3625,
            areaName: '金水区',
            areaPath: '中国,河南省,郑州市,金水区',
            areaCode: '100004100010050000'
          },
          {
            id: 10961,
            parentId: 3625,
            areaName: '上街区',
            areaPath: '中国,河南省,郑州市,上街区',
            areaCode: '100004100010060000'
          },
          {
            id: 10962,
            parentId: 3625,
            areaName: '惠济区',
            areaPath: '中国,河南省,郑州市,惠济区',
            areaCode: '100004100010080000'
          },
          {
            id: 10963,
            parentId: 3625,
            areaName: '中牟县',
            areaPath: '中国,河南省,郑州市,中牟县',
            areaCode: '100004100010220000'
          },
          {
            id: 10964,
            parentId: 3625,
            areaName: '巩义市',
            areaPath: '中国,河南省,郑州市,巩义市',
            areaCode: '100004100010810000'
          },
          {
            id: 10965,
            parentId: 3625,
            areaName: '荥阳市',
            areaPath: '中国,河南省,郑州市,荥阳市',
            areaCode: '100004100010820000'
          },
          {
            id: 10966,
            parentId: 3625,
            areaName: '新密市',
            areaPath: '中国,河南省,郑州市,新密市',
            areaCode: '100004100010830000'
          },
          {
            id: 10967,
            parentId: 3625,
            areaName: '新郑市',
            areaPath: '中国,河南省,郑州市,新郑市',
            areaCode: '100004100010840000'
          },
          {
            id: 10968,
            parentId: 3625,
            areaName: '登封市',
            areaPath: '中国,河南省,郑州市,登封市',
            areaCode: '100004100010850000'
          }
        ]
      },
      {
        id: 3626,
        parentId: 1449,
        areaName: '开封市',
        areaPath: '中国,河南省,开封市',
        areaCode: '100004100020000000',
        children: [
          {
            id: 10969,
            parentId: 3626,
            areaName: '龙亭区',
            areaPath: '中国,河南省,开封市,龙亭区',
            areaCode: '100004100020020000'
          },
          {
            id: 10970,
            parentId: 3626,
            areaName: '顺河回族区',
            areaPath: '中国,河南省,开封市,顺河回族区',
            areaCode: '100004100020030000'
          },
          {
            id: 10971,
            parentId: 3626,
            areaName: '鼓楼区',
            areaPath: '中国,河南省,开封市,鼓楼区',
            areaCode: '100004100020040000'
          },
          {
            id: 10972,
            parentId: 3626,
            areaName: '禹王台区',
            areaPath: '中国,河南省,开封市,禹王台区',
            areaCode: '100004100020050000'
          },
          {
            id: 10973,
            parentId: 3626,
            areaName: '祥符区',
            areaPath: '中国,河南省,开封市,祥符区',
            areaCode: '100004100020120000'
          },
          {
            id: 10974,
            parentId: 3626,
            areaName: '杞县',
            areaPath: '中国,河南省,开封市,杞县',
            areaCode: '100004100020210000'
          },
          {
            id: 10975,
            parentId: 3626,
            areaName: '通许县',
            areaPath: '中国,河南省,开封市,通许县',
            areaCode: '100004100020220000'
          },
          {
            id: 10976,
            parentId: 3626,
            areaName: '尉氏县',
            areaPath: '中国,河南省,开封市,尉氏县',
            areaCode: '100004100020230000'
          },
          {
            id: 10977,
            parentId: 3626,
            areaName: '兰考县',
            areaPath: '中国,河南省,开封市,兰考县',
            areaCode: '100004100020250000'
          }
        ]
      },
      {
        id: 3627,
        parentId: 1449,
        areaName: '洛阳市',
        areaPath: '中国,河南省,洛阳市',
        areaCode: '100004100030000000',
        children: [
          {
            id: 10978,
            parentId: 3627,
            areaName: '老城区',
            areaPath: '中国,河南省,洛阳市,老城区',
            areaCode: '100004100030020000'
          },
          {
            id: 10979,
            parentId: 3627,
            areaName: '西工区',
            areaPath: '中国,河南省,洛阳市,西工区',
            areaCode: '100004100030030000'
          },
          {
            id: 10980,
            parentId: 3627,
            areaName: '瀍河回族区',
            areaPath: '中国,河南省,洛阳市,瀍河回族区',
            areaCode: '100004100030040000'
          },
          {
            id: 10981,
            parentId: 3627,
            areaName: '涧西区',
            areaPath: '中国,河南省,洛阳市,涧西区',
            areaCode: '100004100030050000'
          },
          {
            id: 10982,
            parentId: 3627,
            areaName: '吉利区',
            areaPath: '中国,河南省,洛阳市,吉利区',
            areaCode: '100004100030060000'
          },
          {
            id: 10983,
            parentId: 3627,
            areaName: '洛龙区',
            areaPath: '中国,河南省,洛阳市,洛龙区',
            areaCode: '100004100030110000'
          },
          {
            id: 10984,
            parentId: 3627,
            areaName: '孟津县',
            areaPath: '中国,河南省,洛阳市,孟津县',
            areaCode: '100004100030220000'
          },
          {
            id: 10985,
            parentId: 3627,
            areaName: '新安县',
            areaPath: '中国,河南省,洛阳市,新安县',
            areaCode: '100004100030230000'
          },
          {
            id: 10986,
            parentId: 3627,
            areaName: '栾川县',
            areaPath: '中国,河南省,洛阳市,栾川县',
            areaCode: '100004100030240000'
          },
          {
            id: 10987,
            parentId: 3627,
            areaName: '嵩县',
            areaPath: '中国,河南省,洛阳市,嵩县',
            areaCode: '100004100030250000'
          },
          {
            id: 10988,
            parentId: 3627,
            areaName: '汝阳县',
            areaPath: '中国,河南省,洛阳市,汝阳县',
            areaCode: '100004100030260000'
          },
          {
            id: 10989,
            parentId: 3627,
            areaName: '宜阳县',
            areaPath: '中国,河南省,洛阳市,宜阳县',
            areaCode: '100004100030270000'
          },
          {
            id: 10990,
            parentId: 3627,
            areaName: '洛宁县',
            areaPath: '中国,河南省,洛阳市,洛宁县',
            areaCode: '100004100030280000'
          },
          {
            id: 10991,
            parentId: 3627,
            areaName: '伊川县',
            areaPath: '中国,河南省,洛阳市,伊川县',
            areaCode: '100004100030290000'
          },
          {
            id: 10992,
            parentId: 3627,
            areaName: '偃师市',
            areaPath: '中国,河南省,洛阳市,偃师市',
            areaCode: '100004100030810000'
          }
        ]
      },
      {
        id: 3628,
        parentId: 1449,
        areaName: '平顶山市',
        areaPath: '中国,河南省,平顶山市',
        areaCode: '100004100040000000',
        children: [
          {
            id: 10993,
            parentId: 3628,
            areaName: '新华区',
            areaPath: '中国,河南省,平顶山市,新华区',
            areaCode: '100004100040020000'
          },
          {
            id: 10994,
            parentId: 3628,
            areaName: '卫东区',
            areaPath: '中国,河南省,平顶山市,卫东区',
            areaCode: '100004100040030000'
          },
          {
            id: 10995,
            parentId: 3628,
            areaName: '石龙区',
            areaPath: '中国,河南省,平顶山市,石龙区',
            areaCode: '100004100040040000'
          },
          {
            id: 10996,
            parentId: 3628,
            areaName: '湛河区',
            areaPath: '中国,河南省,平顶山市,湛河区',
            areaCode: '100004100040110000'
          },
          {
            id: 10997,
            parentId: 3628,
            areaName: '宝丰县',
            areaPath: '中国,河南省,平顶山市,宝丰县',
            areaCode: '100004100040210000'
          },
          {
            id: 10998,
            parentId: 3628,
            areaName: '叶县',
            areaPath: '中国,河南省,平顶山市,叶县',
            areaCode: '100004100040220000'
          },
          {
            id: 10999,
            parentId: 3628,
            areaName: '鲁山县',
            areaPath: '中国,河南省,平顶山市,鲁山县',
            areaCode: '100004100040230000'
          },
          {
            id: 11000,
            parentId: 3628,
            areaName: '郏县',
            areaPath: '中国,河南省,平顶山市,郏县',
            areaCode: '100004100040250000'
          },
          {
            id: 11001,
            parentId: 3628,
            areaName: '舞钢市',
            areaPath: '中国,河南省,平顶山市,舞钢市',
            areaCode: '100004100040810000'
          },
          {
            id: 11002,
            parentId: 3628,
            areaName: '汝州市',
            areaPath: '中国,河南省,平顶山市,汝州市',
            areaCode: '100004100040820000'
          }
        ]
      },
      {
        id: 3629,
        parentId: 1449,
        areaName: '安阳市',
        areaPath: '中国,河南省,安阳市',
        areaCode: '100004100050000000',
        children: [
          {
            id: 11003,
            parentId: 3629,
            areaName: '文峰区',
            areaPath: '中国,河南省,安阳市,文峰区',
            areaCode: '100004100050020000'
          },
          {
            id: 11004,
            parentId: 3629,
            areaName: '北关区',
            areaPath: '中国,河南省,安阳市,北关区',
            areaCode: '100004100050030000'
          },
          {
            id: 11005,
            parentId: 3629,
            areaName: '殷都区',
            areaPath: '中国,河南省,安阳市,殷都区',
            areaCode: '100004100050050000'
          },
          {
            id: 11006,
            parentId: 3629,
            areaName: '龙安区',
            areaPath: '中国,河南省,安阳市,龙安区',
            areaCode: '100004100050060000'
          },
          {
            id: 11007,
            parentId: 3629,
            areaName: '安阳县',
            areaPath: '中国,河南省,安阳市,安阳县',
            areaCode: '100004100050220000'
          },
          {
            id: 11008,
            parentId: 3629,
            areaName: '汤阴县',
            areaPath: '中国,河南省,安阳市,汤阴县',
            areaCode: '100004100050230000'
          },
          {
            id: 11009,
            parentId: 3629,
            areaName: '滑县',
            areaPath: '中国,河南省,安阳市,滑县',
            areaCode: '100004100050260000'
          },
          {
            id: 11010,
            parentId: 3629,
            areaName: '内黄县',
            areaPath: '中国,河南省,安阳市,内黄县',
            areaCode: '100004100050270000'
          },
          {
            id: 11011,
            parentId: 3629,
            areaName: '林州市',
            areaPath: '中国,河南省,安阳市,林州市',
            areaCode: '100004100050810000'
          }
        ]
      },
      {
        id: 3630,
        parentId: 1449,
        areaName: '鹤壁市',
        areaPath: '中国,河南省,鹤壁市',
        areaCode: '100004100060000000',
        children: [
          {
            id: 11012,
            parentId: 3630,
            areaName: '鹤山区',
            areaPath: '中国,河南省,鹤壁市,鹤山区',
            areaCode: '100004100060020000'
          },
          {
            id: 11013,
            parentId: 3630,
            areaName: '山城区',
            areaPath: '中国,河南省,鹤壁市,山城区',
            areaCode: '100004100060030000'
          },
          {
            id: 11014,
            parentId: 3630,
            areaName: '淇滨区',
            areaPath: '中国,河南省,鹤壁市,淇滨区',
            areaCode: '100004100060110000'
          },
          {
            id: 11015,
            parentId: 3630,
            areaName: '浚县',
            areaPath: '中国,河南省,鹤壁市,浚县',
            areaCode: '100004100060210000'
          },
          {
            id: 11016,
            parentId: 3630,
            areaName: '淇县',
            areaPath: '中国,河南省,鹤壁市,淇县',
            areaCode: '100004100060220000'
          }
        ]
      },
      {
        id: 3631,
        parentId: 1449,
        areaName: '新乡市',
        areaPath: '中国,河南省,新乡市',
        areaCode: '100004100070000000',
        children: [
          {
            id: 11017,
            parentId: 3631,
            areaName: '红旗区',
            areaPath: '中国,河南省,新乡市,红旗区',
            areaCode: '100004100070020000'
          },
          {
            id: 11018,
            parentId: 3631,
            areaName: '卫滨区',
            areaPath: '中国,河南省,新乡市,卫滨区',
            areaCode: '100004100070030000'
          },
          {
            id: 11019,
            parentId: 3631,
            areaName: '凤泉区',
            areaPath: '中国,河南省,新乡市,凤泉区',
            areaCode: '100004100070040000'
          },
          {
            id: 11020,
            parentId: 3631,
            areaName: '牧野区',
            areaPath: '中国,河南省,新乡市,牧野区',
            areaCode: '100004100070110000'
          },
          {
            id: 11021,
            parentId: 3631,
            areaName: '新乡县',
            areaPath: '中国,河南省,新乡市,新乡县',
            areaCode: '100004100070210000'
          },
          {
            id: 11022,
            parentId: 3631,
            areaName: '获嘉县',
            areaPath: '中国,河南省,新乡市,获嘉县',
            areaCode: '100004100070240000'
          },
          {
            id: 11023,
            parentId: 3631,
            areaName: '原阳县',
            areaPath: '中国,河南省,新乡市,原阳县',
            areaCode: '100004100070250000'
          },
          {
            id: 11024,
            parentId: 3631,
            areaName: '延津县',
            areaPath: '中国,河南省,新乡市,延津县',
            areaCode: '100004100070260000'
          },
          {
            id: 11025,
            parentId: 3631,
            areaName: '封丘县',
            areaPath: '中国,河南省,新乡市,封丘县',
            areaCode: '100004100070270000'
          },
          {
            id: 11026,
            parentId: 3631,
            areaName: '长垣县',
            areaPath: '中国,河南省,新乡市,长垣县',
            areaCode: '100004100070280000'
          },
          {
            id: 11027,
            parentId: 3631,
            areaName: '卫辉市',
            areaPath: '中国,河南省,新乡市,卫辉市',
            areaCode: '100004100070810000'
          },
          {
            id: 11028,
            parentId: 3631,
            areaName: '辉县市',
            areaPath: '中国,河南省,新乡市,辉县市',
            areaCode: '100004100070820000'
          }
        ]
      },
      {
        id: 3632,
        parentId: 1449,
        areaName: '焦作市',
        areaPath: '中国,河南省,焦作市',
        areaCode: '100004100080000000',
        children: [
          {
            id: 11029,
            parentId: 3632,
            areaName: '解放区',
            areaPath: '中国,河南省,焦作市,解放区',
            areaCode: '100004100080020000'
          },
          {
            id: 11030,
            parentId: 3632,
            areaName: '中站区',
            areaPath: '中国,河南省,焦作市,中站区',
            areaCode: '100004100080030000'
          },
          {
            id: 11031,
            parentId: 3632,
            areaName: '马村区',
            areaPath: '中国,河南省,焦作市,马村区',
            areaCode: '100004100080040000'
          },
          {
            id: 11032,
            parentId: 3632,
            areaName: '山阳区',
            areaPath: '中国,河南省,焦作市,山阳区',
            areaCode: '100004100080110000'
          },
          {
            id: 11033,
            parentId: 3632,
            areaName: '修武县',
            areaPath: '中国,河南省,焦作市,修武县',
            areaCode: '100004100080210000'
          },
          {
            id: 11034,
            parentId: 3632,
            areaName: '博爱县',
            areaPath: '中国,河南省,焦作市,博爱县',
            areaCode: '100004100080220000'
          },
          {
            id: 11035,
            parentId: 3632,
            areaName: '武陟县',
            areaPath: '中国,河南省,焦作市,武陟县',
            areaCode: '100004100080230000'
          },
          {
            id: 11036,
            parentId: 3632,
            areaName: '温县',
            areaPath: '中国,河南省,焦作市,温县',
            areaCode: '100004100080250000'
          },
          {
            id: 11037,
            parentId: 3632,
            areaName: '沁阳市',
            areaPath: '中国,河南省,焦作市,沁阳市',
            areaCode: '100004100080820000'
          },
          {
            id: 11038,
            parentId: 3632,
            areaName: '孟州市',
            areaPath: '中国,河南省,焦作市,孟州市',
            areaCode: '100004100080830000'
          }
        ]
      },
      {
        id: 3633,
        parentId: 1449,
        areaName: '濮阳市',
        areaPath: '中国,河南省,濮阳市',
        areaCode: '100004100090000000',
        children: [
          {
            id: 11039,
            parentId: 3633,
            areaName: '华龙区',
            areaPath: '中国,河南省,濮阳市,华龙区',
            areaCode: '100004100090020000'
          },
          {
            id: 11040,
            parentId: 3633,
            areaName: '清丰县',
            areaPath: '中国,河南省,濮阳市,清丰县',
            areaCode: '100004100090220000'
          },
          {
            id: 11041,
            parentId: 3633,
            areaName: '南乐县',
            areaPath: '中国,河南省,濮阳市,南乐县',
            areaCode: '100004100090230000'
          },
          {
            id: 11042,
            parentId: 3633,
            areaName: '范县',
            areaPath: '中国,河南省,濮阳市,范县',
            areaCode: '100004100090260000'
          },
          {
            id: 11043,
            parentId: 3633,
            areaName: '台前县',
            areaPath: '中国,河南省,濮阳市,台前县',
            areaCode: '100004100090270000'
          },
          {
            id: 11044,
            parentId: 3633,
            areaName: '濮阳县',
            areaPath: '中国,河南省,濮阳市,濮阳县',
            areaCode: '100004100090280000'
          }
        ]
      },
      {
        id: 3634,
        parentId: 1449,
        areaName: '许昌市',
        areaPath: '中国,河南省,许昌市',
        areaCode: '100004100100000000',
        children: [
          {
            id: 11045,
            parentId: 3634,
            areaName: '魏都区',
            areaPath: '中国,河南省,许昌市,魏都区',
            areaCode: '100004100100020000'
          },
          {
            id: 11046,
            parentId: 3634,
            areaName: '建安区',
            areaPath: '中国,河南省,许昌市,建安区',
            areaCode: '100004100100030000'
          },
          {
            id: 11047,
            parentId: 3634,
            areaName: '鄢陵县',
            areaPath: '中国,河南省,许昌市,鄢陵县',
            areaCode: '100004100100240000'
          },
          {
            id: 11048,
            parentId: 3634,
            areaName: '襄城县',
            areaPath: '中国,河南省,许昌市,襄城县',
            areaCode: '100004100100250000'
          },
          {
            id: 11049,
            parentId: 3634,
            areaName: '禹州市',
            areaPath: '中国,河南省,许昌市,禹州市',
            areaCode: '100004100100810000'
          },
          {
            id: 11050,
            parentId: 3634,
            areaName: '长葛市',
            areaPath: '中国,河南省,许昌市,长葛市',
            areaCode: '100004100100820000'
          }
        ]
      },
      {
        id: 3635,
        parentId: 1449,
        areaName: '漯河市',
        areaPath: '中国,河南省,漯河市',
        areaCode: '100004100110000000',
        children: [
          {
            id: 11051,
            parentId: 3635,
            areaName: '源汇区',
            areaPath: '中国,河南省,漯河市,源汇区',
            areaCode: '100004100110020000'
          },
          {
            id: 11052,
            parentId: 3635,
            areaName: '郾城区',
            areaPath: '中国,河南省,漯河市,郾城区',
            areaCode: '100004100110030000'
          },
          {
            id: 11053,
            parentId: 3635,
            areaName: '召陵区',
            areaPath: '中国,河南省,漯河市,召陵区',
            areaCode: '100004100110040000'
          },
          {
            id: 11054,
            parentId: 3635,
            areaName: '舞阳县',
            areaPath: '中国,河南省,漯河市,舞阳县',
            areaCode: '100004100110210000'
          },
          {
            id: 11055,
            parentId: 3635,
            areaName: '临颍县',
            areaPath: '中国,河南省,漯河市,临颍县',
            areaCode: '100004100110220000'
          }
        ]
      },
      {
        id: 3636,
        parentId: 1449,
        areaName: '三门峡市',
        areaPath: '中国,河南省,三门峡市',
        areaCode: '100004100120000000',
        children: [
          {
            id: 11056,
            parentId: 3636,
            areaName: '湖滨区',
            areaPath: '中国,河南省,三门峡市,湖滨区',
            areaCode: '100004100120020000'
          },
          {
            id: 11057,
            parentId: 3636,
            areaName: '陕州区',
            areaPath: '中国,河南省,三门峡市,陕州区',
            areaCode: '100004100120030000'
          },
          {
            id: 11058,
            parentId: 3636,
            areaName: '渑池县',
            areaPath: '中国,河南省,三门峡市,渑池县',
            areaCode: '100004100120210000'
          },
          {
            id: 11059,
            parentId: 3636,
            areaName: '卢氏县',
            areaPath: '中国,河南省,三门峡市,卢氏县',
            areaCode: '100004100120240000'
          },
          {
            id: 11060,
            parentId: 3636,
            areaName: '义马市',
            areaPath: '中国,河南省,三门峡市,义马市',
            areaCode: '100004100120810000'
          },
          {
            id: 11061,
            parentId: 3636,
            areaName: '灵宝市',
            areaPath: '中国,河南省,三门峡市,灵宝市',
            areaCode: '100004100120820000'
          }
        ]
      },
      {
        id: 3637,
        parentId: 1449,
        areaName: '南阳市',
        areaPath: '中国,河南省,南阳市',
        areaCode: '100004100130000000',
        children: [
          {
            id: 11062,
            parentId: 3637,
            areaName: '宛城区',
            areaPath: '中国,河南省,南阳市,宛城区',
            areaCode: '100004100130020000'
          },
          {
            id: 11063,
            parentId: 3637,
            areaName: '卧龙区',
            areaPath: '中国,河南省,南阳市,卧龙区',
            areaCode: '100004100130030000'
          },
          {
            id: 11064,
            parentId: 3637,
            areaName: '南召县',
            areaPath: '中国,河南省,南阳市,南召县',
            areaCode: '100004100130210000'
          },
          {
            id: 11065,
            parentId: 3637,
            areaName: '方城县',
            areaPath: '中国,河南省,南阳市,方城县',
            areaCode: '100004100130220000'
          },
          {
            id: 11066,
            parentId: 3637,
            areaName: '西峡县',
            areaPath: '中国,河南省,南阳市,西峡县',
            areaCode: '100004100130230000'
          },
          {
            id: 11067,
            parentId: 3637,
            areaName: '镇平县',
            areaPath: '中国,河南省,南阳市,镇平县',
            areaCode: '100004100130240000'
          },
          {
            id: 11068,
            parentId: 3637,
            areaName: '内乡县',
            areaPath: '中国,河南省,南阳市,内乡县',
            areaCode: '100004100130250000'
          },
          {
            id: 11069,
            parentId: 3637,
            areaName: '淅川县',
            areaPath: '中国,河南省,南阳市,淅川县',
            areaCode: '100004100130260000'
          },
          {
            id: 11070,
            parentId: 3637,
            areaName: '社旗县',
            areaPath: '中国,河南省,南阳市,社旗县',
            areaCode: '100004100130270000'
          },
          {
            id: 11071,
            parentId: 3637,
            areaName: '唐河县',
            areaPath: '中国,河南省,南阳市,唐河县',
            areaCode: '100004100130280000'
          },
          {
            id: 11072,
            parentId: 3637,
            areaName: '新野县',
            areaPath: '中国,河南省,南阳市,新野县',
            areaCode: '100004100130290000'
          },
          {
            id: 11073,
            parentId: 3637,
            areaName: '桐柏县',
            areaPath: '中国,河南省,南阳市,桐柏县',
            areaCode: '100004100130300000'
          },
          {
            id: 11074,
            parentId: 3637,
            areaName: '邓州市',
            areaPath: '中国,河南省,南阳市,邓州市',
            areaCode: '100004100130810000'
          }
        ]
      },
      {
        id: 3638,
        parentId: 1449,
        areaName: '商丘市',
        areaPath: '中国,河南省,商丘市',
        areaCode: '100004100140000000',
        children: [
          {
            id: 11075,
            parentId: 3638,
            areaName: '梁园区',
            areaPath: '中国,河南省,商丘市,梁园区',
            areaCode: '100004100140020000'
          },
          {
            id: 11076,
            parentId: 3638,
            areaName: '睢阳区',
            areaPath: '中国,河南省,商丘市,睢阳区',
            areaCode: '100004100140030000'
          },
          {
            id: 11077,
            parentId: 3638,
            areaName: '民权县',
            areaPath: '中国,河南省,商丘市,民权县',
            areaCode: '100004100140210000'
          },
          {
            id: 11078,
            parentId: 3638,
            areaName: '睢县',
            areaPath: '中国,河南省,商丘市,睢县',
            areaCode: '100004100140220000'
          },
          {
            id: 11079,
            parentId: 3638,
            areaName: '宁陵县',
            areaPath: '中国,河南省,商丘市,宁陵县',
            areaCode: '100004100140230000'
          },
          {
            id: 11080,
            parentId: 3638,
            areaName: '柘城县',
            areaPath: '中国,河南省,商丘市,柘城县',
            areaCode: '100004100140240000'
          },
          {
            id: 11081,
            parentId: 3638,
            areaName: '虞城县',
            areaPath: '中国,河南省,商丘市,虞城县',
            areaCode: '100004100140250000'
          },
          {
            id: 11082,
            parentId: 3638,
            areaName: '夏邑县',
            areaPath: '中国,河南省,商丘市,夏邑县',
            areaCode: '100004100140260000'
          },
          {
            id: 11083,
            parentId: 3638,
            areaName: '永城市',
            areaPath: '中国,河南省,商丘市,永城市',
            areaCode: '100004100140810000'
          }
        ]
      },
      {
        id: 3639,
        parentId: 1449,
        areaName: '信阳市',
        areaPath: '中国,河南省,信阳市',
        areaCode: '100004100150000000',
        children: [
          {
            id: 11084,
            parentId: 3639,
            areaName: '浉河区',
            areaPath: '中国,河南省,信阳市,浉河区',
            areaCode: '100004100150020000'
          },
          {
            id: 11085,
            parentId: 3639,
            areaName: '平桥区',
            areaPath: '中国,河南省,信阳市,平桥区',
            areaCode: '100004100150030000'
          },
          {
            id: 11086,
            parentId: 3639,
            areaName: '罗山县',
            areaPath: '中国,河南省,信阳市,罗山县',
            areaCode: '100004100150210000'
          },
          {
            id: 11087,
            parentId: 3639,
            areaName: '光山县',
            areaPath: '中国,河南省,信阳市,光山县',
            areaCode: '100004100150220000'
          },
          {
            id: 11088,
            parentId: 3639,
            areaName: '新县',
            areaPath: '中国,河南省,信阳市,新县',
            areaCode: '100004100150230000'
          },
          {
            id: 11089,
            parentId: 3639,
            areaName: '商城县',
            areaPath: '中国,河南省,信阳市,商城县',
            areaCode: '100004100150240000'
          },
          {
            id: 11090,
            parentId: 3639,
            areaName: '固始县',
            areaPath: '中国,河南省,信阳市,固始县',
            areaCode: '100004100150250000'
          },
          {
            id: 11091,
            parentId: 3639,
            areaName: '潢川县',
            areaPath: '中国,河南省,信阳市,潢川县',
            areaCode: '100004100150260000'
          },
          {
            id: 11092,
            parentId: 3639,
            areaName: '淮滨县',
            areaPath: '中国,河南省,信阳市,淮滨县',
            areaCode: '100004100150270000'
          },
          {
            id: 11093,
            parentId: 3639,
            areaName: '息县',
            areaPath: '中国,河南省,信阳市,息县',
            areaCode: '100004100150280000'
          }
        ]
      },
      {
        id: 3640,
        parentId: 1449,
        areaName: '周口市',
        areaPath: '中国,河南省,周口市',
        areaCode: '100004100160000000',
        children: [
          {
            id: 11094,
            parentId: 3640,
            areaName: '川汇区',
            areaPath: '中国,河南省,周口市,川汇区',
            areaCode: '100004100160020000'
          },
          {
            id: 11095,
            parentId: 3640,
            areaName: '扶沟县',
            areaPath: '中国,河南省,周口市,扶沟县',
            areaCode: '100004100160210000'
          },
          {
            id: 11096,
            parentId: 3640,
            areaName: '西华县',
            areaPath: '中国,河南省,周口市,西华县',
            areaCode: '100004100160220000'
          },
          {
            id: 11097,
            parentId: 3640,
            areaName: '商水县',
            areaPath: '中国,河南省,周口市,商水县',
            areaCode: '100004100160230000'
          },
          {
            id: 11098,
            parentId: 3640,
            areaName: '沈丘县',
            areaPath: '中国,河南省,周口市,沈丘县',
            areaCode: '100004100160240000'
          },
          {
            id: 11099,
            parentId: 3640,
            areaName: '郸城县',
            areaPath: '中国,河南省,周口市,郸城县',
            areaCode: '100004100160250000'
          },
          {
            id: 11100,
            parentId: 3640,
            areaName: '淮阳县',
            areaPath: '中国,河南省,周口市,淮阳县',
            areaCode: '100004100160260000'
          },
          {
            id: 11101,
            parentId: 3640,
            areaName: '太康县',
            areaPath: '中国,河南省,周口市,太康县',
            areaCode: '100004100160270000'
          },
          {
            id: 11102,
            parentId: 3640,
            areaName: '鹿邑县',
            areaPath: '中国,河南省,周口市,鹿邑县',
            areaCode: '100004100160280000'
          },
          {
            id: 11103,
            parentId: 3640,
            areaName: '项城市',
            areaPath: '中国,河南省,周口市,项城市',
            areaCode: '100004100160810000'
          }
        ]
      },
      {
        id: 3641,
        parentId: 1449,
        areaName: '驻马店市',
        areaPath: '中国,河南省,驻马店市',
        areaCode: '100004100170000000',
        children: [
          {
            id: 11104,
            parentId: 3641,
            areaName: '驿城区',
            areaPath: '中国,河南省,驻马店市,驿城区',
            areaCode: '100004100170020000'
          },
          {
            id: 11105,
            parentId: 3641,
            areaName: '西平县',
            areaPath: '中国,河南省,驻马店市,西平县',
            areaCode: '100004100170210000'
          },
          {
            id: 11106,
            parentId: 3641,
            areaName: '上蔡县',
            areaPath: '中国,河南省,驻马店市,上蔡县',
            areaCode: '100004100170220000'
          },
          {
            id: 11107,
            parentId: 3641,
            areaName: '平舆县',
            areaPath: '中国,河南省,驻马店市,平舆县',
            areaCode: '100004100170230000'
          },
          {
            id: 11108,
            parentId: 3641,
            areaName: '正阳县',
            areaPath: '中国,河南省,驻马店市,正阳县',
            areaCode: '100004100170240000'
          },
          {
            id: 11109,
            parentId: 3641,
            areaName: '确山县',
            areaPath: '中国,河南省,驻马店市,确山县',
            areaCode: '100004100170250000'
          },
          {
            id: 11110,
            parentId: 3641,
            areaName: '泌阳县',
            areaPath: '中国,河南省,驻马店市,泌阳县',
            areaCode: '100004100170260000'
          },
          {
            id: 11111,
            parentId: 3641,
            areaName: '汝南县',
            areaPath: '中国,河南省,驻马店市,汝南县',
            areaCode: '100004100170270000'
          },
          {
            id: 11112,
            parentId: 3641,
            areaName: '遂平县',
            areaPath: '中国,河南省,驻马店市,遂平县',
            areaCode: '100004100170280000'
          },
          {
            id: 11113,
            parentId: 3641,
            areaName: '新蔡县',
            areaPath: '中国,河南省,驻马店市,新蔡县',
            areaCode: '100004100170290000'
          }
        ]
      },
      {
        id: 3642,
        parentId: 1449,
        areaName: '济源市',
        areaPath: '中国,河南省,济源市',
        areaCode: '100004100900000000',
        children: [
          {
            id: 5479,
            parentId: 3642,
            areaName: '沁园街道',
            areaPath: '中国,河南省,济源市,沁园街道',
            areaCode: '100004100900000000'
          },
          {
            id: 5480,
            parentId: 3642,
            areaName: '济水街道',
            areaPath: '中国,河南省,济源市,济水街道',
            areaCode: '100004100900000000'
          },
          {
            id: 5481,
            parentId: 3642,
            areaName: '北海街道',
            areaPath: '中国,河南省,济源市,北海街道',
            areaCode: '100004100900000000'
          },
          {
            id: 5482,
            parentId: 3642,
            areaName: '天坛街道',
            areaPath: '中国,河南省,济源市,天坛街道',
            areaCode: '100004100900000000'
          },
          {
            id: 5483,
            parentId: 3642,
            areaName: '玉泉街道',
            areaPath: '中国,河南省,济源市,玉泉街道',
            areaCode: '100004100900000000'
          },
          {
            id: 5484,
            parentId: 3642,
            areaName: '克井镇',
            areaPath: '中国,河南省,济源市,克井镇',
            areaCode: '100004100900000100'
          },
          {
            id: 5485,
            parentId: 3642,
            areaName: '五龙口镇',
            areaPath: '中国,河南省,济源市,五龙口镇',
            areaCode: '100004100900000100'
          },
          {
            id: 5486,
            parentId: 3642,
            areaName: '梨林镇',
            areaPath: '中国,河南省,济源市,梨林镇',
            areaCode: '100004100900000110'
          },
          {
            id: 5487,
            parentId: 3642,
            areaName: '轵城镇',
            areaPath: '中国,河南省,济源市,轵城镇',
            areaCode: '100004100900000100'
          },
          {
            id: 5488,
            parentId: 3642,
            areaName: '承留镇',
            areaPath: '中国,河南省,济源市,承留镇',
            areaCode: '100004100900000100'
          },
          {
            id: 5489,
            parentId: 3642,
            areaName: '坡头镇',
            areaPath: '中国,河南省,济源市,坡头镇',
            areaCode: '100004100900000110'
          },
          {
            id: 5490,
            parentId: 3642,
            areaName: '大峪镇',
            areaPath: '中国,河南省,济源市,大峪镇',
            areaCode: '100004100900000110'
          },
          {
            id: 5491,
            parentId: 3642,
            areaName: '邵原镇',
            areaPath: '中国,河南省,济源市,邵原镇',
            areaCode: '100004100900000100'
          },
          {
            id: 5492,
            parentId: 3642,
            areaName: '思礼镇',
            areaPath: '中国,河南省,济源市,思礼镇',
            areaCode: '100004100900000110'
          },
          {
            id: 5493,
            parentId: 3642,
            areaName: '王屋镇',
            areaPath: '中国,河南省,济源市,王屋镇',
            areaCode: '100004100900000110'
          },
          {
            id: 5494,
            parentId: 3642,
            areaName: '下冶镇',
            areaPath: '中国,河南省,济源市,下冶镇',
            areaCode: '100004100900000110'
          }
        ]
      }
    ]
  },
  {
    id: 1450,
    parentId: 1,
    areaName: '湖北省',
    areaPath: '中国,湖北省',
    areaCode: '100004200000000000',
    children: [
      {
        id: 3643,
        parentId: 1450,
        areaName: '武汉市',
        areaPath: '中国,湖北省,武汉市',
        areaCode: '100004200010000000',
        children: [
          {
            id: 11115,
            parentId: 3643,
            areaName: '江岸区',
            areaPath: '中国,湖北省,武汉市,江岸区',
            areaCode: '100004200010020000'
          },
          {
            id: 11116,
            parentId: 3643,
            areaName: '江汉区',
            areaPath: '中国,湖北省,武汉市,江汉区',
            areaCode: '100004200010030000'
          },
          {
            id: 11117,
            parentId: 3643,
            areaName: '硚口区',
            areaPath: '中国,湖北省,武汉市,硚口区',
            areaCode: '100004200010040000'
          },
          {
            id: 11118,
            parentId: 3643,
            areaName: '汉阳区',
            areaPath: '中国,湖北省,武汉市,汉阳区',
            areaCode: '100004200010050000'
          },
          {
            id: 11119,
            parentId: 3643,
            areaName: '武昌区',
            areaPath: '中国,湖北省,武汉市,武昌区',
            areaCode: '100004200010060000'
          },
          {
            id: 11120,
            parentId: 3643,
            areaName: '青山区',
            areaPath: '中国,湖北省,武汉市,青山区',
            areaCode: '100004200010070000'
          },
          {
            id: 11121,
            parentId: 3643,
            areaName: '洪山区',
            areaPath: '中国,湖北省,武汉市,洪山区',
            areaCode: '100004200010110000'
          },
          {
            id: 11122,
            parentId: 3643,
            areaName: '东西湖区',
            areaPath: '中国,湖北省,武汉市,东西湖区',
            areaCode: '100004200010120000'
          },
          {
            id: 11123,
            parentId: 3643,
            areaName: '汉南区',
            areaPath: '中国,湖北省,武汉市,汉南区',
            areaCode: '100004200010130000'
          },
          {
            id: 11124,
            parentId: 3643,
            areaName: '蔡甸区',
            areaPath: '中国,湖北省,武汉市,蔡甸区',
            areaCode: '100004200010140000'
          },
          {
            id: 11125,
            parentId: 3643,
            areaName: '江夏区',
            areaPath: '中国,湖北省,武汉市,江夏区',
            areaCode: '100004200010150000'
          },
          {
            id: 11126,
            parentId: 3643,
            areaName: '黄陂区',
            areaPath: '中国,湖北省,武汉市,黄陂区',
            areaCode: '100004200010160000'
          },
          {
            id: 11127,
            parentId: 3643,
            areaName: '新洲区',
            areaPath: '中国,湖北省,武汉市,新洲区',
            areaCode: '100004200010170000'
          }
        ]
      },
      {
        id: 3644,
        parentId: 1450,
        areaName: '黄石市',
        areaPath: '中国,湖北省,黄石市',
        areaCode: '100004200020000000',
        children: [
          {
            id: 11128,
            parentId: 3644,
            areaName: '黄石港区',
            areaPath: '中国,湖北省,黄石市,黄石港区',
            areaCode: '100004200020020000'
          },
          {
            id: 11129,
            parentId: 3644,
            areaName: '西塞山区',
            areaPath: '中国,湖北省,黄石市,西塞山区',
            areaCode: '100004200020030000'
          },
          {
            id: 11130,
            parentId: 3644,
            areaName: '下陆区',
            areaPath: '中国,湖北省,黄石市,下陆区',
            areaCode: '100004200020040000'
          },
          {
            id: 11131,
            parentId: 3644,
            areaName: '铁山区',
            areaPath: '中国,湖北省,黄石市,铁山区',
            areaCode: '100004200020050000'
          },
          {
            id: 11132,
            parentId: 3644,
            areaName: '阳新县',
            areaPath: '中国,湖北省,黄石市,阳新县',
            areaCode: '100004200020220000'
          },
          {
            id: 11133,
            parentId: 3644,
            areaName: '大冶市',
            areaPath: '中国,湖北省,黄石市,大冶市',
            areaCode: '100004200020810000'
          }
        ]
      },
      {
        id: 3645,
        parentId: 1450,
        areaName: '十堰市',
        areaPath: '中国,湖北省,十堰市',
        areaCode: '100004200030000000',
        children: [
          {
            id: 11134,
            parentId: 3645,
            areaName: '茅箭区',
            areaPath: '中国,湖北省,十堰市,茅箭区',
            areaCode: '100004200030020000'
          },
          {
            id: 11135,
            parentId: 3645,
            areaName: '张湾区',
            areaPath: '中国,湖北省,十堰市,张湾区',
            areaCode: '100004200030030000'
          },
          {
            id: 11136,
            parentId: 3645,
            areaName: '郧阳区',
            areaPath: '中国,湖北省,十堰市,郧阳区',
            areaCode: '100004200030040000'
          },
          {
            id: 11137,
            parentId: 3645,
            areaName: '郧西县',
            areaPath: '中国,湖北省,十堰市,郧西县',
            areaCode: '100004200030220000'
          },
          {
            id: 11138,
            parentId: 3645,
            areaName: '竹山县',
            areaPath: '中国,湖北省,十堰市,竹山县',
            areaCode: '100004200030230000'
          },
          {
            id: 11139,
            parentId: 3645,
            areaName: '竹溪县',
            areaPath: '中国,湖北省,十堰市,竹溪县',
            areaCode: '100004200030240000'
          },
          {
            id: 11140,
            parentId: 3645,
            areaName: '房县',
            areaPath: '中国,湖北省,十堰市,房县',
            areaCode: '100004200030250000'
          },
          {
            id: 11141,
            parentId: 3645,
            areaName: '丹江口市',
            areaPath: '中国,湖北省,十堰市,丹江口市',
            areaCode: '100004200030810000'
          }
        ]
      },
      {
        id: 3646,
        parentId: 1450,
        areaName: '宜昌市',
        areaPath: '中国,湖北省,宜昌市',
        areaCode: '100004200050000000',
        children: [
          {
            id: 11142,
            parentId: 3646,
            areaName: '西陵区',
            areaPath: '中国,湖北省,宜昌市,西陵区',
            areaCode: '100004200050020000'
          },
          {
            id: 11143,
            parentId: 3646,
            areaName: '伍家岗区',
            areaPath: '中国,湖北省,宜昌市,伍家岗区',
            areaCode: '100004200050030000'
          },
          {
            id: 11144,
            parentId: 3646,
            areaName: '点军区',
            areaPath: '中国,湖北省,宜昌市,点军区',
            areaCode: '100004200050040000'
          },
          {
            id: 11145,
            parentId: 3646,
            areaName: '猇亭区',
            areaPath: '中国,湖北省,宜昌市,猇亭区',
            areaCode: '100004200050050000'
          },
          {
            id: 11146,
            parentId: 3646,
            areaName: '夷陵区',
            areaPath: '中国,湖北省,宜昌市,夷陵区',
            areaCode: '100004200050060000'
          },
          {
            id: 11147,
            parentId: 3646,
            areaName: '远安县',
            areaPath: '中国,湖北省,宜昌市,远安县',
            areaCode: '100004200050250000'
          },
          {
            id: 11148,
            parentId: 3646,
            areaName: '兴山县',
            areaPath: '中国,湖北省,宜昌市,兴山县',
            areaCode: '100004200050260000'
          },
          {
            id: 11149,
            parentId: 3646,
            areaName: '秭归县',
            areaPath: '中国,湖北省,宜昌市,秭归县',
            areaCode: '100004200050270000'
          },
          {
            id: 11150,
            parentId: 3646,
            areaName: '长阳土家族自治县',
            areaPath: '中国,湖北省,宜昌市,长阳土家族自治县',
            areaCode: '100004200050280000'
          },
          {
            id: 11151,
            parentId: 3646,
            areaName: '五峰土家族自治县',
            areaPath: '中国,湖北省,宜昌市,五峰土家族自治县',
            areaCode: '100004200050290000'
          },
          {
            id: 11152,
            parentId: 3646,
            areaName: '宜都市',
            areaPath: '中国,湖北省,宜昌市,宜都市',
            areaCode: '100004200050810000'
          },
          {
            id: 11153,
            parentId: 3646,
            areaName: '当阳市',
            areaPath: '中国,湖北省,宜昌市,当阳市',
            areaCode: '100004200050820000'
          },
          {
            id: 11154,
            parentId: 3646,
            areaName: '枝江市',
            areaPath: '中国,湖北省,宜昌市,枝江市',
            areaCode: '100004200050830000'
          }
        ]
      },
      {
        id: 3647,
        parentId: 1450,
        areaName: '襄阳市',
        areaPath: '中国,湖北省,襄阳市',
        areaCode: '100004200060000000',
        children: [
          {
            id: 11155,
            parentId: 3647,
            areaName: '襄城区',
            areaPath: '中国,湖北省,襄阳市,襄城区',
            areaCode: '100004200060020000'
          },
          {
            id: 11156,
            parentId: 3647,
            areaName: '樊城区',
            areaPath: '中国,湖北省,襄阳市,樊城区',
            areaCode: '100004200060060000'
          },
          {
            id: 11157,
            parentId: 3647,
            areaName: '襄州区',
            areaPath: '中国,湖北省,襄阳市,襄州区',
            areaCode: '100004200060070000'
          },
          {
            id: 11158,
            parentId: 3647,
            areaName: '南漳县',
            areaPath: '中国,湖北省,襄阳市,南漳县',
            areaCode: '100004200060240000'
          },
          {
            id: 11159,
            parentId: 3647,
            areaName: '谷城县',
            areaPath: '中国,湖北省,襄阳市,谷城县',
            areaCode: '100004200060250000'
          },
          {
            id: 11160,
            parentId: 3647,
            areaName: '保康县',
            areaPath: '中国,湖北省,襄阳市,保康县',
            areaCode: '100004200060260000'
          },
          {
            id: 11161,
            parentId: 3647,
            areaName: '老河口市',
            areaPath: '中国,湖北省,襄阳市,老河口市',
            areaCode: '100004200060820000'
          },
          {
            id: 11162,
            parentId: 3647,
            areaName: '枣阳市',
            areaPath: '中国,湖北省,襄阳市,枣阳市',
            areaCode: '100004200060830000'
          },
          {
            id: 11163,
            parentId: 3647,
            areaName: '宜城市',
            areaPath: '中国,湖北省,襄阳市,宜城市',
            areaCode: '100004200060840000'
          }
        ]
      },
      {
        id: 3648,
        parentId: 1450,
        areaName: '鄂州市',
        areaPath: '中国,湖北省,鄂州市',
        areaCode: '100004200070000000',
        children: [
          {
            id: 11164,
            parentId: 3648,
            areaName: '梁子湖区',
            areaPath: '中国,湖北省,鄂州市,梁子湖区',
            areaCode: '100004200070020000'
          },
          {
            id: 11165,
            parentId: 3648,
            areaName: '华容区',
            areaPath: '中国,湖北省,鄂州市,华容区',
            areaCode: '100004200070030000'
          },
          {
            id: 11166,
            parentId: 3648,
            areaName: '鄂城区',
            areaPath: '中国,湖北省,鄂州市,鄂城区',
            areaCode: '100004200070040000'
          }
        ]
      },
      {
        id: 3649,
        parentId: 1450,
        areaName: '荆门市',
        areaPath: '中国,湖北省,荆门市',
        areaCode: '100004200080000000',
        children: [
          {
            id: 11167,
            parentId: 3649,
            areaName: '东宝区',
            areaPath: '中国,湖北省,荆门市,东宝区',
            areaCode: '100004200080020000'
          },
          {
            id: 11168,
            parentId: 3649,
            areaName: '掇刀区',
            areaPath: '中国,湖北省,荆门市,掇刀区',
            areaCode: '100004200080040000'
          },
          {
            id: 11169,
            parentId: 3649,
            areaName: '京山县',
            areaPath: '中国,湖北省,荆门市,京山县',
            areaCode: '100004200080210000'
          },
          {
            id: 11170,
            parentId: 3649,
            areaName: '沙洋县',
            areaPath: '中国,湖北省,荆门市,沙洋县',
            areaCode: '100004200080220000'
          },
          {
            id: 11171,
            parentId: 3649,
            areaName: '钟祥市',
            areaPath: '中国,湖北省,荆门市,钟祥市',
            areaCode: '100004200080810000'
          }
        ]
      },
      {
        id: 3650,
        parentId: 1450,
        areaName: '孝感市',
        areaPath: '中国,湖北省,孝感市',
        areaCode: '100004200090000000',
        children: [
          {
            id: 11172,
            parentId: 3650,
            areaName: '孝南区',
            areaPath: '中国,湖北省,孝感市,孝南区',
            areaCode: '100004200090020000'
          },
          {
            id: 11173,
            parentId: 3650,
            areaName: '孝昌县',
            areaPath: '中国,湖北省,孝感市,孝昌县',
            areaCode: '100004200090210000'
          },
          {
            id: 11174,
            parentId: 3650,
            areaName: '大悟县',
            areaPath: '中国,湖北省,孝感市,大悟县',
            areaCode: '100004200090220000'
          },
          {
            id: 11175,
            parentId: 3650,
            areaName: '云梦县',
            areaPath: '中国,湖北省,孝感市,云梦县',
            areaCode: '100004200090230000'
          },
          {
            id: 11176,
            parentId: 3650,
            areaName: '应城市',
            areaPath: '中国,湖北省,孝感市,应城市',
            areaCode: '100004200090810000'
          },
          {
            id: 11177,
            parentId: 3650,
            areaName: '安陆市',
            areaPath: '中国,湖北省,孝感市,安陆市',
            areaCode: '100004200090820000'
          },
          {
            id: 11178,
            parentId: 3650,
            areaName: '汉川市',
            areaPath: '中国,湖北省,孝感市,汉川市',
            areaCode: '100004200090840000'
          }
        ]
      },
      {
        id: 3651,
        parentId: 1450,
        areaName: '荆州市',
        areaPath: '中国,湖北省,荆州市',
        areaCode: '100004200100000000',
        children: [
          {
            id: 11179,
            parentId: 3651,
            areaName: '沙市区',
            areaPath: '中国,湖北省,荆州市,沙市区',
            areaCode: '100004200100020000'
          },
          {
            id: 11180,
            parentId: 3651,
            areaName: '荆州区',
            areaPath: '中国,湖北省,荆州市,荆州区',
            areaCode: '100004200100030000'
          },
          {
            id: 11181,
            parentId: 3651,
            areaName: '公安县',
            areaPath: '中国,湖北省,荆州市,公安县',
            areaCode: '100004200100220000'
          },
          {
            id: 11182,
            parentId: 3651,
            areaName: '监利县',
            areaPath: '中国,湖北省,荆州市,监利县',
            areaCode: '100004200100230000'
          },
          {
            id: 11183,
            parentId: 3651,
            areaName: '江陵县',
            areaPath: '中国,湖北省,荆州市,江陵县',
            areaCode: '100004200100240000'
          },
          {
            id: 11184,
            parentId: 3651,
            areaName: '石首市',
            areaPath: '中国,湖北省,荆州市,石首市',
            areaCode: '100004200100810000'
          },
          {
            id: 11185,
            parentId: 3651,
            areaName: '洪湖市',
            areaPath: '中国,湖北省,荆州市,洪湖市',
            areaCode: '100004200100830000'
          },
          {
            id: 11186,
            parentId: 3651,
            areaName: '松滋市',
            areaPath: '中国,湖北省,荆州市,松滋市',
            areaCode: '100004200100870000'
          }
        ]
      },
      {
        id: 3652,
        parentId: 1450,
        areaName: '黄冈市',
        areaPath: '中国,湖北省,黄冈市',
        areaCode: '100004200110000000',
        children: [
          {
            id: 11187,
            parentId: 3652,
            areaName: '黄州区',
            areaPath: '中国,湖北省,黄冈市,黄州区',
            areaCode: '100004200110020000'
          },
          {
            id: 11188,
            parentId: 3652,
            areaName: '团风县',
            areaPath: '中国,湖北省,黄冈市,团风县',
            areaCode: '100004200110210000'
          },
          {
            id: 11189,
            parentId: 3652,
            areaName: '红安县',
            areaPath: '中国,湖北省,黄冈市,红安县',
            areaCode: '100004200110220000'
          },
          {
            id: 11190,
            parentId: 3652,
            areaName: '罗田县',
            areaPath: '中国,湖北省,黄冈市,罗田县',
            areaCode: '100004200110230000'
          },
          {
            id: 11191,
            parentId: 3652,
            areaName: '英山县',
            areaPath: '中国,湖北省,黄冈市,英山县',
            areaCode: '100004200110240000'
          },
          {
            id: 11192,
            parentId: 3652,
            areaName: '浠水县',
            areaPath: '中国,湖北省,黄冈市,浠水县',
            areaCode: '100004200110250000'
          },
          {
            id: 11193,
            parentId: 3652,
            areaName: '蕲春县',
            areaPath: '中国,湖北省,黄冈市,蕲春县',
            areaCode: '100004200110260000'
          },
          {
            id: 11194,
            parentId: 3652,
            areaName: '黄梅县',
            areaPath: '中国,湖北省,黄冈市,黄梅县',
            areaCode: '100004200110270000'
          },
          {
            id: 11195,
            parentId: 3652,
            areaName: '麻城市',
            areaPath: '中国,湖北省,黄冈市,麻城市',
            areaCode: '100004200110810000'
          },
          {
            id: 11196,
            parentId: 3652,
            areaName: '武穴市',
            areaPath: '中国,湖北省,黄冈市,武穴市',
            areaCode: '100004200110820000'
          }
        ]
      },
      {
        id: 3653,
        parentId: 1450,
        areaName: '咸宁市',
        areaPath: '中国,湖北省,咸宁市',
        areaCode: '100004200120000000',
        children: [
          {
            id: 11197,
            parentId: 3653,
            areaName: '咸安区',
            areaPath: '中国,湖北省,咸宁市,咸安区',
            areaCode: '100004200120020000'
          },
          {
            id: 11198,
            parentId: 3653,
            areaName: '嘉鱼县',
            areaPath: '中国,湖北省,咸宁市,嘉鱼县',
            areaCode: '100004200120210000'
          },
          {
            id: 11199,
            parentId: 3653,
            areaName: '通城县',
            areaPath: '中国,湖北省,咸宁市,通城县',
            areaCode: '100004200120220000'
          },
          {
            id: 11200,
            parentId: 3653,
            areaName: '崇阳县',
            areaPath: '中国,湖北省,咸宁市,崇阳县',
            areaCode: '100004200120230000'
          },
          {
            id: 11201,
            parentId: 3653,
            areaName: '通山县',
            areaPath: '中国,湖北省,咸宁市,通山县',
            areaCode: '100004200120240000'
          },
          {
            id: 11202,
            parentId: 3653,
            areaName: '赤壁市',
            areaPath: '中国,湖北省,咸宁市,赤壁市',
            areaCode: '100004200120810000'
          }
        ]
      },
      {
        id: 3654,
        parentId: 1450,
        areaName: '随州市',
        areaPath: '中国,湖北省,随州市',
        areaCode: '100004200130000000',
        children: [
          {
            id: 11203,
            parentId: 3654,
            areaName: '曾都区',
            areaPath: '中国,湖北省,随州市,曾都区',
            areaCode: '100004200130030000'
          },
          {
            id: 11204,
            parentId: 3654,
            areaName: '随县',
            areaPath: '中国,湖北省,随州市,随县',
            areaCode: '100004200130210000'
          },
          {
            id: 11205,
            parentId: 3654,
            areaName: '广水市',
            areaPath: '中国,湖北省,随州市,广水市',
            areaCode: '100004200130810000'
          }
        ]
      },
      {
        id: 3655,
        parentId: 1450,
        areaName: '恩施土家族苗族自治州',
        areaPath: '中国,湖北省,恩施土家族苗族自治州',
        areaCode: '100004200280000000',
        children: [
          {
            id: 11206,
            parentId: 3655,
            areaName: '恩施市',
            areaPath: '中国,湖北省,恩施土家族苗族自治州,恩施市',
            areaCode: '100004200280010000'
          },
          {
            id: 11207,
            parentId: 3655,
            areaName: '利川市',
            areaPath: '中国,湖北省,恩施土家族苗族自治州,利川市',
            areaCode: '100004200280020000'
          },
          {
            id: 11208,
            parentId: 3655,
            areaName: '建始县',
            areaPath: '中国,湖北省,恩施土家族苗族自治州,建始县',
            areaCode: '100004200280220000'
          },
          {
            id: 11209,
            parentId: 3655,
            areaName: '巴东县',
            areaPath: '中国,湖北省,恩施土家族苗族自治州,巴东县',
            areaCode: '100004200280230000'
          },
          {
            id: 11210,
            parentId: 3655,
            areaName: '宣恩县',
            areaPath: '中国,湖北省,恩施土家族苗族自治州,宣恩县',
            areaCode: '100004200280250000'
          },
          {
            id: 11211,
            parentId: 3655,
            areaName: '咸丰县',
            areaPath: '中国,湖北省,恩施土家族苗族自治州,咸丰县',
            areaCode: '100004200280260000'
          },
          {
            id: 11212,
            parentId: 3655,
            areaName: '来凤县',
            areaPath: '中国,湖北省,恩施土家族苗族自治州,来凤县',
            areaCode: '100004200280270000'
          },
          {
            id: 11213,
            parentId: 3655,
            areaName: '鹤峰县',
            areaPath: '中国,湖北省,恩施土家族苗族自治州,鹤峰县',
            areaCode: '100004200280280000'
          }
        ]
      },
      {
        id: 12677,
        parentId: 1450,
        areaName: '省直辖县级行政区划',
        areaPath: '中国,湖北省,省直辖县级行政区划',
        areaCode: '100004200900000000',
        children: [
          {
            id: 3656,
            parentId: 12677,
            areaName: '仙桃市',
            areaPath: '中国,湖北省,省直辖县级行政区划,仙桃市',
            areaCode: '100004200900040000'
          },
          {
            id: 3657,
            parentId: 12677,
            areaName: '潜江市',
            areaPath: '中国,湖北省,省直辖县级行政区划,潜江市',
            areaCode: '100004200900050000'
          },
          {
            id: 3658,
            parentId: 12677,
            areaName: '天门市',
            areaPath: '中国,湖北省,省直辖县级行政区划,天门市',
            areaCode: '100004200900060000'
          },
          {
            id: 3659,
            parentId: 12677,
            areaName: '神农架林区',
            areaPath: '中国,湖北省,省直辖县级行政区划,神农架林区',
            areaCode: '100004200900210000'
          }
        ]
      }
    ]
  },
  {
    id: 1451,
    parentId: 1,
    areaName: '湖南省',
    areaPath: '中国,湖南省',
    areaCode: '100004300000000000',
    children: [
      {
        id: 3660,
        parentId: 1451,
        areaName: '长沙市',
        areaPath: '中国,湖南省,长沙市',
        areaCode: '100004300010000000',
        children: [
          {
            id: 11218,
            parentId: 3660,
            areaName: '芙蓉区',
            areaPath: '中国,湖南省,长沙市,芙蓉区',
            areaCode: '100004300010020000'
          },
          {
            id: 11219,
            parentId: 3660,
            areaName: '天心区',
            areaPath: '中国,湖南省,长沙市,天心区',
            areaCode: '100004300010030000'
          },
          {
            id: 11220,
            parentId: 3660,
            areaName: '岳麓区',
            areaPath: '中国,湖南省,长沙市,岳麓区',
            areaCode: '100004300010040000'
          },
          {
            id: 11221,
            parentId: 3660,
            areaName: '开福区',
            areaPath: '中国,湖南省,长沙市,开福区',
            areaCode: '100004300010050000'
          },
          {
            id: 11222,
            parentId: 3660,
            areaName: '雨花区',
            areaPath: '中国,湖南省,长沙市,雨花区',
            areaCode: '100004300010110000'
          },
          {
            id: 11223,
            parentId: 3660,
            areaName: '望城区',
            areaPath: '中国,湖南省,长沙市,望城区',
            areaCode: '100004300010120000'
          },
          {
            id: 11224,
            parentId: 3660,
            areaName: '长沙县',
            areaPath: '中国,湖南省,长沙市,长沙县',
            areaCode: '100004300010210000'
          },
          {
            id: 11225,
            parentId: 3660,
            areaName: '浏阳市',
            areaPath: '中国,湖南省,长沙市,浏阳市',
            areaCode: '100004300010810000'
          },
          {
            id: 11226,
            parentId: 3660,
            areaName: '宁乡市',
            areaPath: '中国,湖南省,长沙市,宁乡市',
            areaCode: '100004300010820000'
          }
        ]
      },
      {
        id: 3661,
        parentId: 1451,
        areaName: '株洲市',
        areaPath: '中国,湖南省,株洲市',
        areaCode: '100004300020000000',
        children: [
          {
            id: 11227,
            parentId: 3661,
            areaName: '荷塘区',
            areaPath: '中国,湖南省,株洲市,荷塘区',
            areaCode: '100004300020020000'
          },
          {
            id: 11228,
            parentId: 3661,
            areaName: '芦淞区',
            areaPath: '中国,湖南省,株洲市,芦淞区',
            areaCode: '100004300020030000'
          },
          {
            id: 11229,
            parentId: 3661,
            areaName: '石峰区',
            areaPath: '中国,湖南省,株洲市,石峰区',
            areaCode: '100004300020040000'
          },
          {
            id: 11230,
            parentId: 3661,
            areaName: '天元区',
            areaPath: '中国,湖南省,株洲市,天元区',
            areaCode: '100004300020110000'
          },
          {
            id: 11231,
            parentId: 3661,
            areaName: '株洲县',
            areaPath: '中国,湖南省,株洲市,株洲县',
            areaCode: '100004300020210000'
          },
          {
            id: 11232,
            parentId: 3661,
            areaName: '攸县',
            areaPath: '中国,湖南省,株洲市,攸县',
            areaCode: '100004300020230000'
          },
          {
            id: 11233,
            parentId: 3661,
            areaName: '茶陵县',
            areaPath: '中国,湖南省,株洲市,茶陵县',
            areaCode: '100004300020240000'
          },
          {
            id: 11234,
            parentId: 3661,
            areaName: '炎陵县',
            areaPath: '中国,湖南省,株洲市,炎陵县',
            areaCode: '100004300020250000'
          },
          {
            id: 11235,
            parentId: 3661,
            areaName: '醴陵市',
            areaPath: '中国,湖南省,株洲市,醴陵市',
            areaCode: '100004300020810000'
          }
        ]
      },
      {
        id: 3662,
        parentId: 1451,
        areaName: '湘潭市',
        areaPath: '中国,湖南省,湘潭市',
        areaCode: '100004300030000000',
        children: [
          {
            id: 11236,
            parentId: 3662,
            areaName: '雨湖区',
            areaPath: '中国,湖南省,湘潭市,雨湖区',
            areaCode: '100004300030020000'
          },
          {
            id: 11237,
            parentId: 3662,
            areaName: '岳塘区',
            areaPath: '中国,湖南省,湘潭市,岳塘区',
            areaCode: '100004300030040000'
          },
          {
            id: 11238,
            parentId: 3662,
            areaName: '湘潭县',
            areaPath: '中国,湖南省,湘潭市,湘潭县',
            areaCode: '100004300030210000'
          },
          {
            id: 11239,
            parentId: 3662,
            areaName: '湘乡市',
            areaPath: '中国,湖南省,湘潭市,湘乡市',
            areaCode: '100004300030810000'
          },
          {
            id: 11240,
            parentId: 3662,
            areaName: '韶山市',
            areaPath: '中国,湖南省,湘潭市,韶山市',
            areaCode: '100004300030820000'
          }
        ]
      },
      {
        id: 3663,
        parentId: 1451,
        areaName: '衡阳市',
        areaPath: '中国,湖南省,衡阳市',
        areaCode: '100004300040000000',
        children: [
          {
            id: 11241,
            parentId: 3663,
            areaName: '珠晖区',
            areaPath: '中国,湖南省,衡阳市,珠晖区',
            areaCode: '100004300040050000'
          },
          {
            id: 11242,
            parentId: 3663,
            areaName: '雁峰区',
            areaPath: '中国,湖南省,衡阳市,雁峰区',
            areaCode: '100004300040060000'
          },
          {
            id: 11243,
            parentId: 3663,
            areaName: '石鼓区',
            areaPath: '中国,湖南省,衡阳市,石鼓区',
            areaCode: '100004300040070000'
          },
          {
            id: 11244,
            parentId: 3663,
            areaName: '蒸湘区',
            areaPath: '中国,湖南省,衡阳市,蒸湘区',
            areaCode: '100004300040080000'
          },
          {
            id: 11245,
            parentId: 3663,
            areaName: '南岳区',
            areaPath: '中国,湖南省,衡阳市,南岳区',
            areaCode: '100004300040120000'
          },
          {
            id: 11246,
            parentId: 3663,
            areaName: '衡阳县',
            areaPath: '中国,湖南省,衡阳市,衡阳县',
            areaCode: '100004300040210000'
          },
          {
            id: 11247,
            parentId: 3663,
            areaName: '衡南县',
            areaPath: '中国,湖南省,衡阳市,衡南县',
            areaCode: '100004300040220000'
          },
          {
            id: 11248,
            parentId: 3663,
            areaName: '衡山县',
            areaPath: '中国,湖南省,衡阳市,衡山县',
            areaCode: '100004300040230000'
          },
          {
            id: 11249,
            parentId: 3663,
            areaName: '衡东县',
            areaPath: '中国,湖南省,衡阳市,衡东县',
            areaCode: '100004300040240000'
          },
          {
            id: 11250,
            parentId: 3663,
            areaName: '祁东县',
            areaPath: '中国,湖南省,衡阳市,祁东县',
            areaCode: '100004300040260000'
          },
          {
            id: 11251,
            parentId: 3663,
            areaName: '耒阳市',
            areaPath: '中国,湖南省,衡阳市,耒阳市',
            areaCode: '100004300040810000'
          },
          {
            id: 11252,
            parentId: 3663,
            areaName: '常宁市',
            areaPath: '中国,湖南省,衡阳市,常宁市',
            areaCode: '100004300040820000'
          }
        ]
      },
      {
        id: 3664,
        parentId: 1451,
        areaName: '邵阳市',
        areaPath: '中国,湖南省,邵阳市',
        areaCode: '100004300050000000',
        children: [
          {
            id: 11253,
            parentId: 3664,
            areaName: '双清区',
            areaPath: '中国,湖南省,邵阳市,双清区',
            areaCode: '100004300050020000'
          },
          {
            id: 11254,
            parentId: 3664,
            areaName: '大祥区',
            areaPath: '中国,湖南省,邵阳市,大祥区',
            areaCode: '100004300050030000'
          },
          {
            id: 11255,
            parentId: 3664,
            areaName: '北塔区',
            areaPath: '中国,湖南省,邵阳市,北塔区',
            areaCode: '100004300050110000'
          },
          {
            id: 11256,
            parentId: 3664,
            areaName: '邵东县',
            areaPath: '中国,湖南省,邵阳市,邵东县',
            areaCode: '100004300050210000'
          },
          {
            id: 11257,
            parentId: 3664,
            areaName: '新邵县',
            areaPath: '中国,湖南省,邵阳市,新邵县',
            areaCode: '100004300050220000'
          },
          {
            id: 11258,
            parentId: 3664,
            areaName: '邵阳县',
            areaPath: '中国,湖南省,邵阳市,邵阳县',
            areaCode: '100004300050230000'
          },
          {
            id: 11259,
            parentId: 3664,
            areaName: '隆回县',
            areaPath: '中国,湖南省,邵阳市,隆回县',
            areaCode: '100004300050240000'
          },
          {
            id: 11260,
            parentId: 3664,
            areaName: '洞口县',
            areaPath: '中国,湖南省,邵阳市,洞口县',
            areaCode: '100004300050250000'
          },
          {
            id: 11261,
            parentId: 3664,
            areaName: '绥宁县',
            areaPath: '中国,湖南省,邵阳市,绥宁县',
            areaCode: '100004300050270000'
          },
          {
            id: 11262,
            parentId: 3664,
            areaName: '新宁县',
            areaPath: '中国,湖南省,邵阳市,新宁县',
            areaCode: '100004300050280000'
          },
          {
            id: 11263,
            parentId: 3664,
            areaName: '城步苗族自治县',
            areaPath: '中国,湖南省,邵阳市,城步苗族自治县',
            areaCode: '100004300050290000'
          },
          {
            id: 11264,
            parentId: 3664,
            areaName: '武冈市',
            areaPath: '中国,湖南省,邵阳市,武冈市',
            areaCode: '100004300050810000'
          }
        ]
      },
      {
        id: 3665,
        parentId: 1451,
        areaName: '岳阳市',
        areaPath: '中国,湖南省,岳阳市',
        areaCode: '100004300060000000',
        children: [
          {
            id: 11265,
            parentId: 3665,
            areaName: '岳阳楼区',
            areaPath: '中国,湖南省,岳阳市,岳阳楼区',
            areaCode: '100004300060020000'
          },
          {
            id: 11266,
            parentId: 3665,
            areaName: '云溪区',
            areaPath: '中国,湖南省,岳阳市,云溪区',
            areaCode: '100004300060030000'
          },
          {
            id: 11267,
            parentId: 3665,
            areaName: '君山区',
            areaPath: '中国,湖南省,岳阳市,君山区',
            areaCode: '100004300060110000'
          },
          {
            id: 11268,
            parentId: 3665,
            areaName: '岳阳县',
            areaPath: '中国,湖南省,岳阳市,岳阳县',
            areaCode: '100004300060210000'
          },
          {
            id: 11269,
            parentId: 3665,
            areaName: '华容县',
            areaPath: '中国,湖南省,岳阳市,华容县',
            areaCode: '100004300060230000'
          },
          {
            id: 11270,
            parentId: 3665,
            areaName: '湘阴县',
            areaPath: '中国,湖南省,岳阳市,湘阴县',
            areaCode: '100004300060240000'
          },
          {
            id: 11271,
            parentId: 3665,
            areaName: '平江县',
            areaPath: '中国,湖南省,岳阳市,平江县',
            areaCode: '100004300060260000'
          },
          {
            id: 11272,
            parentId: 3665,
            areaName: '汨罗市',
            areaPath: '中国,湖南省,岳阳市,汨罗市',
            areaCode: '100004300060810000'
          },
          {
            id: 11273,
            parentId: 3665,
            areaName: '临湘市',
            areaPath: '中国,湖南省,岳阳市,临湘市',
            areaCode: '100004300060820000'
          }
        ]
      },
      {
        id: 3666,
        parentId: 1451,
        areaName: '常德市',
        areaPath: '中国,湖南省,常德市',
        areaCode: '100004300070000000',
        children: [
          {
            id: 11274,
            parentId: 3666,
            areaName: '武陵区',
            areaPath: '中国,湖南省,常德市,武陵区',
            areaCode: '100004300070020000'
          },
          {
            id: 11275,
            parentId: 3666,
            areaName: '鼎城区',
            areaPath: '中国,湖南省,常德市,鼎城区',
            areaCode: '100004300070030000'
          },
          {
            id: 11276,
            parentId: 3666,
            areaName: '安乡县',
            areaPath: '中国,湖南省,常德市,安乡县',
            areaCode: '100004300070210000'
          },
          {
            id: 11277,
            parentId: 3666,
            areaName: '汉寿县',
            areaPath: '中国,湖南省,常德市,汉寿县',
            areaCode: '100004300070220000'
          },
          {
            id: 11278,
            parentId: 3666,
            areaName: '澧县',
            areaPath: '中国,湖南省,常德市,澧县',
            areaCode: '100004300070230000'
          },
          {
            id: 11279,
            parentId: 3666,
            areaName: '临澧县',
            areaPath: '中国,湖南省,常德市,临澧县',
            areaCode: '100004300070240000'
          },
          {
            id: 11280,
            parentId: 3666,
            areaName: '桃源县',
            areaPath: '中国,湖南省,常德市,桃源县',
            areaCode: '100004300070250000'
          },
          {
            id: 11281,
            parentId: 3666,
            areaName: '石门县',
            areaPath: '中国,湖南省,常德市,石门县',
            areaCode: '100004300070260000'
          },
          {
            id: 11282,
            parentId: 3666,
            areaName: '津市市',
            areaPath: '中国,湖南省,常德市,津市市',
            areaCode: '100004300070810000'
          }
        ]
      },
      {
        id: 3667,
        parentId: 1451,
        areaName: '张家界市',
        areaPath: '中国,湖南省,张家界市',
        areaCode: '100004300080000000',
        children: [
          {
            id: 11283,
            parentId: 3667,
            areaName: '永定区',
            areaPath: '中国,湖南省,张家界市,永定区',
            areaCode: '100004300080020000'
          },
          {
            id: 11284,
            parentId: 3667,
            areaName: '武陵源区',
            areaPath: '中国,湖南省,张家界市,武陵源区',
            areaCode: '100004300080110000'
          },
          {
            id: 11285,
            parentId: 3667,
            areaName: '慈利县',
            areaPath: '中国,湖南省,张家界市,慈利县',
            areaCode: '100004300080210000'
          },
          {
            id: 11286,
            parentId: 3667,
            areaName: '桑植县',
            areaPath: '中国,湖南省,张家界市,桑植县',
            areaCode: '100004300080220000'
          }
        ]
      },
      {
        id: 3668,
        parentId: 1451,
        areaName: '益阳市',
        areaPath: '中国,湖南省,益阳市',
        areaCode: '100004300090000000',
        children: [
          {
            id: 11287,
            parentId: 3668,
            areaName: '资阳区',
            areaPath: '中国,湖南省,益阳市,资阳区',
            areaCode: '100004300090020000'
          },
          {
            id: 11288,
            parentId: 3668,
            areaName: '赫山区',
            areaPath: '中国,湖南省,益阳市,赫山区',
            areaCode: '100004300090030000'
          },
          {
            id: 11289,
            parentId: 3668,
            areaName: '南县',
            areaPath: '中国,湖南省,益阳市,南县',
            areaCode: '100004300090210000'
          },
          {
            id: 11290,
            parentId: 3668,
            areaName: '桃江县',
            areaPath: '中国,湖南省,益阳市,桃江县',
            areaCode: '100004300090220000'
          },
          {
            id: 11291,
            parentId: 3668,
            areaName: '安化县',
            areaPath: '中国,湖南省,益阳市,安化县',
            areaCode: '100004300090230000'
          },
          {
            id: 11292,
            parentId: 3668,
            areaName: '沅江市',
            areaPath: '中国,湖南省,益阳市,沅江市',
            areaCode: '100004300090810000'
          }
        ]
      },
      {
        id: 3669,
        parentId: 1451,
        areaName: '郴州市',
        areaPath: '中国,湖南省,郴州市',
        areaCode: '100004300100000000',
        children: [
          {
            id: 11293,
            parentId: 3669,
            areaName: '北湖区',
            areaPath: '中国,湖南省,郴州市,北湖区',
            areaCode: '100004300100020000'
          },
          {
            id: 11294,
            parentId: 3669,
            areaName: '苏仙区',
            areaPath: '中国,湖南省,郴州市,苏仙区',
            areaCode: '100004300100030000'
          },
          {
            id: 11295,
            parentId: 3669,
            areaName: '桂阳县',
            areaPath: '中国,湖南省,郴州市,桂阳县',
            areaCode: '100004300100210000'
          },
          {
            id: 11296,
            parentId: 3669,
            areaName: '宜章县',
            areaPath: '中国,湖南省,郴州市,宜章县',
            areaCode: '100004300100220000'
          },
          {
            id: 11297,
            parentId: 3669,
            areaName: '永兴县',
            areaPath: '中国,湖南省,郴州市,永兴县',
            areaCode: '100004300100230000'
          },
          {
            id: 11298,
            parentId: 3669,
            areaName: '嘉禾县',
            areaPath: '中国,湖南省,郴州市,嘉禾县',
            areaCode: '100004300100240000'
          },
          {
            id: 11299,
            parentId: 3669,
            areaName: '临武县',
            areaPath: '中国,湖南省,郴州市,临武县',
            areaCode: '100004300100250000'
          },
          {
            id: 11300,
            parentId: 3669,
            areaName: '汝城县',
            areaPath: '中国,湖南省,郴州市,汝城县',
            areaCode: '100004300100260000'
          },
          {
            id: 11301,
            parentId: 3669,
            areaName: '桂东县',
            areaPath: '中国,湖南省,郴州市,桂东县',
            areaCode: '100004300100270000'
          },
          {
            id: 11302,
            parentId: 3669,
            areaName: '安仁县',
            areaPath: '中国,湖南省,郴州市,安仁县',
            areaCode: '100004300100280000'
          },
          {
            id: 11303,
            parentId: 3669,
            areaName: '资兴市',
            areaPath: '中国,湖南省,郴州市,资兴市',
            areaCode: '100004300100810000'
          }
        ]
      },
      {
        id: 3670,
        parentId: 1451,
        areaName: '永州市',
        areaPath: '中国,湖南省,永州市',
        areaCode: '100004300110000000',
        children: [
          {
            id: 11304,
            parentId: 3670,
            areaName: '零陵区',
            areaPath: '中国,湖南省,永州市,零陵区',
            areaCode: '100004300110020000'
          },
          {
            id: 11305,
            parentId: 3670,
            areaName: '冷水滩区',
            areaPath: '中国,湖南省,永州市,冷水滩区',
            areaCode: '100004300110030000'
          },
          {
            id: 11306,
            parentId: 3670,
            areaName: '祁阳县',
            areaPath: '中国,湖南省,永州市,祁阳县',
            areaCode: '100004300110210000'
          },
          {
            id: 11307,
            parentId: 3670,
            areaName: '东安县',
            areaPath: '中国,湖南省,永州市,东安县',
            areaCode: '100004300110220000'
          },
          {
            id: 11308,
            parentId: 3670,
            areaName: '双牌县',
            areaPath: '中国,湖南省,永州市,双牌县',
            areaCode: '100004300110230000'
          },
          {
            id: 11309,
            parentId: 3670,
            areaName: '道县',
            areaPath: '中国,湖南省,永州市,道县',
            areaCode: '100004300110240000'
          },
          {
            id: 11310,
            parentId: 3670,
            areaName: '江永县',
            areaPath: '中国,湖南省,永州市,江永县',
            areaCode: '100004300110250000'
          },
          {
            id: 11311,
            parentId: 3670,
            areaName: '宁远县',
            areaPath: '中国,湖南省,永州市,宁远县',
            areaCode: '100004300110260000'
          },
          {
            id: 11312,
            parentId: 3670,
            areaName: '蓝山县',
            areaPath: '中国,湖南省,永州市,蓝山县',
            areaCode: '100004300110270000'
          },
          {
            id: 11313,
            parentId: 3670,
            areaName: '新田县',
            areaPath: '中国,湖南省,永州市,新田县',
            areaCode: '100004300110280000'
          },
          {
            id: 11314,
            parentId: 3670,
            areaName: '江华瑶族自治县',
            areaPath: '中国,湖南省,永州市,江华瑶族自治县',
            areaCode: '100004300110290000'
          }
        ]
      },
      {
        id: 3671,
        parentId: 1451,
        areaName: '怀化市',
        areaPath: '中国,湖南省,怀化市',
        areaCode: '100004300120000000',
        children: [
          {
            id: 11315,
            parentId: 3671,
            areaName: '鹤城区',
            areaPath: '中国,湖南省,怀化市,鹤城区',
            areaCode: '100004300120020000'
          },
          {
            id: 11316,
            parentId: 3671,
            areaName: '中方县',
            areaPath: '中国,湖南省,怀化市,中方县',
            areaCode: '100004300120210000'
          },
          {
            id: 11317,
            parentId: 3671,
            areaName: '沅陵县',
            areaPath: '中国,湖南省,怀化市,沅陵县',
            areaCode: '100004300120220000'
          },
          {
            id: 11318,
            parentId: 3671,
            areaName: '辰溪县',
            areaPath: '中国,湖南省,怀化市,辰溪县',
            areaCode: '100004300120230000'
          },
          {
            id: 11319,
            parentId: 3671,
            areaName: '溆浦县',
            areaPath: '中国,湖南省,怀化市,溆浦县',
            areaCode: '100004300120240000'
          },
          {
            id: 11320,
            parentId: 3671,
            areaName: '会同县',
            areaPath: '中国,湖南省,怀化市,会同县',
            areaCode: '100004300120250000'
          },
          {
            id: 11321,
            parentId: 3671,
            areaName: '麻阳苗族自治县',
            areaPath: '中国,湖南省,怀化市,麻阳苗族自治县',
            areaCode: '100004300120260000'
          },
          {
            id: 11322,
            parentId: 3671,
            areaName: '新晃侗族自治县',
            areaPath: '中国,湖南省,怀化市,新晃侗族自治县',
            areaCode: '100004300120270000'
          },
          {
            id: 11323,
            parentId: 3671,
            areaName: '芷江侗族自治县',
            areaPath: '中国,湖南省,怀化市,芷江侗族自治县',
            areaCode: '100004300120280000'
          },
          {
            id: 11324,
            parentId: 3671,
            areaName: '靖州苗族侗族自治县',
            areaPath: '中国,湖南省,怀化市,靖州苗族侗族自治县',
            areaCode: '100004300120290000'
          },
          {
            id: 11325,
            parentId: 3671,
            areaName: '通道侗族自治县',
            areaPath: '中国,湖南省,怀化市,通道侗族自治县',
            areaCode: '100004300120300000'
          },
          {
            id: 11326,
            parentId: 3671,
            areaName: '洪江市',
            areaPath: '中国,湖南省,怀化市,洪江市',
            areaCode: '100004300120810000'
          }
        ]
      },
      {
        id: 3672,
        parentId: 1451,
        areaName: '娄底市',
        areaPath: '中国,湖南省,娄底市',
        areaCode: '100004300130000000',
        children: [
          {
            id: 11327,
            parentId: 3672,
            areaName: '娄星区',
            areaPath: '中国,湖南省,娄底市,娄星区',
            areaCode: '100004300130020000'
          },
          {
            id: 11328,
            parentId: 3672,
            areaName: '双峰县',
            areaPath: '中国,湖南省,娄底市,双峰县',
            areaCode: '100004300130210000'
          },
          {
            id: 11329,
            parentId: 3672,
            areaName: '新化县',
            areaPath: '中国,湖南省,娄底市,新化县',
            areaCode: '100004300130220000'
          },
          {
            id: 11330,
            parentId: 3672,
            areaName: '冷水江市',
            areaPath: '中国,湖南省,娄底市,冷水江市',
            areaCode: '100004300130810000'
          },
          {
            id: 11331,
            parentId: 3672,
            areaName: '涟源市',
            areaPath: '中国,湖南省,娄底市,涟源市',
            areaCode: '100004300130820000'
          }
        ]
      },
      {
        id: 3673,
        parentId: 1451,
        areaName: '湘西土家族苗族自治州',
        areaPath: '中国,湖南省,湘西土家族苗族自治州',
        areaCode: '100004300310000000',
        children: [
          {
            id: 11332,
            parentId: 3673,
            areaName: '吉首市',
            areaPath: '中国,湖南省,湘西土家族苗族自治州,吉首市',
            areaCode: '100004300310010000'
          },
          {
            id: 11333,
            parentId: 3673,
            areaName: '泸溪县',
            areaPath: '中国,湖南省,湘西土家族苗族自治州,泸溪县',
            areaCode: '100004300310220000'
          },
          {
            id: 11334,
            parentId: 3673,
            areaName: '凤凰县',
            areaPath: '中国,湖南省,湘西土家族苗族自治州,凤凰县',
            areaCode: '100004300310230000'
          },
          {
            id: 11335,
            parentId: 3673,
            areaName: '花垣县',
            areaPath: '中国,湖南省,湘西土家族苗族自治州,花垣县',
            areaCode: '100004300310240000'
          },
          {
            id: 11336,
            parentId: 3673,
            areaName: '保靖县',
            areaPath: '中国,湖南省,湘西土家族苗族自治州,保靖县',
            areaCode: '100004300310250000'
          },
          {
            id: 11337,
            parentId: 3673,
            areaName: '古丈县',
            areaPath: '中国,湖南省,湘西土家族苗族自治州,古丈县',
            areaCode: '100004300310260000'
          },
          {
            id: 11338,
            parentId: 3673,
            areaName: '永顺县',
            areaPath: '中国,湖南省,湘西土家族苗族自治州,永顺县',
            areaCode: '100004300310270000'
          },
          {
            id: 11339,
            parentId: 3673,
            areaName: '龙山县',
            areaPath: '中国,湖南省,湘西土家族苗族自治州,龙山县',
            areaCode: '100004300310300000'
          }
        ]
      }
    ]
  },
  {
    id: 1452,
    parentId: 1,
    areaName: '广东省',
    areaPath: '中国,广东省',
    areaCode: '100004400000000000',
    children: [
      {
        id: 3674,
        parentId: 1452,
        areaName: '广州市',
        areaPath: '中国,广东省,广州市',
        areaCode: '100004400010000000',
        children: [
          {
            id: 11340,
            parentId: 3674,
            areaName: '荔湾区',
            areaPath: '中国,广东省,广州市,荔湾区',
            areaCode: '100004400010030000'
          },
          {
            id: 11341,
            parentId: 3674,
            areaName: '越秀区',
            areaPath: '中国,广东省,广州市,越秀区',
            areaCode: '100004400010040000'
          },
          {
            id: 11342,
            parentId: 3674,
            areaName: '海珠区',
            areaPath: '中国,广东省,广州市,海珠区',
            areaCode: '100004400010050000'
          },
          {
            id: 11343,
            parentId: 3674,
            areaName: '天河区',
            areaPath: '中国,广东省,广州市,天河区',
            areaCode: '100004400010060000'
          },
          {
            id: 11344,
            parentId: 3674,
            areaName: '白云区',
            areaPath: '中国,广东省,广州市,白云区',
            areaCode: '100004400010110000'
          },
          {
            id: 11345,
            parentId: 3674,
            areaName: '黄埔区',
            areaPath: '中国,广东省,广州市,黄埔区',
            areaCode: '100004400010120000'
          },
          {
            id: 11346,
            parentId: 3674,
            areaName: '番禺区',
            areaPath: '中国,广东省,广州市,番禺区',
            areaCode: '100004400010130000'
          },
          {
            id: 11347,
            parentId: 3674,
            areaName: '花都区',
            areaPath: '中国,广东省,广州市,花都区',
            areaCode: '100004400010140000'
          },
          {
            id: 11348,
            parentId: 3674,
            areaName: '南沙区',
            areaPath: '中国,广东省,广州市,南沙区',
            areaCode: '100004400010150000'
          },
          {
            id: 11349,
            parentId: 3674,
            areaName: '从化区',
            areaPath: '中国,广东省,广州市,从化区',
            areaCode: '100004400010170000'
          },
          {
            id: 11350,
            parentId: 3674,
            areaName: '增城区',
            areaPath: '中国,广东省,广州市,增城区',
            areaCode: '100004400010180000'
          }
        ]
      },
      {
        id: 3675,
        parentId: 1452,
        areaName: '韶关市',
        areaPath: '中国,广东省,韶关市',
        areaCode: '100004400020000000',
        children: [
          {
            id: 11351,
            parentId: 3675,
            areaName: '武江区',
            areaPath: '中国,广东省,韶关市,武江区',
            areaCode: '100004400020030000'
          },
          {
            id: 11352,
            parentId: 3675,
            areaName: '浈江区',
            areaPath: '中国,广东省,韶关市,浈江区',
            areaCode: '100004400020040000'
          },
          {
            id: 11353,
            parentId: 3675,
            areaName: '曲江区',
            areaPath: '中国,广东省,韶关市,曲江区',
            areaCode: '100004400020050000'
          },
          {
            id: 11354,
            parentId: 3675,
            areaName: '始兴县',
            areaPath: '中国,广东省,韶关市,始兴县',
            areaCode: '100004400020220000'
          },
          {
            id: 11355,
            parentId: 3675,
            areaName: '仁化县',
            areaPath: '中国,广东省,韶关市,仁化县',
            areaCode: '100004400020240000'
          },
          {
            id: 11356,
            parentId: 3675,
            areaName: '翁源县',
            areaPath: '中国,广东省,韶关市,翁源县',
            areaCode: '100004400020290000'
          },
          {
            id: 11357,
            parentId: 3675,
            areaName: '乳源瑶族自治县',
            areaPath: '中国,广东省,韶关市,乳源瑶族自治县',
            areaCode: '100004400020320000'
          },
          {
            id: 11358,
            parentId: 3675,
            areaName: '新丰县',
            areaPath: '中国,广东省,韶关市,新丰县',
            areaCode: '100004400020330000'
          },
          {
            id: 11359,
            parentId: 3675,
            areaName: '乐昌市',
            areaPath: '中国,广东省,韶关市,乐昌市',
            areaCode: '100004400020810000'
          },
          {
            id: 11360,
            parentId: 3675,
            areaName: '南雄市',
            areaPath: '中国,广东省,韶关市,南雄市',
            areaCode: '100004400020820000'
          }
        ]
      },
      {
        id: 3676,
        parentId: 1452,
        areaName: '深圳市',
        areaPath: '中国,广东省,深圳市',
        areaCode: '100004400030000000',
        children: [
          {
            id: 11361,
            parentId: 3676,
            areaName: '罗湖区',
            areaPath: '中国,广东省,深圳市,罗湖区',
            areaCode: '100004400030030000'
          },
          {
            id: 11362,
            parentId: 3676,
            areaName: '福田区',
            areaPath: '中国,广东省,深圳市,福田区',
            areaCode: '100004400030040000'
          },
          {
            id: 11363,
            parentId: 3676,
            areaName: '南山区',
            areaPath: '中国,广东省,深圳市,南山区',
            areaCode: '100004400030050000'
          },
          {
            id: 11364,
            parentId: 3676,
            areaName: '宝安区',
            areaPath: '中国,广东省,深圳市,宝安区',
            areaCode: '100004400030060000'
          },
          {
            id: 11365,
            parentId: 3676,
            areaName: '龙岗区',
            areaPath: '中国,广东省,深圳市,龙岗区',
            areaCode: '100004400030070000'
          },
          {
            id: 11366,
            parentId: 3676,
            areaName: '盐田区',
            areaPath: '中国,广东省,深圳市,盐田区',
            areaCode: '100004400030080000'
          },
          {
            id: 11367,
            parentId: 3676,
            areaName: '龙华区',
            areaPath: '中国,广东省,深圳市,龙华区',
            areaCode: '100004400030090000'
          },
          {
            id: 11368,
            parentId: 3676,
            areaName: '坪山区',
            areaPath: '中国,广东省,深圳市,坪山区',
            areaCode: '100004400030100000'
          }
        ]
      },
      {
        id: 3677,
        parentId: 1452,
        areaName: '珠海市',
        areaPath: '中国,广东省,珠海市',
        areaCode: '100004400040000000',
        children: [
          {
            id: 11369,
            parentId: 3677,
            areaName: '香洲区',
            areaPath: '中国,广东省,珠海市,香洲区',
            areaCode: '100004400040020000'
          },
          {
            id: 11370,
            parentId: 3677,
            areaName: '斗门区',
            areaPath: '中国,广东省,珠海市,斗门区',
            areaCode: '100004400040030000'
          },
          {
            id: 11371,
            parentId: 3677,
            areaName: '金湾区',
            areaPath: '中国,广东省,珠海市,金湾区',
            areaCode: '100004400040040000'
          }
        ]
      },
      {
        id: 3678,
        parentId: 1452,
        areaName: '汕头市',
        areaPath: '中国,广东省,汕头市',
        areaCode: '100004400050000000',
        children: [
          {
            id: 11372,
            parentId: 3678,
            areaName: '龙湖区',
            areaPath: '中国,广东省,汕头市,龙湖区',
            areaCode: '100004400050070000'
          },
          {
            id: 11373,
            parentId: 3678,
            areaName: '金平区',
            areaPath: '中国,广东省,汕头市,金平区',
            areaCode: '100004400050110000'
          },
          {
            id: 11374,
            parentId: 3678,
            areaName: '濠江区',
            areaPath: '中国,广东省,汕头市,濠江区',
            areaCode: '100004400050120000'
          },
          {
            id: 11375,
            parentId: 3678,
            areaName: '潮阳区',
            areaPath: '中国,广东省,汕头市,潮阳区',
            areaCode: '100004400050130000'
          },
          {
            id: 11376,
            parentId: 3678,
            areaName: '潮南区',
            areaPath: '中国,广东省,汕头市,潮南区',
            areaCode: '100004400050140000'
          },
          {
            id: 11377,
            parentId: 3678,
            areaName: '澄海区',
            areaPath: '中国,广东省,汕头市,澄海区',
            areaCode: '100004400050150000'
          },
          {
            id: 11378,
            parentId: 3678,
            areaName: '南澳县',
            areaPath: '中国,广东省,汕头市,南澳县',
            areaCode: '100004400050230000'
          }
        ]
      },
      {
        id: 3679,
        parentId: 1452,
        areaName: '佛山市',
        areaPath: '中国,广东省,佛山市',
        areaCode: '100004400060000000',
        children: [
          {
            id: 11379,
            parentId: 3679,
            areaName: '禅城区',
            areaPath: '中国,广东省,佛山市,禅城区',
            areaCode: '100004400060040000'
          },
          {
            id: 11380,
            parentId: 3679,
            areaName: '南海区',
            areaPath: '中国,广东省,佛山市,南海区',
            areaCode: '100004400060050000'
          },
          {
            id: 11381,
            parentId: 3679,
            areaName: '顺德区',
            areaPath: '中国,广东省,佛山市,顺德区',
            areaCode: '100004400060060000'
          },
          {
            id: 11382,
            parentId: 3679,
            areaName: '三水区',
            areaPath: '中国,广东省,佛山市,三水区',
            areaCode: '100004400060070000'
          },
          {
            id: 11383,
            parentId: 3679,
            areaName: '高明区',
            areaPath: '中国,广东省,佛山市,高明区',
            areaCode: '100004400060080000'
          }
        ]
      },
      {
        id: 3680,
        parentId: 1452,
        areaName: '江门市',
        areaPath: '中国,广东省,江门市',
        areaCode: '100004400070000000',
        children: [
          {
            id: 11384,
            parentId: 3680,
            areaName: '蓬江区',
            areaPath: '中国,广东省,江门市,蓬江区',
            areaCode: '100004400070030000'
          },
          {
            id: 11385,
            parentId: 3680,
            areaName: '江海区',
            areaPath: '中国,广东省,江门市,江海区',
            areaCode: '100004400070040000'
          },
          {
            id: 11386,
            parentId: 3680,
            areaName: '新会区',
            areaPath: '中国,广东省,江门市,新会区',
            areaCode: '100004400070050000'
          },
          {
            id: 11387,
            parentId: 3680,
            areaName: '台山市',
            areaPath: '中国,广东省,江门市,台山市',
            areaCode: '100004400070810000'
          },
          {
            id: 11388,
            parentId: 3680,
            areaName: '开平市',
            areaPath: '中国,广东省,江门市,开平市',
            areaCode: '100004400070830000'
          },
          {
            id: 11389,
            parentId: 3680,
            areaName: '鹤山市',
            areaPath: '中国,广东省,江门市,鹤山市',
            areaCode: '100004400070840000'
          },
          {
            id: 11390,
            parentId: 3680,
            areaName: '恩平市',
            areaPath: '中国,广东省,江门市,恩平市',
            areaCode: '100004400070850000'
          }
        ]
      },
      {
        id: 3681,
        parentId: 1452,
        areaName: '湛江市',
        areaPath: '中国,广东省,湛江市',
        areaCode: '100004400080000000',
        children: [
          {
            id: 11391,
            parentId: 3681,
            areaName: '赤坎区',
            areaPath: '中国,广东省,湛江市,赤坎区',
            areaCode: '100004400080020000'
          },
          {
            id: 11392,
            parentId: 3681,
            areaName: '霞山区',
            areaPath: '中国,广东省,湛江市,霞山区',
            areaCode: '100004400080030000'
          },
          {
            id: 11393,
            parentId: 3681,
            areaName: '坡头区',
            areaPath: '中国,广东省,湛江市,坡头区',
            areaCode: '100004400080040000'
          },
          {
            id: 11394,
            parentId: 3681,
            areaName: '麻章区',
            areaPath: '中国,广东省,湛江市,麻章区',
            areaCode: '100004400080110000'
          },
          {
            id: 11395,
            parentId: 3681,
            areaName: '遂溪县',
            areaPath: '中国,广东省,湛江市,遂溪县',
            areaCode: '100004400080230000'
          },
          {
            id: 11396,
            parentId: 3681,
            areaName: '徐闻县',
            areaPath: '中国,广东省,湛江市,徐闻县',
            areaCode: '100004400080250000'
          },
          {
            id: 11397,
            parentId: 3681,
            areaName: '廉江市',
            areaPath: '中国,广东省,湛江市,廉江市',
            areaCode: '100004400080810000'
          },
          {
            id: 11398,
            parentId: 3681,
            areaName: '雷州市',
            areaPath: '中国,广东省,湛江市,雷州市',
            areaCode: '100004400080820000'
          },
          {
            id: 11399,
            parentId: 3681,
            areaName: '吴川市',
            areaPath: '中国,广东省,湛江市,吴川市',
            areaCode: '100004400080830000'
          }
        ]
      },
      {
        id: 3682,
        parentId: 1452,
        areaName: '茂名市',
        areaPath: '中国,广东省,茂名市',
        areaCode: '100004400090000000',
        children: [
          {
            id: 11400,
            parentId: 3682,
            areaName: '茂南区',
            areaPath: '中国,广东省,茂名市,茂南区',
            areaCode: '100004400090020000'
          },
          {
            id: 11401,
            parentId: 3682,
            areaName: '电白区',
            areaPath: '中国,广东省,茂名市,电白区',
            areaCode: '100004400090040000'
          },
          {
            id: 11402,
            parentId: 3682,
            areaName: '高州市',
            areaPath: '中国,广东省,茂名市,高州市',
            areaCode: '100004400090810000'
          },
          {
            id: 11403,
            parentId: 3682,
            areaName: '化州市',
            areaPath: '中国,广东省,茂名市,化州市',
            areaCode: '100004400090820000'
          },
          {
            id: 11404,
            parentId: 3682,
            areaName: '信宜市',
            areaPath: '中国,广东省,茂名市,信宜市',
            areaCode: '100004400090830000'
          }
        ]
      },
      {
        id: 3683,
        parentId: 1452,
        areaName: '肇庆市',
        areaPath: '中国,广东省,肇庆市',
        areaCode: '100004400120000000',
        children: [
          {
            id: 11405,
            parentId: 3683,
            areaName: '端州区',
            areaPath: '中国,广东省,肇庆市,端州区',
            areaCode: '100004400120020000'
          },
          {
            id: 11406,
            parentId: 3683,
            areaName: '鼎湖区',
            areaPath: '中国,广东省,肇庆市,鼎湖区',
            areaCode: '100004400120030000'
          },
          {
            id: 11407,
            parentId: 3683,
            areaName: '高要区',
            areaPath: '中国,广东省,肇庆市,高要区',
            areaCode: '100004400120040000'
          },
          {
            id: 11408,
            parentId: 3683,
            areaName: '广宁县',
            areaPath: '中国,广东省,肇庆市,广宁县',
            areaCode: '100004400120230000'
          },
          {
            id: 11409,
            parentId: 3683,
            areaName: '怀集县',
            areaPath: '中国,广东省,肇庆市,怀集县',
            areaCode: '100004400120240000'
          },
          {
            id: 11410,
            parentId: 3683,
            areaName: '封开县',
            areaPath: '中国,广东省,肇庆市,封开县',
            areaCode: '100004400120250000'
          },
          {
            id: 11411,
            parentId: 3683,
            areaName: '德庆县',
            areaPath: '中国,广东省,肇庆市,德庆县',
            areaCode: '100004400120260000'
          },
          {
            id: 11412,
            parentId: 3683,
            areaName: '四会市',
            areaPath: '中国,广东省,肇庆市,四会市',
            areaCode: '100004400120840000'
          }
        ]
      },
      {
        id: 3684,
        parentId: 1452,
        areaName: '惠州市',
        areaPath: '中国,广东省,惠州市',
        areaCode: '100004400130000000',
        children: [
          {
            id: 11413,
            parentId: 3684,
            areaName: '惠城区',
            areaPath: '中国,广东省,惠州市,惠城区',
            areaCode: '100004400130020000'
          },
          {
            id: 11414,
            parentId: 3684,
            areaName: '惠阳区',
            areaPath: '中国,广东省,惠州市,惠阳区',
            areaCode: '100004400130030000'
          },
          {
            id: 11415,
            parentId: 3684,
            areaName: '博罗县',
            areaPath: '中国,广东省,惠州市,博罗县',
            areaCode: '100004400130220000'
          },
          {
            id: 11416,
            parentId: 3684,
            areaName: '惠东县',
            areaPath: '中国,广东省,惠州市,惠东县',
            areaCode: '100004400130230000'
          },
          {
            id: 11417,
            parentId: 3684,
            areaName: '龙门县',
            areaPath: '中国,广东省,惠州市,龙门县',
            areaCode: '100004400130240000'
          }
        ]
      },
      {
        id: 3685,
        parentId: 1452,
        areaName: '梅州市',
        areaPath: '中国,广东省,梅州市',
        areaCode: '100004400140000000',
        children: [
          {
            id: 11418,
            parentId: 3685,
            areaName: '梅江区',
            areaPath: '中国,广东省,梅州市,梅江区',
            areaCode: '100004400140020000'
          },
          {
            id: 11419,
            parentId: 3685,
            areaName: '梅县区',
            areaPath: '中国,广东省,梅州市,梅县区',
            areaCode: '100004400140030000'
          },
          {
            id: 11420,
            parentId: 3685,
            areaName: '大埔县',
            areaPath: '中国,广东省,梅州市,大埔县',
            areaCode: '100004400140220000'
          },
          {
            id: 11421,
            parentId: 3685,
            areaName: '丰顺县',
            areaPath: '中国,广东省,梅州市,丰顺县',
            areaCode: '100004400140230000'
          },
          {
            id: 11422,
            parentId: 3685,
            areaName: '五华县',
            areaPath: '中国,广东省,梅州市,五华县',
            areaCode: '100004400140240000'
          },
          {
            id: 11423,
            parentId: 3685,
            areaName: '平远县',
            areaPath: '中国,广东省,梅州市,平远县',
            areaCode: '100004400140260000'
          },
          {
            id: 11424,
            parentId: 3685,
            areaName: '蕉岭县',
            areaPath: '中国,广东省,梅州市,蕉岭县',
            areaCode: '100004400140270000'
          },
          {
            id: 11425,
            parentId: 3685,
            areaName: '兴宁市',
            areaPath: '中国,广东省,梅州市,兴宁市',
            areaCode: '100004400140810000'
          }
        ]
      },
      {
        id: 3686,
        parentId: 1452,
        areaName: '汕尾市',
        areaPath: '中国,广东省,汕尾市',
        areaCode: '100004400150000000',
        children: [
          {
            id: 11426,
            parentId: 3686,
            areaName: '城区',
            areaPath: '中国,广东省,汕尾市,城区',
            areaCode: '100004400150020000'
          },
          {
            id: 11427,
            parentId: 3686,
            areaName: '海丰县',
            areaPath: '中国,广东省,汕尾市,海丰县',
            areaCode: '100004400150210000'
          },
          {
            id: 11428,
            parentId: 3686,
            areaName: '陆河县',
            areaPath: '中国,广东省,汕尾市,陆河县',
            areaCode: '100004400150230000'
          },
          {
            id: 11429,
            parentId: 3686,
            areaName: '陆丰市',
            areaPath: '中国,广东省,汕尾市,陆丰市',
            areaCode: '100004400150810000'
          }
        ]
      },
      {
        id: 3687,
        parentId: 1452,
        areaName: '河源市',
        areaPath: '中国,广东省,河源市',
        areaCode: '100004400160000000',
        children: [
          {
            id: 11430,
            parentId: 3687,
            areaName: '源城区',
            areaPath: '中国,广东省,河源市,源城区',
            areaCode: '100004400160020000'
          },
          {
            id: 11431,
            parentId: 3687,
            areaName: '紫金县',
            areaPath: '中国,广东省,河源市,紫金县',
            areaCode: '100004400160210000'
          },
          {
            id: 11432,
            parentId: 3687,
            areaName: '龙川县',
            areaPath: '中国,广东省,河源市,龙川县',
            areaCode: '100004400160220000'
          },
          {
            id: 11433,
            parentId: 3687,
            areaName: '连平县',
            areaPath: '中国,广东省,河源市,连平县',
            areaCode: '100004400160230000'
          },
          {
            id: 11434,
            parentId: 3687,
            areaName: '和平县',
            areaPath: '中国,广东省,河源市,和平县',
            areaCode: '100004400160240000'
          },
          {
            id: 11435,
            parentId: 3687,
            areaName: '东源县',
            areaPath: '中国,广东省,河源市,东源县',
            areaCode: '100004400160250000'
          }
        ]
      },
      {
        id: 3688,
        parentId: 1452,
        areaName: '阳江市',
        areaPath: '中国,广东省,阳江市',
        areaCode: '100004400170000000',
        children: [
          {
            id: 11436,
            parentId: 3688,
            areaName: '江城区',
            areaPath: '中国,广东省,阳江市,江城区',
            areaCode: '100004400170020000'
          },
          {
            id: 11437,
            parentId: 3688,
            areaName: '阳东区',
            areaPath: '中国,广东省,阳江市,阳东区',
            areaCode: '100004400170040000'
          },
          {
            id: 11438,
            parentId: 3688,
            areaName: '阳西县',
            areaPath: '中国,广东省,阳江市,阳西县',
            areaCode: '100004400170210000'
          },
          {
            id: 11439,
            parentId: 3688,
            areaName: '阳春市',
            areaPath: '中国,广东省,阳江市,阳春市',
            areaCode: '100004400170810000'
          }
        ]
      },
      {
        id: 3689,
        parentId: 1452,
        areaName: '清远市',
        areaPath: '中国,广东省,清远市',
        areaCode: '100004400180000000',
        children: [
          {
            id: 11440,
            parentId: 3689,
            areaName: '清城区',
            areaPath: '中国,广东省,清远市,清城区',
            areaCode: '100004400180020000'
          },
          {
            id: 11441,
            parentId: 3689,
            areaName: '清新区',
            areaPath: '中国,广东省,清远市,清新区',
            areaCode: '100004400180030000'
          },
          {
            id: 11442,
            parentId: 3689,
            areaName: '佛冈县',
            areaPath: '中国,广东省,清远市,佛冈县',
            areaCode: '100004400180210000'
          },
          {
            id: 11443,
            parentId: 3689,
            areaName: '阳山县',
            areaPath: '中国,广东省,清远市,阳山县',
            areaCode: '100004400180230000'
          },
          {
            id: 11444,
            parentId: 3689,
            areaName: '连山壮族瑶族自治县',
            areaPath: '中国,广东省,清远市,连山壮族瑶族自治县',
            areaCode: '100004400180250000'
          },
          {
            id: 11445,
            parentId: 3689,
            areaName: '连南瑶族自治县',
            areaPath: '中国,广东省,清远市,连南瑶族自治县',
            areaCode: '100004400180260000'
          },
          {
            id: 11446,
            parentId: 3689,
            areaName: '英德市',
            areaPath: '中国,广东省,清远市,英德市',
            areaCode: '100004400180810000'
          },
          {
            id: 11447,
            parentId: 3689,
            areaName: '连州市',
            areaPath: '中国,广东省,清远市,连州市',
            areaCode: '100004400180820000'
          }
        ]
      },
      {
        id: 3690,
        parentId: 1452,
        areaName: '东莞市',
        areaPath: '中国,广东省,东莞市',
        areaCode: '100004400190000000',
        children: [
          {
            id: 5923,
            parentId: 3690,
            areaName: '莞城区',
            areaPath: '中国,广东省,东莞市,莞城区',
            areaCode: '100004400190000000'
          },
          {
            id: 5924,
            parentId: 3690,
            areaName: '南城区',
            areaPath: '中国,广东省,东莞市,南城区',
            areaCode: '100004400190000000'
          },
          {
            id: 5925,
            parentId: 3690,
            areaName: '东城区',
            areaPath: '中国,广东省,东莞市,东城区',
            areaCode: '100004400190000000'
          },
          {
            id: 5926,
            parentId: 3690,
            areaName: '万江区',
            areaPath: '中国,广东省,东莞市,万江区',
            areaCode: '100004400190000000'
          },
          {
            id: 5927,
            parentId: 3690,
            areaName: '石碣镇',
            areaPath: '中国,广东省,东莞市,石碣镇',
            areaCode: '100004400190000100'
          },
          {
            id: 5928,
            parentId: 3690,
            areaName: '石龙镇',
            areaPath: '中国,广东省,东莞市,石龙镇',
            areaCode: '100004400190000100'
          },
          {
            id: 5929,
            parentId: 3690,
            areaName: '茶山镇',
            areaPath: '中国,广东省,东莞市,茶山镇',
            areaCode: '100004400190000100'
          },
          {
            id: 5930,
            parentId: 3690,
            areaName: '石排镇',
            areaPath: '中国,广东省,东莞市,石排镇',
            areaCode: '100004400190000100'
          },
          {
            id: 5931,
            parentId: 3690,
            areaName: '企石镇',
            areaPath: '中国,广东省,东莞市,企石镇',
            areaCode: '100004400190000110'
          },
          {
            id: 5932,
            parentId: 3690,
            areaName: '横沥镇',
            areaPath: '中国,广东省,东莞市,横沥镇',
            areaCode: '100004400190000110'
          },
          {
            id: 5933,
            parentId: 3690,
            areaName: '桥头镇',
            areaPath: '中国,广东省,东莞市,桥头镇',
            areaCode: '100004400190000110'
          },
          {
            id: 5934,
            parentId: 3690,
            areaName: '谢岗镇',
            areaPath: '中国,广东省,东莞市,谢岗镇',
            areaCode: '100004400190000110'
          },
          {
            id: 5935,
            parentId: 3690,
            areaName: '东坑镇',
            areaPath: '中国,广东省,东莞市,东坑镇',
            areaCode: '100004400190000110'
          },
          {
            id: 5936,
            parentId: 3690,
            areaName: '常平镇',
            areaPath: '中国,广东省,东莞市,常平镇',
            areaCode: '100004400190000110'
          },
          {
            id: 5937,
            parentId: 3690,
            areaName: '寮步镇',
            areaPath: '中国,广东省,东莞市,寮步镇',
            areaCode: '100004400190000110'
          },
          {
            id: 5938,
            parentId: 3690,
            areaName: '大朗镇',
            areaPath: '中国,广东省,东莞市,大朗镇',
            areaCode: '100004400190000110'
          },
          {
            id: 5939,
            parentId: 3690,
            areaName: '麻涌镇',
            areaPath: '中国,广东省,东莞市,麻涌镇',
            areaCode: '100004400190000130'
          },
          {
            id: 5940,
            parentId: 3690,
            areaName: '中堂镇',
            areaPath: '中国,广东省,东莞市,中堂镇',
            areaCode: '100004400190000130'
          },
          {
            id: 5941,
            parentId: 3690,
            areaName: '高埗镇',
            areaPath: '中国,广东省,东莞市,高埗镇',
            areaCode: '100004400190000130'
          },
          {
            id: 5942,
            parentId: 3690,
            areaName: '樟木头镇',
            areaPath: '中国,广东省,东莞市,樟木头镇',
            areaCode: '100004400190000110'
          },
          {
            id: 5943,
            parentId: 3690,
            areaName: '大岭山镇',
            areaPath: '中国,广东省,东莞市,大岭山镇',
            areaCode: '100004400190000110'
          },
          {
            id: 5944,
            parentId: 3690,
            areaName: '望牛墩镇',
            areaPath: '中国,广东省,东莞市,望牛墩镇',
            areaCode: '100004400190000130'
          },
          {
            id: 5945,
            parentId: 3690,
            areaName: '黄江镇',
            areaPath: '中国,广东省,东莞市,黄江镇',
            areaCode: '100004400190000110'
          },
          {
            id: 5946,
            parentId: 3690,
            areaName: '洪梅镇',
            areaPath: '中国,广东省,东莞市,洪梅镇',
            areaCode: '100004400190000130'
          },
          {
            id: 5947,
            parentId: 3690,
            areaName: '清溪镇',
            areaPath: '中国,广东省,东莞市,清溪镇',
            areaCode: '100004400190000110'
          },
          {
            id: 5948,
            parentId: 3690,
            areaName: '沙田镇',
            areaPath: '中国,广东省,东莞市,沙田镇',
            areaCode: '100004400190000130'
          },
          {
            id: 5949,
            parentId: 3690,
            areaName: '道滘镇',
            areaPath: '中国,广东省,东莞市,道滘镇',
            areaCode: '100004400190000130'
          },
          {
            id: 5950,
            parentId: 3690,
            areaName: '塘厦镇',
            areaPath: '中国,广东省,东莞市,塘厦镇',
            areaCode: '100004400190000110'
          },
          {
            id: 5951,
            parentId: 3690,
            areaName: '虎门镇',
            areaPath: '中国,广东省,东莞市,虎门镇',
            areaCode: '100004400190000130'
          },
          {
            id: 5952,
            parentId: 3690,
            areaName: '厚街镇',
            areaPath: '中国,广东省,东莞市,厚街镇',
            areaCode: '100004400190000130'
          },
          {
            id: 5953,
            parentId: 3690,
            areaName: '凤岗镇',
            areaPath: '中国,广东省,东莞市,凤岗镇',
            areaCode: '100004400190000110'
          },
          {
            id: 5954,
            parentId: 3690,
            areaName: '长安镇',
            areaPath: '中国,广东省,东莞市,长安镇',
            areaCode: '100004400190000110'
          },
          {
            id: 5955,
            parentId: 3690,
            areaName: '松山湖高新区',
            areaPath: '中国,广东省,东莞市,松山湖高新区',
            areaCode: '100004400190000400'
          }
        ]
      },
      {
        id: 3691,
        parentId: 1452,
        areaName: '中山市',
        areaPath: '中国,广东省,中山市',
        areaCode: '100004400200000000',
        children: [
          {
            id: 5956,
            parentId: 3691,
            areaName: '石岐区',
            areaPath: '中国,广东省,中山市,石岐区',
            areaCode: '100004400200000000'
          },
          {
            id: 5957,
            parentId: 3691,
            areaName: '东区',
            areaPath: '中国,广东省,中山市,东区',
            areaCode: '100004400200000000'
          },
          {
            id: 5958,
            parentId: 3691,
            areaName: '西区',
            areaPath: '中国,广东省,中山市,西区',
            areaCode: '100004400200000000'
          },
          {
            id: 5959,
            parentId: 3691,
            areaName: '南区',
            areaPath: '中国,广东省,中山市,南区',
            areaCode: '100004400200000000'
          },
          {
            id: 5960,
            parentId: 3691,
            areaName: '五桂山区',
            areaPath: '中国,广东省,中山市,五桂山区',
            areaCode: '100004400200000000'
          },
          {
            id: 5961,
            parentId: 3691,
            areaName: '火炬开发区',
            areaPath: '中国,广东省,中山市,火炬开发区',
            areaCode: '100004400200000000'
          },
          {
            id: 5962,
            parentId: 3691,
            areaName: '黄圃镇',
            areaPath: '中国,广东省,中山市,黄圃镇',
            areaCode: '100004400200000100'
          },
          {
            id: 5963,
            parentId: 3691,
            areaName: '南头镇',
            areaPath: '中国,广东省,中山市,南头镇',
            areaCode: '100004400200000110'
          },
          {
            id: 5964,
            parentId: 3691,
            areaName: '东凤镇',
            areaPath: '中国,广东省,中山市,东凤镇',
            areaCode: '100004400200000100'
          },
          {
            id: 5965,
            parentId: 3691,
            areaName: '阜沙镇',
            areaPath: '中国,广东省,中山市,阜沙镇',
            areaCode: '100004400200000110'
          },
          {
            id: 5966,
            parentId: 3691,
            areaName: '小榄镇',
            areaPath: '中国,广东省,中山市,小榄镇',
            areaCode: '100004400200000100'
          },
          {
            id: 5967,
            parentId: 3691,
            areaName: '东升镇',
            areaPath: '中国,广东省,中山市,东升镇',
            areaCode: '100004400200000100'
          },
          {
            id: 5968,
            parentId: 3691,
            areaName: '古镇镇',
            areaPath: '中国,广东省,中山市,古镇镇',
            areaCode: '100004400200000110'
          },
          {
            id: 5969,
            parentId: 3691,
            areaName: '横栏镇',
            areaPath: '中国,广东省,中山市,横栏镇',
            areaCode: '100004400200000110'
          },
          {
            id: 5970,
            parentId: 3691,
            areaName: '三角镇',
            areaPath: '中国,广东省,中山市,三角镇',
            areaCode: '100004400200000110'
          },
          {
            id: 5971,
            parentId: 3691,
            areaName: '民众镇',
            areaPath: '中国,广东省,中山市,民众镇',
            areaCode: '100004400200000100'
          },
          {
            id: 5972,
            parentId: 3691,
            areaName: '南朗镇',
            areaPath: '中国,广东省,中山市,南朗镇',
            areaCode: '100004400200000110'
          },
          {
            id: 5973,
            parentId: 3691,
            areaName: '港口镇',
            areaPath: '中国,广东省,中山市,港口镇',
            areaCode: '100004400200000110'
          },
          {
            id: 5974,
            parentId: 3691,
            areaName: '大涌镇',
            areaPath: '中国,广东省,中山市,大涌镇',
            areaCode: '100004400200000110'
          },
          {
            id: 5975,
            parentId: 3691,
            areaName: '沙溪镇',
            areaPath: '中国,广东省,中山市,沙溪镇',
            areaCode: '100004400200000110'
          },
          {
            id: 5976,
            parentId: 3691,
            areaName: '三乡镇',
            areaPath: '中国,广东省,中山市,三乡镇',
            areaCode: '100004400200000110'
          },
          {
            id: 5977,
            parentId: 3691,
            areaName: '板芙镇',
            areaPath: '中国,广东省,中山市,板芙镇',
            areaCode: '100004400200000110'
          },
          {
            id: 5978,
            parentId: 3691,
            areaName: '神湾镇',
            areaPath: '中国,广东省,中山市,神湾镇',
            areaCode: '100004400200000110'
          },
          {
            id: 5979,
            parentId: 3691,
            areaName: '坦洲镇',
            areaPath: '中国,广东省,中山市,坦洲镇',
            areaCode: '100004400200000110'
          }
        ]
      },
      {
        id: 3692,
        parentId: 1452,
        areaName: '潮州市',
        areaPath: '中国,广东省,潮州市',
        areaCode: '100004400510000000',
        children: [
          {
            id: 11448,
            parentId: 3692,
            areaName: '湘桥区',
            areaPath: '中国,广东省,潮州市,湘桥区',
            areaCode: '100004400510020000'
          },
          {
            id: 11449,
            parentId: 3692,
            areaName: '潮安区',
            areaPath: '中国,广东省,潮州市,潮安区',
            areaCode: '100004400510030000'
          },
          {
            id: 11450,
            parentId: 3692,
            areaName: '饶平县',
            areaPath: '中国,广东省,潮州市,饶平县',
            areaCode: '100004400510220000'
          }
        ]
      },
      {
        id: 3693,
        parentId: 1452,
        areaName: '揭阳市',
        areaPath: '中国,广东省,揭阳市',
        areaCode: '100004400520000000',
        children: [
          {
            id: 11451,
            parentId: 3693,
            areaName: '榕城区',
            areaPath: '中国,广东省,揭阳市,榕城区',
            areaCode: '100004400520020000'
          },
          {
            id: 11452,
            parentId: 3693,
            areaName: '揭东区',
            areaPath: '中国,广东省,揭阳市,揭东区',
            areaCode: '100004400520030000'
          },
          {
            id: 11453,
            parentId: 3693,
            areaName: '揭西县',
            areaPath: '中国,广东省,揭阳市,揭西县',
            areaCode: '100004400520220000'
          },
          {
            id: 11454,
            parentId: 3693,
            areaName: '惠来县',
            areaPath: '中国,广东省,揭阳市,惠来县',
            areaCode: '100004400520240000'
          },
          {
            id: 11455,
            parentId: 3693,
            areaName: '普宁市',
            areaPath: '中国,广东省,揭阳市,普宁市',
            areaCode: '100004400520810000'
          }
        ]
      },
      {
        id: 3694,
        parentId: 1452,
        areaName: '云浮市',
        areaPath: '中国,广东省,云浮市',
        areaCode: '100004400530000000',
        children: [
          {
            id: 11456,
            parentId: 3694,
            areaName: '云城区',
            areaPath: '中国,广东省,云浮市,云城区',
            areaCode: '100004400530020000'
          },
          {
            id: 11457,
            parentId: 3694,
            areaName: '云安区',
            areaPath: '中国,广东省,云浮市,云安区',
            areaCode: '100004400530030000'
          },
          {
            id: 11458,
            parentId: 3694,
            areaName: '新兴县',
            areaPath: '中国,广东省,云浮市,新兴县',
            areaCode: '100004400530210000'
          },
          {
            id: 11459,
            parentId: 3694,
            areaName: '郁南县',
            areaPath: '中国,广东省,云浮市,郁南县',
            areaCode: '100004400530220000'
          },
          {
            id: 11460,
            parentId: 3694,
            areaName: '罗定市',
            areaPath: '中国,广东省,云浮市,罗定市',
            areaCode: '100004400530810000'
          }
        ]
      }
    ]
  },
  {
    id: 1453,
    parentId: 1,
    areaName: '广西壮族自治区',
    areaPath: '中国,广西壮族自治区',
    areaCode: '100004500000000000',
    children: [
      {
        id: 3695,
        parentId: 1453,
        areaName: '南宁市',
        areaPath: '中国,广西壮族自治区,南宁市',
        areaCode: '100004500010000000',
        children: [
          {
            id: 11488,
            parentId: 3695,
            areaName: '兴宁区',
            areaPath: '中国,广西壮族自治区,南宁市,兴宁区',
            areaCode: '100004500010020000'
          },
          {
            id: 11489,
            parentId: 3695,
            areaName: '青秀区',
            areaPath: '中国,广西壮族自治区,南宁市,青秀区',
            areaCode: '100004500010030000'
          },
          {
            id: 11490,
            parentId: 3695,
            areaName: '江南区',
            areaPath: '中国,广西壮族自治区,南宁市,江南区',
            areaCode: '100004500010050000'
          },
          {
            id: 11491,
            parentId: 3695,
            areaName: '西乡塘区',
            areaPath: '中国,广西壮族自治区,南宁市,西乡塘区',
            areaCode: '100004500010070000'
          },
          {
            id: 11492,
            parentId: 3695,
            areaName: '良庆区',
            areaPath: '中国,广西壮族自治区,南宁市,良庆区',
            areaCode: '100004500010080000'
          },
          {
            id: 11493,
            parentId: 3695,
            areaName: '邕宁区',
            areaPath: '中国,广西壮族自治区,南宁市,邕宁区',
            areaCode: '100004500010090000'
          },
          {
            id: 11494,
            parentId: 3695,
            areaName: '武鸣区',
            areaPath: '中国,广西壮族自治区,南宁市,武鸣区',
            areaCode: '100004500010100000'
          },
          {
            id: 11495,
            parentId: 3695,
            areaName: '隆安县',
            areaPath: '中国,广西壮族自治区,南宁市,隆安县',
            areaCode: '100004500010230000'
          },
          {
            id: 11496,
            parentId: 3695,
            areaName: '马山县',
            areaPath: '中国,广西壮族自治区,南宁市,马山县',
            areaCode: '100004500010240000'
          },
          {
            id: 11497,
            parentId: 3695,
            areaName: '上林县',
            areaPath: '中国,广西壮族自治区,南宁市,上林县',
            areaCode: '100004500010250000'
          },
          {
            id: 11498,
            parentId: 3695,
            areaName: '宾阳县',
            areaPath: '中国,广西壮族自治区,南宁市,宾阳县',
            areaCode: '100004500010260000'
          },
          {
            id: 11499,
            parentId: 3695,
            areaName: '横县',
            areaPath: '中国,广西壮族自治区,南宁市,横县',
            areaCode: '100004500010270000'
          }
        ]
      },
      {
        id: 3696,
        parentId: 1453,
        areaName: '柳州市',
        areaPath: '中国,广西壮族自治区,柳州市',
        areaCode: '100004500020000000',
        children: [
          {
            id: 11500,
            parentId: 3696,
            areaName: '城中区',
            areaPath: '中国,广西壮族自治区,柳州市,城中区',
            areaCode: '100004500020020000'
          },
          {
            id: 11501,
            parentId: 3696,
            areaName: '鱼峰区',
            areaPath: '中国,广西壮族自治区,柳州市,鱼峰区',
            areaCode: '100004500020030000'
          },
          {
            id: 11502,
            parentId: 3696,
            areaName: '柳南区',
            areaPath: '中国,广西壮族自治区,柳州市,柳南区',
            areaCode: '100004500020040000'
          },
          {
            id: 11503,
            parentId: 3696,
            areaName: '柳北区',
            areaPath: '中国,广西壮族自治区,柳州市,柳北区',
            areaCode: '100004500020050000'
          },
          {
            id: 11504,
            parentId: 3696,
            areaName: '柳江区',
            areaPath: '中国,广西壮族自治区,柳州市,柳江区',
            areaCode: '100004500020060000'
          },
          {
            id: 11505,
            parentId: 3696,
            areaName: '柳城县',
            areaPath: '中国,广西壮族自治区,柳州市,柳城县',
            areaCode: '100004500020220000'
          },
          {
            id: 11506,
            parentId: 3696,
            areaName: '鹿寨县',
            areaPath: '中国,广西壮族自治区,柳州市,鹿寨县',
            areaCode: '100004500020230000'
          },
          {
            id: 11507,
            parentId: 3696,
            areaName: '融安县',
            areaPath: '中国,广西壮族自治区,柳州市,融安县',
            areaCode: '100004500020240000'
          },
          {
            id: 11508,
            parentId: 3696,
            areaName: '融水苗族自治县',
            areaPath: '中国,广西壮族自治区,柳州市,融水苗族自治县',
            areaCode: '100004500020250000'
          },
          {
            id: 11509,
            parentId: 3696,
            areaName: '三江侗族自治县',
            areaPath: '中国,广西壮族自治区,柳州市,三江侗族自治县',
            areaCode: '100004500020260000'
          }
        ]
      },
      {
        id: 3697,
        parentId: 1453,
        areaName: '桂林市',
        areaPath: '中国,广西壮族自治区,桂林市',
        areaCode: '100004500030000000',
        children: [
          {
            id: 11510,
            parentId: 3697,
            areaName: '秀峰区',
            areaPath: '中国,广西壮族自治区,桂林市,秀峰区',
            areaCode: '100004500030020000'
          },
          {
            id: 11511,
            parentId: 3697,
            areaName: '叠彩区',
            areaPath: '中国,广西壮族自治区,桂林市,叠彩区',
            areaCode: '100004500030030000'
          },
          {
            id: 11512,
            parentId: 3697,
            areaName: '象山区',
            areaPath: '中国,广西壮族自治区,桂林市,象山区',
            areaCode: '100004500030040000'
          },
          {
            id: 11513,
            parentId: 3697,
            areaName: '七星区',
            areaPath: '中国,广西壮族自治区,桂林市,七星区',
            areaCode: '100004500030050000'
          },
          {
            id: 11514,
            parentId: 3697,
            areaName: '雁山区',
            areaPath: '中国,广西壮族自治区,桂林市,雁山区',
            areaCode: '100004500030110000'
          },
          {
            id: 11515,
            parentId: 3697,
            areaName: '临桂区',
            areaPath: '中国,广西壮族自治区,桂林市,临桂区',
            areaCode: '100004500030120000'
          },
          {
            id: 11516,
            parentId: 3697,
            areaName: '阳朔县',
            areaPath: '中国,广西壮族自治区,桂林市,阳朔县',
            areaCode: '100004500030210000'
          },
          {
            id: 11517,
            parentId: 3697,
            areaName: '灵川县',
            areaPath: '中国,广西壮族自治区,桂林市,灵川县',
            areaCode: '100004500030230000'
          },
          {
            id: 11518,
            parentId: 3697,
            areaName: '全州县',
            areaPath: '中国,广西壮族自治区,桂林市,全州县',
            areaCode: '100004500030240000'
          },
          {
            id: 11519,
            parentId: 3697,
            areaName: '兴安县',
            areaPath: '中国,广西壮族自治区,桂林市,兴安县',
            areaCode: '100004500030250000'
          },
          {
            id: 11520,
            parentId: 3697,
            areaName: '永福县',
            areaPath: '中国,广西壮族自治区,桂林市,永福县',
            areaCode: '100004500030260000'
          },
          {
            id: 11521,
            parentId: 3697,
            areaName: '灌阳县',
            areaPath: '中国,广西壮族自治区,桂林市,灌阳县',
            areaCode: '100004500030270000'
          },
          {
            id: 11522,
            parentId: 3697,
            areaName: '龙胜各族自治县',
            areaPath: '中国,广西壮族自治区,桂林市,龙胜各族自治县',
            areaCode: '100004500030280000'
          },
          {
            id: 11523,
            parentId: 3697,
            areaName: '资源县',
            areaPath: '中国,广西壮族自治区,桂林市,资源县',
            areaCode: '100004500030290000'
          },
          {
            id: 11524,
            parentId: 3697,
            areaName: '平乐县',
            areaPath: '中国,广西壮族自治区,桂林市,平乐县',
            areaCode: '100004500030300000'
          },
          {
            id: 11525,
            parentId: 3697,
            areaName: '荔浦县',
            areaPath: '中国,广西壮族自治区,桂林市,荔浦县',
            areaCode: '100004500030310000'
          },
          {
            id: 11526,
            parentId: 3697,
            areaName: '恭城瑶族自治县',
            areaPath: '中国,广西壮族自治区,桂林市,恭城瑶族自治县',
            areaCode: '100004500030320000'
          }
        ]
      },
      {
        id: 3698,
        parentId: 1453,
        areaName: '梧州市',
        areaPath: '中国,广西壮族自治区,梧州市',
        areaCode: '100004500040000000',
        children: [
          {
            id: 11527,
            parentId: 3698,
            areaName: '万秀区',
            areaPath: '中国,广西壮族自治区,梧州市,万秀区',
            areaCode: '100004500040030000'
          },
          {
            id: 11528,
            parentId: 3698,
            areaName: '长洲区',
            areaPath: '中国,广西壮族自治区,梧州市,长洲区',
            areaCode: '100004500040050000'
          },
          {
            id: 11529,
            parentId: 3698,
            areaName: '龙圩区',
            areaPath: '中国,广西壮族自治区,梧州市,龙圩区',
            areaCode: '100004500040060000'
          },
          {
            id: 11530,
            parentId: 3698,
            areaName: '苍梧县',
            areaPath: '中国,广西壮族自治区,梧州市,苍梧县',
            areaCode: '100004500040210000'
          },
          {
            id: 11531,
            parentId: 3698,
            areaName: '藤县',
            areaPath: '中国,广西壮族自治区,梧州市,藤县',
            areaCode: '100004500040220000'
          },
          {
            id: 11532,
            parentId: 3698,
            areaName: '蒙山县',
            areaPath: '中国,广西壮族自治区,梧州市,蒙山县',
            areaCode: '100004500040230000'
          },
          {
            id: 11533,
            parentId: 3698,
            areaName: '岑溪市',
            areaPath: '中国,广西壮族自治区,梧州市,岑溪市',
            areaCode: '100004500040810000'
          }
        ]
      },
      {
        id: 3699,
        parentId: 1453,
        areaName: '北海市',
        areaPath: '中国,广西壮族自治区,北海市',
        areaCode: '100004500050000000',
        children: [
          {
            id: 11534,
            parentId: 3699,
            areaName: '海城区',
            areaPath: '中国,广西壮族自治区,北海市,海城区',
            areaCode: '100004500050020000'
          },
          {
            id: 11535,
            parentId: 3699,
            areaName: '银海区',
            areaPath: '中国,广西壮族自治区,北海市,银海区',
            areaCode: '100004500050030000'
          },
          {
            id: 11536,
            parentId: 3699,
            areaName: '铁山港区',
            areaPath: '中国,广西壮族自治区,北海市,铁山港区',
            areaCode: '100004500050120000'
          },
          {
            id: 11537,
            parentId: 3699,
            areaName: '合浦县',
            areaPath: '中国,广西壮族自治区,北海市,合浦县',
            areaCode: '100004500050210000'
          }
        ]
      },
      {
        id: 3700,
        parentId: 1453,
        areaName: '防城港市',
        areaPath: '中国,广西壮族自治区,防城港市',
        areaCode: '100004500060000000',
        children: [
          {
            id: 11538,
            parentId: 3700,
            areaName: '港口区',
            areaPath: '中国,广西壮族自治区,防城港市,港口区',
            areaCode: '100004500060020000'
          },
          {
            id: 11539,
            parentId: 3700,
            areaName: '防城区',
            areaPath: '中国,广西壮族自治区,防城港市,防城区',
            areaCode: '100004500060030000'
          },
          {
            id: 11540,
            parentId: 3700,
            areaName: '上思县',
            areaPath: '中国,广西壮族自治区,防城港市,上思县',
            areaCode: '100004500060210000'
          },
          {
            id: 11541,
            parentId: 3700,
            areaName: '东兴市',
            areaPath: '中国,广西壮族自治区,防城港市,东兴市',
            areaCode: '100004500060810000'
          }
        ]
      },
      {
        id: 3701,
        parentId: 1453,
        areaName: '钦州市',
        areaPath: '中国,广西壮族自治区,钦州市',
        areaCode: '100004500070000000',
        children: [
          {
            id: 11542,
            parentId: 3701,
            areaName: '钦南区',
            areaPath: '中国,广西壮族自治区,钦州市,钦南区',
            areaCode: '100004500070020000'
          },
          {
            id: 11543,
            parentId: 3701,
            areaName: '钦北区',
            areaPath: '中国,广西壮族自治区,钦州市,钦北区',
            areaCode: '100004500070030000'
          },
          {
            id: 11544,
            parentId: 3701,
            areaName: '灵山县',
            areaPath: '中国,广西壮族自治区,钦州市,灵山县',
            areaCode: '100004500070210000'
          },
          {
            id: 11545,
            parentId: 3701,
            areaName: '浦北县',
            areaPath: '中国,广西壮族自治区,钦州市,浦北县',
            areaCode: '100004500070220000'
          }
        ]
      },
      {
        id: 3702,
        parentId: 1453,
        areaName: '贵港市',
        areaPath: '中国,广西壮族自治区,贵港市',
        areaCode: '100004500080000000',
        children: [
          {
            id: 11546,
            parentId: 3702,
            areaName: '港北区',
            areaPath: '中国,广西壮族自治区,贵港市,港北区',
            areaCode: '100004500080020000'
          },
          {
            id: 11547,
            parentId: 3702,
            areaName: '港南区',
            areaPath: '中国,广西壮族自治区,贵港市,港南区',
            areaCode: '100004500080030000'
          },
          {
            id: 11548,
            parentId: 3702,
            areaName: '覃塘区',
            areaPath: '中国,广西壮族自治区,贵港市,覃塘区',
            areaCode: '100004500080040000'
          },
          {
            id: 11549,
            parentId: 3702,
            areaName: '平南县',
            areaPath: '中国,广西壮族自治区,贵港市,平南县',
            areaCode: '100004500080210000'
          },
          {
            id: 11550,
            parentId: 3702,
            areaName: '桂平市',
            areaPath: '中国,广西壮族自治区,贵港市,桂平市',
            areaCode: '100004500080810000'
          }
        ]
      },
      {
        id: 3703,
        parentId: 1453,
        areaName: '玉林市',
        areaPath: '中国,广西壮族自治区,玉林市',
        areaCode: '100004500090000000',
        children: [
          {
            id: 11551,
            parentId: 3703,
            areaName: '玉州区',
            areaPath: '中国,广西壮族自治区,玉林市,玉州区',
            areaCode: '100004500090020000'
          },
          {
            id: 11552,
            parentId: 3703,
            areaName: '福绵区',
            areaPath: '中国,广西壮族自治区,玉林市,福绵区',
            areaCode: '100004500090030000'
          },
          {
            id: 11553,
            parentId: 3703,
            areaName: '容县',
            areaPath: '中国,广西壮族自治区,玉林市,容县',
            areaCode: '100004500090210000'
          },
          {
            id: 11554,
            parentId: 3703,
            areaName: '陆川县',
            areaPath: '中国,广西壮族自治区,玉林市,陆川县',
            areaCode: '100004500090220000'
          },
          {
            id: 11555,
            parentId: 3703,
            areaName: '博白县',
            areaPath: '中国,广西壮族自治区,玉林市,博白县',
            areaCode: '100004500090230000'
          },
          {
            id: 11556,
            parentId: 3703,
            areaName: '兴业县',
            areaPath: '中国,广西壮族自治区,玉林市,兴业县',
            areaCode: '100004500090240000'
          },
          {
            id: 11557,
            parentId: 3703,
            areaName: '北流市',
            areaPath: '中国,广西壮族自治区,玉林市,北流市',
            areaCode: '100004500090810000'
          }
        ]
      },
      {
        id: 3704,
        parentId: 1453,
        areaName: '百色市',
        areaPath: '中国,广西壮族自治区,百色市',
        areaCode: '100004500100000000',
        children: [
          {
            id: 11558,
            parentId: 3704,
            areaName: '右江区',
            areaPath: '中国,广西壮族自治区,百色市,右江区',
            areaCode: '100004500100020000'
          },
          {
            id: 11559,
            parentId: 3704,
            areaName: '田阳县',
            areaPath: '中国,广西壮族自治区,百色市,田阳县',
            areaCode: '100004500100210000'
          },
          {
            id: 11560,
            parentId: 3704,
            areaName: '田东县',
            areaPath: '中国,广西壮族自治区,百色市,田东县',
            areaCode: '100004500100220000'
          },
          {
            id: 11561,
            parentId: 3704,
            areaName: '平果县',
            areaPath: '中国,广西壮族自治区,百色市,平果县',
            areaCode: '100004500100230000'
          },
          {
            id: 11562,
            parentId: 3704,
            areaName: '德保县',
            areaPath: '中国,广西壮族自治区,百色市,德保县',
            areaCode: '100004500100240000'
          },
          {
            id: 11563,
            parentId: 3704,
            areaName: '那坡县',
            areaPath: '中国,广西壮族自治区,百色市,那坡县',
            areaCode: '100004500100260000'
          },
          {
            id: 11564,
            parentId: 3704,
            areaName: '凌云县',
            areaPath: '中国,广西壮族自治区,百色市,凌云县',
            areaCode: '100004500100270000'
          },
          {
            id: 11565,
            parentId: 3704,
            areaName: '乐业县',
            areaPath: '中国,广西壮族自治区,百色市,乐业县',
            areaCode: '100004500100280000'
          },
          {
            id: 11566,
            parentId: 3704,
            areaName: '田林县',
            areaPath: '中国,广西壮族自治区,百色市,田林县',
            areaCode: '100004500100290000'
          },
          {
            id: 11567,
            parentId: 3704,
            areaName: '西林县',
            areaPath: '中国,广西壮族自治区,百色市,西林县',
            areaCode: '100004500100300000'
          },
          {
            id: 11568,
            parentId: 3704,
            areaName: '隆林各族自治县',
            areaPath: '中国,广西壮族自治区,百色市,隆林各族自治县',
            areaCode: '100004500100310000'
          },
          {
            id: 11569,
            parentId: 3704,
            areaName: '靖西市',
            areaPath: '中国,广西壮族自治区,百色市,靖西市',
            areaCode: '100004500100810000'
          }
        ]
      },
      {
        id: 3705,
        parentId: 1453,
        areaName: '贺州市',
        areaPath: '中国,广西壮族自治区,贺州市',
        areaCode: '100004500110000000',
        children: [
          {
            id: 11570,
            parentId: 3705,
            areaName: '八步区',
            areaPath: '中国,广西壮族自治区,贺州市,八步区',
            areaCode: '100004500110020000'
          },
          {
            id: 11571,
            parentId: 3705,
            areaName: '平桂区',
            areaPath: '中国,广西壮族自治区,贺州市,平桂区',
            areaCode: '100004500110030000'
          },
          {
            id: 11572,
            parentId: 3705,
            areaName: '昭平县',
            areaPath: '中国,广西壮族自治区,贺州市,昭平县',
            areaCode: '100004500110210000'
          },
          {
            id: 11573,
            parentId: 3705,
            areaName: '钟山县',
            areaPath: '中国,广西壮族自治区,贺州市,钟山县',
            areaCode: '100004500110220000'
          },
          {
            id: 11574,
            parentId: 3705,
            areaName: '富川瑶族自治县',
            areaPath: '中国,广西壮族自治区,贺州市,富川瑶族自治县',
            areaCode: '100004500110230000'
          }
        ]
      },
      {
        id: 3706,
        parentId: 1453,
        areaName: '河池市',
        areaPath: '中国,广西壮族自治区,河池市',
        areaCode: '100004500120000000',
        children: [
          {
            id: 11575,
            parentId: 3706,
            areaName: '金城江区',
            areaPath: '中国,广西壮族自治区,河池市,金城江区',
            areaCode: '100004500120020000'
          },
          {
            id: 11576,
            parentId: 3706,
            areaName: '宜州区',
            areaPath: '中国,广西壮族自治区,河池市,宜州区',
            areaCode: '100004500120030000'
          },
          {
            id: 11577,
            parentId: 3706,
            areaName: '南丹县',
            areaPath: '中国,广西壮族自治区,河池市,南丹县',
            areaCode: '100004500120210000'
          },
          {
            id: 11578,
            parentId: 3706,
            areaName: '天峨县',
            areaPath: '中国,广西壮族自治区,河池市,天峨县',
            areaCode: '100004500120220000'
          },
          {
            id: 11579,
            parentId: 3706,
            areaName: '凤山县',
            areaPath: '中国,广西壮族自治区,河池市,凤山县',
            areaCode: '100004500120230000'
          },
          {
            id: 11580,
            parentId: 3706,
            areaName: '东兰县',
            areaPath: '中国,广西壮族自治区,河池市,东兰县',
            areaCode: '100004500120240000'
          },
          {
            id: 11581,
            parentId: 3706,
            areaName: '罗城仫佬族自治县',
            areaPath: '中国,广西壮族自治区,河池市,罗城仫佬族自治县',
            areaCode: '100004500120250000'
          },
          {
            id: 11582,
            parentId: 3706,
            areaName: '环江毛南族自治县',
            areaPath: '中国,广西壮族自治区,河池市,环江毛南族自治县',
            areaCode: '100004500120260000'
          },
          {
            id: 11583,
            parentId: 3706,
            areaName: '巴马瑶族自治县',
            areaPath: '中国,广西壮族自治区,河池市,巴马瑶族自治县',
            areaCode: '100004500120270000'
          },
          {
            id: 11584,
            parentId: 3706,
            areaName: '都安瑶族自治县',
            areaPath: '中国,广西壮族自治区,河池市,都安瑶族自治县',
            areaCode: '100004500120280000'
          },
          {
            id: 11585,
            parentId: 3706,
            areaName: '大化瑶族自治县',
            areaPath: '中国,广西壮族自治区,河池市,大化瑶族自治县',
            areaCode: '100004500120290000'
          }
        ]
      },
      {
        id: 3707,
        parentId: 1453,
        areaName: '来宾市',
        areaPath: '中国,广西壮族自治区,来宾市',
        areaCode: '100004500130000000',
        children: [
          {
            id: 11586,
            parentId: 3707,
            areaName: '兴宾区',
            areaPath: '中国,广西壮族自治区,来宾市,兴宾区',
            areaCode: '100004500130020000'
          },
          {
            id: 11587,
            parentId: 3707,
            areaName: '忻城县',
            areaPath: '中国,广西壮族自治区,来宾市,忻城县',
            areaCode: '100004500130210000'
          },
          {
            id: 11588,
            parentId: 3707,
            areaName: '象州县',
            areaPath: '中国,广西壮族自治区,来宾市,象州县',
            areaCode: '100004500130220000'
          },
          {
            id: 11589,
            parentId: 3707,
            areaName: '武宣县',
            areaPath: '中国,广西壮族自治区,来宾市,武宣县',
            areaCode: '100004500130230000'
          },
          {
            id: 11590,
            parentId: 3707,
            areaName: '金秀瑶族自治县',
            areaPath: '中国,广西壮族自治区,来宾市,金秀瑶族自治县',
            areaCode: '100004500130240000'
          },
          {
            id: 11591,
            parentId: 3707,
            areaName: '合山市',
            areaPath: '中国,广西壮族自治区,来宾市,合山市',
            areaCode: '100004500130810000'
          }
        ]
      },
      {
        id: 3708,
        parentId: 1453,
        areaName: '崇左市',
        areaPath: '中国,广西壮族自治区,崇左市',
        areaCode: '100004500140000000',
        children: [
          {
            id: 11592,
            parentId: 3708,
            areaName: '江州区',
            areaPath: '中国,广西壮族自治区,崇左市,江州区',
            areaCode: '100004500140020000'
          },
          {
            id: 11593,
            parentId: 3708,
            areaName: '扶绥县',
            areaPath: '中国,广西壮族自治区,崇左市,扶绥县',
            areaCode: '100004500140210000'
          },
          {
            id: 11594,
            parentId: 3708,
            areaName: '宁明县',
            areaPath: '中国,广西壮族自治区,崇左市,宁明县',
            areaCode: '100004500140220000'
          },
          {
            id: 11595,
            parentId: 3708,
            areaName: '龙州县',
            areaPath: '中国,广西壮族自治区,崇左市,龙州县',
            areaCode: '100004500140230000'
          },
          {
            id: 11596,
            parentId: 3708,
            areaName: '大新县',
            areaPath: '中国,广西壮族自治区,崇左市,大新县',
            areaCode: '100004500140240000'
          },
          {
            id: 11597,
            parentId: 3708,
            areaName: '天等县',
            areaPath: '中国,广西壮族自治区,崇左市,天等县',
            areaCode: '100004500140250000'
          },
          {
            id: 11598,
            parentId: 3708,
            areaName: '凭祥市',
            areaPath: '中国,广西壮族自治区,崇左市,凭祥市',
            areaCode: '100004500140810000'
          }
        ]
      }
    ]
  },
  {
    id: 1454,
    parentId: 1,
    areaName: '海南省',
    areaPath: '中国,海南省',
    areaCode: '100004600000000000',
    children: [
      {
        id: 3709,
        parentId: 1454,
        areaName: '海口市',
        areaPath: '中国,海南省,海口市',
        areaCode: '100004600010000000',
        children: [
          {
            id: 11599,
            parentId: 3709,
            areaName: '秀英区',
            areaPath: '中国,海南省,海口市,秀英区',
            areaCode: '100004600010050000'
          },
          {
            id: 11600,
            parentId: 3709,
            areaName: '龙华区',
            areaPath: '中国,海南省,海口市,龙华区',
            areaCode: '100004600010060000'
          },
          {
            id: 11601,
            parentId: 3709,
            areaName: '琼山区',
            areaPath: '中国,海南省,海口市,琼山区',
            areaCode: '100004600010070000'
          },
          {
            id: 11602,
            parentId: 3709,
            areaName: '美兰区',
            areaPath: '中国,海南省,海口市,美兰区',
            areaCode: '100004600010080000'
          }
        ]
      },
      {
        id: 3710,
        parentId: 1454,
        areaName: '三亚市',
        areaPath: '中国,海南省,三亚市',
        areaCode: '100004600020000000',
        children: [
          {
            id: 11603,
            parentId: 3710,
            areaName: '海棠区',
            areaPath: '中国,海南省,三亚市,海棠区',
            areaCode: '100004600020020000'
          },
          {
            id: 11604,
            parentId: 3710,
            areaName: '吉阳区',
            areaPath: '中国,海南省,三亚市,吉阳区',
            areaCode: '100004600020030000'
          },
          {
            id: 11605,
            parentId: 3710,
            areaName: '天涯区',
            areaPath: '中国,海南省,三亚市,天涯区',
            areaCode: '100004600020040000'
          },
          {
            id: 11606,
            parentId: 3710,
            areaName: '崖州区',
            areaPath: '中国,海南省,三亚市,崖州区',
            areaCode: '100004600020050000'
          }
        ]
      },
      {
        id: 3711,
        parentId: 1454,
        areaName: '三沙市',
        areaPath: '中国,海南省,三沙市',
        areaCode: '100004600030000000',
        children: [
          {
            id: 11607,
            parentId: 3711,
            areaName: '西沙群岛',
            areaPath: '中国,海南省,三沙市,西沙群岛',
            areaCode: '100004600030210000'
          },
          {
            id: 11608,
            parentId: 3711,
            areaName: '南沙群岛',
            areaPath: '中国,海南省,三沙市,南沙群岛',
            areaCode: '100004600030220000'
          },
          {
            id: 11609,
            parentId: 3711,
            areaName: '中沙群岛',
            areaPath: '中国,海南省,三沙市,中沙群岛',
            areaCode: '100004600030230000'
          }
        ]
      },
      {
        id: 3712,
        parentId: 1454,
        areaName: '儋州市',
        areaPath: '中国,海南省,儋州市',
        areaCode: '100004600040000000',
        children: [
          {
            id: 11611,
            parentId: 3712,
            areaName: '那大镇',
            areaPath: '中国,海南省,儋州市,那大镇',
            areaCode: '100004600040000100'
          },
          {
            id: 11612,
            parentId: 3712,
            areaName: '和庆镇',
            areaPath: '中国,海南省,儋州市,和庆镇',
            areaCode: '100004600040000100'
          },
          {
            id: 11617,
            parentId: 3712,
            areaName: '南丰镇',
            areaPath: '中国,海南省,儋州市,南丰镇',
            areaCode: '100004600040000100'
          },
          {
            id: 11618,
            parentId: 3712,
            areaName: '大成镇',
            areaPath: '中国,海南省,儋州市,\t大成镇',
            areaCode: '100004600040000100'
          },
          {
            id: 11619,
            parentId: 3712,
            areaName: '雅星镇',
            areaPath: '中国,海南省,儋州市,雅星镇',
            areaCode: '100004600040000100'
          },
          {
            id: 12678,
            parentId: 3712,
            areaName: '兰洋镇',
            areaPath: '中国,海南省,儋州市,兰洋镇',
            areaCode: '100004600040000110'
          },
          {
            id: 12679,
            parentId: 3712,
            areaName: '光村镇',
            areaPath: '中国,海南省,儋州市,光村镇',
            areaCode: '100004600040000110'
          },
          {
            id: 12680,
            parentId: 3712,
            areaName: '木棠镇',
            areaPath: '中国,海南省,儋州市,木棠镇',
            areaCode: '100004600040000110'
          },
          {
            id: 12681,
            parentId: 3712,
            areaName: '海头镇',
            areaPath: '中国,海南省,儋州市,海头镇',
            areaCode: '100004600040000110'
          },
          {
            id: 12682,
            parentId: 3712,
            areaName: '峨蔓镇',
            areaPath: '中国,海南省,儋州市,峨蔓镇',
            areaCode: '100004600040000110'
          },
          {
            id: 12683,
            parentId: 3712,
            areaName: '王五镇',
            areaPath: '中国,海南省,儋州市,王五镇',
            areaCode: '100004600040000110'
          },
          {
            id: 12684,
            parentId: 3712,
            areaName: '白马井镇',
            areaPath: '中国,海南省,儋州市,白马井镇',
            areaCode: '100004600040000110'
          },
          {
            id: 12685,
            parentId: 3712,
            areaName: '中和镇',
            areaPath: '中国,海南省,儋州市,中和镇',
            areaCode: '100004600040000110'
          }
        ]
      },
      {
        id: 12675,
        parentId: 1454,
        areaName: '省直辖县级行政区划',
        areaPath: '中国,海南省,省直辖县级行政区划',
        areaCode: '100004600900000000',
        children: [
          {
            id: 3713,
            parentId: 12675,
            areaName: '五指山市',
            areaPath: '中国,海南省,省直辖县级行政区划,五指山市',
            areaCode: '100004600900010000'
          },
          {
            id: 3714,
            parentId: 12675,
            areaName: '琼海市',
            areaPath: '中国,海南省,省直辖县级行政区划,琼海市',
            areaCode: '100004600900020000'
          },
          {
            id: 3715,
            parentId: 12675,
            areaName: '文昌市',
            areaPath: '中国,海南省,省直辖县级行政区划,文昌市',
            areaCode: '100004600900050000'
          },
          {
            id: 3716,
            parentId: 12675,
            areaName: '万宁市',
            areaPath: '中国,海南省,省直辖县级行政区划,万宁市',
            areaCode: '100004600900060000'
          },
          {
            id: 3717,
            parentId: 12675,
            areaName: '东方市',
            areaPath: '中国,海南省,省直辖县级行政区划,东方市',
            areaCode: '100004600900070000'
          },
          {
            id: 3718,
            parentId: 12675,
            areaName: '定安县',
            areaPath: '中国,海南省,省直辖县级行政区划,定安县',
            areaCode: '100004600900210000'
          },
          {
            id: 3719,
            parentId: 12675,
            areaName: '屯昌县',
            areaPath: '中国,海南省,省直辖县级行政区划,屯昌县',
            areaCode: '100004600900220000'
          },
          {
            id: 3720,
            parentId: 12675,
            areaName: '澄迈县',
            areaPath: '中国,海南省,省直辖县级行政区划,澄迈县',
            areaCode: '100004600900230000'
          },
          {
            id: 3721,
            parentId: 12675,
            areaName: '临高县',
            areaPath: '中国,海南省,省直辖县级行政区划,临高县',
            areaCode: '100004600900240000'
          },
          {
            id: 3722,
            parentId: 12675,
            areaName: '白沙黎族自治县',
            areaPath: '中国,海南省,省直辖县级行政区划,白沙黎族自治县',
            areaCode: '100004600900250000'
          },
          {
            id: 3723,
            parentId: 12675,
            areaName: '昌江黎族自治县',
            areaPath: '中国,海南省,省直辖县级行政区划,昌江黎族自治县',
            areaCode: '100004600900260000'
          },
          {
            id: 3724,
            parentId: 12675,
            areaName: '乐东黎族自治县',
            areaPath: '中国,海南省,省直辖县级行政区划,乐东黎族自治县',
            areaCode: '100004600900270000'
          },
          {
            id: 3725,
            parentId: 12675,
            areaName: '陵水黎族自治县',
            areaPath: '中国,海南省,省直辖县级行政区划,陵水黎族自治县',
            areaCode: '100004600900280000'
          },
          {
            id: 3726,
            parentId: 12675,
            areaName: '保亭黎族苗族自治县',
            areaPath: '中国,海南省,省直辖县级行政区划,保亭黎族苗族自治县',
            areaCode: '100004600900290000'
          },
          {
            id: 3727,
            parentId: 12675,
            areaName: '琼中黎族苗族自治县',
            areaPath: '中国,海南省,省直辖县级行政区划,琼中黎族苗族自治县',
            areaCode: '100004600900300000'
          }
        ]
      }
    ]
  },
  {
    id: 1455,
    parentId: 1,
    areaName: '重庆',
    areaPath: '中国,重庆',
    areaCode: '100005000000000000',
    children: [
      {
        id: 3728,
        parentId: 1455,
        areaName: '重庆市',
        areaPath: '中国,重庆,重庆市',
        areaCode: '100005000010000000',
        children: [
          {
            id: 11626,
            parentId: 3728,
            areaName: '万州区',
            areaPath: '中国,重庆,重庆市,万州区',
            areaCode: '100005000010010000'
          },
          {
            id: 11627,
            parentId: 3728,
            areaName: '涪陵区',
            areaPath: '中国,重庆,重庆市,涪陵区',
            areaCode: '100005000010020000'
          },
          {
            id: 11628,
            parentId: 3728,
            areaName: '渝中区',
            areaPath: '中国,重庆,重庆市,渝中区',
            areaCode: '100005000010030000'
          },
          {
            id: 11629,
            parentId: 3728,
            areaName: '大渡口区',
            areaPath: '中国,重庆,重庆市,大渡口区',
            areaCode: '100005000010040000'
          },
          {
            id: 11630,
            parentId: 3728,
            areaName: '江北区',
            areaPath: '中国,重庆,重庆市,江北区',
            areaCode: '100005000010050000'
          },
          {
            id: 11631,
            parentId: 3728,
            areaName: '沙坪坝区',
            areaPath: '中国,重庆,重庆市,沙坪坝区',
            areaCode: '100005000010060000'
          },
          {
            id: 11632,
            parentId: 3728,
            areaName: '九龙坡区',
            areaPath: '中国,重庆,重庆市,九龙坡区',
            areaCode: '100005000010070000'
          },
          {
            id: 11633,
            parentId: 3728,
            areaName: '南岸区',
            areaPath: '中国,重庆,重庆市,南岸区',
            areaCode: '100005000010080000'
          },
          {
            id: 11634,
            parentId: 3728,
            areaName: '北碚区',
            areaPath: '中国,重庆,重庆市,北碚区',
            areaCode: '100005000010090000'
          },
          {
            id: 11635,
            parentId: 3728,
            areaName: '綦江区',
            areaPath: '中国,重庆,重庆市,綦江区',
            areaCode: '100005000010100000'
          },
          {
            id: 11636,
            parentId: 3728,
            areaName: '大足区',
            areaPath: '中国,重庆,重庆市,大足区',
            areaCode: '100005000010110000'
          },
          {
            id: 11637,
            parentId: 3728,
            areaName: '渝北区',
            areaPath: '中国,重庆,重庆市,渝北区',
            areaCode: '100005000010120000'
          },
          {
            id: 11638,
            parentId: 3728,
            areaName: '巴南区',
            areaPath: '中国,重庆,重庆市,巴南区',
            areaCode: '100005000010130000'
          },
          {
            id: 11639,
            parentId: 3728,
            areaName: '黔江区',
            areaPath: '中国,重庆,重庆市,黔江区',
            areaCode: '100005000010140000'
          },
          {
            id: 11640,
            parentId: 3728,
            areaName: '长寿区',
            areaPath: '中国,重庆,重庆市,长寿区',
            areaCode: '100005000010150000'
          },
          {
            id: 11641,
            parentId: 3728,
            areaName: '江津区',
            areaPath: '中国,重庆,重庆市,江津区',
            areaCode: '100005000010160000'
          },
          {
            id: 11642,
            parentId: 3728,
            areaName: '合川区',
            areaPath: '中国,重庆,重庆市,合川区',
            areaCode: '100005000010170000'
          },
          {
            id: 11643,
            parentId: 3728,
            areaName: '永川区',
            areaPath: '中国,重庆,重庆市,永川区',
            areaCode: '100005000010180000'
          },
          {
            id: 11644,
            parentId: 3728,
            areaName: '南川区',
            areaPath: '中国,重庆,重庆市,南川区',
            areaCode: '100005000010190000'
          },
          {
            id: 11645,
            parentId: 3728,
            areaName: '璧山区',
            areaPath: '中国,重庆,重庆市,璧山区',
            areaCode: '100005000010200000'
          },
          {
            id: 11646,
            parentId: 3728,
            areaName: '铜梁区',
            areaPath: '中国,重庆,重庆市,铜梁区',
            areaCode: '100005000010510000'
          },
          {
            id: 11647,
            parentId: 3728,
            areaName: '潼南区',
            areaPath: '中国,重庆,重庆市,潼南区',
            areaCode: '100005000010520000'
          },
          {
            id: 11648,
            parentId: 3728,
            areaName: '荣昌区',
            areaPath: '中国,重庆,重庆市,荣昌区',
            areaCode: '100005000010530000'
          },
          {
            id: 11649,
            parentId: 3728,
            areaName: '开州区',
            areaPath: '中国,重庆,重庆市,开州区',
            areaCode: '100005000010540000'
          },
          {
            id: 11650,
            parentId: 3728,
            areaName: '梁平区',
            areaPath: '中国,重庆,重庆市,梁平区',
            areaCode: '100005000010550000'
          },
          {
            id: 11651,
            parentId: 3728,
            areaName: '武隆区',
            areaPath: '中国,重庆,重庆市,武隆区',
            areaCode: '100005000010560000'
          }
        ]
      },
      {
        id: 1364744,
        parentId: 1455,
        areaName: '重庆县',
        areaPath: '中国,重庆,重庆县',
        areaCode: '100005000020000000',
        children: [
          {
            id: 11652,
            parentId: 1364744,
            areaName: '城口县',
            areaPath: '中国,重庆,重庆县,城口县',
            areaCode: '100005000020290000'
          },
          {
            id: 11653,
            parentId: 1364744,
            areaName: '丰都县',
            areaPath: '中国,重庆,重庆县,丰都县',
            areaCode: '100005000020300000'
          },
          {
            id: 11654,
            parentId: 1364744,
            areaName: '垫江县',
            areaPath: '中国,重庆,重庆县,垫江县',
            areaCode: '100005000020310000'
          },
          {
            id: 11655,
            parentId: 1364744,
            areaName: '忠县',
            areaPath: '中国,重庆,重庆县,忠县',
            areaCode: '100005000020330000'
          },
          {
            id: 11656,
            parentId: 1364744,
            areaName: '云阳县',
            areaPath: '中国,重庆,重庆县,云阳县',
            areaCode: '100005000020350000'
          },
          {
            id: 11657,
            parentId: 1364744,
            areaName: '奉节县',
            areaPath: '中国,重庆,重庆县,奉节县',
            areaCode: '100005000020360000'
          },
          {
            id: 11658,
            parentId: 1364744,
            areaName: '巫山县',
            areaPath: '中国,重庆,重庆县,巫山县',
            areaCode: '100005000020370000'
          },
          {
            id: 11659,
            parentId: 1364744,
            areaName: '巫溪县',
            areaPath: '中国,重庆,重庆县,巫溪县',
            areaCode: '100005000020380000'
          },
          {
            id: 11660,
            parentId: 1364744,
            areaName: '石柱土家族自治县',
            areaPath: '中国,重庆,重庆县,石柱土家族自治县',
            areaCode: '100005000020400000'
          },
          {
            id: 11661,
            parentId: 1364744,
            areaName: '秀山土家族苗族自治县',
            areaPath: '中国,重庆,重庆县,秀山土家族苗族自治县',
            areaCode: '100005000020410000'
          },
          {
            id: 11662,
            parentId: 1364744,
            areaName: '酉阳土家族苗族自治县',
            areaPath: '中国,重庆,重庆县,酉阳土家族苗族自治县',
            areaCode: '100005000020420000'
          },
          {
            id: 11663,
            parentId: 1364744,
            areaName: '彭水苗族土家族自治县',
            areaPath: '中国,重庆,重庆县,彭水苗族土家族自治县',
            areaCode: '100005000020430000'
          }
        ]
      }
    ]
  },
  {
    id: 1456,
    parentId: 1,
    areaName: '四川省',
    areaPath: '中国,四川省',
    areaCode: '100005100000000000',
    children: [
      {
        id: 3729,
        parentId: 1456,
        areaName: '成都市',
        areaPath: '中国,四川省,成都市',
        areaCode: '100005100010000000',
        children: [
          {
            id: 11664,
            parentId: 3729,
            areaName: '锦江区',
            areaPath: '中国,四川省,成都市,锦江区',
            areaCode: '100005100010040000'
          },
          {
            id: 11665,
            parentId: 3729,
            areaName: '青羊区',
            areaPath: '中国,四川省,成都市,青羊区',
            areaCode: '100005100010050000'
          },
          {
            id: 11666,
            parentId: 3729,
            areaName: '金牛区',
            areaPath: '中国,四川省,成都市,金牛区',
            areaCode: '100005100010060000'
          },
          {
            id: 11667,
            parentId: 3729,
            areaName: '武侯区',
            areaPath: '中国,四川省,成都市,武侯区',
            areaCode: '100005100010070000'
          },
          {
            id: 11668,
            parentId: 3729,
            areaName: '成华区',
            areaPath: '中国,四川省,成都市,成华区',
            areaCode: '100005100010080000'
          },
          {
            id: 11669,
            parentId: 3729,
            areaName: '龙泉驿区',
            areaPath: '中国,四川省,成都市,龙泉驿区',
            areaCode: '100005100010120000'
          },
          {
            id: 11670,
            parentId: 3729,
            areaName: '青白江区',
            areaPath: '中国,四川省,成都市,青白江区',
            areaCode: '100005100010130000'
          },
          {
            id: 11671,
            parentId: 3729,
            areaName: '新都区',
            areaPath: '中国,四川省,成都市,新都区',
            areaCode: '100005100010140000'
          },
          {
            id: 11672,
            parentId: 3729,
            areaName: '温江区',
            areaPath: '中国,四川省,成都市,温江区',
            areaCode: '100005100010150000'
          },
          {
            id: 11673,
            parentId: 3729,
            areaName: '双流区',
            areaPath: '中国,四川省,成都市,双流区',
            areaCode: '100005100010160000'
          },
          {
            id: 11674,
            parentId: 3729,
            areaName: '郫都区',
            areaPath: '中国,四川省,成都市,郫都区',
            areaCode: '100005100010170000'
          },
          {
            id: 11675,
            parentId: 3729,
            areaName: '金堂县',
            areaPath: '中国,四川省,成都市,金堂县',
            areaCode: '100005100010210000'
          },
          {
            id: 11676,
            parentId: 3729,
            areaName: '大邑县',
            areaPath: '中国,四川省,成都市,大邑县',
            areaCode: '100005100010290000'
          },
          {
            id: 11677,
            parentId: 3729,
            areaName: '蒲江县',
            areaPath: '中国,四川省,成都市,蒲江县',
            areaCode: '100005100010310000'
          },
          {
            id: 11678,
            parentId: 3729,
            areaName: '新津县',
            areaPath: '中国,四川省,成都市,新津县',
            areaCode: '100005100010320000'
          },
          {
            id: 11679,
            parentId: 3729,
            areaName: '都江堰市',
            areaPath: '中国,四川省,成都市,都江堰市',
            areaCode: '100005100010810000'
          },
          {
            id: 11680,
            parentId: 3729,
            areaName: '彭州市',
            areaPath: '中国,四川省,成都市,彭州市',
            areaCode: '100005100010820000'
          },
          {
            id: 11681,
            parentId: 3729,
            areaName: '邛崃市',
            areaPath: '中国,四川省,成都市,邛崃市',
            areaCode: '100005100010830000'
          },
          {
            id: 11682,
            parentId: 3729,
            areaName: '崇州市',
            areaPath: '中国,四川省,成都市,崇州市',
            areaCode: '100005100010840000'
          },
          {
            id: 11683,
            parentId: 3729,
            areaName: '简阳市',
            areaPath: '中国,四川省,成都市,简阳市',
            areaCode: '100005100010850000'
          }
        ]
      },
      {
        id: 3730,
        parentId: 1456,
        areaName: '自贡市',
        areaPath: '中国,四川省,自贡市',
        areaCode: '100005100030000000',
        children: [
          {
            id: 11684,
            parentId: 3730,
            areaName: '自流井区',
            areaPath: '中国,四川省,自贡市,自流井区',
            areaCode: '100005100030020000'
          },
          {
            id: 11685,
            parentId: 3730,
            areaName: '贡井区',
            areaPath: '中国,四川省,自贡市,贡井区',
            areaCode: '100005100030030000'
          },
          {
            id: 11686,
            parentId: 3730,
            areaName: '大安区',
            areaPath: '中国,四川省,自贡市,大安区',
            areaCode: '100005100030040000'
          },
          {
            id: 11687,
            parentId: 3730,
            areaName: '沿滩区',
            areaPath: '中国,四川省,自贡市,沿滩区',
            areaCode: '100005100030110000'
          },
          {
            id: 11688,
            parentId: 3730,
            areaName: '荣县',
            areaPath: '中国,四川省,自贡市,荣县',
            areaCode: '100005100030210000'
          },
          {
            id: 11689,
            parentId: 3730,
            areaName: '富顺县',
            areaPath: '中国,四川省,自贡市,富顺县',
            areaCode: '100005100030220000'
          }
        ]
      },
      {
        id: 3731,
        parentId: 1456,
        areaName: '攀枝花市',
        areaPath: '中国,四川省,攀枝花市',
        areaCode: '100005100040000000',
        children: [
          {
            id: 11690,
            parentId: 3731,
            areaName: '东区',
            areaPath: '中国,四川省,攀枝花市,东区',
            areaCode: '100005100040020000'
          },
          {
            id: 11691,
            parentId: 3731,
            areaName: '西区',
            areaPath: '中国,四川省,攀枝花市,西区',
            areaCode: '100005100040030000'
          },
          {
            id: 11692,
            parentId: 3731,
            areaName: '仁和区',
            areaPath: '中国,四川省,攀枝花市,仁和区',
            areaCode: '100005100040110000'
          },
          {
            id: 11693,
            parentId: 3731,
            areaName: '米易县',
            areaPath: '中国,四川省,攀枝花市,米易县',
            areaCode: '100005100040210000'
          },
          {
            id: 11694,
            parentId: 3731,
            areaName: '盐边县',
            areaPath: '中国,四川省,攀枝花市,盐边县',
            areaCode: '100005100040220000'
          }
        ]
      },
      {
        id: 3732,
        parentId: 1456,
        areaName: '泸州市',
        areaPath: '中国,四川省,泸州市',
        areaCode: '100005100050000000',
        children: [
          {
            id: 11695,
            parentId: 3732,
            areaName: '江阳区',
            areaPath: '中国,四川省,泸州市,江阳区',
            areaCode: '100005100050020000'
          },
          {
            id: 11696,
            parentId: 3732,
            areaName: '纳溪区',
            areaPath: '中国,四川省,泸州市,纳溪区',
            areaCode: '100005100050030000'
          },
          {
            id: 11697,
            parentId: 3732,
            areaName: '龙马潭区',
            areaPath: '中国,四川省,泸州市,龙马潭区',
            areaCode: '100005100050040000'
          },
          {
            id: 11698,
            parentId: 3732,
            areaName: '泸县',
            areaPath: '中国,四川省,泸州市,泸县',
            areaCode: '100005100050210000'
          },
          {
            id: 11699,
            parentId: 3732,
            areaName: '合江县',
            areaPath: '中国,四川省,泸州市,合江县',
            areaCode: '100005100050220000'
          },
          {
            id: 11700,
            parentId: 3732,
            areaName: '叙永县',
            areaPath: '中国,四川省,泸州市,叙永县',
            areaCode: '100005100050240000'
          },
          {
            id: 11701,
            parentId: 3732,
            areaName: '古蔺县',
            areaPath: '中国,四川省,泸州市,古蔺县',
            areaCode: '100005100050250000'
          }
        ]
      },
      {
        id: 3733,
        parentId: 1456,
        areaName: '德阳市',
        areaPath: '中国,四川省,德阳市',
        areaCode: '100005100060000000',
        children: [
          {
            id: 11702,
            parentId: 3733,
            areaName: '旌阳区',
            areaPath: '中国,四川省,德阳市,旌阳区',
            areaCode: '100005100060030000'
          },
          {
            id: 11703,
            parentId: 3733,
            areaName: '罗江区',
            areaPath: '中国,四川省,德阳市,罗江区',
            areaCode: '100005100060040000'
          },
          {
            id: 11704,
            parentId: 3733,
            areaName: '中江县',
            areaPath: '中国,四川省,德阳市,中江县',
            areaCode: '100005100060230000'
          },
          {
            id: 11705,
            parentId: 3733,
            areaName: '广汉市',
            areaPath: '中国,四川省,德阳市,广汉市',
            areaCode: '100005100060810000'
          },
          {
            id: 11706,
            parentId: 3733,
            areaName: '什邡市',
            areaPath: '中国,四川省,德阳市,什邡市',
            areaCode: '100005100060820000'
          },
          {
            id: 11707,
            parentId: 3733,
            areaName: '绵竹市',
            areaPath: '中国,四川省,德阳市,绵竹市',
            areaCode: '100005100060830000'
          }
        ]
      },
      {
        id: 3734,
        parentId: 1456,
        areaName: '绵阳市',
        areaPath: '中国,四川省,绵阳市',
        areaCode: '100005100070000000',
        children: [
          {
            id: 11708,
            parentId: 3734,
            areaName: '涪城区',
            areaPath: '中国,四川省,绵阳市,涪城区',
            areaCode: '100005100070030000'
          },
          {
            id: 11709,
            parentId: 3734,
            areaName: '游仙区',
            areaPath: '中国,四川省,绵阳市,游仙区',
            areaCode: '100005100070040000'
          },
          {
            id: 11710,
            parentId: 3734,
            areaName: '安州区',
            areaPath: '中国,四川省,绵阳市,安州区',
            areaCode: '100005100070050000'
          },
          {
            id: 11711,
            parentId: 3734,
            areaName: '三台县',
            areaPath: '中国,四川省,绵阳市,三台县',
            areaCode: '100005100070220000'
          },
          {
            id: 11712,
            parentId: 3734,
            areaName: '盐亭县',
            areaPath: '中国,四川省,绵阳市,盐亭县',
            areaCode: '100005100070230000'
          },
          {
            id: 11713,
            parentId: 3734,
            areaName: '梓潼县',
            areaPath: '中国,四川省,绵阳市,梓潼县',
            areaCode: '100005100070250000'
          },
          {
            id: 11714,
            parentId: 3734,
            areaName: '北川羌族自治县',
            areaPath: '中国,四川省,绵阳市,北川羌族自治县',
            areaCode: '100005100070260000'
          },
          {
            id: 11715,
            parentId: 3734,
            areaName: '平武县',
            areaPath: '中国,四川省,绵阳市,平武县',
            areaCode: '100005100070270000'
          },
          {
            id: 11716,
            parentId: 3734,
            areaName: '江油市',
            areaPath: '中国,四川省,绵阳市,江油市',
            areaCode: '100005100070810000'
          }
        ]
      },
      {
        id: 3735,
        parentId: 1456,
        areaName: '广元市',
        areaPath: '中国,四川省,广元市',
        areaCode: '100005100080000000',
        children: [
          {
            id: 11717,
            parentId: 3735,
            areaName: '利州区',
            areaPath: '中国,四川省,广元市,利州区',
            areaCode: '100005100080020000'
          },
          {
            id: 11718,
            parentId: 3735,
            areaName: '昭化区',
            areaPath: '中国,四川省,广元市,昭化区',
            areaCode: '100005100080110000'
          },
          {
            id: 11719,
            parentId: 3735,
            areaName: '朝天区',
            areaPath: '中国,四川省,广元市,朝天区',
            areaCode: '100005100080120000'
          },
          {
            id: 11720,
            parentId: 3735,
            areaName: '旺苍县',
            areaPath: '中国,四川省,广元市,旺苍县',
            areaCode: '100005100080210000'
          },
          {
            id: 11721,
            parentId: 3735,
            areaName: '青川县',
            areaPath: '中国,四川省,广元市,青川县',
            areaCode: '100005100080220000'
          },
          {
            id: 11722,
            parentId: 3735,
            areaName: '剑阁县',
            areaPath: '中国,四川省,广元市,剑阁县',
            areaCode: '100005100080230000'
          },
          {
            id: 11723,
            parentId: 3735,
            areaName: '苍溪县',
            areaPath: '中国,四川省,广元市,苍溪县',
            areaCode: '100005100080240000'
          }
        ]
      },
      {
        id: 3736,
        parentId: 1456,
        areaName: '遂宁市',
        areaPath: '中国,四川省,遂宁市',
        areaCode: '100005100090000000',
        children: [
          {
            id: 11724,
            parentId: 3736,
            areaName: '船山区',
            areaPath: '中国,四川省,遂宁市,船山区',
            areaCode: '100005100090030000'
          },
          {
            id: 11725,
            parentId: 3736,
            areaName: '安居区',
            areaPath: '中国,四川省,遂宁市,安居区',
            areaCode: '100005100090040000'
          },
          {
            id: 11726,
            parentId: 3736,
            areaName: '蓬溪县',
            areaPath: '中国,四川省,遂宁市,蓬溪县',
            areaCode: '100005100090210000'
          },
          {
            id: 11727,
            parentId: 3736,
            areaName: '射洪县',
            areaPath: '中国,四川省,遂宁市,射洪县',
            areaCode: '100005100090220000'
          },
          {
            id: 11728,
            parentId: 3736,
            areaName: '大英县',
            areaPath: '中国,四川省,遂宁市,大英县',
            areaCode: '100005100090230000'
          }
        ]
      },
      {
        id: 3737,
        parentId: 1456,
        areaName: '内江市',
        areaPath: '中国,四川省,内江市',
        areaCode: '100005100100000000',
        children: [
          {
            id: 11729,
            parentId: 3737,
            areaName: '市中区',
            areaPath: '中国,四川省,内江市,市中区',
            areaCode: '100005100100020000'
          },
          {
            id: 11730,
            parentId: 3737,
            areaName: '东兴区',
            areaPath: '中国,四川省,内江市,东兴区',
            areaCode: '100005100100110000'
          },
          {
            id: 11731,
            parentId: 3737,
            areaName: '威远县',
            areaPath: '中国,四川省,内江市,威远县',
            areaCode: '100005100100240000'
          },
          {
            id: 11732,
            parentId: 3737,
            areaName: '资中县',
            areaPath: '中国,四川省,内江市,资中县',
            areaCode: '100005100100250000'
          },
          {
            id: 11733,
            parentId: 3737,
            areaName: '隆昌市',
            areaPath: '中国,四川省,内江市,隆昌市',
            areaCode: '100005100100830000'
          }
        ]
      },
      {
        id: 3738,
        parentId: 1456,
        areaName: '乐山市',
        areaPath: '中国,四川省,乐山市',
        areaCode: '100005100110000000',
        children: [
          {
            id: 11734,
            parentId: 3738,
            areaName: '市中区',
            areaPath: '中国,四川省,乐山市,市中区',
            areaCode: '100005100110020000'
          },
          {
            id: 11735,
            parentId: 3738,
            areaName: '沙湾区',
            areaPath: '中国,四川省,乐山市,沙湾区',
            areaCode: '100005100110110000'
          },
          {
            id: 11736,
            parentId: 3738,
            areaName: '五通桥区',
            areaPath: '中国,四川省,乐山市,五通桥区',
            areaCode: '100005100110120000'
          },
          {
            id: 11737,
            parentId: 3738,
            areaName: '金口河区',
            areaPath: '中国,四川省,乐山市,金口河区',
            areaCode: '100005100110130000'
          },
          {
            id: 11738,
            parentId: 3738,
            areaName: '犍为县',
            areaPath: '中国,四川省,乐山市,犍为县',
            areaCode: '100005100110230000'
          },
          {
            id: 11739,
            parentId: 3738,
            areaName: '井研县',
            areaPath: '中国,四川省,乐山市,井研县',
            areaCode: '100005100110240000'
          },
          {
            id: 11740,
            parentId: 3738,
            areaName: '夹江县',
            areaPath: '中国,四川省,乐山市,夹江县',
            areaCode: '100005100110260000'
          },
          {
            id: 11741,
            parentId: 3738,
            areaName: '沐川县',
            areaPath: '中国,四川省,乐山市,沐川县',
            areaCode: '100005100110290000'
          },
          {
            id: 11742,
            parentId: 3738,
            areaName: '峨边彝族自治县',
            areaPath: '中国,四川省,乐山市,峨边彝族自治县',
            areaCode: '100005100110320000'
          },
          {
            id: 11743,
            parentId: 3738,
            areaName: '马边彝族自治县',
            areaPath: '中国,四川省,乐山市,马边彝族自治县',
            areaCode: '100005100110330000'
          },
          {
            id: 11744,
            parentId: 3738,
            areaName: '峨眉山市',
            areaPath: '中国,四川省,乐山市,峨眉山市',
            areaCode: '100005100110810000'
          }
        ]
      },
      {
        id: 3739,
        parentId: 1456,
        areaName: '南充市',
        areaPath: '中国,四川省,南充市',
        areaCode: '100005100130000000',
        children: [
          {
            id: 11745,
            parentId: 3739,
            areaName: '顺庆区',
            areaPath: '中国,四川省,南充市,顺庆区',
            areaCode: '100005100130020000'
          },
          {
            id: 11746,
            parentId: 3739,
            areaName: '高坪区',
            areaPath: '中国,四川省,南充市,高坪区',
            areaCode: '100005100130030000'
          },
          {
            id: 11747,
            parentId: 3739,
            areaName: '嘉陵区',
            areaPath: '中国,四川省,南充市,嘉陵区',
            areaCode: '100005100130040000'
          },
          {
            id: 11748,
            parentId: 3739,
            areaName: '南部县',
            areaPath: '中国,四川省,南充市,南部县',
            areaCode: '100005100130210000'
          },
          {
            id: 11749,
            parentId: 3739,
            areaName: '营山县',
            areaPath: '中国,四川省,南充市,营山县',
            areaCode: '100005100130220000'
          },
          {
            id: 11750,
            parentId: 3739,
            areaName: '蓬安县',
            areaPath: '中国,四川省,南充市,蓬安县',
            areaCode: '100005100130230000'
          },
          {
            id: 11751,
            parentId: 3739,
            areaName: '仪陇县',
            areaPath: '中国,四川省,南充市,仪陇县',
            areaCode: '100005100130240000'
          },
          {
            id: 11752,
            parentId: 3739,
            areaName: '西充县',
            areaPath: '中国,四川省,南充市,西充县',
            areaCode: '100005100130250000'
          },
          {
            id: 11753,
            parentId: 3739,
            areaName: '阆中市',
            areaPath: '中国,四川省,南充市,阆中市',
            areaCode: '100005100130810000'
          }
        ]
      },
      {
        id: 3740,
        parentId: 1456,
        areaName: '眉山市',
        areaPath: '中国,四川省,眉山市',
        areaCode: '100005100140000000',
        children: [
          {
            id: 11754,
            parentId: 3740,
            areaName: '东坡区',
            areaPath: '中国,四川省,眉山市,东坡区',
            areaCode: '100005100140020000'
          },
          {
            id: 11755,
            parentId: 3740,
            areaName: '彭山区',
            areaPath: '中国,四川省,眉山市,彭山区',
            areaCode: '100005100140030000'
          },
          {
            id: 11756,
            parentId: 3740,
            areaName: '仁寿县',
            areaPath: '中国,四川省,眉山市,仁寿县',
            areaCode: '100005100140210000'
          },
          {
            id: 11757,
            parentId: 3740,
            areaName: '洪雅县',
            areaPath: '中国,四川省,眉山市,洪雅县',
            areaCode: '100005100140230000'
          },
          {
            id: 11758,
            parentId: 3740,
            areaName: '丹棱县',
            areaPath: '中国,四川省,眉山市,丹棱县',
            areaCode: '100005100140240000'
          },
          {
            id: 11759,
            parentId: 3740,
            areaName: '青神县',
            areaPath: '中国,四川省,眉山市,青神县',
            areaCode: '100005100140250000'
          }
        ]
      },
      {
        id: 3741,
        parentId: 1456,
        areaName: '宜宾市',
        areaPath: '中国,四川省,宜宾市',
        areaCode: '100005100150000000',
        children: [
          {
            id: 11760,
            parentId: 3741,
            areaName: '翠屏区',
            areaPath: '中国,四川省,宜宾市,翠屏区',
            areaCode: '100005100150020000'
          },
          {
            id: 11761,
            parentId: 3741,
            areaName: '南溪区',
            areaPath: '中国,四川省,宜宾市,南溪区',
            areaCode: '100005100150030000'
          },
          {
            id: 11762,
            parentId: 3741,
            areaName: '宜宾县',
            areaPath: '中国,四川省,宜宾市,宜宾县',
            areaCode: '100005100150210000'
          },
          {
            id: 11763,
            parentId: 3741,
            areaName: '江安县',
            areaPath: '中国,四川省,宜宾市,江安县',
            areaCode: '100005100150230000'
          },
          {
            id: 11764,
            parentId: 3741,
            areaName: '长宁县',
            areaPath: '中国,四川省,宜宾市,长宁县',
            areaCode: '100005100150240000'
          },
          {
            id: 11765,
            parentId: 3741,
            areaName: '高县',
            areaPath: '中国,四川省,宜宾市,高县',
            areaCode: '100005100150250000'
          },
          {
            id: 11766,
            parentId: 3741,
            areaName: '珙县',
            areaPath: '中国,四川省,宜宾市,珙县',
            areaCode: '100005100150260000'
          },
          {
            id: 11767,
            parentId: 3741,
            areaName: '筠连县',
            areaPath: '中国,四川省,宜宾市,筠连县',
            areaCode: '100005100150270000'
          },
          {
            id: 11768,
            parentId: 3741,
            areaName: '兴文县',
            areaPath: '中国,四川省,宜宾市,兴文县',
            areaCode: '100005100150280000'
          },
          {
            id: 11769,
            parentId: 3741,
            areaName: '屏山县',
            areaPath: '中国,四川省,宜宾市,屏山县',
            areaCode: '100005100150290000'
          }
        ]
      },
      {
        id: 3742,
        parentId: 1456,
        areaName: '广安市',
        areaPath: '中国,四川省,广安市',
        areaCode: '100005100160000000',
        children: [
          {
            id: 11770,
            parentId: 3742,
            areaName: '广安区',
            areaPath: '中国,四川省,广安市,广安区',
            areaCode: '100005100160020000'
          },
          {
            id: 11771,
            parentId: 3742,
            areaName: '前锋区',
            areaPath: '中国,四川省,广安市,前锋区',
            areaCode: '100005100160030000'
          },
          {
            id: 11772,
            parentId: 3742,
            areaName: '岳池县',
            areaPath: '中国,四川省,广安市,岳池县',
            areaCode: '100005100160210000'
          },
          {
            id: 11773,
            parentId: 3742,
            areaName: '武胜县',
            areaPath: '中国,四川省,广安市,武胜县',
            areaCode: '100005100160220000'
          },
          {
            id: 11774,
            parentId: 3742,
            areaName: '邻水县',
            areaPath: '中国,四川省,广安市,邻水县',
            areaCode: '100005100160230000'
          },
          {
            id: 11775,
            parentId: 3742,
            areaName: '华蓥市',
            areaPath: '中国,四川省,广安市,华蓥市',
            areaCode: '100005100160810000'
          }
        ]
      },
      {
        id: 3743,
        parentId: 1456,
        areaName: '达州市',
        areaPath: '中国,四川省,达州市',
        areaCode: '100005100170000000',
        children: [
          {
            id: 11776,
            parentId: 3743,
            areaName: '通川区',
            areaPath: '中国,四川省,达州市,通川区',
            areaCode: '100005100170020000'
          },
          {
            id: 11777,
            parentId: 3743,
            areaName: '达川区',
            areaPath: '中国,四川省,达州市,达川区',
            areaCode: '100005100170030000'
          },
          {
            id: 11778,
            parentId: 3743,
            areaName: '宣汉县',
            areaPath: '中国,四川省,达州市,宣汉县',
            areaCode: '100005100170220000'
          },
          {
            id: 11779,
            parentId: 3743,
            areaName: '开江县',
            areaPath: '中国,四川省,达州市,开江县',
            areaCode: '100005100170230000'
          },
          {
            id: 11780,
            parentId: 3743,
            areaName: '大竹县',
            areaPath: '中国,四川省,达州市,大竹县',
            areaCode: '100005100170240000'
          },
          {
            id: 11781,
            parentId: 3743,
            areaName: '渠县',
            areaPath: '中国,四川省,达州市,渠县',
            areaCode: '100005100170250000'
          },
          {
            id: 11782,
            parentId: 3743,
            areaName: '万源市',
            areaPath: '中国,四川省,达州市,万源市',
            areaCode: '100005100170810000'
          }
        ]
      },
      {
        id: 3744,
        parentId: 1456,
        areaName: '雅安市',
        areaPath: '中国,四川省,雅安市',
        areaCode: '100005100180000000',
        children: [
          {
            id: 11783,
            parentId: 3744,
            areaName: '雨城区',
            areaPath: '中国,四川省,雅安市,雨城区',
            areaCode: '100005100180020000'
          },
          {
            id: 11784,
            parentId: 3744,
            areaName: '名山区',
            areaPath: '中国,四川省,雅安市,名山区',
            areaCode: '100005100180030000'
          },
          {
            id: 11785,
            parentId: 3744,
            areaName: '荥经县',
            areaPath: '中国,四川省,雅安市,荥经县',
            areaCode: '100005100180220000'
          },
          {
            id: 11786,
            parentId: 3744,
            areaName: '汉源县',
            areaPath: '中国,四川省,雅安市,汉源县',
            areaCode: '100005100180230000'
          },
          {
            id: 11787,
            parentId: 3744,
            areaName: '石棉县',
            areaPath: '中国,四川省,雅安市,石棉县',
            areaCode: '100005100180240000'
          },
          {
            id: 11788,
            parentId: 3744,
            areaName: '天全县',
            areaPath: '中国,四川省,雅安市,天全县',
            areaCode: '100005100180250000'
          },
          {
            id: 11789,
            parentId: 3744,
            areaName: '芦山县',
            areaPath: '中国,四川省,雅安市,芦山县',
            areaCode: '100005100180260000'
          },
          {
            id: 11790,
            parentId: 3744,
            areaName: '宝兴县',
            areaPath: '中国,四川省,雅安市,宝兴县',
            areaCode: '100005100180270000'
          }
        ]
      },
      {
        id: 3745,
        parentId: 1456,
        areaName: '巴中市',
        areaPath: '中国,四川省,巴中市',
        areaCode: '100005100190000000',
        children: [
          {
            id: 11791,
            parentId: 3745,
            areaName: '巴州区',
            areaPath: '中国,四川省,巴中市,巴州区',
            areaCode: '100005100190020000'
          },
          {
            id: 11792,
            parentId: 3745,
            areaName: '恩阳区',
            areaPath: '中国,四川省,巴中市,恩阳区',
            areaCode: '100005100190030000'
          },
          {
            id: 11793,
            parentId: 3745,
            areaName: '通江县',
            areaPath: '中国,四川省,巴中市,通江县',
            areaCode: '100005100190210000'
          },
          {
            id: 11794,
            parentId: 3745,
            areaName: '南江县',
            areaPath: '中国,四川省,巴中市,南江县',
            areaCode: '100005100190220000'
          },
          {
            id: 11795,
            parentId: 3745,
            areaName: '平昌县',
            areaPath: '中国,四川省,巴中市,平昌县',
            areaCode: '100005100190230000'
          }
        ]
      },
      {
        id: 3746,
        parentId: 1456,
        areaName: '资阳市',
        areaPath: '中国,四川省,资阳市',
        areaCode: '100005100200000000',
        children: [
          {
            id: 11796,
            parentId: 3746,
            areaName: '雁江区',
            areaPath: '中国,四川省,资阳市,雁江区',
            areaCode: '100005100200020000'
          },
          {
            id: 11797,
            parentId: 3746,
            areaName: '安岳县',
            areaPath: '中国,四川省,资阳市,安岳县',
            areaCode: '100005100200210000'
          },
          {
            id: 11798,
            parentId: 3746,
            areaName: '乐至县',
            areaPath: '中国,四川省,资阳市,乐至县',
            areaCode: '100005100200220000'
          }
        ]
      },
      {
        id: 3747,
        parentId: 1456,
        areaName: '阿坝藏族羌族自治州',
        areaPath: '中国,四川省,阿坝藏族羌族自治州',
        areaCode: '100005100320000000',
        children: [
          {
            id: 11799,
            parentId: 3747,
            areaName: '马尔康市',
            areaPath: '中国,四川省,阿坝藏族羌族自治州,马尔康市',
            areaCode: '100005100320010000'
          },
          {
            id: 11800,
            parentId: 3747,
            areaName: '汶川县',
            areaPath: '中国,四川省,阿坝藏族羌族自治州,汶川县',
            areaCode: '100005100320210000'
          },
          {
            id: 11801,
            parentId: 3747,
            areaName: '理县',
            areaPath: '中国,四川省,阿坝藏族羌族自治州,理县',
            areaCode: '100005100320220000'
          },
          {
            id: 11802,
            parentId: 3747,
            areaName: '茂县',
            areaPath: '中国,四川省,阿坝藏族羌族自治州,茂县',
            areaCode: '100005100320230000'
          },
          {
            id: 11803,
            parentId: 3747,
            areaName: '松潘县',
            areaPath: '中国,四川省,阿坝藏族羌族自治州,松潘县',
            areaCode: '100005100320240000'
          },
          {
            id: 11804,
            parentId: 3747,
            areaName: '九寨沟县',
            areaPath: '中国,四川省,阿坝藏族羌族自治州,九寨沟县',
            areaCode: '100005100320250000'
          },
          {
            id: 11805,
            parentId: 3747,
            areaName: '金川县',
            areaPath: '中国,四川省,阿坝藏族羌族自治州,金川县',
            areaCode: '100005100320260000'
          },
          {
            id: 11806,
            parentId: 3747,
            areaName: '小金县',
            areaPath: '中国,四川省,阿坝藏族羌族自治州,小金县',
            areaCode: '100005100320270000'
          },
          {
            id: 11807,
            parentId: 3747,
            areaName: '黑水县',
            areaPath: '中国,四川省,阿坝藏族羌族自治州,黑水县',
            areaCode: '100005100320280000'
          },
          {
            id: 11808,
            parentId: 3747,
            areaName: '壤塘县',
            areaPath: '中国,四川省,阿坝藏族羌族自治州,壤塘县',
            areaCode: '100005100320300000'
          },
          {
            id: 11809,
            parentId: 3747,
            areaName: '阿坝县',
            areaPath: '中国,四川省,阿坝藏族羌族自治州,阿坝县',
            areaCode: '100005100320310000'
          },
          {
            id: 11810,
            parentId: 3747,
            areaName: '若尔盖县',
            areaPath: '中国,四川省,阿坝藏族羌族自治州,若尔盖县',
            areaCode: '100005100320320000'
          },
          {
            id: 11811,
            parentId: 3747,
            areaName: '红原县',
            areaPath: '中国,四川省,阿坝藏族羌族自治州,红原县',
            areaCode: '100005100320330000'
          }
        ]
      },
      {
        id: 3748,
        parentId: 1456,
        areaName: '甘孜藏族自治州',
        areaPath: '中国,四川省,甘孜藏族自治州',
        areaCode: '100005100330000000',
        children: [
          {
            id: 11812,
            parentId: 3748,
            areaName: '康定市',
            areaPath: '中国,四川省,甘孜藏族自治州,康定市',
            areaCode: '100005100330010000'
          },
          {
            id: 11813,
            parentId: 3748,
            areaName: '泸定县',
            areaPath: '中国,四川省,甘孜藏族自治州,泸定县',
            areaCode: '100005100330220000'
          },
          {
            id: 11814,
            parentId: 3748,
            areaName: '丹巴县',
            areaPath: '中国,四川省,甘孜藏族自治州,丹巴县',
            areaCode: '100005100330230000'
          },
          {
            id: 11815,
            parentId: 3748,
            areaName: '九龙县',
            areaPath: '中国,四川省,甘孜藏族自治州,九龙县',
            areaCode: '100005100330240000'
          },
          {
            id: 11816,
            parentId: 3748,
            areaName: '雅江县',
            areaPath: '中国,四川省,甘孜藏族自治州,雅江县',
            areaCode: '100005100330250000'
          },
          {
            id: 11817,
            parentId: 3748,
            areaName: '道孚县',
            areaPath: '中国,四川省,甘孜藏族自治州,道孚县',
            areaCode: '100005100330260000'
          },
          {
            id: 11818,
            parentId: 3748,
            areaName: '炉霍县',
            areaPath: '中国,四川省,甘孜藏族自治州,炉霍县',
            areaCode: '100005100330270000'
          },
          {
            id: 11819,
            parentId: 3748,
            areaName: '甘孜县',
            areaPath: '中国,四川省,甘孜藏族自治州,甘孜县',
            areaCode: '100005100330280000'
          },
          {
            id: 11820,
            parentId: 3748,
            areaName: '新龙县',
            areaPath: '中国,四川省,甘孜藏族自治州,新龙县',
            areaCode: '100005100330290000'
          },
          {
            id: 11821,
            parentId: 3748,
            areaName: '德格县',
            areaPath: '中国,四川省,甘孜藏族自治州,德格县',
            areaCode: '100005100330300000'
          },
          {
            id: 11822,
            parentId: 3748,
            areaName: '白玉县',
            areaPath: '中国,四川省,甘孜藏族自治州,白玉县',
            areaCode: '100005100330310000'
          },
          {
            id: 11823,
            parentId: 3748,
            areaName: '石渠县',
            areaPath: '中国,四川省,甘孜藏族自治州,石渠县',
            areaCode: '100005100330320000'
          },
          {
            id: 11824,
            parentId: 3748,
            areaName: '色达县',
            areaPath: '中国,四川省,甘孜藏族自治州,色达县',
            areaCode: '100005100330330000'
          },
          {
            id: 11825,
            parentId: 3748,
            areaName: '理塘县',
            areaPath: '中国,四川省,甘孜藏族自治州,理塘县',
            areaCode: '100005100330340000'
          },
          {
            id: 11826,
            parentId: 3748,
            areaName: '巴塘县',
            areaPath: '中国,四川省,甘孜藏族自治州,巴塘县',
            areaCode: '100005100330350000'
          },
          {
            id: 11827,
            parentId: 3748,
            areaName: '乡城县',
            areaPath: '中国,四川省,甘孜藏族自治州,乡城县',
            areaCode: '100005100330360000'
          },
          {
            id: 11828,
            parentId: 3748,
            areaName: '稻城县',
            areaPath: '中国,四川省,甘孜藏族自治州,稻城县',
            areaCode: '100005100330370000'
          },
          {
            id: 11829,
            parentId: 3748,
            areaName: '得荣县',
            areaPath: '中国,四川省,甘孜藏族自治州,得荣县',
            areaCode: '100005100330380000'
          }
        ]
      },
      {
        id: 3749,
        parentId: 1456,
        areaName: '凉山彝族自治州',
        areaPath: '中国,四川省,凉山彝族自治州',
        areaCode: '100005100340000000',
        children: [
          {
            id: 11830,
            parentId: 3749,
            areaName: '西昌市',
            areaPath: '中国,四川省,凉山彝族自治州,西昌市',
            areaCode: '100005100340010000'
          },
          {
            id: 11831,
            parentId: 3749,
            areaName: '木里藏族自治县',
            areaPath: '中国,四川省,凉山彝族自治州,木里藏族自治县',
            areaCode: '100005100340220000'
          },
          {
            id: 11832,
            parentId: 3749,
            areaName: '盐源县',
            areaPath: '中国,四川省,凉山彝族自治州,盐源县',
            areaCode: '100005100340230000'
          },
          {
            id: 11833,
            parentId: 3749,
            areaName: '德昌县',
            areaPath: '中国,四川省,凉山彝族自治州,德昌县',
            areaCode: '100005100340240000'
          },
          {
            id: 11834,
            parentId: 3749,
            areaName: '会理县',
            areaPath: '中国,四川省,凉山彝族自治州,会理县',
            areaCode: '100005100340250000'
          },
          {
            id: 11835,
            parentId: 3749,
            areaName: '会东县',
            areaPath: '中国,四川省,凉山彝族自治州,会东县',
            areaCode: '100005100340260000'
          },
          {
            id: 11836,
            parentId: 3749,
            areaName: '宁南县',
            areaPath: '中国,四川省,凉山彝族自治州,宁南县',
            areaCode: '100005100340270000'
          },
          {
            id: 11837,
            parentId: 3749,
            areaName: '普格县',
            areaPath: '中国,四川省,凉山彝族自治州,普格县',
            areaCode: '100005100340280000'
          },
          {
            id: 11838,
            parentId: 3749,
            areaName: '布拖县',
            areaPath: '中国,四川省,凉山彝族自治州,布拖县',
            areaCode: '100005100340290000'
          },
          {
            id: 11839,
            parentId: 3749,
            areaName: '金阳县',
            areaPath: '中国,四川省,凉山彝族自治州,金阳县',
            areaCode: '100005100340300000'
          },
          {
            id: 11840,
            parentId: 3749,
            areaName: '昭觉县',
            areaPath: '中国,四川省,凉山彝族自治州,昭觉县',
            areaCode: '100005100340310000'
          },
          {
            id: 11841,
            parentId: 3749,
            areaName: '喜德县',
            areaPath: '中国,四川省,凉山彝族自治州,喜德县',
            areaCode: '100005100340320000'
          },
          {
            id: 11842,
            parentId: 3749,
            areaName: '冕宁县',
            areaPath: '中国,四川省,凉山彝族自治州,冕宁县',
            areaCode: '100005100340330000'
          },
          {
            id: 11843,
            parentId: 3749,
            areaName: '越西县',
            areaPath: '中国,四川省,凉山彝族自治州,越西县',
            areaCode: '100005100340340000'
          },
          {
            id: 11844,
            parentId: 3749,
            areaName: '甘洛县',
            areaPath: '中国,四川省,凉山彝族自治州,甘洛县',
            areaCode: '100005100340350000'
          },
          {
            id: 11845,
            parentId: 3749,
            areaName: '美姑县',
            areaPath: '中国,四川省,凉山彝族自治州,美姑县',
            areaCode: '100005100340360000'
          },
          {
            id: 11846,
            parentId: 3749,
            areaName: '雷波县',
            areaPath: '中国,四川省,凉山彝族自治州,雷波县',
            areaCode: '100005100340370000'
          }
        ]
      }
    ]
  },
  {
    id: 1457,
    parentId: 1,
    areaName: '贵州省',
    areaPath: '中国,贵州省',
    areaCode: '100005200000000000',
    children: [
      {
        id: 3750,
        parentId: 1457,
        areaName: '贵阳市',
        areaPath: '中国,贵州省,贵阳市',
        areaCode: '100005200010000000',
        children: [
          {
            id: 11847,
            parentId: 3750,
            areaName: '南明区',
            areaPath: '中国,贵州省,贵阳市,南明区',
            areaCode: '100005200010020000'
          },
          {
            id: 11848,
            parentId: 3750,
            areaName: '云岩区',
            areaPath: '中国,贵州省,贵阳市,云岩区',
            areaCode: '100005200010030000'
          },
          {
            id: 11849,
            parentId: 3750,
            areaName: '花溪区',
            areaPath: '中国,贵州省,贵阳市,花溪区',
            areaCode: '100005200010110000'
          },
          {
            id: 11850,
            parentId: 3750,
            areaName: '乌当区',
            areaPath: '中国,贵州省,贵阳市,乌当区',
            areaCode: '100005200010120000'
          },
          {
            id: 11851,
            parentId: 3750,
            areaName: '白云区',
            areaPath: '中国,贵州省,贵阳市,白云区',
            areaCode: '100005200010130000'
          },
          {
            id: 11852,
            parentId: 3750,
            areaName: '观山湖区',
            areaPath: '中国,贵州省,贵阳市,观山湖区',
            areaCode: '100005200010150000'
          },
          {
            id: 11853,
            parentId: 3750,
            areaName: '开阳县',
            areaPath: '中国,贵州省,贵阳市,开阳县',
            areaCode: '100005200010210000'
          },
          {
            id: 11854,
            parentId: 3750,
            areaName: '息烽县',
            areaPath: '中国,贵州省,贵阳市,息烽县',
            areaCode: '100005200010220000'
          },
          {
            id: 11855,
            parentId: 3750,
            areaName: '修文县',
            areaPath: '中国,贵州省,贵阳市,修文县',
            areaCode: '100005200010230000'
          },
          {
            id: 11856,
            parentId: 3750,
            areaName: '清镇市',
            areaPath: '中国,贵州省,贵阳市,清镇市',
            areaCode: '100005200010810000'
          }
        ]
      },
      {
        id: 3751,
        parentId: 1457,
        areaName: '六盘水市',
        areaPath: '中国,贵州省,六盘水市',
        areaCode: '100005200020000000',
        children: [
          {
            id: 11857,
            parentId: 3751,
            areaName: '钟山区',
            areaPath: '中国,贵州省,六盘水市,钟山区',
            areaCode: '100005200020010000'
          },
          {
            id: 11858,
            parentId: 3751,
            areaName: '六枝特区',
            areaPath: '中国,贵州省,六盘水市,六枝特区',
            areaCode: '100005200020030000'
          },
          {
            id: 11859,
            parentId: 3751,
            areaName: '水城县',
            areaPath: '中国,贵州省,六盘水市,水城县',
            areaCode: '100005200020210000'
          },
          {
            id: 11860,
            parentId: 3751,
            areaName: '盘州市',
            areaPath: '中国,贵州省,六盘水市,盘州市',
            areaCode: '100005200020810000'
          }
        ]
      },
      {
        id: 3752,
        parentId: 1457,
        areaName: '遵义市',
        areaPath: '中国,贵州省,遵义市',
        areaCode: '100005200030000000',
        children: [
          {
            id: 11861,
            parentId: 3752,
            areaName: '红花岗区',
            areaPath: '中国,贵州省,遵义市,红花岗区',
            areaCode: '100005200030020000'
          },
          {
            id: 11862,
            parentId: 3752,
            areaName: '汇川区',
            areaPath: '中国,贵州省,遵义市,汇川区',
            areaCode: '100005200030030000'
          },
          {
            id: 11863,
            parentId: 3752,
            areaName: '播州区',
            areaPath: '中国,贵州省,遵义市,播州区',
            areaCode: '100005200030040000'
          },
          {
            id: 11864,
            parentId: 3752,
            areaName: '桐梓县',
            areaPath: '中国,贵州省,遵义市,桐梓县',
            areaCode: '100005200030220000'
          },
          {
            id: 11865,
            parentId: 3752,
            areaName: '绥阳县',
            areaPath: '中国,贵州省,遵义市,绥阳县',
            areaCode: '100005200030230000'
          },
          {
            id: 11866,
            parentId: 3752,
            areaName: '正安县',
            areaPath: '中国,贵州省,遵义市,正安县',
            areaCode: '100005200030240000'
          },
          {
            id: 11867,
            parentId: 3752,
            areaName: '道真仡佬族苗族自治县',
            areaPath: '中国,贵州省,遵义市,道真仡佬族苗族自治县',
            areaCode: '100005200030250000'
          },
          {
            id: 11868,
            parentId: 3752,
            areaName: '务川仡佬族苗族自治县',
            areaPath: '中国,贵州省,遵义市,务川仡佬族苗族自治县',
            areaCode: '100005200030260000'
          },
          {
            id: 11869,
            parentId: 3752,
            areaName: '凤冈县',
            areaPath: '中国,贵州省,遵义市,凤冈县',
            areaCode: '100005200030270000'
          },
          {
            id: 11870,
            parentId: 3752,
            areaName: '湄潭县',
            areaPath: '中国,贵州省,遵义市,湄潭县',
            areaCode: '100005200030280000'
          },
          {
            id: 11871,
            parentId: 3752,
            areaName: '余庆县',
            areaPath: '中国,贵州省,遵义市,余庆县',
            areaCode: '100005200030290000'
          },
          {
            id: 11872,
            parentId: 3752,
            areaName: '习水县',
            areaPath: '中国,贵州省,遵义市,习水县',
            areaCode: '100005200030300000'
          },
          {
            id: 11873,
            parentId: 3752,
            areaName: '赤水市',
            areaPath: '中国,贵州省,遵义市,赤水市',
            areaCode: '100005200030810000'
          },
          {
            id: 11874,
            parentId: 3752,
            areaName: '仁怀市',
            areaPath: '中国,贵州省,遵义市,仁怀市',
            areaCode: '100005200030820000'
          }
        ]
      },
      {
        id: 3753,
        parentId: 1457,
        areaName: '安顺市',
        areaPath: '中国,贵州省,安顺市',
        areaCode: '100005200040000000',
        children: [
          {
            id: 11875,
            parentId: 3753,
            areaName: '西秀区',
            areaPath: '中国,贵州省,安顺市,西秀区',
            areaCode: '100005200040020000'
          },
          {
            id: 11876,
            parentId: 3753,
            areaName: '平坝区',
            areaPath: '中国,贵州省,安顺市,平坝区',
            areaCode: '100005200040030000'
          },
          {
            id: 11877,
            parentId: 3753,
            areaName: '普定县',
            areaPath: '中国,贵州省,安顺市,普定县',
            areaCode: '100005200040220000'
          },
          {
            id: 11878,
            parentId: 3753,
            areaName: '镇宁布依族苗族自治县',
            areaPath: '中国,贵州省,安顺市,镇宁布依族苗族自治县',
            areaCode: '100005200040230000'
          },
          {
            id: 11879,
            parentId: 3753,
            areaName: '关岭布依族苗族自治县',
            areaPath: '中国,贵州省,安顺市,关岭布依族苗族自治县',
            areaCode: '100005200040240000'
          },
          {
            id: 11880,
            parentId: 3753,
            areaName: '紫云苗族布依族自治县',
            areaPath: '中国,贵州省,安顺市,紫云苗族布依族自治县',
            areaCode: '100005200040250000'
          }
        ]
      },
      {
        id: 3754,
        parentId: 1457,
        areaName: '毕节市',
        areaPath: '中国,贵州省,毕节市',
        areaCode: '100005200050000000',
        children: [
          {
            id: 11881,
            parentId: 3754,
            areaName: '七星关区',
            areaPath: '中国,贵州省,毕节市,七星关区',
            areaCode: '100005200050020000'
          },
          {
            id: 11882,
            parentId: 3754,
            areaName: '大方县',
            areaPath: '中国,贵州省,毕节市,大方县',
            areaCode: '100005200050210000'
          },
          {
            id: 11883,
            parentId: 3754,
            areaName: '黔西县',
            areaPath: '中国,贵州省,毕节市,黔西县',
            areaCode: '100005200050220000'
          },
          {
            id: 11884,
            parentId: 3754,
            areaName: '金沙县',
            areaPath: '中国,贵州省,毕节市,金沙县',
            areaCode: '100005200050230000'
          },
          {
            id: 11885,
            parentId: 3754,
            areaName: '织金县',
            areaPath: '中国,贵州省,毕节市,织金县',
            areaCode: '100005200050240000'
          },
          {
            id: 11886,
            parentId: 3754,
            areaName: '纳雍县',
            areaPath: '中国,贵州省,毕节市,纳雍县',
            areaCode: '100005200050250000'
          },
          {
            id: 11887,
            parentId: 3754,
            areaName: '威宁彝族回族苗族自治县',
            areaPath: '中国,贵州省,毕节市,威宁彝族回族苗族自治县',
            areaCode: '100005200050260000'
          },
          {
            id: 11888,
            parentId: 3754,
            areaName: '赫章县',
            areaPath: '中国,贵州省,毕节市,赫章县',
            areaCode: '100005200050270000'
          }
        ]
      },
      {
        id: 3755,
        parentId: 1457,
        areaName: '铜仁市',
        areaPath: '中国,贵州省,铜仁市',
        areaCode: '100005200060000000',
        children: [
          {
            id: 11889,
            parentId: 3755,
            areaName: '碧江区',
            areaPath: '中国,贵州省,铜仁市,碧江区',
            areaCode: '100005200060020000'
          },
          {
            id: 11890,
            parentId: 3755,
            areaName: '万山区',
            areaPath: '中国,贵州省,铜仁市,万山区',
            areaCode: '100005200060030000'
          },
          {
            id: 11891,
            parentId: 3755,
            areaName: '江口县',
            areaPath: '中国,贵州省,铜仁市,江口县',
            areaCode: '100005200060210000'
          },
          {
            id: 11892,
            parentId: 3755,
            areaName: '玉屏侗族自治县',
            areaPath: '中国,贵州省,铜仁市,玉屏侗族自治县',
            areaCode: '100005200060220000'
          },
          {
            id: 11893,
            parentId: 3755,
            areaName: '石阡县',
            areaPath: '中国,贵州省,铜仁市,石阡县',
            areaCode: '100005200060230000'
          },
          {
            id: 11894,
            parentId: 3755,
            areaName: '思南县',
            areaPath: '中国,贵州省,铜仁市,思南县',
            areaCode: '100005200060240000'
          },
          {
            id: 11895,
            parentId: 3755,
            areaName: '印江土家族苗族自治县',
            areaPath: '中国,贵州省,铜仁市,印江土家族苗族自治县',
            areaCode: '100005200060250000'
          },
          {
            id: 11896,
            parentId: 3755,
            areaName: '德江县',
            areaPath: '中国,贵州省,铜仁市,德江县',
            areaCode: '100005200060260000'
          },
          {
            id: 11897,
            parentId: 3755,
            areaName: '沿河土家族自治县',
            areaPath: '中国,贵州省,铜仁市,沿河土家族自治县',
            areaCode: '100005200060270000'
          },
          {
            id: 11898,
            parentId: 3755,
            areaName: '松桃苗族自治县',
            areaPath: '中国,贵州省,铜仁市,松桃苗族自治县',
            areaCode: '100005200060280000'
          }
        ]
      },
      {
        id: 3756,
        parentId: 1457,
        areaName: '黔西南布依族苗族自治州',
        areaPath: '中国,贵州省,黔西南布依族苗族自治州',
        areaCode: '100005200230000000',
        children: [
          {
            id: 11899,
            parentId: 3756,
            areaName: '兴义市',
            areaPath: '中国,贵州省,黔西南布依族苗族自治州,兴义市',
            areaCode: '100005200230010000'
          },
          {
            id: 11900,
            parentId: 3756,
            areaName: '兴仁县',
            areaPath: '中国,贵州省,黔西南布依族苗族自治州,兴仁县',
            areaCode: '100005200230220000'
          },
          {
            id: 11901,
            parentId: 3756,
            areaName: '普安县',
            areaPath: '中国,贵州省,黔西南布依族苗族自治州,普安县',
            areaCode: '100005200230230000'
          },
          {
            id: 11902,
            parentId: 3756,
            areaName: '晴隆县',
            areaPath: '中国,贵州省,黔西南布依族苗族自治州,晴隆县',
            areaCode: '100005200230240000'
          },
          {
            id: 11903,
            parentId: 3756,
            areaName: '贞丰县',
            areaPath: '中国,贵州省,黔西南布依族苗族自治州,贞丰县',
            areaCode: '100005200230250000'
          },
          {
            id: 11904,
            parentId: 3756,
            areaName: '望谟县',
            areaPath: '中国,贵州省,黔西南布依族苗族自治州,望谟县',
            areaCode: '100005200230260000'
          },
          {
            id: 11905,
            parentId: 3756,
            areaName: '册亨县',
            areaPath: '中国,贵州省,黔西南布依族苗族自治州,册亨县',
            areaCode: '100005200230270000'
          },
          {
            id: 11906,
            parentId: 3756,
            areaName: '安龙县',
            areaPath: '中国,贵州省,黔西南布依族苗族自治州,安龙县',
            areaCode: '100005200230280000'
          }
        ]
      },
      {
        id: 3757,
        parentId: 1457,
        areaName: '黔东南苗族侗族自治州',
        areaPath: '中国,贵州省,黔东南苗族侗族自治州',
        areaCode: '100005200260000000',
        children: [
          {
            id: 11907,
            parentId: 3757,
            areaName: '凯里市',
            areaPath: '中国,贵州省,黔东南苗族侗族自治州,凯里市',
            areaCode: '100005200260010000'
          },
          {
            id: 11908,
            parentId: 3757,
            areaName: '黄平县',
            areaPath: '中国,贵州省,黔东南苗族侗族自治州,黄平县',
            areaCode: '100005200260220000'
          },
          {
            id: 11909,
            parentId: 3757,
            areaName: '施秉县',
            areaPath: '中国,贵州省,黔东南苗族侗族自治州,施秉县',
            areaCode: '100005200260230000'
          },
          {
            id: 11910,
            parentId: 3757,
            areaName: '三穗县',
            areaPath: '中国,贵州省,黔东南苗族侗族自治州,三穗县',
            areaCode: '100005200260240000'
          },
          {
            id: 11911,
            parentId: 3757,
            areaName: '镇远县',
            areaPath: '中国,贵州省,黔东南苗族侗族自治州,镇远县',
            areaCode: '100005200260250000'
          },
          {
            id: 11912,
            parentId: 3757,
            areaName: '岑巩县',
            areaPath: '中国,贵州省,黔东南苗族侗族自治州,岑巩县',
            areaCode: '100005200260260000'
          },
          {
            id: 11913,
            parentId: 3757,
            areaName: '天柱县',
            areaPath: '中国,贵州省,黔东南苗族侗族自治州,天柱县',
            areaCode: '100005200260270000'
          },
          {
            id: 11914,
            parentId: 3757,
            areaName: '锦屏县',
            areaPath: '中国,贵州省,黔东南苗族侗族自治州,锦屏县',
            areaCode: '100005200260280000'
          },
          {
            id: 11915,
            parentId: 3757,
            areaName: '剑河县',
            areaPath: '中国,贵州省,黔东南苗族侗族自治州,剑河县',
            areaCode: '100005200260290000'
          },
          {
            id: 11916,
            parentId: 3757,
            areaName: '台江县',
            areaPath: '中国,贵州省,黔东南苗族侗族自治州,台江县',
            areaCode: '100005200260300000'
          },
          {
            id: 11917,
            parentId: 3757,
            areaName: '黎平县',
            areaPath: '中国,贵州省,黔东南苗族侗族自治州,黎平县',
            areaCode: '100005200260310000'
          },
          {
            id: 11918,
            parentId: 3757,
            areaName: '榕江县',
            areaPath: '中国,贵州省,黔东南苗族侗族自治州,榕江县',
            areaCode: '100005200260320000'
          },
          {
            id: 11919,
            parentId: 3757,
            areaName: '从江县',
            areaPath: '中国,贵州省,黔东南苗族侗族自治州,从江县',
            areaCode: '100005200260330000'
          },
          {
            id: 11920,
            parentId: 3757,
            areaName: '雷山县',
            areaPath: '中国,贵州省,黔东南苗族侗族自治州,雷山县',
            areaCode: '100005200260340000'
          },
          {
            id: 11921,
            parentId: 3757,
            areaName: '麻江县',
            areaPath: '中国,贵州省,黔东南苗族侗族自治州,麻江县',
            areaCode: '100005200260350000'
          },
          {
            id: 11922,
            parentId: 3757,
            areaName: '丹寨县',
            areaPath: '中国,贵州省,黔东南苗族侗族自治州,丹寨县',
            areaCode: '100005200260360000'
          }
        ]
      },
      {
        id: 3758,
        parentId: 1457,
        areaName: '黔南布依族苗族自治州',
        areaPath: '中国,贵州省,黔南布依族苗族自治州',
        areaCode: '100005200270000000',
        children: [
          {
            id: 11923,
            parentId: 3758,
            areaName: '都匀市',
            areaPath: '中国,贵州省,黔南布依族苗族自治州,都匀市',
            areaCode: '100005200270010000'
          },
          {
            id: 11924,
            parentId: 3758,
            areaName: '福泉市',
            areaPath: '中国,贵州省,黔南布依族苗族自治州,福泉市',
            areaCode: '100005200270020000'
          },
          {
            id: 11925,
            parentId: 3758,
            areaName: '荔波县',
            areaPath: '中国,贵州省,黔南布依族苗族自治州,荔波县',
            areaCode: '100005200270220000'
          },
          {
            id: 11926,
            parentId: 3758,
            areaName: '贵定县',
            areaPath: '中国,贵州省,黔南布依族苗族自治州,贵定县',
            areaCode: '100005200270230000'
          },
          {
            id: 11927,
            parentId: 3758,
            areaName: '瓮安县',
            areaPath: '中国,贵州省,黔南布依族苗族自治州,瓮安县',
            areaCode: '100005200270250000'
          },
          {
            id: 11928,
            parentId: 3758,
            areaName: '独山县',
            areaPath: '中国,贵州省,黔南布依族苗族自治州,独山县',
            areaCode: '100005200270260000'
          },
          {
            id: 11929,
            parentId: 3758,
            areaName: '平塘县',
            areaPath: '中国,贵州省,黔南布依族苗族自治州,平塘县',
            areaCode: '100005200270270000'
          },
          {
            id: 11930,
            parentId: 3758,
            areaName: '罗甸县',
            areaPath: '中国,贵州省,黔南布依族苗族自治州,罗甸县',
            areaCode: '100005200270280000'
          },
          {
            id: 11931,
            parentId: 3758,
            areaName: '长顺县',
            areaPath: '中国,贵州省,黔南布依族苗族自治州,长顺县',
            areaCode: '100005200270290000'
          },
          {
            id: 11932,
            parentId: 3758,
            areaName: '龙里县',
            areaPath: '中国,贵州省,黔南布依族苗族自治州,龙里县',
            areaCode: '100005200270300000'
          },
          {
            id: 11933,
            parentId: 3758,
            areaName: '惠水县',
            areaPath: '中国,贵州省,黔南布依族苗族自治州,惠水县',
            areaCode: '100005200270310000'
          },
          {
            id: 11934,
            parentId: 3758,
            areaName: '三都水族自治县',
            areaPath: '中国,贵州省,黔南布依族苗族自治州,三都水族自治县',
            areaCode: '100005200270320000'
          }
        ]
      }
    ]
  },
  {
    id: 1458,
    parentId: 1,
    areaName: '云南省',
    areaPath: '中国,云南省',
    areaCode: '100005300000000000',
    children: [
      {
        id: 3759,
        parentId: 1458,
        areaName: '昆明市',
        areaPath: '中国,云南省,昆明市',
        areaCode: '100005300010000000',
        children: [
          {
            id: 11935,
            parentId: 3759,
            areaName: '五华区',
            areaPath: '中国,云南省,昆明市,五华区',
            areaCode: '100005300010020000'
          },
          {
            id: 11936,
            parentId: 3759,
            areaName: '盘龙区',
            areaPath: '中国,云南省,昆明市,盘龙区',
            areaCode: '100005300010030000'
          },
          {
            id: 11937,
            parentId: 3759,
            areaName: '官渡区',
            areaPath: '中国,云南省,昆明市,官渡区',
            areaCode: '100005300010110000'
          },
          {
            id: 11938,
            parentId: 3759,
            areaName: '西山区',
            areaPath: '中国,云南省,昆明市,西山区',
            areaCode: '100005300010120000'
          },
          {
            id: 11939,
            parentId: 3759,
            areaName: '东川区',
            areaPath: '中国,云南省,昆明市,东川区',
            areaCode: '100005300010130000'
          },
          {
            id: 11940,
            parentId: 3759,
            areaName: '呈贡区',
            areaPath: '中国,云南省,昆明市,呈贡区',
            areaCode: '100005300010140000'
          },
          {
            id: 11941,
            parentId: 3759,
            areaName: '晋宁区',
            areaPath: '中国,云南省,昆明市,晋宁区',
            areaCode: '100005300010150000'
          },
          {
            id: 11942,
            parentId: 3759,
            areaName: '富民县',
            areaPath: '中国,云南省,昆明市,富民县',
            areaCode: '100005300010240000'
          },
          {
            id: 11943,
            parentId: 3759,
            areaName: '宜良县',
            areaPath: '中国,云南省,昆明市,宜良县',
            areaCode: '100005300010250000'
          },
          {
            id: 11944,
            parentId: 3759,
            areaName: '石林彝族自治县',
            areaPath: '中国,云南省,昆明市,石林彝族自治县',
            areaCode: '100005300010260000'
          },
          {
            id: 11945,
            parentId: 3759,
            areaName: '嵩明县',
            areaPath: '中国,云南省,昆明市,嵩明县',
            areaCode: '100005300010270000'
          },
          {
            id: 11946,
            parentId: 3759,
            areaName: '禄劝彝族苗族自治县',
            areaPath: '中国,云南省,昆明市,禄劝彝族苗族自治县',
            areaCode: '100005300010280000'
          },
          {
            id: 11947,
            parentId: 3759,
            areaName: '寻甸回族彝族自治县',
            areaPath: '中国,云南省,昆明市,寻甸回族彝族自治县',
            areaCode: '100005300010290000'
          },
          {
            id: 11948,
            parentId: 3759,
            areaName: '安宁市',
            areaPath: '中国,云南省,昆明市,安宁市',
            areaCode: '100005300010810000'
          }
        ]
      },
      {
        id: 3760,
        parentId: 1458,
        areaName: '曲靖市',
        areaPath: '中国,云南省,曲靖市',
        areaCode: '100005300030000000',
        children: [
          {
            id: 11949,
            parentId: 3760,
            areaName: '麒麟区',
            areaPath: '中国,云南省,曲靖市,麒麟区',
            areaCode: '100005300030020000'
          },
          {
            id: 11950,
            parentId: 3760,
            areaName: '沾益区',
            areaPath: '中国,云南省,曲靖市,沾益区',
            areaCode: '100005300030030000'
          },
          {
            id: 11951,
            parentId: 3760,
            areaName: '马龙县',
            areaPath: '中国,云南省,曲靖市,马龙县',
            areaCode: '100005300030210000'
          },
          {
            id: 11952,
            parentId: 3760,
            areaName: '陆良县',
            areaPath: '中国,云南省,曲靖市,陆良县',
            areaCode: '100005300030220000'
          },
          {
            id: 11953,
            parentId: 3760,
            areaName: '师宗县',
            areaPath: '中国,云南省,曲靖市,师宗县',
            areaCode: '100005300030230000'
          },
          {
            id: 11954,
            parentId: 3760,
            areaName: '罗平县',
            areaPath: '中国,云南省,曲靖市,罗平县',
            areaCode: '100005300030240000'
          },
          {
            id: 11955,
            parentId: 3760,
            areaName: '富源县',
            areaPath: '中国,云南省,曲靖市,富源县',
            areaCode: '100005300030250000'
          },
          {
            id: 11956,
            parentId: 3760,
            areaName: '会泽县',
            areaPath: '中国,云南省,曲靖市,会泽县',
            areaCode: '100005300030260000'
          },
          {
            id: 11957,
            parentId: 3760,
            areaName: '宣威市',
            areaPath: '中国,云南省,曲靖市,宣威市',
            areaCode: '100005300030810000'
          }
        ]
      },
      {
        id: 3761,
        parentId: 1458,
        areaName: '玉溪市',
        areaPath: '中国,云南省,玉溪市',
        areaCode: '100005300040000000',
        children: [
          {
            id: 11958,
            parentId: 3761,
            areaName: '红塔区',
            areaPath: '中国,云南省,玉溪市,红塔区',
            areaCode: '100005300040020000'
          },
          {
            id: 11959,
            parentId: 3761,
            areaName: '江川区',
            areaPath: '中国,云南省,玉溪市,江川区',
            areaCode: '100005300040030000'
          },
          {
            id: 11960,
            parentId: 3761,
            areaName: '澄江县',
            areaPath: '中国,云南省,玉溪市,澄江县',
            areaCode: '100005300040220000'
          },
          {
            id: 11961,
            parentId: 3761,
            areaName: '通海县',
            areaPath: '中国,云南省,玉溪市,通海县',
            areaCode: '100005300040230000'
          },
          {
            id: 11962,
            parentId: 3761,
            areaName: '华宁县',
            areaPath: '中国,云南省,玉溪市,华宁县',
            areaCode: '100005300040240000'
          },
          {
            id: 11963,
            parentId: 3761,
            areaName: '易门县',
            areaPath: '中国,云南省,玉溪市,易门县',
            areaCode: '100005300040250000'
          },
          {
            id: 11964,
            parentId: 3761,
            areaName: '峨山彝族自治县',
            areaPath: '中国,云南省,玉溪市,峨山彝族自治县',
            areaCode: '100005300040260000'
          },
          {
            id: 11965,
            parentId: 3761,
            areaName: '新平彝族傣族自治县',
            areaPath: '中国,云南省,玉溪市,新平彝族傣族自治县',
            areaCode: '100005300040270000'
          },
          {
            id: 11966,
            parentId: 3761,
            areaName: '元江哈尼族彝族傣族自治县',
            areaPath: '中国,云南省,玉溪市,元江哈尼族彝族傣族自治县',
            areaCode: '100005300040280000'
          }
        ]
      },
      {
        id: 3762,
        parentId: 1458,
        areaName: '保山市',
        areaPath: '中国,云南省,保山市',
        areaCode: '100005300050000000',
        children: [
          {
            id: 11967,
            parentId: 3762,
            areaName: '隆阳区',
            areaPath: '中国,云南省,保山市,隆阳区',
            areaCode: '100005300050020000'
          },
          {
            id: 11968,
            parentId: 3762,
            areaName: '施甸县',
            areaPath: '中国,云南省,保山市,施甸县',
            areaCode: '100005300050210000'
          },
          {
            id: 11969,
            parentId: 3762,
            areaName: '龙陵县',
            areaPath: '中国,云南省,保山市,龙陵县',
            areaCode: '100005300050230000'
          },
          {
            id: 11970,
            parentId: 3762,
            areaName: '昌宁县',
            areaPath: '中国,云南省,保山市,昌宁县',
            areaCode: '100005300050240000'
          },
          {
            id: 11971,
            parentId: 3762,
            areaName: '腾冲市',
            areaPath: '中国,云南省,保山市,腾冲市',
            areaCode: '100005300050810000'
          }
        ]
      },
      {
        id: 3763,
        parentId: 1458,
        areaName: '昭通市',
        areaPath: '中国,云南省,昭通市',
        areaCode: '100005300060000000',
        children: [
          {
            id: 11972,
            parentId: 3763,
            areaName: '昭阳区',
            areaPath: '中国,云南省,昭通市,昭阳区',
            areaCode: '100005300060020000'
          },
          {
            id: 11973,
            parentId: 3763,
            areaName: '鲁甸县',
            areaPath: '中国,云南省,昭通市,鲁甸县',
            areaCode: '100005300060210000'
          },
          {
            id: 11974,
            parentId: 3763,
            areaName: '巧家县',
            areaPath: '中国,云南省,昭通市,巧家县',
            areaCode: '100005300060220000'
          },
          {
            id: 11975,
            parentId: 3763,
            areaName: '盐津县',
            areaPath: '中国,云南省,昭通市,盐津县',
            areaCode: '100005300060230000'
          },
          {
            id: 11976,
            parentId: 3763,
            areaName: '大关县',
            areaPath: '中国,云南省,昭通市,大关县',
            areaCode: '100005300060240000'
          },
          {
            id: 11977,
            parentId: 3763,
            areaName: '永善县',
            areaPath: '中国,云南省,昭通市,永善县',
            areaCode: '100005300060250000'
          },
          {
            id: 11978,
            parentId: 3763,
            areaName: '绥江县',
            areaPath: '中国,云南省,昭通市,绥江县',
            areaCode: '100005300060260000'
          },
          {
            id: 11979,
            parentId: 3763,
            areaName: '镇雄县',
            areaPath: '中国,云南省,昭通市,镇雄县',
            areaCode: '100005300060270000'
          },
          {
            id: 11980,
            parentId: 3763,
            areaName: '彝良县',
            areaPath: '中国,云南省,昭通市,彝良县',
            areaCode: '100005300060280000'
          },
          {
            id: 11981,
            parentId: 3763,
            areaName: '威信县',
            areaPath: '中国,云南省,昭通市,威信县',
            areaCode: '100005300060290000'
          },
          {
            id: 11982,
            parentId: 3763,
            areaName: '水富县',
            areaPath: '中国,云南省,昭通市,水富县',
            areaCode: '100005300060300000'
          }
        ]
      },
      {
        id: 3764,
        parentId: 1458,
        areaName: '丽江市',
        areaPath: '中国,云南省,丽江市',
        areaCode: '100005300070000000',
        children: [
          {
            id: 11983,
            parentId: 3764,
            areaName: '古城区',
            areaPath: '中国,云南省,丽江市,古城区',
            areaCode: '100005300070020000'
          },
          {
            id: 11984,
            parentId: 3764,
            areaName: '玉龙纳西族自治县',
            areaPath: '中国,云南省,丽江市,玉龙纳西族自治县',
            areaCode: '100005300070210000'
          },
          {
            id: 11985,
            parentId: 3764,
            areaName: '永胜县',
            areaPath: '中国,云南省,丽江市,永胜县',
            areaCode: '100005300070220000'
          },
          {
            id: 11986,
            parentId: 3764,
            areaName: '华坪县',
            areaPath: '中国,云南省,丽江市,华坪县',
            areaCode: '100005300070230000'
          },
          {
            id: 11987,
            parentId: 3764,
            areaName: '宁蒗彝族自治县',
            areaPath: '中国,云南省,丽江市,宁蒗彝族自治县',
            areaCode: '100005300070240000'
          }
        ]
      },
      {
        id: 3765,
        parentId: 1458,
        areaName: '普洱市',
        areaPath: '中国,云南省,普洱市',
        areaCode: '100005300080000000',
        children: [
          {
            id: 11988,
            parentId: 3765,
            areaName: '思茅区',
            areaPath: '中国,云南省,普洱市,思茅区',
            areaCode: '100005300080020000'
          },
          {
            id: 11989,
            parentId: 3765,
            areaName: '宁洱哈尼族彝族自治县',
            areaPath: '中国,云南省,普洱市,宁洱哈尼族彝族自治县',
            areaCode: '100005300080210000'
          },
          {
            id: 11990,
            parentId: 3765,
            areaName: '墨江哈尼族自治县',
            areaPath: '中国,云南省,普洱市,墨江哈尼族自治县',
            areaCode: '100005300080220000'
          },
          {
            id: 11991,
            parentId: 3765,
            areaName: '景东彝族自治县',
            areaPath: '中国,云南省,普洱市,景东彝族自治县',
            areaCode: '100005300080230000'
          },
          {
            id: 11992,
            parentId: 3765,
            areaName: '景谷傣族彝族自治县',
            areaPath: '中国,云南省,普洱市,景谷傣族彝族自治县',
            areaCode: '100005300080240000'
          },
          {
            id: 11993,
            parentId: 3765,
            areaName: '镇沅彝族哈尼族拉祜族自治县',
            areaPath: '中国,云南省,普洱市,镇沅彝族哈尼族拉祜族自治县',
            areaCode: '100005300080250000'
          },
          {
            id: 11994,
            parentId: 3765,
            areaName: '江城哈尼族彝族自治县',
            areaPath: '中国,云南省,普洱市,江城哈尼族彝族自治县',
            areaCode: '100005300080260000'
          },
          {
            id: 11995,
            parentId: 3765,
            areaName: '孟连傣族拉祜族佤族自治县',
            areaPath: '中国,云南省,普洱市,孟连傣族拉祜族佤族自治县',
            areaCode: '100005300080270000'
          },
          {
            id: 11996,
            parentId: 3765,
            areaName: '澜沧拉祜族自治县',
            areaPath: '中国,云南省,普洱市,澜沧拉祜族自治县',
            areaCode: '100005300080280000'
          },
          {
            id: 11997,
            parentId: 3765,
            areaName: '西盟佤族自治县',
            areaPath: '中国,云南省,普洱市,西盟佤族自治县',
            areaCode: '100005300080290000'
          }
        ]
      },
      {
        id: 3766,
        parentId: 1458,
        areaName: '临沧市',
        areaPath: '中国,云南省,临沧市',
        areaCode: '100005300090000000',
        children: [
          {
            id: 11998,
            parentId: 3766,
            areaName: '临翔区',
            areaPath: '中国,云南省,临沧市,临翔区',
            areaCode: '100005300090020000'
          },
          {
            id: 11999,
            parentId: 3766,
            areaName: '凤庆县',
            areaPath: '中国,云南省,临沧市,凤庆县',
            areaCode: '100005300090210000'
          },
          {
            id: 12000,
            parentId: 3766,
            areaName: '云县',
            areaPath: '中国,云南省,临沧市,云县',
            areaCode: '100005300090220000'
          },
          {
            id: 12001,
            parentId: 3766,
            areaName: '永德县',
            areaPath: '中国,云南省,临沧市,永德县',
            areaCode: '100005300090230000'
          },
          {
            id: 12002,
            parentId: 3766,
            areaName: '镇康县',
            areaPath: '中国,云南省,临沧市,镇康县',
            areaCode: '100005300090240000'
          },
          {
            id: 12003,
            parentId: 3766,
            areaName: '双江拉祜族佤族布朗族傣族自治县',
            areaPath: '中国,云南省,临沧市,双江拉祜族佤族布朗族傣族自治县',
            areaCode: '100005300090250000'
          },
          {
            id: 12004,
            parentId: 3766,
            areaName: '耿马傣族佤族自治县',
            areaPath: '中国,云南省,临沧市,耿马傣族佤族自治县',
            areaCode: '100005300090260000'
          },
          {
            id: 12005,
            parentId: 3766,
            areaName: '沧源佤族自治县',
            areaPath: '中国,云南省,临沧市,沧源佤族自治县',
            areaCode: '100005300090270000'
          }
        ]
      },
      {
        id: 3767,
        parentId: 1458,
        areaName: '楚雄彝族自治州',
        areaPath: '中国,云南省,楚雄彝族自治州',
        areaCode: '100005300230000000',
        children: [
          {
            id: 12006,
            parentId: 3767,
            areaName: '楚雄市',
            areaPath: '中国,云南省,楚雄彝族自治州,楚雄市',
            areaCode: '100005300230010000'
          },
          {
            id: 12007,
            parentId: 3767,
            areaName: '双柏县',
            areaPath: '中国,云南省,楚雄彝族自治州,双柏县',
            areaCode: '100005300230220000'
          },
          {
            id: 12008,
            parentId: 3767,
            areaName: '牟定县',
            areaPath: '中国,云南省,楚雄彝族自治州,牟定县',
            areaCode: '100005300230230000'
          },
          {
            id: 12009,
            parentId: 3767,
            areaName: '南华县',
            areaPath: '中国,云南省,楚雄彝族自治州,南华县',
            areaCode: '100005300230240000'
          },
          {
            id: 12010,
            parentId: 3767,
            areaName: '姚安县',
            areaPath: '中国,云南省,楚雄彝族自治州,姚安县',
            areaCode: '100005300230250000'
          },
          {
            id: 12011,
            parentId: 3767,
            areaName: '大姚县',
            areaPath: '中国,云南省,楚雄彝族自治州,大姚县',
            areaCode: '100005300230260000'
          },
          {
            id: 12012,
            parentId: 3767,
            areaName: '永仁县',
            areaPath: '中国,云南省,楚雄彝族自治州,永仁县',
            areaCode: '100005300230270000'
          },
          {
            id: 12013,
            parentId: 3767,
            areaName: '元谋县',
            areaPath: '中国,云南省,楚雄彝族自治州,元谋县',
            areaCode: '100005300230280000'
          },
          {
            id: 12014,
            parentId: 3767,
            areaName: '武定县',
            areaPath: '中国,云南省,楚雄彝族自治州,武定县',
            areaCode: '100005300230290000'
          },
          {
            id: 12015,
            parentId: 3767,
            areaName: '禄丰县',
            areaPath: '中国,云南省,楚雄彝族自治州,禄丰县',
            areaCode: '100005300230310000'
          }
        ]
      },
      {
        id: 3768,
        parentId: 1458,
        areaName: '红河哈尼族彝族自治州',
        areaPath: '中国,云南省,红河哈尼族彝族自治州',
        areaCode: '100005300250000000',
        children: [
          {
            id: 12016,
            parentId: 3768,
            areaName: '个旧市',
            areaPath: '中国,云南省,红河哈尼族彝族自治州,个旧市',
            areaCode: '100005300250010000'
          },
          {
            id: 12017,
            parentId: 3768,
            areaName: '开远市',
            areaPath: '中国,云南省,红河哈尼族彝族自治州,开远市',
            areaCode: '100005300250020000'
          },
          {
            id: 12018,
            parentId: 3768,
            areaName: '蒙自市',
            areaPath: '中国,云南省,红河哈尼族彝族自治州,蒙自市',
            areaCode: '100005300250030000'
          },
          {
            id: 12019,
            parentId: 3768,
            areaName: '弥勒市',
            areaPath: '中国,云南省,红河哈尼族彝族自治州,弥勒市',
            areaCode: '100005300250040000'
          },
          {
            id: 12020,
            parentId: 3768,
            areaName: '屏边苗族自治县',
            areaPath: '中国,云南省,红河哈尼族彝族自治州,屏边苗族自治县',
            areaCode: '100005300250230000'
          },
          {
            id: 12021,
            parentId: 3768,
            areaName: '建水县',
            areaPath: '中国,云南省,红河哈尼族彝族自治州,建水县',
            areaCode: '100005300250240000'
          },
          {
            id: 12022,
            parentId: 3768,
            areaName: '石屏县',
            areaPath: '中国,云南省,红河哈尼族彝族自治州,石屏县',
            areaCode: '100005300250250000'
          },
          {
            id: 12023,
            parentId: 3768,
            areaName: '泸西县',
            areaPath: '中国,云南省,红河哈尼族彝族自治州,泸西县',
            areaCode: '100005300250270000'
          },
          {
            id: 12024,
            parentId: 3768,
            areaName: '元阳县',
            areaPath: '中国,云南省,红河哈尼族彝族自治州,元阳县',
            areaCode: '100005300250280000'
          },
          {
            id: 12025,
            parentId: 3768,
            areaName: '红河县',
            areaPath: '中国,云南省,红河哈尼族彝族自治州,红河县',
            areaCode: '100005300250290000'
          },
          {
            id: 12026,
            parentId: 3768,
            areaName: '金平苗族瑶族傣族自治县',
            areaPath: '中国,云南省,红河哈尼族彝族自治州,金平苗族瑶族傣族自治县',
            areaCode: '100005300250300000'
          },
          {
            id: 12027,
            parentId: 3768,
            areaName: '绿春县',
            areaPath: '中国,云南省,红河哈尼族彝族自治州,绿春县',
            areaCode: '100005300250310000'
          },
          {
            id: 12028,
            parentId: 3768,
            areaName: '河口瑶族自治县',
            areaPath: '中国,云南省,红河哈尼族彝族自治州,河口瑶族自治县',
            areaCode: '100005300250320000'
          }
        ]
      },
      {
        id: 3769,
        parentId: 1458,
        areaName: '文山壮族苗族自治州',
        areaPath: '中国,云南省,文山壮族苗族自治州',
        areaCode: '100005300260000000',
        children: [
          {
            id: 12029,
            parentId: 3769,
            areaName: '文山市',
            areaPath: '中国,云南省,文山壮族苗族自治州,文山市',
            areaCode: '100005300260010000'
          },
          {
            id: 12030,
            parentId: 3769,
            areaName: '砚山县',
            areaPath: '中国,云南省,文山壮族苗族自治州,砚山县',
            areaCode: '100005300260220000'
          },
          {
            id: 12031,
            parentId: 3769,
            areaName: '西畴县',
            areaPath: '中国,云南省,文山壮族苗族自治州,西畴县',
            areaCode: '100005300260230000'
          },
          {
            id: 12032,
            parentId: 3769,
            areaName: '麻栗坡县',
            areaPath: '中国,云南省,文山壮族苗族自治州,麻栗坡县',
            areaCode: '100005300260240000'
          },
          {
            id: 12033,
            parentId: 3769,
            areaName: '马关县',
            areaPath: '中国,云南省,文山壮族苗族自治州,马关县',
            areaCode: '100005300260250000'
          },
          {
            id: 12034,
            parentId: 3769,
            areaName: '丘北县',
            areaPath: '中国,云南省,文山壮族苗族自治州,丘北县',
            areaCode: '100005300260260000'
          },
          {
            id: 12035,
            parentId: 3769,
            areaName: '广南县',
            areaPath: '中国,云南省,文山壮族苗族自治州,广南县',
            areaCode: '100005300260270000'
          },
          {
            id: 12036,
            parentId: 3769,
            areaName: '富宁县',
            areaPath: '中国,云南省,文山壮族苗族自治州,富宁县',
            areaCode: '100005300260280000'
          }
        ]
      },
      {
        id: 3770,
        parentId: 1458,
        areaName: '西双版纳傣族自治州',
        areaPath: '中国,云南省,西双版纳傣族自治州',
        areaCode: '100005300280000000',
        children: [
          {
            id: 12037,
            parentId: 3770,
            areaName: '景洪市',
            areaPath: '中国,云南省,西双版纳傣族自治州,景洪市',
            areaCode: '100005300280010000'
          },
          {
            id: 12038,
            parentId: 3770,
            areaName: '勐海县',
            areaPath: '中国,云南省,西双版纳傣族自治州,勐海县',
            areaCode: '100005300280220000'
          },
          {
            id: 12039,
            parentId: 3770,
            areaName: '勐腊县',
            areaPath: '中国,云南省,西双版纳傣族自治州,勐腊县',
            areaCode: '100005300280230000'
          }
        ]
      },
      {
        id: 3771,
        parentId: 1458,
        areaName: '大理白族自治州',
        areaPath: '中国,云南省,大理白族自治州',
        areaCode: '100005300290000000',
        children: [
          {
            id: 12040,
            parentId: 3771,
            areaName: '大理市',
            areaPath: '中国,云南省,大理白族自治州,大理市',
            areaCode: '100005300290010000'
          },
          {
            id: 12041,
            parentId: 3771,
            areaName: '漾濞彝族自治县',
            areaPath: '中国,云南省,大理白族自治州,漾濞彝族自治县',
            areaCode: '100005300290220000'
          },
          {
            id: 12042,
            parentId: 3771,
            areaName: '祥云县',
            areaPath: '中国,云南省,大理白族自治州,祥云县',
            areaCode: '100005300290230000'
          },
          {
            id: 12043,
            parentId: 3771,
            areaName: '宾川县',
            areaPath: '中国,云南省,大理白族自治州,宾川县',
            areaCode: '100005300290240000'
          },
          {
            id: 12044,
            parentId: 3771,
            areaName: '弥渡县',
            areaPath: '中国,云南省,大理白族自治州,弥渡县',
            areaCode: '100005300290250000'
          },
          {
            id: 12045,
            parentId: 3771,
            areaName: '南涧彝族自治县',
            areaPath: '中国,云南省,大理白族自治州,南涧彝族自治县',
            areaCode: '100005300290260000'
          },
          {
            id: 12046,
            parentId: 3771,
            areaName: '巍山彝族回族自治县',
            areaPath: '中国,云南省,大理白族自治州,巍山彝族回族自治县',
            areaCode: '100005300290270000'
          },
          {
            id: 12047,
            parentId: 3771,
            areaName: '永平县',
            areaPath: '中国,云南省,大理白族自治州,永平县',
            areaCode: '100005300290280000'
          },
          {
            id: 12048,
            parentId: 3771,
            areaName: '云龙县',
            areaPath: '中国,云南省,大理白族自治州,云龙县',
            areaCode: '100005300290290000'
          },
          {
            id: 12049,
            parentId: 3771,
            areaName: '洱源县',
            areaPath: '中国,云南省,大理白族自治州,洱源县',
            areaCode: '100005300290300000'
          },
          {
            id: 12050,
            parentId: 3771,
            areaName: '剑川县',
            areaPath: '中国,云南省,大理白族自治州,剑川县',
            areaCode: '100005300290310000'
          },
          {
            id: 12051,
            parentId: 3771,
            areaName: '鹤庆县',
            areaPath: '中国,云南省,大理白族自治州,鹤庆县',
            areaCode: '100005300290320000'
          }
        ]
      },
      {
        id: 3772,
        parentId: 1458,
        areaName: '德宏傣族景颇族自治州',
        areaPath: '中国,云南省,德宏傣族景颇族自治州',
        areaCode: '100005300310000000',
        children: [
          {
            id: 12052,
            parentId: 3772,
            areaName: '瑞丽市',
            areaPath: '中国,云南省,德宏傣族景颇族自治州,瑞丽市',
            areaCode: '100005300310020000'
          },
          {
            id: 12053,
            parentId: 3772,
            areaName: '芒市',
            areaPath: '中国,云南省,德宏傣族景颇族自治州,芒市',
            areaCode: '100005300310030000'
          },
          {
            id: 12054,
            parentId: 3772,
            areaName: '梁河县',
            areaPath: '中国,云南省,德宏傣族景颇族自治州,梁河县',
            areaCode: '100005300310220000'
          },
          {
            id: 12055,
            parentId: 3772,
            areaName: '盈江县',
            areaPath: '中国,云南省,德宏傣族景颇族自治州,盈江县',
            areaCode: '100005300310230000'
          },
          {
            id: 12056,
            parentId: 3772,
            areaName: '陇川县',
            areaPath: '中国,云南省,德宏傣族景颇族自治州,陇川县',
            areaCode: '100005300310240000'
          }
        ]
      },
      {
        id: 3773,
        parentId: 1458,
        areaName: '怒江傈僳族自治州',
        areaPath: '中国,云南省,怒江傈僳族自治州',
        areaCode: '100005300330000000',
        children: [
          {
            id: 12057,
            parentId: 3773,
            areaName: '泸水市',
            areaPath: '中国,云南省,怒江傈僳族自治州,泸水市',
            areaCode: '100005300330010000'
          },
          {
            id: 12058,
            parentId: 3773,
            areaName: '福贡县',
            areaPath: '中国,云南省,怒江傈僳族自治州,福贡县',
            areaCode: '100005300330230000'
          },
          {
            id: 12059,
            parentId: 3773,
            areaName: '贡山独龙族怒族自治县',
            areaPath: '中国,云南省,怒江傈僳族自治州,贡山独龙族怒族自治县',
            areaCode: '100005300330240000'
          },
          {
            id: 12060,
            parentId: 3773,
            areaName: '兰坪白族普米族自治县',
            areaPath: '中国,云南省,怒江傈僳族自治州,兰坪白族普米族自治县',
            areaCode: '100005300330250000'
          }
        ]
      },
      {
        id: 3774,
        parentId: 1458,
        areaName: '迪庆藏族自治州',
        areaPath: '中国,云南省,迪庆藏族自治州',
        areaCode: '100005300340000000',
        children: [
          {
            id: 12061,
            parentId: 3774,
            areaName: '香格里拉市',
            areaPath: '中国,云南省,迪庆藏族自治州,香格里拉市',
            areaCode: '100005300340010000'
          },
          {
            id: 12062,
            parentId: 3774,
            areaName: '德钦县',
            areaPath: '中国,云南省,迪庆藏族自治州,德钦县',
            areaCode: '100005300340220000'
          },
          {
            id: 12063,
            parentId: 3774,
            areaName: '维西傈僳族自治县',
            areaPath: '中国,云南省,迪庆藏族自治州,维西傈僳族自治县',
            areaCode: '100005300340230000'
          }
        ]
      }
    ]
  },
  {
    id: 1459,
    parentId: 1,
    areaName: '西藏自治区',
    areaPath: '中国,西藏自治区',
    areaCode: '100005400000000000',
    children: [
      {
        id: 3775,
        parentId: 1459,
        areaName: '拉萨市',
        areaPath: '中国,西藏自治区,拉萨市',
        areaCode: '100005400010000000',
        children: [
          {
            id: 12064,
            parentId: 3775,
            areaName: '城关区',
            areaPath: '中国,西藏自治区,拉萨市,城关区',
            areaCode: '100005400010020000'
          },
          {
            id: 12065,
            parentId: 3775,
            areaName: '堆龙德庆区',
            areaPath: '中国,西藏自治区,拉萨市,堆龙德庆区',
            areaCode: '100005400010030000'
          },
          {
            id: 12066,
            parentId: 3775,
            areaName: '达孜区',
            areaPath: '中国,西藏自治区,拉萨市,达孜区',
            areaCode: '100005400010260000'
          },
          {
            id: 12067,
            parentId: 3775,
            areaName: '林周县',
            areaPath: '中国,西藏自治区,拉萨市,林周县',
            areaCode: '100005400010210000'
          },
          {
            id: 12068,
            parentId: 3775,
            areaName: '当雄县',
            areaPath: '中国,西藏自治区,拉萨市,当雄县',
            areaCode: '100005400010220000'
          },
          {
            id: 12069,
            parentId: 3775,
            areaName: '尼木县',
            areaPath: '中国,西藏自治区,拉萨市,尼木县',
            areaCode: '100005400010230000'
          },
          {
            id: 12070,
            parentId: 3775,
            areaName: '曲水县',
            areaPath: '中国,西藏自治区,拉萨市,曲水县',
            areaCode: '100005400010240000'
          },
          {
            id: 12071,
            parentId: 3775,
            areaName: '墨竹工卡县',
            areaPath: '中国,西藏自治区,拉萨市,墨竹工卡县',
            areaCode: '100005400010270000'
          }
        ]
      },
      {
        id: 3776,
        parentId: 1459,
        areaName: '日喀则市',
        areaPath: '中国,西藏自治区,日喀则市',
        areaCode: '100005400020000000',
        children: [
          {
            id: 12072,
            parentId: 3776,
            areaName: '桑珠孜区',
            areaPath: '中国,西藏自治区,日喀则市,桑珠孜区',
            areaCode: '100005400020020000'
          },
          {
            id: 12073,
            parentId: 3776,
            areaName: '南木林县',
            areaPath: '中国,西藏自治区,日喀则市,南木林县',
            areaCode: '100005400020210000'
          },
          {
            id: 12074,
            parentId: 3776,
            areaName: '江孜县',
            areaPath: '中国,西藏自治区,日喀则市,江孜县',
            areaCode: '100005400020220000'
          },
          {
            id: 12075,
            parentId: 3776,
            areaName: '定日县',
            areaPath: '中国,西藏自治区,日喀则市,定日县',
            areaCode: '100005400020230000'
          },
          {
            id: 12076,
            parentId: 3776,
            areaName: '萨迦县',
            areaPath: '中国,西藏自治区,日喀则市,萨迦县',
            areaCode: '100005400020240000'
          },
          {
            id: 12077,
            parentId: 3776,
            areaName: '拉孜县',
            areaPath: '中国,西藏自治区,日喀则市,拉孜县',
            areaCode: '100005400020250000'
          },
          {
            id: 12078,
            parentId: 3776,
            areaName: '昂仁县',
            areaPath: '中国,西藏自治区,日喀则市,昂仁县',
            areaCode: '100005400020260000'
          },
          {
            id: 12079,
            parentId: 3776,
            areaName: '谢通门县',
            areaPath: '中国,西藏自治区,日喀则市,谢通门县',
            areaCode: '100005400020270000'
          },
          {
            id: 12080,
            parentId: 3776,
            areaName: '白朗县',
            areaPath: '中国,西藏自治区,日喀则市,白朗县',
            areaCode: '100005400020280000'
          },
          {
            id: 12081,
            parentId: 3776,
            areaName: '仁布县',
            areaPath: '中国,西藏自治区,日喀则市,仁布县',
            areaCode: '100005400020290000'
          },
          {
            id: 12082,
            parentId: 3776,
            areaName: '康马县',
            areaPath: '中国,西藏自治区,日喀则市,康马县',
            areaCode: '100005400020300000'
          },
          {
            id: 12083,
            parentId: 3776,
            areaName: '定结县',
            areaPath: '中国,西藏自治区,日喀则市,定结县',
            areaCode: '100005400020310000'
          },
          {
            id: 12084,
            parentId: 3776,
            areaName: '仲巴县',
            areaPath: '中国,西藏自治区,日喀则市,仲巴县',
            areaCode: '100005400020320000'
          },
          {
            id: 12085,
            parentId: 3776,
            areaName: '亚东县',
            areaPath: '中国,西藏自治区,日喀则市,亚东县',
            areaCode: '100005400020330000'
          },
          {
            id: 12086,
            parentId: 3776,
            areaName: '吉隆县',
            areaPath: '中国,西藏自治区,日喀则市,吉隆县',
            areaCode: '100005400020340000'
          },
          {
            id: 12087,
            parentId: 3776,
            areaName: '聂拉木县',
            areaPath: '中国,西藏自治区,日喀则市,聂拉木县',
            areaCode: '100005400020350000'
          },
          {
            id: 12088,
            parentId: 3776,
            areaName: '萨嘎县',
            areaPath: '中国,西藏自治区,日喀则市,萨嘎县',
            areaCode: '100005400020360000'
          },
          {
            id: 12089,
            parentId: 3776,
            areaName: '岗巴县',
            areaPath: '中国,西藏自治区,日喀则市,岗巴县',
            areaCode: '100005400020370000'
          }
        ]
      },
      {
        id: 3777,
        parentId: 1459,
        areaName: '昌都市',
        areaPath: '中国,西藏自治区,昌都市',
        areaCode: '100005400030000000',
        children: [
          {
            id: 12090,
            parentId: 3777,
            areaName: '卡若区',
            areaPath: '中国,西藏自治区,昌都市,卡若区',
            areaCode: '100005400030020000'
          },
          {
            id: 12091,
            parentId: 3777,
            areaName: '江达县',
            areaPath: '中国,西藏自治区,昌都市,江达县',
            areaCode: '100005400030210000'
          },
          {
            id: 12092,
            parentId: 3777,
            areaName: '贡觉县',
            areaPath: '中国,西藏自治区,昌都市,贡觉县',
            areaCode: '100005400030220000'
          },
          {
            id: 12093,
            parentId: 3777,
            areaName: '类乌齐县',
            areaPath: '中国,西藏自治区,昌都市,类乌齐县',
            areaCode: '100005400030230000'
          },
          {
            id: 12094,
            parentId: 3777,
            areaName: '丁青县',
            areaPath: '中国,西藏自治区,昌都市,丁青县',
            areaCode: '100005400030240000'
          },
          {
            id: 12095,
            parentId: 3777,
            areaName: '察雅县',
            areaPath: '中国,西藏自治区,昌都市,察雅县',
            areaCode: '100005400030250000'
          },
          {
            id: 12096,
            parentId: 3777,
            areaName: '八宿县',
            areaPath: '中国,西藏自治区,昌都市,八宿县',
            areaCode: '100005400030260000'
          },
          {
            id: 12097,
            parentId: 3777,
            areaName: '左贡县',
            areaPath: '中国,西藏自治区,昌都市,左贡县',
            areaCode: '100005400030270000'
          },
          {
            id: 12098,
            parentId: 3777,
            areaName: '芒康县',
            areaPath: '中国,西藏自治区,昌都市,芒康县',
            areaCode: '100005400030280000'
          },
          {
            id: 12099,
            parentId: 3777,
            areaName: '洛隆县',
            areaPath: '中国,西藏自治区,昌都市,洛隆县',
            areaCode: '100005400030290000'
          },
          {
            id: 12100,
            parentId: 3777,
            areaName: '边坝县',
            areaPath: '中国,西藏自治区,昌都市,边坝县',
            areaCode: '100005400030300000'
          }
        ]
      },
      {
        id: 3778,
        parentId: 1459,
        areaName: '林芝市',
        areaPath: '中国,西藏自治区,林芝市',
        areaCode: '100005400040000000',
        children: [
          {
            id: 12101,
            parentId: 3778,
            areaName: '巴宜区',
            areaPath: '中国,西藏自治区,林芝市,巴宜区',
            areaCode: '100005400040020000'
          },
          {
            id: 12102,
            parentId: 3778,
            areaName: '工布江达县',
            areaPath: '中国,西藏自治区,林芝市,工布江达县',
            areaCode: '100005400040210000'
          },
          {
            id: 12103,
            parentId: 3778,
            areaName: '米林县',
            areaPath: '中国,西藏自治区,林芝市,米林县',
            areaCode: '100005400040220000'
          },
          {
            id: 12104,
            parentId: 3778,
            areaName: '墨脱县',
            areaPath: '中国,西藏自治区,林芝市,墨脱县',
            areaCode: '100005400040230000'
          },
          {
            id: 12105,
            parentId: 3778,
            areaName: '波密县',
            areaPath: '中国,西藏自治区,林芝市,波密县',
            areaCode: '100005400040240000'
          },
          {
            id: 12106,
            parentId: 3778,
            areaName: '察隅县',
            areaPath: '中国,西藏自治区,林芝市,察隅县',
            areaCode: '100005400040250000'
          },
          {
            id: 12107,
            parentId: 3778,
            areaName: '朗县',
            areaPath: '中国,西藏自治区,林芝市,朗县',
            areaCode: '100005400040260000'
          }
        ]
      },
      {
        id: 3779,
        parentId: 1459,
        areaName: '山南市',
        areaPath: '中国,西藏自治区,山南市',
        areaCode: '100005400050000000',
        children: [
          {
            id: 12108,
            parentId: 3779,
            areaName: '乃东区',
            areaPath: '中国,西藏自治区,山南市,乃东区',
            areaCode: '100005400050020000'
          },
          {
            id: 12109,
            parentId: 3779,
            areaName: '扎囊县',
            areaPath: '中国,西藏自治区,山南市,扎囊县',
            areaCode: '100005400050210000'
          },
          {
            id: 12110,
            parentId: 3779,
            areaName: '贡嘎县',
            areaPath: '中国,西藏自治区,山南市,贡嘎县',
            areaCode: '100005400050220000'
          },
          {
            id: 12111,
            parentId: 3779,
            areaName: '桑日县',
            areaPath: '中国,西藏自治区,山南市,桑日县',
            areaCode: '100005400050230000'
          },
          {
            id: 12112,
            parentId: 3779,
            areaName: '琼结县',
            areaPath: '中国,西藏自治区,山南市,琼结县',
            areaCode: '100005400050240000'
          },
          {
            id: 12113,
            parentId: 3779,
            areaName: '曲松县',
            areaPath: '中国,西藏自治区,山南市,曲松县',
            areaCode: '100005400050250000'
          },
          {
            id: 12114,
            parentId: 3779,
            areaName: '措美县',
            areaPath: '中国,西藏自治区,山南市,措美县',
            areaCode: '100005400050260000'
          },
          {
            id: 12115,
            parentId: 3779,
            areaName: '洛扎县',
            areaPath: '中国,西藏自治区,山南市,洛扎县',
            areaCode: '100005400050270000'
          },
          {
            id: 12116,
            parentId: 3779,
            areaName: '加查县',
            areaPath: '中国,西藏自治区,山南市,加查县',
            areaCode: '100005400050280000'
          },
          {
            id: 12117,
            parentId: 3779,
            areaName: '隆子县',
            areaPath: '中国,西藏自治区,山南市,隆子县',
            areaCode: '100005400050290000'
          },
          {
            id: 12118,
            parentId: 3779,
            areaName: '错那县',
            areaPath: '中国,西藏自治区,山南市,错那县',
            areaCode: '100005400050300000'
          },
          {
            id: 12119,
            parentId: 3779,
            areaName: '浪卡子县',
            areaPath: '中国,西藏自治区,山南市,浪卡子县',
            areaCode: '100005400050310000'
          }
        ]
      },
      {
        id: 3780,
        parentId: 1459,
        areaName: '那曲地区',
        areaPath: '中国,西藏自治区,那曲地区',
        areaCode: '100005400240000000',
        children: [
          {
            id: 6858,
            parentId: 3780,
            areaName: '那曲县',
            areaPath: '中国,西藏自治区,那曲地区,那曲县',
            areaCode: '100005400240210000'
          },
          {
            id: 6859,
            parentId: 3780,
            areaName: '嘉黎县',
            areaPath: '中国,西藏自治区,那曲地区,嘉黎县',
            areaCode: '100005400240220000'
          },
          {
            id: 6860,
            parentId: 3780,
            areaName: '比如县',
            areaPath: '中国,西藏自治区,那曲地区,比如县',
            areaCode: '100005400240230000'
          },
          {
            id: 6861,
            parentId: 3780,
            areaName: '聂荣县',
            areaPath: '中国,西藏自治区,那曲地区,聂荣县',
            areaCode: '100005400240240000'
          },
          {
            id: 6862,
            parentId: 3780,
            areaName: '安多县',
            areaPath: '中国,西藏自治区,那曲地区,安多县',
            areaCode: '100005400240250000'
          },
          {
            id: 6863,
            parentId: 3780,
            areaName: '申扎县',
            areaPath: '中国,西藏自治区,那曲地区,申扎县',
            areaCode: '100005400240260000'
          },
          {
            id: 6864,
            parentId: 3780,
            areaName: '索县',
            areaPath: '中国,西藏自治区,那曲地区,索县',
            areaCode: '100005400240270000'
          },
          {
            id: 6865,
            parentId: 3780,
            areaName: '班戈县',
            areaPath: '中国,西藏自治区,那曲地区,班戈县',
            areaCode: '100005400240280000'
          },
          {
            id: 6866,
            parentId: 3780,
            areaName: '巴青县',
            areaPath: '中国,西藏自治区,那曲地区,巴青县',
            areaCode: '100005400240290000'
          },
          {
            id: 6867,
            parentId: 3780,
            areaName: '尼玛县',
            areaPath: '中国,西藏自治区,那曲地区,尼玛县',
            areaCode: '100005400240300000'
          },
          {
            id: 6868,
            parentId: 3780,
            areaName: '双湖县',
            areaPath: '中国,西藏自治区,那曲地区,双湖县',
            areaCode: '100005400240310000'
          }
        ]
      },
      {
        id: 3781,
        parentId: 1459,
        areaName: '阿里地区',
        areaPath: '中国,西藏自治区,阿里地区',
        areaCode: '100005400250000000',
        children: [
          {
            id: 12120,
            parentId: 3781,
            areaName: '普兰县',
            areaPath: '中国,西藏自治区,阿里地区,普兰县',
            areaCode: '100005400250210000'
          },
          {
            id: 12121,
            parentId: 3781,
            areaName: '札达县',
            areaPath: '中国,西藏自治区,阿里地区,札达县',
            areaCode: '100005400250220000'
          },
          {
            id: 12122,
            parentId: 3781,
            areaName: '噶尔县',
            areaPath: '中国,西藏自治区,阿里地区,噶尔县',
            areaCode: '100005400250230000'
          },
          {
            id: 12123,
            parentId: 3781,
            areaName: '日土县',
            areaPath: '中国,西藏自治区,阿里地区,日土县',
            areaCode: '100005400250240000'
          },
          {
            id: 12124,
            parentId: 3781,
            areaName: '革吉县',
            areaPath: '中国,西藏自治区,阿里地区,革吉县',
            areaCode: '100005400250250000'
          },
          {
            id: 12125,
            parentId: 3781,
            areaName: '改则县',
            areaPath: '中国,西藏自治区,阿里地区,改则县',
            areaCode: '100005400250260000'
          },
          {
            id: 12126,
            parentId: 3781,
            areaName: '措勤县',
            areaPath: '中国,西藏自治区,阿里地区,措勤县',
            areaCode: '100005400250270000'
          }
        ]
      }
    ]
  },
  {
    id: 1460,
    parentId: 1,
    areaName: '陕西省',
    areaPath: '中国,陕西省',
    areaCode: '100006100000000000',
    children: [
      {
        id: 3782,
        parentId: 1460,
        areaName: '西安市',
        areaPath: '中国,陕西省,西安市',
        areaCode: '100006100010000000',
        children: [
          {
            id: 12127,
            parentId: 3782,
            areaName: '新城区',
            areaPath: '中国,陕西省,西安市,新城区',
            areaCode: '100006100010020000'
          },
          {
            id: 12128,
            parentId: 3782,
            areaName: '碑林区',
            areaPath: '中国,陕西省,西安市,碑林区',
            areaCode: '100006100010030000'
          },
          {
            id: 12129,
            parentId: 3782,
            areaName: '莲湖区',
            areaPath: '中国,陕西省,西安市,莲湖区',
            areaCode: '100006100010040000'
          },
          {
            id: 12130,
            parentId: 3782,
            areaName: '灞桥区',
            areaPath: '中国,陕西省,西安市,灞桥区',
            areaCode: '100006100010110000'
          },
          {
            id: 12131,
            parentId: 3782,
            areaName: '未央区',
            areaPath: '中国,陕西省,西安市,未央区',
            areaCode: '100006100010120000'
          },
          {
            id: 12132,
            parentId: 3782,
            areaName: '雁塔区',
            areaPath: '中国,陕西省,西安市,雁塔区',
            areaCode: '100006100010130000'
          },
          {
            id: 12133,
            parentId: 3782,
            areaName: '阎良区',
            areaPath: '中国,陕西省,西安市,阎良区',
            areaCode: '100006100010140000'
          },
          {
            id: 12134,
            parentId: 3782,
            areaName: '临潼区',
            areaPath: '中国,陕西省,西安市,临潼区',
            areaCode: '100006100010150000'
          },
          {
            id: 12135,
            parentId: 3782,
            areaName: '长安区',
            areaPath: '中国,陕西省,西安市,长安区',
            areaCode: '100006100010160000'
          },
          {
            id: 12136,
            parentId: 3782,
            areaName: '高陵区',
            areaPath: '中国,陕西省,西安市,高陵区',
            areaCode: '100006100010170000'
          },
          {
            id: 12137,
            parentId: 3782,
            areaName: '鄠邑区',
            areaPath: '中国,陕西省,西安市,鄠邑区',
            areaCode: '100006100010180000'
          },
          {
            id: 12138,
            parentId: 3782,
            areaName: '蓝田县',
            areaPath: '中国,陕西省,西安市,蓝田县',
            areaCode: '100006100010220000'
          },
          {
            id: 12139,
            parentId: 3782,
            areaName: '周至县',
            areaPath: '中国,陕西省,西安市,周至县',
            areaCode: '100006100010240000'
          }
        ]
      },
      {
        id: 3783,
        parentId: 1460,
        areaName: '铜川市',
        areaPath: '中国,陕西省,铜川市',
        areaCode: '100006100020000000',
        children: [
          {
            id: 12140,
            parentId: 3783,
            areaName: '王益区',
            areaPath: '中国,陕西省,铜川市,王益区',
            areaCode: '100006100020020000'
          },
          {
            id: 12141,
            parentId: 3783,
            areaName: '印台区',
            areaPath: '中国,陕西省,铜川市,印台区',
            areaCode: '100006100020030000'
          },
          {
            id: 12142,
            parentId: 3783,
            areaName: '耀州区',
            areaPath: '中国,陕西省,铜川市,耀州区',
            areaCode: '100006100020040000'
          },
          {
            id: 12143,
            parentId: 3783,
            areaName: '宜君县',
            areaPath: '中国,陕西省,铜川市,宜君县',
            areaCode: '100006100020220000'
          }
        ]
      },
      {
        id: 3784,
        parentId: 1460,
        areaName: '宝鸡市',
        areaPath: '中国,陕西省,宝鸡市',
        areaCode: '100006100030000000',
        children: [
          {
            id: 12144,
            parentId: 3784,
            areaName: '渭滨区',
            areaPath: '中国,陕西省,宝鸡市,渭滨区',
            areaCode: '100006100030020000'
          },
          {
            id: 12145,
            parentId: 3784,
            areaName: '金台区',
            areaPath: '中国,陕西省,宝鸡市,金台区',
            areaCode: '100006100030030000'
          },
          {
            id: 12146,
            parentId: 3784,
            areaName: '陈仓区',
            areaPath: '中国,陕西省,宝鸡市,陈仓区',
            areaCode: '100006100030040000'
          },
          {
            id: 12147,
            parentId: 3784,
            areaName: '凤翔县',
            areaPath: '中国,陕西省,宝鸡市,凤翔县',
            areaCode: '100006100030220000'
          },
          {
            id: 12148,
            parentId: 3784,
            areaName: '岐山县',
            areaPath: '中国,陕西省,宝鸡市,岐山县',
            areaCode: '100006100030230000'
          },
          {
            id: 12149,
            parentId: 3784,
            areaName: '扶风县',
            areaPath: '中国,陕西省,宝鸡市,扶风县',
            areaCode: '100006100030240000'
          },
          {
            id: 12150,
            parentId: 3784,
            areaName: '眉县',
            areaPath: '中国,陕西省,宝鸡市,眉县',
            areaCode: '100006100030260000'
          },
          {
            id: 12151,
            parentId: 3784,
            areaName: '陇县',
            areaPath: '中国,陕西省,宝鸡市,陇县',
            areaCode: '100006100030270000'
          },
          {
            id: 12152,
            parentId: 3784,
            areaName: '千阳县',
            areaPath: '中国,陕西省,宝鸡市,千阳县',
            areaCode: '100006100030280000'
          },
          {
            id: 12153,
            parentId: 3784,
            areaName: '麟游县',
            areaPath: '中国,陕西省,宝鸡市,麟游县',
            areaCode: '100006100030290000'
          },
          {
            id: 12154,
            parentId: 3784,
            areaName: '凤县',
            areaPath: '中国,陕西省,宝鸡市,凤县',
            areaCode: '100006100030300000'
          },
          {
            id: 12155,
            parentId: 3784,
            areaName: '太白县',
            areaPath: '中国,陕西省,宝鸡市,太白县',
            areaCode: '100006100030310000'
          }
        ]
      },
      {
        id: 3785,
        parentId: 1460,
        areaName: '咸阳市',
        areaPath: '中国,陕西省,咸阳市',
        areaCode: '100006100040000000',
        children: [
          {
            id: 12156,
            parentId: 3785,
            areaName: '秦都区',
            areaPath: '中国,陕西省,咸阳市,秦都区',
            areaCode: '100006100040020000'
          },
          {
            id: 12157,
            parentId: 3785,
            areaName: '杨陵区',
            areaPath: '中国,陕西省,咸阳市,杨陵区',
            areaCode: '100006100040030000'
          },
          {
            id: 12158,
            parentId: 3785,
            areaName: '渭城区',
            areaPath: '中国,陕西省,咸阳市,渭城区',
            areaCode: '100006100040040000'
          },
          {
            id: 12159,
            parentId: 3785,
            areaName: '三原县',
            areaPath: '中国,陕西省,咸阳市,三原县',
            areaCode: '100006100040220000'
          },
          {
            id: 12160,
            parentId: 3785,
            areaName: '泾阳县',
            areaPath: '中国,陕西省,咸阳市,泾阳县',
            areaCode: '100006100040230000'
          },
          {
            id: 12161,
            parentId: 3785,
            areaName: '乾县',
            areaPath: '中国,陕西省,咸阳市,乾县',
            areaCode: '100006100040240000'
          },
          {
            id: 12162,
            parentId: 3785,
            areaName: '礼泉县',
            areaPath: '中国,陕西省,咸阳市,礼泉县',
            areaCode: '100006100040250000'
          },
          {
            id: 12163,
            parentId: 3785,
            areaName: '永寿县',
            areaPath: '中国,陕西省,咸阳市,永寿县',
            areaCode: '100006100040260000'
          },
          {
            id: 12164,
            parentId: 3785,
            areaName: '彬县',
            areaPath: '中国,陕西省,咸阳市,彬县',
            areaCode: '100006100040270000'
          },
          {
            id: 12165,
            parentId: 3785,
            areaName: '长武县',
            areaPath: '中国,陕西省,咸阳市,长武县',
            areaCode: '100006100040280000'
          },
          {
            id: 12166,
            parentId: 3785,
            areaName: '旬邑县',
            areaPath: '中国,陕西省,咸阳市,旬邑县',
            areaCode: '100006100040290000'
          },
          {
            id: 12167,
            parentId: 3785,
            areaName: '淳化县',
            areaPath: '中国,陕西省,咸阳市,淳化县',
            areaCode: '100006100040300000'
          },
          {
            id: 12168,
            parentId: 3785,
            areaName: '武功县',
            areaPath: '中国,陕西省,咸阳市,武功县',
            areaCode: '100006100040310000'
          },
          {
            id: 12169,
            parentId: 3785,
            areaName: '兴平市',
            areaPath: '中国,陕西省,咸阳市,兴平市',
            areaCode: '100006100040810000'
          }
        ]
      },
      {
        id: 3786,
        parentId: 1460,
        areaName: '渭南市',
        areaPath: '中国,陕西省,渭南市',
        areaCode: '100006100050000000',
        children: [
          {
            id: 12170,
            parentId: 3786,
            areaName: '临渭区',
            areaPath: '中国,陕西省,渭南市,临渭区',
            areaCode: '100006100050020000'
          },
          {
            id: 12171,
            parentId: 3786,
            areaName: '华州区',
            areaPath: '中国,陕西省,渭南市,华州区',
            areaCode: '100006100050030000'
          },
          {
            id: 12172,
            parentId: 3786,
            areaName: '潼关县',
            areaPath: '中国,陕西省,渭南市,潼关县',
            areaCode: '100006100050220000'
          },
          {
            id: 12173,
            parentId: 3786,
            areaName: '大荔县',
            areaPath: '中国,陕西省,渭南市,大荔县',
            areaCode: '100006100050230000'
          },
          {
            id: 12174,
            parentId: 3786,
            areaName: '合阳县',
            areaPath: '中国,陕西省,渭南市,合阳县',
            areaCode: '100006100050240000'
          },
          {
            id: 12175,
            parentId: 3786,
            areaName: '澄城县',
            areaPath: '中国,陕西省,渭南市,澄城县',
            areaCode: '100006100050250000'
          },
          {
            id: 12176,
            parentId: 3786,
            areaName: '蒲城县',
            areaPath: '中国,陕西省,渭南市,蒲城县',
            areaCode: '100006100050260000'
          },
          {
            id: 12177,
            parentId: 3786,
            areaName: '白水县',
            areaPath: '中国,陕西省,渭南市,白水县',
            areaCode: '100006100050270000'
          },
          {
            id: 12178,
            parentId: 3786,
            areaName: '富平县',
            areaPath: '中国,陕西省,渭南市,富平县',
            areaCode: '100006100050280000'
          },
          {
            id: 12179,
            parentId: 3786,
            areaName: '韩城市',
            areaPath: '中国,陕西省,渭南市,韩城市',
            areaCode: '100006100050810000'
          },
          {
            id: 12180,
            parentId: 3786,
            areaName: '华阴市',
            areaPath: '中国,陕西省,渭南市,华阴市',
            areaCode: '100006100050820000'
          }
        ]
      },
      {
        id: 3787,
        parentId: 1460,
        areaName: '延安市',
        areaPath: '中国,陕西省,延安市',
        areaCode: '100006100060000000',
        children: [
          {
            id: 12181,
            parentId: 3787,
            areaName: '宝塔区',
            areaPath: '中国,陕西省,延安市,宝塔区',
            areaCode: '100006100060020000'
          },
          {
            id: 12182,
            parentId: 3787,
            areaName: '安塞区',
            areaPath: '中国,陕西省,延安市,安塞区',
            areaCode: '100006100060030000'
          },
          {
            id: 12183,
            parentId: 3787,
            areaName: '延长县',
            areaPath: '中国,陕西省,延安市,延长县',
            areaCode: '100006100060210000'
          },
          {
            id: 12184,
            parentId: 3787,
            areaName: '延川县',
            areaPath: '中国,陕西省,延安市,延川县',
            areaCode: '100006100060220000'
          },
          {
            id: 12185,
            parentId: 3787,
            areaName: '子长县',
            areaPath: '中国,陕西省,延安市,子长县',
            areaCode: '100006100060230000'
          },
          {
            id: 12186,
            parentId: 3787,
            areaName: '志丹县',
            areaPath: '中国,陕西省,延安市,志丹县',
            areaCode: '100006100060250000'
          },
          {
            id: 12187,
            parentId: 3787,
            areaName: '吴起县',
            areaPath: '中国,陕西省,延安市,吴起县',
            areaCode: '100006100060260000'
          },
          {
            id: 12188,
            parentId: 3787,
            areaName: '甘泉县',
            areaPath: '中国,陕西省,延安市,甘泉县',
            areaCode: '100006100060270000'
          },
          {
            id: 12189,
            parentId: 3787,
            areaName: '富县',
            areaPath: '中国,陕西省,延安市,富县',
            areaCode: '100006100060280000'
          },
          {
            id: 12190,
            parentId: 3787,
            areaName: '洛川县',
            areaPath: '中国,陕西省,延安市,洛川县',
            areaCode: '100006100060290000'
          },
          {
            id: 12191,
            parentId: 3787,
            areaName: '宜川县',
            areaPath: '中国,陕西省,延安市,宜川县',
            areaCode: '100006100060300000'
          },
          {
            id: 12192,
            parentId: 3787,
            areaName: '黄龙县',
            areaPath: '中国,陕西省,延安市,黄龙县',
            areaCode: '100006100060310000'
          },
          {
            id: 12193,
            parentId: 3787,
            areaName: '黄陵县',
            areaPath: '中国,陕西省,延安市,黄陵县',
            areaCode: '100006100060320000'
          }
        ]
      },
      {
        id: 3788,
        parentId: 1460,
        areaName: '汉中市',
        areaPath: '中国,陕西省,汉中市',
        areaCode: '100006100070000000',
        children: [
          {
            id: 12194,
            parentId: 3788,
            areaName: '汉台区',
            areaPath: '中国,陕西省,汉中市,汉台区',
            areaCode: '100006100070020000'
          },
          {
            id: 12195,
            parentId: 3788,
            areaName: '南郑区',
            areaPath: '中国,陕西省,汉中市,南郑区',
            areaCode: '100006100070030000'
          },
          {
            id: 12196,
            parentId: 3788,
            areaName: '城固县',
            areaPath: '中国,陕西省,汉中市,城固县',
            areaCode: '100006100070220000'
          },
          {
            id: 12197,
            parentId: 3788,
            areaName: '洋县',
            areaPath: '中国,陕西省,汉中市,洋县',
            areaCode: '100006100070230000'
          },
          {
            id: 12198,
            parentId: 3788,
            areaName: '西乡县',
            areaPath: '中国,陕西省,汉中市,西乡县',
            areaCode: '100006100070240000'
          },
          {
            id: 12199,
            parentId: 3788,
            areaName: '勉县',
            areaPath: '中国,陕西省,汉中市,勉县',
            areaCode: '100006100070250000'
          },
          {
            id: 12200,
            parentId: 3788,
            areaName: '宁强县',
            areaPath: '中国,陕西省,汉中市,宁强县',
            areaCode: '100006100070260000'
          },
          {
            id: 12201,
            parentId: 3788,
            areaName: '略阳县',
            areaPath: '中国,陕西省,汉中市,略阳县',
            areaCode: '100006100070270000'
          },
          {
            id: 12202,
            parentId: 3788,
            areaName: '镇巴县',
            areaPath: '中国,陕西省,汉中市,镇巴县',
            areaCode: '100006100070280000'
          },
          {
            id: 12203,
            parentId: 3788,
            areaName: '留坝县',
            areaPath: '中国,陕西省,汉中市,留坝县',
            areaCode: '100006100070290000'
          },
          {
            id: 12204,
            parentId: 3788,
            areaName: '佛坪县',
            areaPath: '中国,陕西省,汉中市,佛坪县',
            areaCode: '100006100070300000'
          }
        ]
      },
      {
        id: 3789,
        parentId: 1460,
        areaName: '榆林市',
        areaPath: '中国,陕西省,榆林市',
        areaCode: '100006100080000000',
        children: [
          {
            id: 12205,
            parentId: 3789,
            areaName: '榆阳区',
            areaPath: '中国,陕西省,榆林市,榆阳区',
            areaCode: '100006100080020000'
          },
          {
            id: 12206,
            parentId: 3789,
            areaName: '横山区',
            areaPath: '中国,陕西省,榆林市,横山区',
            areaCode: '100006100080030000'
          },
          {
            id: 12207,
            parentId: 3789,
            areaName: '府谷县',
            areaPath: '中国,陕西省,榆林市,府谷县',
            areaCode: '100006100080220000'
          },
          {
            id: 12208,
            parentId: 3789,
            areaName: '靖边县',
            areaPath: '中国,陕西省,榆林市,靖边县',
            areaCode: '100006100080240000'
          },
          {
            id: 12209,
            parentId: 3789,
            areaName: '定边县',
            areaPath: '中国,陕西省,榆林市,定边县',
            areaCode: '100006100080250000'
          },
          {
            id: 12210,
            parentId: 3789,
            areaName: '绥德县',
            areaPath: '中国,陕西省,榆林市,绥德县',
            areaCode: '100006100080260000'
          },
          {
            id: 12211,
            parentId: 3789,
            areaName: '米脂县',
            areaPath: '中国,陕西省,榆林市,米脂县',
            areaCode: '100006100080270000'
          },
          {
            id: 12212,
            parentId: 3789,
            areaName: '佳县',
            areaPath: '中国,陕西省,榆林市,佳县',
            areaCode: '100006100080280000'
          },
          {
            id: 12213,
            parentId: 3789,
            areaName: '吴堡县',
            areaPath: '中国,陕西省,榆林市,吴堡县',
            areaCode: '100006100080290000'
          },
          {
            id: 12214,
            parentId: 3789,
            areaName: '清涧县',
            areaPath: '中国,陕西省,榆林市,清涧县',
            areaCode: '100006100080300000'
          },
          {
            id: 12215,
            parentId: 3789,
            areaName: '子洲县',
            areaPath: '中国,陕西省,榆林市,子洲县',
            areaCode: '100006100080310000'
          },
          {
            id: 12216,
            parentId: 3789,
            areaName: '神木市',
            areaPath: '中国,陕西省,榆林市,神木市',
            areaCode: '100006100080810000'
          }
        ]
      },
      {
        id: 3790,
        parentId: 1460,
        areaName: '安康市',
        areaPath: '中国,陕西省,安康市',
        areaCode: '100006100090000000',
        children: [
          {
            id: 12217,
            parentId: 3790,
            areaName: '汉滨区',
            areaPath: '中国,陕西省,安康市,汉滨区',
            areaCode: '100006100090020000'
          },
          {
            id: 12218,
            parentId: 3790,
            areaName: '汉阴县',
            areaPath: '中国,陕西省,安康市,汉阴县',
            areaCode: '100006100090210000'
          },
          {
            id: 12219,
            parentId: 3790,
            areaName: '石泉县',
            areaPath: '中国,陕西省,安康市,石泉县',
            areaCode: '100006100090220000'
          },
          {
            id: 12220,
            parentId: 3790,
            areaName: '宁陕县',
            areaPath: '中国,陕西省,安康市,宁陕县',
            areaCode: '100006100090230000'
          },
          {
            id: 12221,
            parentId: 3790,
            areaName: '紫阳县',
            areaPath: '中国,陕西省,安康市,紫阳县',
            areaCode: '100006100090240000'
          },
          {
            id: 12222,
            parentId: 3790,
            areaName: '岚皋县',
            areaPath: '中国,陕西省,安康市,岚皋县',
            areaCode: '100006100090250000'
          },
          {
            id: 12223,
            parentId: 3790,
            areaName: '平利县',
            areaPath: '中国,陕西省,安康市,平利县',
            areaCode: '100006100090260000'
          },
          {
            id: 12224,
            parentId: 3790,
            areaName: '镇坪县',
            areaPath: '中国,陕西省,安康市,镇坪县',
            areaCode: '100006100090270000'
          },
          {
            id: 12225,
            parentId: 3790,
            areaName: '旬阳县',
            areaPath: '中国,陕西省,安康市,旬阳县',
            areaCode: '100006100090280000'
          },
          {
            id: 12226,
            parentId: 3790,
            areaName: '白河县',
            areaPath: '中国,陕西省,安康市,白河县',
            areaCode: '100006100090290000'
          }
        ]
      },
      {
        id: 3791,
        parentId: 1460,
        areaName: '商洛市',
        areaPath: '中国,陕西省,商洛市',
        areaCode: '100006100100000000',
        children: [
          {
            id: 12227,
            parentId: 3791,
            areaName: '商州区',
            areaPath: '中国,陕西省,商洛市,商州区',
            areaCode: '100006100100020000'
          },
          {
            id: 12228,
            parentId: 3791,
            areaName: '洛南县',
            areaPath: '中国,陕西省,商洛市,洛南县',
            areaCode: '100006100100210000'
          },
          {
            id: 12229,
            parentId: 3791,
            areaName: '丹凤县',
            areaPath: '中国,陕西省,商洛市,丹凤县',
            areaCode: '100006100100220000'
          },
          {
            id: 12230,
            parentId: 3791,
            areaName: '商南县',
            areaPath: '中国,陕西省,商洛市,商南县',
            areaCode: '100006100100230000'
          },
          {
            id: 12231,
            parentId: 3791,
            areaName: '山阳县',
            areaPath: '中国,陕西省,商洛市,山阳县',
            areaCode: '100006100100240000'
          },
          {
            id: 12232,
            parentId: 3791,
            areaName: '镇安县',
            areaPath: '中国,陕西省,商洛市,镇安县',
            areaCode: '100006100100250000'
          },
          {
            id: 12233,
            parentId: 3791,
            areaName: '柞水县',
            areaPath: '中国,陕西省,商洛市,柞水县',
            areaCode: '100006100100260000'
          }
        ]
      }
    ]
  },
  {
    id: 1461,
    parentId: 1,
    areaName: '甘肃省',
    areaPath: '中国,甘肃省',
    areaCode: '100006200000000000',
    children: [
      {
        id: 3793,
        parentId: 1461,
        areaName: '兰州市',
        areaPath: '中国,甘肃省,兰州市',
        areaCode: '100006200010000000',
        children: [
          {
            id: 12234,
            parentId: 3793,
            areaName: '城关区',
            areaPath: '中国,甘肃省,兰州市,城关区',
            areaCode: '100006200010020000'
          },
          {
            id: 12235,
            parentId: 3793,
            areaName: '七里河区',
            areaPath: '中国,甘肃省,兰州市,七里河区',
            areaCode: '100006200010030000'
          },
          {
            id: 12236,
            parentId: 3793,
            areaName: '西固区',
            areaPath: '中国,甘肃省,兰州市,西固区',
            areaCode: '100006200010040000'
          },
          {
            id: 12237,
            parentId: 3793,
            areaName: '安宁区',
            areaPath: '中国,甘肃省,兰州市,安宁区',
            areaCode: '100006200010050000'
          },
          {
            id: 12238,
            parentId: 3793,
            areaName: '红古区',
            areaPath: '中国,甘肃省,兰州市,红古区',
            areaCode: '100006200010110000'
          },
          {
            id: 12239,
            parentId: 3793,
            areaName: '永登县',
            areaPath: '中国,甘肃省,兰州市,永登县',
            areaCode: '100006200010210000'
          },
          {
            id: 12240,
            parentId: 3793,
            areaName: '皋兰县',
            areaPath: '中国,甘肃省,兰州市,皋兰县',
            areaCode: '100006200010220000'
          },
          {
            id: 12241,
            parentId: 3793,
            areaName: '榆中县',
            areaPath: '中国,甘肃省,兰州市,榆中县',
            areaCode: '100006200010230000'
          }
        ]
      },
      {
        id: 3794,
        parentId: 1461,
        areaName: '嘉峪关市',
        areaPath: '中国,甘肃省,嘉峪关市',
        areaCode: '100006200020000000',
        children: [
          {
            id: 7003,
            parentId: 3794,
            areaName: '雄关区',
            areaPath: '中国,甘肃省,嘉峪关市,雄关区',
            areaCode: '100006200020001400'
          },
          {
            id: 7004,
            parentId: 3794,
            areaName: '长城区',
            areaPath: '中国,甘肃省,嘉峪关市,长城区',
            areaCode: '100006200020001400'
          },
          {
            id: 7005,
            parentId: 3794,
            areaName: '镜铁区',
            areaPath: '中国,甘肃省,嘉峪关市,镜铁区',
            areaCode: '100006200020001400'
          }
        ]
      },
      {
        id: 3795,
        parentId: 1461,
        areaName: '金昌市',
        areaPath: '中国,甘肃省,金昌市',
        areaCode: '100006200030000000',
        children: [
          {
            id: 12242,
            parentId: 3795,
            areaName: '金川区',
            areaPath: '中国,甘肃省,金昌市,金川区',
            areaCode: '100006200030020000'
          },
          {
            id: 12243,
            parentId: 3795,
            areaName: '永昌县',
            areaPath: '中国,甘肃省,金昌市,永昌县',
            areaCode: '100006200030210000'
          }
        ]
      },
      {
        id: 3796,
        parentId: 1461,
        areaName: '白银市',
        areaPath: '中国,甘肃省,白银市',
        areaCode: '100006200040000000',
        children: [
          {
            id: 12244,
            parentId: 3796,
            areaName: '白银区',
            areaPath: '中国,甘肃省,白银市,白银区',
            areaCode: '100006200040020000'
          },
          {
            id: 12245,
            parentId: 3796,
            areaName: '平川区',
            areaPath: '中国,甘肃省,白银市,平川区',
            areaCode: '100006200040030000'
          },
          {
            id: 12246,
            parentId: 3796,
            areaName: '靖远县',
            areaPath: '中国,甘肃省,白银市,靖远县',
            areaCode: '100006200040210000'
          },
          {
            id: 12247,
            parentId: 3796,
            areaName: '会宁县',
            areaPath: '中国,甘肃省,白银市,会宁县',
            areaCode: '100006200040220000'
          },
          {
            id: 12248,
            parentId: 3796,
            areaName: '景泰县',
            areaPath: '中国,甘肃省,白银市,景泰县',
            areaCode: '100006200040230000'
          }
        ]
      },
      {
        id: 3797,
        parentId: 1461,
        areaName: '天水市',
        areaPath: '中国,甘肃省,天水市',
        areaCode: '100006200050000000',
        children: [
          {
            id: 12249,
            parentId: 3797,
            areaName: '秦州区',
            areaPath: '中国,甘肃省,天水市,秦州区',
            areaCode: '100006200050020000'
          },
          {
            id: 12250,
            parentId: 3797,
            areaName: '麦积区',
            areaPath: '中国,甘肃省,天水市,麦积区',
            areaCode: '100006200050030000'
          },
          {
            id: 12251,
            parentId: 3797,
            areaName: '清水县',
            areaPath: '中国,甘肃省,天水市,清水县',
            areaCode: '100006200050210000'
          },
          {
            id: 12252,
            parentId: 3797,
            areaName: '秦安县',
            areaPath: '中国,甘肃省,天水市,秦安县',
            areaCode: '100006200050220000'
          },
          {
            id: 12253,
            parentId: 3797,
            areaName: '甘谷县',
            areaPath: '中国,甘肃省,天水市,甘谷县',
            areaCode: '100006200050230000'
          },
          {
            id: 12254,
            parentId: 3797,
            areaName: '武山县',
            areaPath: '中国,甘肃省,天水市,武山县',
            areaCode: '100006200050240000'
          },
          {
            id: 12255,
            parentId: 3797,
            areaName: '张家川回族自治县',
            areaPath: '中国,甘肃省,天水市,张家川回族自治县',
            areaCode: '100006200050250000'
          }
        ]
      },
      {
        id: 3798,
        parentId: 1461,
        areaName: '武威市',
        areaPath: '中国,甘肃省,武威市',
        areaCode: '100006200060000000',
        children: [
          {
            id: 12256,
            parentId: 3798,
            areaName: '凉州区',
            areaPath: '中国,甘肃省,武威市,凉州区',
            areaCode: '100006200060020000'
          },
          {
            id: 12257,
            parentId: 3798,
            areaName: '民勤县',
            areaPath: '中国,甘肃省,武威市,民勤县',
            areaCode: '100006200060210000'
          },
          {
            id: 12258,
            parentId: 3798,
            areaName: '古浪县',
            areaPath: '中国,甘肃省,武威市,古浪县',
            areaCode: '100006200060220000'
          },
          {
            id: 12259,
            parentId: 3798,
            areaName: '天祝藏族自治县',
            areaPath: '中国,甘肃省,武威市,天祝藏族自治县',
            areaCode: '100006200060230000'
          }
        ]
      },
      {
        id: 3799,
        parentId: 1461,
        areaName: '张掖市',
        areaPath: '中国,甘肃省,张掖市',
        areaCode: '100006200070000000',
        children: [
          {
            id: 12260,
            parentId: 3799,
            areaName: '甘州区',
            areaPath: '中国,甘肃省,张掖市,甘州区',
            areaCode: '100006200070020000'
          },
          {
            id: 12261,
            parentId: 3799,
            areaName: '肃南裕固族自治县',
            areaPath: '中国,甘肃省,张掖市,肃南裕固族自治县',
            areaCode: '100006200070210000'
          },
          {
            id: 12262,
            parentId: 3799,
            areaName: '民乐县',
            areaPath: '中国,甘肃省,张掖市,民乐县',
            areaCode: '100006200070220000'
          },
          {
            id: 12263,
            parentId: 3799,
            areaName: '临泽县',
            areaPath: '中国,甘肃省,张掖市,临泽县',
            areaCode: '100006200070230000'
          },
          {
            id: 12264,
            parentId: 3799,
            areaName: '高台县',
            areaPath: '中国,甘肃省,张掖市,高台县',
            areaCode: '100006200070240000'
          },
          {
            id: 12265,
            parentId: 3799,
            areaName: '山丹县',
            areaPath: '中国,甘肃省,张掖市,山丹县',
            areaCode: '100006200070250000'
          }
        ]
      },
      {
        id: 3800,
        parentId: 1461,
        areaName: '平凉市',
        areaPath: '中国,甘肃省,平凉市',
        areaCode: '100006200080000000',
        children: [
          {
            id: 12266,
            parentId: 3800,
            areaName: '崆峒区',
            areaPath: '中国,甘肃省,平凉市,崆峒区',
            areaCode: '100006200080020000'
          },
          {
            id: 12267,
            parentId: 3800,
            areaName: '泾川县',
            areaPath: '中国,甘肃省,平凉市,泾川县',
            areaCode: '100006200080210000'
          },
          {
            id: 12268,
            parentId: 3800,
            areaName: '灵台县',
            areaPath: '中国,甘肃省,平凉市,灵台县',
            areaCode: '100006200080220000'
          },
          {
            id: 12269,
            parentId: 3800,
            areaName: '崇信县',
            areaPath: '中国,甘肃省,平凉市,崇信县',
            areaCode: '100006200080230000'
          },
          {
            id: 12270,
            parentId: 3800,
            areaName: '华亭县',
            areaPath: '中国,甘肃省,平凉市,华亭县',
            areaCode: '100006200080240000'
          },
          {
            id: 12271,
            parentId: 3800,
            areaName: '庄浪县',
            areaPath: '中国,甘肃省,平凉市,庄浪县',
            areaCode: '100006200080250000'
          },
          {
            id: 12272,
            parentId: 3800,
            areaName: '静宁县',
            areaPath: '中国,甘肃省,平凉市,静宁县',
            areaCode: '100006200080260000'
          }
        ]
      },
      {
        id: 3801,
        parentId: 1461,
        areaName: '酒泉市',
        areaPath: '中国,甘肃省,酒泉市',
        areaCode: '100006200090000000',
        children: [
          {
            id: 12273,
            parentId: 3801,
            areaName: '肃州区',
            areaPath: '中国,甘肃省,酒泉市,肃州区',
            areaCode: '100006200090020000'
          },
          {
            id: 12274,
            parentId: 3801,
            areaName: '金塔县',
            areaPath: '中国,甘肃省,酒泉市,金塔县',
            areaCode: '100006200090210000'
          },
          {
            id: 12275,
            parentId: 3801,
            areaName: '瓜州县',
            areaPath: '中国,甘肃省,酒泉市,瓜州县',
            areaCode: '100006200090220000'
          },
          {
            id: 12276,
            parentId: 3801,
            areaName: '肃北蒙古族自治县',
            areaPath: '中国,甘肃省,酒泉市,肃北蒙古族自治县',
            areaCode: '100006200090230000'
          },
          {
            id: 12277,
            parentId: 3801,
            areaName: '阿克塞哈萨克族自治县',
            areaPath: '中国,甘肃省,酒泉市,阿克塞哈萨克族自治县',
            areaCode: '100006200090240000'
          },
          {
            id: 12278,
            parentId: 3801,
            areaName: '玉门市',
            areaPath: '中国,甘肃省,酒泉市,玉门市',
            areaCode: '100006200090810000'
          },
          {
            id: 12279,
            parentId: 3801,
            areaName: '敦煌市',
            areaPath: '中国,甘肃省,酒泉市,敦煌市',
            areaCode: '100006200090820000'
          }
        ]
      },
      {
        id: 3802,
        parentId: 1461,
        areaName: '庆阳市',
        areaPath: '中国,甘肃省,庆阳市',
        areaCode: '100006200100000000',
        children: [
          {
            id: 12280,
            parentId: 3802,
            areaName: '西峰区',
            areaPath: '中国,甘肃省,庆阳市,西峰区',
            areaCode: '100006200100020000'
          },
          {
            id: 12281,
            parentId: 3802,
            areaName: '庆城县',
            areaPath: '中国,甘肃省,庆阳市,庆城县',
            areaCode: '100006200100210000'
          },
          {
            id: 12282,
            parentId: 3802,
            areaName: '环县',
            areaPath: '中国,甘肃省,庆阳市,环县',
            areaCode: '100006200100220000'
          },
          {
            id: 12283,
            parentId: 3802,
            areaName: '华池县',
            areaPath: '中国,甘肃省,庆阳市,华池县',
            areaCode: '100006200100230000'
          },
          {
            id: 12284,
            parentId: 3802,
            areaName: '合水县',
            areaPath: '中国,甘肃省,庆阳市,合水县',
            areaCode: '100006200100240000'
          },
          {
            id: 12285,
            parentId: 3802,
            areaName: '正宁县',
            areaPath: '中国,甘肃省,庆阳市,正宁县',
            areaCode: '100006200100250000'
          },
          {
            id: 12286,
            parentId: 3802,
            areaName: '宁县',
            areaPath: '中国,甘肃省,庆阳市,宁县',
            areaCode: '100006200100260000'
          },
          {
            id: 12287,
            parentId: 3802,
            areaName: '镇原县',
            areaPath: '中国,甘肃省,庆阳市,镇原县',
            areaCode: '100006200100270000'
          }
        ]
      },
      {
        id: 3803,
        parentId: 1461,
        areaName: '定西市',
        areaPath: '中国,甘肃省,定西市',
        areaCode: '100006200110000000',
        children: [
          {
            id: 12288,
            parentId: 3803,
            areaName: '安定区',
            areaPath: '中国,甘肃省,定西市,安定区',
            areaCode: '100006200110020000'
          },
          {
            id: 12289,
            parentId: 3803,
            areaName: '通渭县',
            areaPath: '中国,甘肃省,定西市,通渭县',
            areaCode: '100006200110210000'
          },
          {
            id: 12290,
            parentId: 3803,
            areaName: '陇西县',
            areaPath: '中国,甘肃省,定西市,陇西县',
            areaCode: '100006200110220000'
          },
          {
            id: 12291,
            parentId: 3803,
            areaName: '渭源县',
            areaPath: '中国,甘肃省,定西市,渭源县',
            areaCode: '100006200110230000'
          },
          {
            id: 12292,
            parentId: 3803,
            areaName: '临洮县',
            areaPath: '中国,甘肃省,定西市,临洮县',
            areaCode: '100006200110240000'
          },
          {
            id: 12293,
            parentId: 3803,
            areaName: '漳县',
            areaPath: '中国,甘肃省,定西市,漳县',
            areaCode: '100006200110250000'
          },
          {
            id: 12294,
            parentId: 3803,
            areaName: '岷县',
            areaPath: '中国,甘肃省,定西市,岷县',
            areaCode: '100006200110260000'
          }
        ]
      },
      {
        id: 3804,
        parentId: 1461,
        areaName: '陇南市',
        areaPath: '中国,甘肃省,陇南市',
        areaCode: '100006200120000000',
        children: [
          {
            id: 12295,
            parentId: 3804,
            areaName: '武都区',
            areaPath: '中国,甘肃省,陇南市,武都区',
            areaCode: '100006200120020000'
          },
          {
            id: 12296,
            parentId: 3804,
            areaName: '成县',
            areaPath: '中国,甘肃省,陇南市,成县',
            areaCode: '100006200120210000'
          },
          {
            id: 12297,
            parentId: 3804,
            areaName: '文县',
            areaPath: '中国,甘肃省,陇南市,文县',
            areaCode: '100006200120220000'
          },
          {
            id: 12298,
            parentId: 3804,
            areaName: '宕昌县',
            areaPath: '中国,甘肃省,陇南市,宕昌县',
            areaCode: '100006200120230000'
          },
          {
            id: 12299,
            parentId: 3804,
            areaName: '康县',
            areaPath: '中国,甘肃省,陇南市,康县',
            areaCode: '100006200120240000'
          },
          {
            id: 12300,
            parentId: 3804,
            areaName: '西和县',
            areaPath: '中国,甘肃省,陇南市,西和县',
            areaCode: '100006200120250000'
          },
          {
            id: 12301,
            parentId: 3804,
            areaName: '礼县',
            areaPath: '中国,甘肃省,陇南市,礼县',
            areaCode: '100006200120260000'
          },
          {
            id: 12302,
            parentId: 3804,
            areaName: '徽县',
            areaPath: '中国,甘肃省,陇南市,徽县',
            areaCode: '100006200120270000'
          },
          {
            id: 12303,
            parentId: 3804,
            areaName: '两当县',
            areaPath: '中国,甘肃省,陇南市,两当县',
            areaCode: '100006200120280000'
          }
        ]
      },
      {
        id: 3805,
        parentId: 1461,
        areaName: '临夏回族自治州',
        areaPath: '中国,甘肃省,临夏回族自治州',
        areaCode: '100006200290000000',
        children: [
          {
            id: 12304,
            parentId: 3805,
            areaName: '临夏市',
            areaPath: '中国,甘肃省,临夏回族自治州,临夏市',
            areaCode: '100006200290010000'
          },
          {
            id: 12305,
            parentId: 3805,
            areaName: '临夏县',
            areaPath: '中国,甘肃省,临夏回族自治州,临夏县',
            areaCode: '100006200290210000'
          },
          {
            id: 12306,
            parentId: 3805,
            areaName: '康乐县',
            areaPath: '中国,甘肃省,临夏回族自治州,康乐县',
            areaCode: '100006200290220000'
          },
          {
            id: 12307,
            parentId: 3805,
            areaName: '永靖县',
            areaPath: '中国,甘肃省,临夏回族自治州,永靖县',
            areaCode: '100006200290230000'
          },
          {
            id: 12308,
            parentId: 3805,
            areaName: '广河县',
            areaPath: '中国,甘肃省,临夏回族自治州,广河县',
            areaCode: '100006200290240000'
          },
          {
            id: 12309,
            parentId: 3805,
            areaName: '和政县',
            areaPath: '中国,甘肃省,临夏回族自治州,和政县',
            areaCode: '100006200290250000'
          },
          {
            id: 12310,
            parentId: 3805,
            areaName: '东乡族自治县',
            areaPath: '中国,甘肃省,临夏回族自治州,东乡族自治县',
            areaCode: '100006200290260000'
          },
          {
            id: 12311,
            parentId: 3805,
            areaName: '积石山保安族东乡族撒拉族自治县',
            areaPath:
              '中国,甘肃省,临夏回族自治州,积石山保安族东乡族撒拉族自治县',
            areaCode: '100006200290270000'
          }
        ]
      },
      {
        id: 3806,
        parentId: 1461,
        areaName: '甘南藏族自治州',
        areaPath: '中国,甘肃省,甘南藏族自治州',
        areaCode: '100006200300000000',
        children: [
          {
            id: 12312,
            parentId: 3806,
            areaName: '合作市',
            areaPath: '中国,甘肃省,甘南藏族自治州,合作市',
            areaCode: '100006200300010000'
          },
          {
            id: 12313,
            parentId: 3806,
            areaName: '临潭县',
            areaPath: '中国,甘肃省,甘南藏族自治州,临潭县',
            areaCode: '100006200300210000'
          },
          {
            id: 12314,
            parentId: 3806,
            areaName: '卓尼县',
            areaPath: '中国,甘肃省,甘南藏族自治州,卓尼县',
            areaCode: '100006200300220000'
          },
          {
            id: 12315,
            parentId: 3806,
            areaName: '舟曲县',
            areaPath: '中国,甘肃省,甘南藏族自治州,舟曲县',
            areaCode: '100006200300230000'
          },
          {
            id: 12316,
            parentId: 3806,
            areaName: '迭部县',
            areaPath: '中国,甘肃省,甘南藏族自治州,迭部县',
            areaCode: '100006200300240000'
          },
          {
            id: 12317,
            parentId: 3806,
            areaName: '玛曲县',
            areaPath: '中国,甘肃省,甘南藏族自治州,玛曲县',
            areaCode: '100006200300250000'
          },
          {
            id: 12318,
            parentId: 3806,
            areaName: '碌曲县',
            areaPath: '中国,甘肃省,甘南藏族自治州,碌曲县',
            areaCode: '100006200300260000'
          },
          {
            id: 12319,
            parentId: 3806,
            areaName: '夏河县',
            areaPath: '中国,甘肃省,甘南藏族自治州,夏河县',
            areaCode: '100006200300270000'
          }
        ]
      }
    ]
  },
  {
    id: 1462,
    parentId: 1,
    areaName: '青海省',
    areaPath: '中国,青海省',
    areaCode: '100006300000000000',
    children: [
      {
        id: 3807,
        parentId: 1462,
        areaName: '西宁市',
        areaPath: '中国,青海省,西宁市',
        areaCode: '100006300010000000',
        children: [
          {
            id: 12320,
            parentId: 3807,
            areaName: '城东区',
            areaPath: '中国,青海省,西宁市,城东区',
            areaCode: '100006300010020000'
          },
          {
            id: 12321,
            parentId: 3807,
            areaName: '城中区',
            areaPath: '中国,青海省,西宁市,城中区',
            areaCode: '100006300010030000'
          },
          {
            id: 12322,
            parentId: 3807,
            areaName: '城西区',
            areaPath: '中国,青海省,西宁市,城西区',
            areaCode: '100006300010040000'
          },
          {
            id: 12323,
            parentId: 3807,
            areaName: '城北区',
            areaPath: '中国,青海省,西宁市,城北区',
            areaCode: '100006300010050000'
          },
          {
            id: 12324,
            parentId: 3807,
            areaName: '大通回族土族自治县',
            areaPath: '中国,青海省,西宁市,大通回族土族自治县',
            areaCode: '100006300010210000'
          },
          {
            id: 12325,
            parentId: 3807,
            areaName: '湟中县',
            areaPath: '中国,青海省,西宁市,湟中县',
            areaCode: '100006300010220000'
          },
          {
            id: 12326,
            parentId: 3807,
            areaName: '湟源县',
            areaPath: '中国,青海省,西宁市,湟源县',
            areaCode: '100006300010230000'
          }
        ]
      },
      {
        id: 3808,
        parentId: 1462,
        areaName: '海东市',
        areaPath: '中国,青海省,海东市',
        areaCode: '100006300020000000',
        children: [
          {
            id: 12327,
            parentId: 3808,
            areaName: '乐都区',
            areaPath: '中国,青海省,海东市,乐都区',
            areaCode: '100006300020020000'
          },
          {
            id: 12328,
            parentId: 3808,
            areaName: '平安区',
            areaPath: '中国,青海省,海东市,平安区',
            areaCode: '100006300020030000'
          },
          {
            id: 12329,
            parentId: 3808,
            areaName: '民和回族土族自治县',
            areaPath: '中国,青海省,海东市,民和回族土族自治县',
            areaCode: '100006300020220000'
          },
          {
            id: 12330,
            parentId: 3808,
            areaName: '互助土族自治县',
            areaPath: '中国,青海省,海东市,互助土族自治县',
            areaCode: '100006300020230000'
          },
          {
            id: 12331,
            parentId: 3808,
            areaName: '化隆回族自治县',
            areaPath: '中国,青海省,海东市,化隆回族自治县',
            areaCode: '100006300020240000'
          },
          {
            id: 12332,
            parentId: 3808,
            areaName: '循化撒拉族自治县',
            areaPath: '中国,青海省,海东市,循化撒拉族自治县',
            areaCode: '100006300020250000'
          }
        ]
      },
      {
        id: 3809,
        parentId: 1462,
        areaName: '海北藏族自治州',
        areaPath: '中国,青海省,海北藏族自治州',
        areaCode: '100006300220000000',
        children: [
          {
            id: 12333,
            parentId: 3809,
            areaName: '门源回族自治县',
            areaPath: '中国,青海省,海北藏族自治州,门源回族自治县',
            areaCode: '100006300220210000'
          },
          {
            id: 12334,
            parentId: 3809,
            areaName: '祁连县',
            areaPath: '中国,青海省,海北藏族自治州,祁连县',
            areaCode: '100006300220220000'
          },
          {
            id: 12335,
            parentId: 3809,
            areaName: '海晏县',
            areaPath: '中国,青海省,海北藏族自治州,海晏县',
            areaCode: '100006300220230000'
          },
          {
            id: 12336,
            parentId: 3809,
            areaName: '刚察县',
            areaPath: '中国,青海省,海北藏族自治州,刚察县',
            areaCode: '100006300220240000'
          }
        ]
      },
      {
        id: 3810,
        parentId: 1462,
        areaName: '黄南藏族自治州',
        areaPath: '中国,青海省,黄南藏族自治州',
        areaCode: '100006300230000000',
        children: [
          {
            id: 12337,
            parentId: 3810,
            areaName: '同仁县',
            areaPath: '中国,青海省,黄南藏族自治州,同仁县',
            areaCode: '100006300230210000'
          },
          {
            id: 12338,
            parentId: 3810,
            areaName: '尖扎县',
            areaPath: '中国,青海省,黄南藏族自治州,尖扎县',
            areaCode: '100006300230220000'
          },
          {
            id: 12339,
            parentId: 3810,
            areaName: '泽库县',
            areaPath: '中国,青海省,黄南藏族自治州,泽库县',
            areaCode: '100006300230230000'
          },
          {
            id: 12340,
            parentId: 3810,
            areaName: '河南蒙古族自治县',
            areaPath: '中国,青海省,黄南藏族自治州,河南蒙古族自治县',
            areaCode: '100006300230240000'
          }
        ]
      },
      {
        id: 3811,
        parentId: 1462,
        areaName: '海南藏族自治州',
        areaPath: '中国,青海省,海南藏族自治州',
        areaCode: '100006300250000000',
        children: [
          {
            id: 12341,
            parentId: 3811,
            areaName: '共和县',
            areaPath: '中国,青海省,海南藏族自治州,共和县',
            areaCode: '100006300250210000'
          },
          {
            id: 12342,
            parentId: 3811,
            areaName: '同德县',
            areaPath: '中国,青海省,海南藏族自治州,同德县',
            areaCode: '100006300250220000'
          },
          {
            id: 12343,
            parentId: 3811,
            areaName: '贵德县',
            areaPath: '中国,青海省,海南藏族自治州,贵德县',
            areaCode: '100006300250230000'
          },
          {
            id: 12344,
            parentId: 3811,
            areaName: '兴海县',
            areaPath: '中国,青海省,海南藏族自治州,兴海县',
            areaCode: '100006300250240000'
          },
          {
            id: 12345,
            parentId: 3811,
            areaName: '贵南县',
            areaPath: '中国,青海省,海南藏族自治州,贵南县',
            areaCode: '100006300250250000'
          }
        ]
      },
      {
        id: 3812,
        parentId: 1462,
        areaName: '果洛藏族自治州',
        areaPath: '中国,青海省,果洛藏族自治州',
        areaCode: '100006300260000000',
        children: [
          {
            id: 12346,
            parentId: 3812,
            areaName: '玛沁县',
            areaPath: '中国,青海省,果洛藏族自治州,玛沁县',
            areaCode: '100006300260210000'
          },
          {
            id: 12347,
            parentId: 3812,
            areaName: '班玛县',
            areaPath: '中国,青海省,果洛藏族自治州,班玛县',
            areaCode: '100006300260220000'
          },
          {
            id: 12348,
            parentId: 3812,
            areaName: '甘德县',
            areaPath: '中国,青海省,果洛藏族自治州,甘德县',
            areaCode: '100006300260230000'
          },
          {
            id: 12349,
            parentId: 3812,
            areaName: '达日县',
            areaPath: '中国,青海省,果洛藏族自治州,达日县',
            areaCode: '100006300260240000'
          },
          {
            id: 12350,
            parentId: 3812,
            areaName: '久治县',
            areaPath: '中国,青海省,果洛藏族自治州,久治县',
            areaCode: '100006300260250000'
          },
          {
            id: 12351,
            parentId: 3812,
            areaName: '玛多县',
            areaPath: '中国,青海省,果洛藏族自治州,玛多县',
            areaCode: '100006300260260000'
          }
        ]
      },
      {
        id: 3813,
        parentId: 1462,
        areaName: '玉树藏族自治州',
        areaPath: '中国,青海省,玉树藏族自治州',
        areaCode: '100006300270000000',
        children: [
          {
            id: 12352,
            parentId: 3813,
            areaName: '玉树市',
            areaPath: '中国,青海省,玉树藏族自治州,玉树市',
            areaCode: '100006300270010000'
          },
          {
            id: 12353,
            parentId: 3813,
            areaName: '杂多县',
            areaPath: '中国,青海省,玉树藏族自治州,杂多县',
            areaCode: '100006300270220000'
          },
          {
            id: 12354,
            parentId: 3813,
            areaName: '称多县',
            areaPath: '中国,青海省,玉树藏族自治州,称多县',
            areaCode: '100006300270230000'
          },
          {
            id: 12355,
            parentId: 3813,
            areaName: '治多县',
            areaPath: '中国,青海省,玉树藏族自治州,治多县',
            areaCode: '100006300270240000'
          },
          {
            id: 12356,
            parentId: 3813,
            areaName: '囊谦县',
            areaPath: '中国,青海省,玉树藏族自治州,囊谦县',
            areaCode: '100006300270250000'
          },
          {
            id: 12357,
            parentId: 3813,
            areaName: '曲麻莱县',
            areaPath: '中国,青海省,玉树藏族自治州,曲麻莱县',
            areaCode: '100006300270260000'
          }
        ]
      },
      {
        id: 3814,
        parentId: 1462,
        areaName: '海西蒙古族藏族自治州',
        areaPath: '中国,青海省,海西蒙古族藏族自治州',
        areaCode: '100006300280000000',
        children: [
          {
            id: 12358,
            parentId: 3814,
            areaName: '格尔木市',
            areaPath: '中国,青海省,海西蒙古族藏族自治州,格尔木市',
            areaCode: '100006300280010000'
          },
          {
            id: 12359,
            parentId: 3814,
            areaName: '德令哈市',
            areaPath: '中国,青海省,海西蒙古族藏族自治州,德令哈市',
            areaCode: '100006300280020000'
          },
          {
            id: 12360,
            parentId: 3814,
            areaName: '乌兰县',
            areaPath: '中国,青海省,海西蒙古族藏族自治州,乌兰县',
            areaCode: '100006300280210000'
          },
          {
            id: 12361,
            parentId: 3814,
            areaName: '都兰县',
            areaPath: '中国,青海省,海西蒙古族藏族自治州,都兰县',
            areaCode: '100006300280220000'
          },
          {
            id: 12362,
            parentId: 3814,
            areaName: '天峻县',
            areaPath: '中国,青海省,海西蒙古族藏族自治州,天峻县',
            areaCode: '100006300280230000'
          }
        ]
      }
    ]
  },
  {
    id: 1463,
    parentId: 1,
    areaName: '宁夏回族自治区',
    areaPath: '中国,宁夏回族自治区',
    areaCode: '100006400000000000',
    children: [
      {
        id: 3815,
        parentId: 1463,
        areaName: '银川市',
        areaPath: '中国,宁夏回族自治区,银川市',
        areaCode: '100006400010000000',
        children: [
          {
            id: 12363,
            parentId: 3815,
            areaName: '兴庆区',
            areaPath: '中国,宁夏回族自治区,银川市,兴庆区',
            areaCode: '100006400010040000'
          },
          {
            id: 12364,
            parentId: 3815,
            areaName: '西夏区',
            areaPath: '中国,宁夏回族自治区,银川市,西夏区',
            areaCode: '100006400010050000'
          },
          {
            id: 12365,
            parentId: 3815,
            areaName: '金凤区',
            areaPath: '中国,宁夏回族自治区,银川市,金凤区',
            areaCode: '100006400010060000'
          },
          {
            id: 12366,
            parentId: 3815,
            areaName: '永宁县',
            areaPath: '中国,宁夏回族自治区,银川市,永宁县',
            areaCode: '100006400010210000'
          },
          {
            id: 12367,
            parentId: 3815,
            areaName: '贺兰县',
            areaPath: '中国,宁夏回族自治区,银川市,贺兰县',
            areaCode: '100006400010220000'
          },
          {
            id: 12368,
            parentId: 3815,
            areaName: '灵武市',
            areaPath: '中国,宁夏回族自治区,银川市,灵武市',
            areaCode: '100006400010810000'
          }
        ]
      },
      {
        id: 3816,
        parentId: 1463,
        areaName: '石嘴山市',
        areaPath: '中国,宁夏回族自治区,石嘴山市',
        areaCode: '100006400020000000',
        children: [
          {
            id: 12369,
            parentId: 3816,
            areaName: '大武口区',
            areaPath: '中国,宁夏回族自治区,石嘴山市,大武口区',
            areaCode: '100006400020020000'
          },
          {
            id: 12370,
            parentId: 3816,
            areaName: '惠农区',
            areaPath: '中国,宁夏回族自治区,石嘴山市,惠农区',
            areaCode: '100006400020050000'
          },
          {
            id: 12371,
            parentId: 3816,
            areaName: '平罗县',
            areaPath: '中国,宁夏回族自治区,石嘴山市,平罗县',
            areaCode: '100006400020210000'
          }
        ]
      },
      {
        id: 3817,
        parentId: 1463,
        areaName: '吴忠市',
        areaPath: '中国,宁夏回族自治区,吴忠市',
        areaCode: '100006400030000000',
        children: [
          {
            id: 12372,
            parentId: 3817,
            areaName: '利通区',
            areaPath: '中国,宁夏回族自治区,吴忠市,利通区',
            areaCode: '100006400030020000'
          },
          {
            id: 12373,
            parentId: 3817,
            areaName: '红寺堡区',
            areaPath: '中国,宁夏回族自治区,吴忠市,红寺堡区',
            areaCode: '100006400030030000'
          },
          {
            id: 12374,
            parentId: 3817,
            areaName: '盐池县',
            areaPath: '中国,宁夏回族自治区,吴忠市,盐池县',
            areaCode: '100006400030230000'
          },
          {
            id: 12375,
            parentId: 3817,
            areaName: '同心县',
            areaPath: '中国,宁夏回族自治区,吴忠市,同心县',
            areaCode: '100006400030240000'
          },
          {
            id: 12376,
            parentId: 3817,
            areaName: '青铜峡市',
            areaPath: '中国,宁夏回族自治区,吴忠市,青铜峡市',
            areaCode: '100006400030810000'
          }
        ]
      },
      {
        id: 3818,
        parentId: 1463,
        areaName: '固原市',
        areaPath: '中国,宁夏回族自治区,固原市',
        areaCode: '100006400040000000',
        children: [
          {
            id: 12377,
            parentId: 3818,
            areaName: '原州区',
            areaPath: '中国,宁夏回族自治区,固原市,原州区',
            areaCode: '100006400040020000'
          },
          {
            id: 12378,
            parentId: 3818,
            areaName: '西吉县',
            areaPath: '中国,宁夏回族自治区,固原市,西吉县',
            areaCode: '100006400040220000'
          },
          {
            id: 12379,
            parentId: 3818,
            areaName: '隆德县',
            areaPath: '中国,宁夏回族自治区,固原市,隆德县',
            areaCode: '100006400040230000'
          },
          {
            id: 12380,
            parentId: 3818,
            areaName: '泾源县',
            areaPath: '中国,宁夏回族自治区,固原市,泾源县',
            areaCode: '100006400040240000'
          },
          {
            id: 12381,
            parentId: 3818,
            areaName: '彭阳县',
            areaPath: '中国,宁夏回族自治区,固原市,彭阳县',
            areaCode: '100006400040250000'
          }
        ]
      },
      {
        id: 3819,
        parentId: 1463,
        areaName: '中卫市',
        areaPath: '中国,宁夏回族自治区,中卫市',
        areaCode: '100006400050000000',
        children: [
          {
            id: 12382,
            parentId: 3819,
            areaName: '沙坡头区',
            areaPath: '中国,宁夏回族自治区,中卫市,沙坡头区',
            areaCode: '100006400050020000'
          },
          {
            id: 12383,
            parentId: 3819,
            areaName: '中宁县',
            areaPath: '中国,宁夏回族自治区,中卫市,中宁县',
            areaCode: '100006400050210000'
          },
          {
            id: 12384,
            parentId: 3819,
            areaName: '海原县',
            areaPath: '中国,宁夏回族自治区,中卫市,海原县',
            areaCode: '100006400050220000'
          }
        ]
      }
    ]
  },
  {
    id: 1464,
    parentId: 1,
    areaName: '新疆维吾尔自治区',
    areaPath: '中国,新疆维吾尔自治区',
    areaCode: '100006500000000000',
    children: [
      {
        id: 3820,
        parentId: 1464,
        areaName: '乌鲁木齐市',
        areaPath: '中国,新疆维吾尔自治区,乌鲁木齐市',
        areaCode: '100006500010000000',
        children: [
          {
            id: 12385,
            parentId: 3820,
            areaName: '天山区',
            areaPath: '中国,新疆维吾尔自治区,乌鲁木齐市,天山区',
            areaCode: '100006500010020000'
          },
          {
            id: 12386,
            parentId: 3820,
            areaName: '沙依巴克区',
            areaPath: '中国,新疆维吾尔自治区,乌鲁木齐市,沙依巴克区',
            areaCode: '100006500010030000'
          },
          {
            id: 12387,
            parentId: 3820,
            areaName: '新市区',
            areaPath: '中国,新疆维吾尔自治区,乌鲁木齐市,新市区',
            areaCode: '100006500010040000'
          },
          {
            id: 12388,
            parentId: 3820,
            areaName: '水磨沟区',
            areaPath: '中国,新疆维吾尔自治区,乌鲁木齐市,水磨沟区',
            areaCode: '100006500010050000'
          },
          {
            id: 12389,
            parentId: 3820,
            areaName: '头屯河区',
            areaPath: '中国,新疆维吾尔自治区,乌鲁木齐市,头屯河区',
            areaCode: '100006500010060000'
          },
          {
            id: 12390,
            parentId: 3820,
            areaName: '达坂城区',
            areaPath: '中国,新疆维吾尔自治区,乌鲁木齐市,达坂城区',
            areaCode: '100006500010070000'
          },
          {
            id: 12391,
            parentId: 3820,
            areaName: '米东区',
            areaPath: '中国,新疆维吾尔自治区,乌鲁木齐市,米东区',
            areaCode: '100006500010090000'
          },
          {
            id: 12392,
            parentId: 3820,
            areaName: '乌鲁木齐县',
            areaPath: '中国,新疆维吾尔自治区,乌鲁木齐市,乌鲁木齐县',
            areaCode: '100006500010210000'
          }
        ]
      },
      {
        id: 3821,
        parentId: 1464,
        areaName: '克拉玛依市',
        areaPath: '中国,新疆维吾尔自治区,克拉玛依市',
        areaCode: '100006500020000000',
        children: [
          {
            id: 12393,
            parentId: 3821,
            areaName: '独山子区',
            areaPath: '中国,新疆维吾尔自治区,克拉玛依市,独山子区',
            areaCode: '100006500020020000'
          },
          {
            id: 12394,
            parentId: 3821,
            areaName: '克拉玛依区',
            areaPath: '中国,新疆维吾尔自治区,克拉玛依市,克拉玛依区',
            areaCode: '100006500020030000'
          },
          {
            id: 12395,
            parentId: 3821,
            areaName: '白碱滩区',
            areaPath: '中国,新疆维吾尔自治区,克拉玛依市,白碱滩区',
            areaCode: '100006500020040000'
          },
          {
            id: 12396,
            parentId: 3821,
            areaName: '乌尔禾区',
            areaPath: '中国,新疆维吾尔自治区,克拉玛依市,乌尔禾区',
            areaCode: '100006500020050000'
          }
        ]
      },
      {
        id: 3822,
        parentId: 1464,
        areaName: '吐鲁番市',
        areaPath: '中国,新疆维吾尔自治区,吐鲁番市',
        areaCode: '100006500040000000',
        children: [
          {
            id: 12397,
            parentId: 3822,
            areaName: '高昌区',
            areaPath: '中国,新疆维吾尔自治区,吐鲁番市,高昌区',
            areaCode: '100006500040020000'
          },
          {
            id: 12398,
            parentId: 3822,
            areaName: '鄯善县',
            areaPath: '中国,新疆维吾尔自治区,吐鲁番市,鄯善县',
            areaCode: '100006500040210000'
          },
          {
            id: 12399,
            parentId: 3822,
            areaName: '托克逊县',
            areaPath: '中国,新疆维吾尔自治区,吐鲁番市,托克逊县',
            areaCode: '100006500040220000'
          }
        ]
      },
      {
        id: 3823,
        parentId: 1464,
        areaName: '哈密市',
        areaPath: '中国,新疆维吾尔自治区,哈密市',
        areaCode: '100006500050000000',
        children: [
          {
            id: 12400,
            parentId: 3823,
            areaName: '伊州区',
            areaPath: '中国,新疆维吾尔自治区,哈密市,伊州区',
            areaCode: '100006500050020000'
          },
          {
            id: 12401,
            parentId: 3823,
            areaName: '巴里坤哈萨克自治县',
            areaPath: '中国,新疆维吾尔自治区,哈密市,巴里坤哈萨克自治县',
            areaCode: '100006500050210000'
          },
          {
            id: 12402,
            parentId: 3823,
            areaName: '伊吾县',
            areaPath: '中国,新疆维吾尔自治区,哈密市,伊吾县',
            areaCode: '100006500050220000'
          }
        ]
      },
      {
        id: 3824,
        parentId: 1464,
        areaName: '昌吉回族自治州',
        areaPath: '中国,新疆维吾尔自治区,昌吉回族自治州',
        areaCode: '100006500230000000',
        children: [
          {
            id: 12403,
            parentId: 3824,
            areaName: '昌吉市',
            areaPath: '中国,新疆维吾尔自治区,昌吉回族自治州,昌吉市',
            areaCode: '100006500230010000'
          },
          {
            id: 12404,
            parentId: 3824,
            areaName: '阜康市',
            areaPath: '中国,新疆维吾尔自治区,昌吉回族自治州,阜康市',
            areaCode: '100006500230020000'
          },
          {
            id: 12405,
            parentId: 3824,
            areaName: '呼图壁县',
            areaPath: '中国,新疆维吾尔自治区,昌吉回族自治州,呼图壁县',
            areaCode: '100006500230230000'
          },
          {
            id: 12406,
            parentId: 3824,
            areaName: '玛纳斯县',
            areaPath: '中国,新疆维吾尔自治区,昌吉回族自治州,玛纳斯县',
            areaCode: '100006500230240000'
          },
          {
            id: 12407,
            parentId: 3824,
            areaName: '奇台县',
            areaPath: '中国,新疆维吾尔自治区,昌吉回族自治州,奇台县',
            areaCode: '100006500230250000'
          },
          {
            id: 12408,
            parentId: 3824,
            areaName: '吉木萨尔县',
            areaPath: '中国,新疆维吾尔自治区,昌吉回族自治州,吉木萨尔县',
            areaCode: '100006500230270000'
          },
          {
            id: 12409,
            parentId: 3824,
            areaName: '木垒哈萨克自治县',
            areaPath: '中国,新疆维吾尔自治区,昌吉回族自治州,木垒哈萨克自治县',
            areaCode: '100006500230280000'
          }
        ]
      },
      {
        id: 3825,
        parentId: 1464,
        areaName: '博尔塔拉蒙古自治州',
        areaPath: '中国,新疆维吾尔自治区,博尔塔拉蒙古自治州',
        areaCode: '100006500270000000',
        children: [
          {
            id: 12410,
            parentId: 3825,
            areaName: '博乐市',
            areaPath: '中国,新疆维吾尔自治区,博尔塔拉蒙古自治州,博乐市',
            areaCode: '100006500270010000'
          },
          {
            id: 12411,
            parentId: 3825,
            areaName: '阿拉山口市',
            areaPath: '中国,新疆维吾尔自治区,博尔塔拉蒙古自治州,阿拉山口市',
            areaCode: '100006500270020000'
          },
          {
            id: 12412,
            parentId: 3825,
            areaName: '精河县',
            areaPath: '中国,新疆维吾尔自治区,博尔塔拉蒙古自治州,精河县',
            areaCode: '100006500270220000'
          },
          {
            id: 12413,
            parentId: 3825,
            areaName: '温泉县',
            areaPath: '中国,新疆维吾尔自治区,博尔塔拉蒙古自治州,温泉县',
            areaCode: '100006500270230000'
          }
        ]
      },
      {
        id: 3826,
        parentId: 1464,
        areaName: '巴音郭楞蒙古自治州',
        areaPath: '中国,新疆维吾尔自治区,巴音郭楞蒙古自治州',
        areaCode: '100006500280000000',
        children: [
          {
            id: 12414,
            parentId: 3826,
            areaName: '库尔勒市',
            areaPath: '中国,新疆维吾尔自治区,巴音郭楞蒙古自治州,库尔勒市',
            areaCode: '100006500280010000'
          },
          {
            id: 12415,
            parentId: 3826,
            areaName: '轮台县',
            areaPath: '中国,新疆维吾尔自治区,巴音郭楞蒙古自治州,轮台县',
            areaCode: '100006500280220000'
          },
          {
            id: 12416,
            parentId: 3826,
            areaName: '尉犁县',
            areaPath: '中国,新疆维吾尔自治区,巴音郭楞蒙古自治州,尉犁县',
            areaCode: '100006500280230000'
          },
          {
            id: 12417,
            parentId: 3826,
            areaName: '若羌县',
            areaPath: '中国,新疆维吾尔自治区,巴音郭楞蒙古自治州,若羌县',
            areaCode: '100006500280240000'
          },
          {
            id: 12418,
            parentId: 3826,
            areaName: '且末县',
            areaPath: '中国,新疆维吾尔自治区,巴音郭楞蒙古自治州,且末县',
            areaCode: '100006500280250000'
          },
          {
            id: 12419,
            parentId: 3826,
            areaName: '焉耆回族自治县',
            areaPath: '中国,新疆维吾尔自治区,巴音郭楞蒙古自治州,焉耆回族自治县',
            areaCode: '100006500280260000'
          },
          {
            id: 12420,
            parentId: 3826,
            areaName: '和静县',
            areaPath: '中国,新疆维吾尔自治区,巴音郭楞蒙古自治州,和静县',
            areaCode: '100006500280270000'
          },
          {
            id: 12421,
            parentId: 3826,
            areaName: '和硕县',
            areaPath: '中国,新疆维吾尔自治区,巴音郭楞蒙古自治州,和硕县',
            areaCode: '100006500280280000'
          },
          {
            id: 12422,
            parentId: 3826,
            areaName: '博湖县',
            areaPath: '中国,新疆维吾尔自治区,巴音郭楞蒙古自治州,博湖县',
            areaCode: '100006500280290000'
          }
        ]
      },
      {
        id: 3827,
        parentId: 1464,
        areaName: '阿克苏地区',
        areaPath: '中国,新疆维吾尔自治区,阿克苏地区',
        areaCode: '100006500290000000',
        children: [
          {
            id: 12423,
            parentId: 3827,
            areaName: '阿克苏市',
            areaPath: '中国,新疆维吾尔自治区,阿克苏地区,阿克苏市',
            areaCode: '100006500290010000'
          },
          {
            id: 12424,
            parentId: 3827,
            areaName: '温宿县',
            areaPath: '中国,新疆维吾尔自治区,阿克苏地区,温宿县',
            areaCode: '100006500290220000'
          },
          {
            id: 12425,
            parentId: 3827,
            areaName: '库车县',
            areaPath: '中国,新疆维吾尔自治区,阿克苏地区,库车县',
            areaCode: '100006500290230000'
          },
          {
            id: 12426,
            parentId: 3827,
            areaName: '沙雅县',
            areaPath: '中国,新疆维吾尔自治区,阿克苏地区,沙雅县',
            areaCode: '100006500290240000'
          },
          {
            id: 12427,
            parentId: 3827,
            areaName: '新和县',
            areaPath: '中国,新疆维吾尔自治区,阿克苏地区,新和县',
            areaCode: '100006500290250000'
          },
          {
            id: 12428,
            parentId: 3827,
            areaName: '拜城县',
            areaPath: '中国,新疆维吾尔自治区,阿克苏地区,拜城县',
            areaCode: '100006500290260000'
          },
          {
            id: 12429,
            parentId: 3827,
            areaName: '乌什县',
            areaPath: '中国,新疆维吾尔自治区,阿克苏地区,乌什县',
            areaCode: '100006500290270000'
          },
          {
            id: 12430,
            parentId: 3827,
            areaName: '阿瓦提县',
            areaPath: '中国,新疆维吾尔自治区,阿克苏地区,阿瓦提县',
            areaCode: '100006500290280000'
          },
          {
            id: 12431,
            parentId: 3827,
            areaName: '柯坪县',
            areaPath: '中国,新疆维吾尔自治区,阿克苏地区,柯坪县',
            areaCode: '100006500290290000'
          }
        ]
      },
      {
        id: 3828,
        parentId: 1464,
        areaName: '克孜勒苏柯尔克孜自治州',
        areaPath: '中国,新疆维吾尔自治区,克孜勒苏柯尔克孜自治州',
        areaCode: '100006500300000000',
        children: [
          {
            id: 12432,
            parentId: 3828,
            areaName: '阿图什市',
            areaPath: '中国,新疆维吾尔自治区,克孜勒苏柯尔克孜自治州,阿图什市',
            areaCode: '100006500300010000'
          },
          {
            id: 12433,
            parentId: 3828,
            areaName: '阿克陶县',
            areaPath: '中国,新疆维吾尔自治区,克孜勒苏柯尔克孜自治州,阿克陶县',
            areaCode: '100006500300220000'
          },
          {
            id: 12434,
            parentId: 3828,
            areaName: '阿合奇县',
            areaPath: '中国,新疆维吾尔自治区,克孜勒苏柯尔克孜自治州,阿合奇县',
            areaCode: '100006500300230000'
          },
          {
            id: 12435,
            parentId: 3828,
            areaName: '乌恰县',
            areaPath: '中国,新疆维吾尔自治区,克孜勒苏柯尔克孜自治州,乌恰县',
            areaCode: '100006500300240000'
          }
        ]
      },
      {
        id: 3829,
        parentId: 1464,
        areaName: '喀什地区',
        areaPath: '中国,新疆维吾尔自治区,喀什地区',
        areaCode: '100006500310000000',
        children: [
          {
            id: 12436,
            parentId: 3829,
            areaName: '喀什市',
            areaPath: '中国,新疆维吾尔自治区,喀什地区,喀什市',
            areaCode: '100006500310010000'
          },
          {
            id: 12437,
            parentId: 3829,
            areaName: '疏附县',
            areaPath: '中国,新疆维吾尔自治区,喀什地区,疏附县',
            areaCode: '100006500310210000'
          },
          {
            id: 12438,
            parentId: 3829,
            areaName: '疏勒县',
            areaPath: '中国,新疆维吾尔自治区,喀什地区,疏勒县',
            areaCode: '100006500310220000'
          },
          {
            id: 12439,
            parentId: 3829,
            areaName: '英吉沙县',
            areaPath: '中国,新疆维吾尔自治区,喀什地区,英吉沙县',
            areaCode: '100006500310230000'
          },
          {
            id: 12440,
            parentId: 3829,
            areaName: '泽普县',
            areaPath: '中国,新疆维吾尔自治区,喀什地区,泽普县',
            areaCode: '100006500310240000'
          },
          {
            id: 12441,
            parentId: 3829,
            areaName: '莎车县',
            areaPath: '中国,新疆维吾尔自治区,喀什地区,莎车县',
            areaCode: '100006500310250000'
          },
          {
            id: 12442,
            parentId: 3829,
            areaName: '叶城县',
            areaPath: '中国,新疆维吾尔自治区,喀什地区,叶城县',
            areaCode: '100006500310260000'
          },
          {
            id: 12443,
            parentId: 3829,
            areaName: '麦盖提县',
            areaPath: '中国,新疆维吾尔自治区,喀什地区,麦盖提县',
            areaCode: '100006500310270000'
          },
          {
            id: 12444,
            parentId: 3829,
            areaName: '岳普湖县',
            areaPath: '中国,新疆维吾尔自治区,喀什地区,岳普湖县',
            areaCode: '100006500310280000'
          },
          {
            id: 12445,
            parentId: 3829,
            areaName: '伽师县',
            areaPath: '中国,新疆维吾尔自治区,喀什地区,伽师县',
            areaCode: '100006500310290000'
          },
          {
            id: 12446,
            parentId: 3829,
            areaName: '巴楚县',
            areaPath: '中国,新疆维吾尔自治区,喀什地区,巴楚县',
            areaCode: '100006500310300000'
          },
          {
            id: 12447,
            parentId: 3829,
            areaName: '塔什库尔干塔吉克自治县',
            areaPath: '中国,新疆维吾尔自治区,喀什地区,塔什库尔干塔吉克自治县',
            areaCode: '100006500310310000'
          }
        ]
      },
      {
        id: 3830,
        parentId: 1464,
        areaName: '和田地区',
        areaPath: '中国,新疆维吾尔自治区,和田地区',
        areaCode: '100006500320000000',
        children: [
          {
            id: 12448,
            parentId: 3830,
            areaName: '和田市',
            areaPath: '中国,新疆维吾尔自治区,和田地区,和田市',
            areaCode: '100006500320010000'
          },
          {
            id: 12449,
            parentId: 3830,
            areaName: '和田县',
            areaPath: '中国,新疆维吾尔自治区,和田地区,和田县',
            areaCode: '100006500320210000'
          },
          {
            id: 12450,
            parentId: 3830,
            areaName: '墨玉县',
            areaPath: '中国,新疆维吾尔自治区,和田地区,墨玉县',
            areaCode: '100006500320220000'
          },
          {
            id: 12451,
            parentId: 3830,
            areaName: '皮山县',
            areaPath: '中国,新疆维吾尔自治区,和田地区,皮山县',
            areaCode: '100006500320230000'
          },
          {
            id: 12452,
            parentId: 3830,
            areaName: '洛浦县',
            areaPath: '中国,新疆维吾尔自治区,和田地区,洛浦县',
            areaCode: '100006500320240000'
          },
          {
            id: 12453,
            parentId: 3830,
            areaName: '策勒县',
            areaPath: '中国,新疆维吾尔自治区,和田地区,策勒县',
            areaCode: '100006500320250000'
          },
          {
            id: 12454,
            parentId: 3830,
            areaName: '于田县',
            areaPath: '中国,新疆维吾尔自治区,和田地区,于田县',
            areaCode: '100006500320260000'
          },
          {
            id: 12455,
            parentId: 3830,
            areaName: '民丰县',
            areaPath: '中国,新疆维吾尔自治区,和田地区,民丰县',
            areaCode: '100006500320270000'
          }
        ]
      },
      {
        id: 3831,
        parentId: 1464,
        areaName: '伊犁哈萨克自治州',
        areaPath: '中国,新疆维吾尔自治区,伊犁哈萨克自治州',
        areaCode: '100006500400000000',
        children: [
          {
            id: 12456,
            parentId: 3831,
            areaName: '伊宁市',
            areaPath: '中国,新疆维吾尔自治区,伊犁哈萨克自治州,伊宁市',
            areaCode: '100006500400020000'
          },
          {
            id: 12457,
            parentId: 3831,
            areaName: '奎屯市',
            areaPath: '中国,新疆维吾尔自治区,伊犁哈萨克自治州,奎屯市',
            areaCode: '100006500400030000'
          },
          {
            id: 12458,
            parentId: 3831,
            areaName: '霍尔果斯市',
            areaPath: '中国,新疆维吾尔自治区,伊犁哈萨克自治州,霍尔果斯市',
            areaCode: '100006500400040000'
          },
          {
            id: 12459,
            parentId: 3831,
            areaName: '伊宁县',
            areaPath: '中国,新疆维吾尔自治区,伊犁哈萨克自治州,伊宁县',
            areaCode: '100006500400210000'
          },
          {
            id: 12460,
            parentId: 3831,
            areaName: '察布查尔锡伯自治县',
            areaPath:
              '中国,新疆维吾尔自治区,伊犁哈萨克自治州,察布查尔锡伯自治县',
            areaCode: '100006500400220000'
          },
          {
            id: 12461,
            parentId: 3831,
            areaName: '霍城县',
            areaPath: '中国,新疆维吾尔自治区,伊犁哈萨克自治州,霍城县',
            areaCode: '100006500400230000'
          },
          {
            id: 12462,
            parentId: 3831,
            areaName: '巩留县',
            areaPath: '中国,新疆维吾尔自治区,伊犁哈萨克自治州,巩留县',
            areaCode: '100006500400240000'
          },
          {
            id: 12463,
            parentId: 3831,
            areaName: '新源县',
            areaPath: '中国,新疆维吾尔自治区,伊犁哈萨克自治州,新源县',
            areaCode: '100006500400250000'
          },
          {
            id: 12464,
            parentId: 3831,
            areaName: '昭苏县',
            areaPath: '中国,新疆维吾尔自治区,伊犁哈萨克自治州,昭苏县',
            areaCode: '100006500400260000'
          },
          {
            id: 12465,
            parentId: 3831,
            areaName: '特克斯县',
            areaPath: '中国,新疆维吾尔自治区,伊犁哈萨克自治州,特克斯县',
            areaCode: '100006500400270000'
          },
          {
            id: 12466,
            parentId: 3831,
            areaName: '尼勒克县',
            areaPath: '中国,新疆维吾尔自治区,伊犁哈萨克自治州,尼勒克县',
            areaCode: '100006500400280000'
          }
        ]
      },
      {
        id: 3832,
        parentId: 1464,
        areaName: '塔城地区',
        areaPath: '中国,新疆维吾尔自治区,塔城地区',
        areaCode: '100006500420000000',
        children: [
          {
            id: 12467,
            parentId: 3832,
            areaName: '塔城市',
            areaPath: '中国,新疆维吾尔自治区,塔城地区,塔城市',
            areaCode: '100006500420010000'
          },
          {
            id: 12468,
            parentId: 3832,
            areaName: '乌苏市',
            areaPath: '中国,新疆维吾尔自治区,塔城地区,乌苏市',
            areaCode: '100006500420020000'
          },
          {
            id: 12469,
            parentId: 3832,
            areaName: '额敏县',
            areaPath: '中国,新疆维吾尔自治区,塔城地区,额敏县',
            areaCode: '100006500420210000'
          },
          {
            id: 12470,
            parentId: 3832,
            areaName: '沙湾县',
            areaPath: '中国,新疆维吾尔自治区,塔城地区,沙湾县',
            areaCode: '100006500420230000'
          },
          {
            id: 12471,
            parentId: 3832,
            areaName: '托里县',
            areaPath: '中国,新疆维吾尔自治区,塔城地区,托里县',
            areaCode: '100006500420240000'
          },
          {
            id: 12472,
            parentId: 3832,
            areaName: '裕民县',
            areaPath: '中国,新疆维吾尔自治区,塔城地区,裕民县',
            areaCode: '100006500420250000'
          },
          {
            id: 12473,
            parentId: 3832,
            areaName: '和布克赛尔蒙古自治县',
            areaPath: '中国,新疆维吾尔自治区,塔城地区,和布克赛尔蒙古自治县',
            areaCode: '100006500420260000'
          }
        ]
      },
      {
        id: 3833,
        parentId: 1464,
        areaName: '阿勒泰地区',
        areaPath: '中国,新疆维吾尔自治区,阿勒泰地区',
        areaCode: '100006500430000000',
        children: [
          {
            id: 12474,
            parentId: 3833,
            areaName: '阿勒泰市',
            areaPath: '中国,新疆维吾尔自治区,阿勒泰地区,阿勒泰市',
            areaCode: '100006500430010000'
          },
          {
            id: 12475,
            parentId: 3833,
            areaName: '布尔津县',
            areaPath: '中国,新疆维吾尔自治区,阿勒泰地区,布尔津县',
            areaCode: '100006500430210000'
          },
          {
            id: 12476,
            parentId: 3833,
            areaName: '富蕴县',
            areaPath: '中国,新疆维吾尔自治区,阿勒泰地区,富蕴县',
            areaCode: '100006500430220000'
          },
          {
            id: 12477,
            parentId: 3833,
            areaName: '福海县',
            areaPath: '中国,新疆维吾尔自治区,阿勒泰地区,福海县',
            areaCode: '100006500430230000'
          },
          {
            id: 12478,
            parentId: 3833,
            areaName: '哈巴河县',
            areaPath: '中国,新疆维吾尔自治区,阿勒泰地区,哈巴河县',
            areaCode: '100006500430240000'
          },
          {
            id: 12479,
            parentId: 3833,
            areaName: '青河县',
            areaPath: '中国,新疆维吾尔自治区,阿勒泰地区,青河县',
            areaCode: '100006500430250000'
          },
          {
            id: 12480,
            parentId: 3833,
            areaName: '吉木乃县',
            areaPath: '中国,新疆维吾尔自治区,阿勒泰地区,吉木乃县',
            areaCode: '100006500430260000'
          }
        ]
      },
      {
        id: 12676,
        parentId: 1464,
        areaName: '自治区直辖县级行政区划',
        areaPath: '中国,新疆维吾尔自治区,自治区直辖县级行政区划',
        areaCode: '100006500900000000',
        children: [
          {
            id: 3834,
            parentId: 12676,
            areaName: '石河子市',
            areaPath: '中国,新疆维吾尔自治区,自治区直辖县级行政区划,石河子市',
            areaCode: '100006500900010000'
          },
          {
            id: 3835,
            parentId: 12676,
            areaName: '阿拉尔市',
            areaPath: '中国,新疆维吾尔自治区,自治区直辖县级行政区划,阿拉尔市',
            areaCode: '100006500900020000'
          },
          {
            id: 3836,
            parentId: 12676,
            areaName: '图木舒克市',
            areaPath: '中国,新疆维吾尔自治区,自治区直辖县级行政区划,图木舒克市',
            areaCode: '100006500900030000'
          },
          {
            id: 3837,
            parentId: 12676,
            areaName: '五家渠市',
            areaPath: '中国,新疆维吾尔自治区,自治区直辖县级行政区划,五家渠市',
            areaCode: '100006500900040000'
          },
          {
            id: 3838,
            parentId: 12676,
            areaName: '北屯市',
            areaPath: '中国,新疆维吾尔自治区,自治区直辖县级行政区划,北屯市',
            areaCode: '100006500900050000'
          },
          {
            id: 3839,
            parentId: 12676,
            areaName: '铁门关市',
            areaPath: '中国,新疆维吾尔自治区,自治区直辖县级行政区划,铁门关市',
            areaCode: '100006500900060000'
          }
        ]
      }
    ]
  },
  {
    id: 1465,
    parentId: 1,
    areaName: '台湾',
    areaPath: '中国,台湾',
    areaCode: '100007100000000000',
    children: [
      {
        id: 3843,
        parentId: 1465,
        areaName: '台北市',
        areaPath: '中国,台湾,台北市',
        areaCode: '100007100010000000',
        children: [
          {
            id: 12490,
            parentId: 3843,
            areaName: '中正区',
            areaPath: '中国,台湾,台北市,中正区',
            areaCode: '100007100010010000'
          },
          {
            id: 12491,
            parentId: 3843,
            areaName: '大同区',
            areaPath: '中国,台湾,台北市,大同区',
            areaCode: '100007100010020000'
          },
          {
            id: 12492,
            parentId: 3843,
            areaName: '中山区',
            areaPath: '中国,台湾,台北市,中山区',
            areaCode: '100007100010030000'
          },
          {
            id: 12493,
            parentId: 3843,
            areaName: '万华区',
            areaPath: '中国,台湾,台北市,万华区',
            areaCode: '100007100010040000'
          },
          {
            id: 12494,
            parentId: 3843,
            areaName: '信义区',
            areaPath: '中国,台湾,台北市,信义区',
            areaCode: '100007100010050000'
          },
          {
            id: 12495,
            parentId: 3843,
            areaName: '松山区',
            areaPath: '中国,台湾,台北市,松山区',
            areaCode: '100007100010060000'
          },
          {
            id: 12496,
            parentId: 3843,
            areaName: '大安区',
            areaPath: '中国,台湾,台北市,大安区',
            areaCode: '100007100010070000'
          },
          {
            id: 12497,
            parentId: 3843,
            areaName: '南港区',
            areaPath: '中国,台湾,台北市,南港区',
            areaCode: '100007100010080000'
          },
          {
            id: 12498,
            parentId: 3843,
            areaName: '北投区',
            areaPath: '中国,台湾,台北市,北投区',
            areaCode: '100007100010090000'
          },
          {
            id: 12499,
            parentId: 3843,
            areaName: '内湖区',
            areaPath: '中国,台湾,台北市,内湖区',
            areaCode: '100007100010100000'
          },
          {
            id: 12500,
            parentId: 3843,
            areaName: '士林区',
            areaPath: '中国,台湾,台北市,士林区',
            areaCode: '100007100010110000'
          },
          {
            id: 12501,
            parentId: 3843,
            areaName: '文山区',
            areaPath: '中国,台湾,台北市,文山区',
            areaCode: '100007100010120000'
          }
        ]
      },
      {
        id: 3844,
        parentId: 1465,
        areaName: '高雄市',
        areaPath: '中国,台湾,高雄市',
        areaCode: '100007100060000000',
        children: [
          {
            id: 12502,
            parentId: 3844,
            areaName: '楠梓区',
            areaPath: '中国,台湾,高雄市,楠梓区',
            areaCode: '100007100060010000'
          },
          {
            id: 12503,
            parentId: 3844,
            areaName: '左营区',
            areaPath: '中国,台湾,高雄市,左营区',
            areaCode: '100007100060020000'
          },
          {
            id: 12504,
            parentId: 3844,
            areaName: '鼓山区',
            areaPath: '中国,台湾,高雄市,鼓山区',
            areaCode: '100007100060030000'
          },
          {
            id: 12505,
            parentId: 3844,
            areaName: '三民区',
            areaPath: '中国,台湾,高雄市,三民区',
            areaCode: '100007100060040000'
          },
          {
            id: 12506,
            parentId: 3844,
            areaName: '盐埕区',
            areaPath: '中国,台湾,高雄市,盐埕区',
            areaCode: '100007100060050000'
          },
          {
            id: 12507,
            parentId: 3844,
            areaName: '前金区',
            areaPath: '中国,台湾,高雄市,前金区',
            areaCode: '100007100060060000'
          },
          {
            id: 12508,
            parentId: 3844,
            areaName: '新兴区',
            areaPath: '中国,台湾,高雄市,新兴区',
            areaCode: '100007100060070000'
          },
          {
            id: 12509,
            parentId: 3844,
            areaName: '苓雅区',
            areaPath: '中国,台湾,高雄市,苓雅区',
            areaCode: '100007100060080000'
          },
          {
            id: 12510,
            parentId: 3844,
            areaName: '前镇区',
            areaPath: '中国,台湾,高雄市,前镇区',
            areaCode: '100007100060090000'
          },
          {
            id: 12511,
            parentId: 3844,
            areaName: '旗津区',
            areaPath: '中国,台湾,高雄市,旗津区',
            areaCode: '100007100060100000'
          },
          {
            id: 12512,
            parentId: 3844,
            areaName: '小港区',
            areaPath: '中国,台湾,高雄市,小港区',
            areaCode: '100007100060110000'
          },
          {
            id: 12513,
            parentId: 3844,
            areaName: '凤山区',
            areaPath: '中国,台湾,高雄市,凤山区',
            areaCode: '100007100060120000'
          },
          {
            id: 12514,
            parentId: 3844,
            areaName: '大寮区',
            areaPath: '中国,台湾,高雄市,大寮区',
            areaCode: '100007100060130000'
          },
          {
            id: 12515,
            parentId: 3844,
            areaName: '鸟松区',
            areaPath: '中国,台湾,高雄市,鸟松区',
            areaCode: '100007100060140000'
          },
          {
            id: 12516,
            parentId: 3844,
            areaName: '林园区',
            areaPath: '中国,台湾,高雄市,林园区',
            areaCode: '100007100060150000'
          },
          {
            id: 12517,
            parentId: 3844,
            areaName: '仁武区',
            areaPath: '中国,台湾,高雄市,仁武区',
            areaCode: '100007100060160000'
          },
          {
            id: 12518,
            parentId: 3844,
            areaName: '大树区',
            areaPath: '中国,台湾,高雄市,大树区',
            areaCode: '100007100060170000'
          },
          {
            id: 12519,
            parentId: 3844,
            areaName: '大社区',
            areaPath: '中国,台湾,高雄市,大社区',
            areaCode: '100007100060180000'
          },
          {
            id: 12520,
            parentId: 3844,
            areaName: '冈山区',
            areaPath: '中国,台湾,高雄市,冈山区',
            areaCode: '100007100060190000'
          },
          {
            id: 12521,
            parentId: 3844,
            areaName: '路竹区',
            areaPath: '中国,台湾,高雄市,路竹区',
            areaCode: '100007100060200000'
          },
          {
            id: 12522,
            parentId: 3844,
            areaName: '桥头区',
            areaPath: '中国,台湾,高雄市,桥头区',
            areaCode: '100007100060210000'
          },
          {
            id: 12523,
            parentId: 3844,
            areaName: '梓官区',
            areaPath: '中国,台湾,高雄市,梓官区',
            areaCode: '100007100060220000'
          },
          {
            id: 12524,
            parentId: 3844,
            areaName: '弥陀区',
            areaPath: '中国,台湾,高雄市,弥陀区',
            areaCode: '100007100060230000'
          },
          {
            id: 12525,
            parentId: 3844,
            areaName: '永安区',
            areaPath: '中国,台湾,高雄市,永安区',
            areaCode: '100007100060240000'
          },
          {
            id: 12526,
            parentId: 3844,
            areaName: '燕巢区',
            areaPath: '中国,台湾,高雄市,燕巢区',
            areaCode: '100007100060250000'
          },
          {
            id: 12527,
            parentId: 3844,
            areaName: '阿莲区',
            areaPath: '中国,台湾,高雄市,阿莲区',
            areaCode: '100007100060260000'
          },
          {
            id: 12528,
            parentId: 3844,
            areaName: '茄萣区',
            areaPath: '中国,台湾,高雄市,茄萣区',
            areaCode: '100007100060270000'
          },
          {
            id: 12529,
            parentId: 3844,
            areaName: '湖内区',
            areaPath: '中国,台湾,高雄市,湖内区',
            areaCode: '100007100060280000'
          },
          {
            id: 12530,
            parentId: 3844,
            areaName: '旗山区',
            areaPath: '中国,台湾,高雄市,旗山区',
            areaCode: '100007100060290000'
          },
          {
            id: 12531,
            parentId: 3844,
            areaName: '美浓区',
            areaPath: '中国,台湾,高雄市,美浓区',
            areaCode: '100007100060300000'
          },
          {
            id: 12532,
            parentId: 3844,
            areaName: '内门区',
            areaPath: '中国,台湾,高雄市,内门区',
            areaCode: '100007100060310000'
          },
          {
            id: 12533,
            parentId: 3844,
            areaName: '杉林区',
            areaPath: '中国,台湾,高雄市,杉林区',
            areaCode: '100007100060320000'
          },
          {
            id: 12534,
            parentId: 3844,
            areaName: '甲仙区',
            areaPath: '中国,台湾,高雄市,甲仙区',
            areaCode: '100007100060330000'
          },
          {
            id: 12535,
            parentId: 3844,
            areaName: '六龟区',
            areaPath: '中国,台湾,高雄市,六龟区',
            areaCode: '100007100060340000'
          },
          {
            id: 12536,
            parentId: 3844,
            areaName: '茂林区',
            areaPath: '中国,台湾,高雄市,茂林区',
            areaCode: '100007100060350000'
          },
          {
            id: 12537,
            parentId: 3844,
            areaName: '桃源区',
            areaPath: '中国,台湾,高雄市,桃源区',
            areaCode: '100007100060360000'
          },
          {
            id: 12538,
            parentId: 3844,
            areaName: '那玛夏区',
            areaPath: '中国,台湾,高雄市,那玛夏区',
            areaCode: '100007100060370000'
          }
        ]
      },
      {
        id: 3845,
        parentId: 1465,
        areaName: '基隆市',
        areaPath: '中国,台湾,基隆市',
        areaCode: '100007100070000000',
        children: [
          {
            id: 12539,
            parentId: 3845,
            areaName: '中正区',
            areaPath: '中国,台湾,基隆市,中正区',
            areaCode: '100007100070010000'
          },
          {
            id: 12540,
            parentId: 3845,
            areaName: '七堵区',
            areaPath: '中国,台湾,基隆市,七堵区',
            areaCode: '100007100070020000'
          },
          {
            id: 12541,
            parentId: 3845,
            areaName: '暖暖区',
            areaPath: '中国,台湾,基隆市,暖暖区',
            areaCode: '100007100070030000'
          },
          {
            id: 12542,
            parentId: 3845,
            areaName: '仁爱区',
            areaPath: '中国,台湾,基隆市,仁爱区',
            areaCode: '100007100070040000'
          },
          {
            id: 12543,
            parentId: 3845,
            areaName: '中山区',
            areaPath: '中国,台湾,基隆市,中山区',
            areaCode: '100007100070050000'
          },
          {
            id: 12544,
            parentId: 3845,
            areaName: '安乐区',
            areaPath: '中国,台湾,基隆市,安乐区',
            areaCode: '100007100070060000'
          },
          {
            id: 12545,
            parentId: 3845,
            areaName: '信义区',
            areaPath: '中国,台湾,基隆市,信义区',
            areaCode: '100007100070070000'
          }
        ]
      },
      {
        id: 3846,
        parentId: 1465,
        areaName: '台中市',
        areaPath: '中国,台湾,台中市',
        areaCode: '100007100040000000',
        children: [
          {
            id: 12546,
            parentId: 3846,
            areaName: '中区',
            areaPath: '中国,台湾,台中市,中区',
            areaCode: '100007100040010000'
          },
          {
            id: 12547,
            parentId: 3846,
            areaName: '东区',
            areaPath: '中国,台湾,台中市,东区',
            areaCode: '100007100040020000'
          },
          {
            id: 12548,
            parentId: 3846,
            areaName: '西区',
            areaPath: '中国,台湾,台中市,西区',
            areaCode: '100007100040030000'
          },
          {
            id: 12549,
            parentId: 3846,
            areaName: '南区',
            areaPath: '中国,台湾,台中市,南区',
            areaCode: '100007100040040000'
          },
          {
            id: 12550,
            parentId: 3846,
            areaName: '北区',
            areaPath: '中国,台湾,台中市,北区',
            areaCode: '100007100040050000'
          },
          {
            id: 12551,
            parentId: 3846,
            areaName: '西屯区',
            areaPath: '中国,台湾,台中市,西屯区',
            areaCode: '100007100040060000'
          },
          {
            id: 12552,
            parentId: 3846,
            areaName: '南屯区',
            areaPath: '中国,台湾,台中市,南屯区',
            areaCode: '100007100040070000'
          },
          {
            id: 12553,
            parentId: 3846,
            areaName: '北屯区',
            areaPath: '中国,台湾,台中市,北屯区',
            areaCode: '100007100040080000'
          },
          {
            id: 12554,
            parentId: 3846,
            areaName: '丰原区',
            areaPath: '中国,台湾,台中市,丰原区',
            areaCode: '100007100040090000'
          },
          {
            id: 12555,
            parentId: 3846,
            areaName: '大里区',
            areaPath: '中国,台湾,台中市,大里区',
            areaCode: '100007100040100000'
          },
          {
            id: 12556,
            parentId: 3846,
            areaName: '太平区',
            areaPath: '中国,台湾,台中市,太平区',
            areaCode: '100007100040110000'
          },
          {
            id: 12557,
            parentId: 3846,
            areaName: '东势区',
            areaPath: '中国,台湾,台中市,东势区',
            areaCode: '100007100040120000'
          },
          {
            id: 12558,
            parentId: 3846,
            areaName: '大甲区',
            areaPath: '中国,台湾,台中市,大甲区',
            areaCode: '100007100040130000'
          },
          {
            id: 12559,
            parentId: 3846,
            areaName: '清水区',
            areaPath: '中国,台湾,台中市,清水区',
            areaCode: '100007100040140000'
          },
          {
            id: 12560,
            parentId: 3846,
            areaName: '沙鹿区',
            areaPath: '中国,台湾,台中市,沙鹿区',
            areaCode: '100007100040150000'
          },
          {
            id: 12561,
            parentId: 3846,
            areaName: '梧栖区',
            areaPath: '中国,台湾,台中市,梧栖区',
            areaCode: '100007100040160000'
          },
          {
            id: 12562,
            parentId: 3846,
            areaName: '后里区',
            areaPath: '中国,台湾,台中市,后里区',
            areaCode: '100007100040170000'
          },
          {
            id: 12563,
            parentId: 3846,
            areaName: '神冈区',
            areaPath: '中国,台湾,台中市,神冈区',
            areaCode: '100007100040180000'
          },
          {
            id: 12564,
            parentId: 3846,
            areaName: '潭子区',
            areaPath: '中国,台湾,台中市,潭子区',
            areaCode: '100007100040190000'
          },
          {
            id: 12565,
            parentId: 3846,
            areaName: '大雅区',
            areaPath: '中国,台湾,台中市,大雅区',
            areaCode: '100007100040200000'
          },
          {
            id: 12566,
            parentId: 3846,
            areaName: '新小区',
            areaPath: '中国,台湾,台中市,新小区',
            areaCode: '100007100040210000'
          },
          {
            id: 12567,
            parentId: 3846,
            areaName: '石冈区',
            areaPath: '中国,台湾,台中市,石冈区',
            areaCode: '100007100040220000'
          },
          {
            id: 12568,
            parentId: 3846,
            areaName: '外埔区',
            areaPath: '中国,台湾,台中市,外埔区',
            areaCode: '100007100040230000'
          },
          {
            id: 12569,
            parentId: 3846,
            areaName: '大安区',
            areaPath: '中国,台湾,台中市,大安区',
            areaCode: '100007100040240000'
          },
          {
            id: 12570,
            parentId: 3846,
            areaName: '乌日区',
            areaPath: '中国,台湾,台中市,乌日区',
            areaCode: '100007100040250000'
          },
          {
            id: 12571,
            parentId: 3846,
            areaName: '大肚区',
            areaPath: '中国,台湾,台中市,大肚区',
            areaCode: '100007100040260000'
          },
          {
            id: 12572,
            parentId: 3846,
            areaName: '龙井区',
            areaPath: '中国,台湾,台中市,龙井区',
            areaCode: '100007100040270000'
          },
          {
            id: 12573,
            parentId: 3846,
            areaName: '雾峰区',
            areaPath: '中国,台湾,台中市,雾峰区',
            areaCode: '100007100040280000'
          },
          {
            id: 12574,
            parentId: 3846,
            areaName: '和平区',
            areaPath: '中国,台湾,台中市,和平区',
            areaCode: '100007100040290000'
          }
        ]
      },
      {
        id: 3847,
        parentId: 1465,
        areaName: '台南市',
        areaPath: '中国,台湾,台南市',
        areaCode: '100007100050000000',
        children: [
          {
            id: 12575,
            parentId: 3847,
            areaName: '中西区',
            areaPath: '中国,台湾,台南市,中西区',
            areaCode: '100007100050010000'
          },
          {
            id: 12576,
            parentId: 3847,
            areaName: '东区',
            areaPath: '中国,台湾,台南市,东区',
            areaCode: '100007100050020000'
          },
          {
            id: 12577,
            parentId: 3847,
            areaName: '南区',
            areaPath: '中国,台湾,台南市,南区',
            areaCode: '100007100050030000'
          },
          {
            id: 12578,
            parentId: 3847,
            areaName: '北区',
            areaPath: '中国,台湾,台南市,北区',
            areaCode: '100007100050040000'
          },
          {
            id: 12579,
            parentId: 3847,
            areaName: '安平区',
            areaPath: '中国,台湾,台南市,安平区',
            areaCode: '100007100050050000'
          },
          {
            id: 12580,
            parentId: 3847,
            areaName: '安南区',
            areaPath: '中国,台湾,台南市,安南区',
            areaCode: '100007100050060000'
          },
          {
            id: 12581,
            parentId: 3847,
            areaName: '永康区',
            areaPath: '中国,台湾,台南市,永康区',
            areaCode: '100007100050070000'
          },
          {
            id: 12582,
            parentId: 3847,
            areaName: '归仁区',
            areaPath: '中国,台湾,台南市,归仁区',
            areaCode: '100007100050080000'
          },
          {
            id: 12583,
            parentId: 3847,
            areaName: '新化区',
            areaPath: '中国,台湾,台南市,新化区',
            areaCode: '100007100050090000'
          },
          {
            id: 12584,
            parentId: 3847,
            areaName: '左镇区',
            areaPath: '中国,台湾,台南市,左镇区',
            areaCode: '100007100050100000'
          },
          {
            id: 12585,
            parentId: 3847,
            areaName: '玉井区',
            areaPath: '中国,台湾,台南市,玉井区',
            areaCode: '100007100050110000'
          },
          {
            id: 12586,
            parentId: 3847,
            areaName: '楠西区',
            areaPath: '中国,台湾,台南市,楠西区',
            areaCode: '100007100050120000'
          },
          {
            id: 12587,
            parentId: 3847,
            areaName: '南化区',
            areaPath: '中国,台湾,台南市,南化区',
            areaCode: '100007100050130000'
          },
          {
            id: 12588,
            parentId: 3847,
            areaName: '仁德区',
            areaPath: '中国,台湾,台南市,仁德区',
            areaCode: '100007100050140000'
          },
          {
            id: 12589,
            parentId: 3847,
            areaName: '关庙区',
            areaPath: '中国,台湾,台南市,关庙区',
            areaCode: '100007100050150000'
          },
          {
            id: 12590,
            parentId: 3847,
            areaName: '龙崎区',
            areaPath: '中国,台湾,台南市,龙崎区',
            areaCode: '100007100050160000'
          },
          {
            id: 12591,
            parentId: 3847,
            areaName: '官田区',
            areaPath: '中国,台湾,台南市,官田区',
            areaCode: '100007100050170000'
          },
          {
            id: 12592,
            parentId: 3847,
            areaName: '麻豆区',
            areaPath: '中国,台湾,台南市,麻豆区',
            areaCode: '100007100050180000'
          },
          {
            id: 12593,
            parentId: 3847,
            areaName: '佳里区',
            areaPath: '中国,台湾,台南市,佳里区',
            areaCode: '100007100050190000'
          },
          {
            id: 12594,
            parentId: 3847,
            areaName: '西港区',
            areaPath: '中国,台湾,台南市,西港区',
            areaCode: '100007100050200000'
          },
          {
            id: 12595,
            parentId: 3847,
            areaName: '七股区',
            areaPath: '中国,台湾,台南市,七股区',
            areaCode: '100007100050210000'
          },
          {
            id: 12596,
            parentId: 3847,
            areaName: '将军区',
            areaPath: '中国,台湾,台南市,将军区',
            areaCode: '100007100050220000'
          },
          {
            id: 12597,
            parentId: 3847,
            areaName: '学甲区',
            areaPath: '中国,台湾,台南市,学甲区',
            areaCode: '100007100050230000'
          },
          {
            id: 12598,
            parentId: 3847,
            areaName: '北门区',
            areaPath: '中国,台湾,台南市,北门区',
            areaCode: '100007100050240000'
          },
          {
            id: 12599,
            parentId: 3847,
            areaName: '新营区',
            areaPath: '中国,台湾,台南市,新营区',
            areaCode: '100007100050250000'
          },
          {
            id: 12600,
            parentId: 3847,
            areaName: '后壁区',
            areaPath: '中国,台湾,台南市,后壁区',
            areaCode: '100007100050260000'
          },
          {
            id: 12601,
            parentId: 3847,
            areaName: '白河区',
            areaPath: '中国,台湾,台南市,白河区',
            areaCode: '100007100050270000'
          },
          {
            id: 12602,
            parentId: 3847,
            areaName: '东山区',
            areaPath: '中国,台湾,台南市,东山区',
            areaCode: '100007100050280000'
          },
          {
            id: 12603,
            parentId: 3847,
            areaName: '六甲区',
            areaPath: '中国,台湾,台南市,六甲区',
            areaCode: '100007100050290000'
          },
          {
            id: 12604,
            parentId: 3847,
            areaName: '下营区',
            areaPath: '中国,台湾,台南市,下营区',
            areaCode: '100007100050300000'
          },
          {
            id: 12605,
            parentId: 3847,
            areaName: '柳营区',
            areaPath: '中国,台湾,台南市,柳营区',
            areaCode: '100007100050310000'
          },
          {
            id: 12606,
            parentId: 3847,
            areaName: '盐水区',
            areaPath: '中国,台湾,台南市,盐水区',
            areaCode: '100007100050320000'
          },
          {
            id: 12607,
            parentId: 3847,
            areaName: '善化区',
            areaPath: '中国,台湾,台南市,善化区',
            areaCode: '100007100050330000'
          },
          {
            id: 12608,
            parentId: 3847,
            areaName: '大内区',
            areaPath: '中国,台湾,台南市,大内区',
            areaCode: '100007100050340000'
          },
          {
            id: 12609,
            parentId: 3847,
            areaName: '山上区',
            areaPath: '中国,台湾,台南市,山上区',
            areaCode: '100007100050350000'
          },
          {
            id: 12610,
            parentId: 3847,
            areaName: '新市区',
            areaPath: '中国,台湾,台南市,新市区',
            areaCode: '100007100050360000'
          },
          {
            id: 12611,
            parentId: 3847,
            areaName: '安定区',
            areaPath: '中国,台湾,台南市,安定区',
            areaCode: '100007100050370000'
          }
        ]
      },
      {
        id: 3848,
        parentId: 1465,
        areaName: '新竹市',
        areaPath: '中国,台湾,新竹市',
        areaCode: '100007100080000000',
        children: [
          {
            id: 12612,
            parentId: 3848,
            areaName: '东区',
            areaPath: '中国,台湾,新竹市,东区',
            areaCode: '100007100080010000'
          },
          {
            id: 12613,
            parentId: 3848,
            areaName: '北区',
            areaPath: '中国,台湾,新竹市,北区',
            areaCode: '100007100080020000'
          },
          {
            id: 12614,
            parentId: 3848,
            areaName: '香山区',
            areaPath: '中国,台湾,新竹市,香山区',
            areaCode: '100007100080030000'
          }
        ]
      },
      {
        id: 3849,
        parentId: 1465,
        areaName: '嘉义市',
        areaPath: '中国,台湾,嘉义市',
        areaCode: '100007100090000000',
        children: [
          {
            id: 12615,
            parentId: 3849,
            areaName: '东区',
            areaPath: '中国,台湾,嘉义市,东区',
            areaCode: '100007100090010000'
          },
          {
            id: 12616,
            parentId: 3849,
            areaName: '西区',
            areaPath: '中国,台湾,嘉义市,西区',
            areaCode: '100007100090020000'
          }
        ]
      },
      {
        id: 3850,
        parentId: 1465,
        areaName: '新北市',
        areaPath: '中国,台湾,新北市',
        areaCode: '100007100020000000',
        children: [
          {
            id: 12630,
            parentId: 3850,
            areaName: '板桥区',
            areaPath: '中国,台湾,新北市,板桥区',
            areaCode: '100007100020010000'
          },
          {
            id: 12631,
            parentId: 3850,
            areaName: '土城区',
            areaPath: '中国,台湾,新北市,土城区',
            areaCode: '100007100020020000'
          },
          {
            id: 12632,
            parentId: 3850,
            areaName: '新庄区',
            areaPath: '中国,台湾,新北市,新庄区',
            areaCode: '100007100020030000'
          },
          {
            id: 12633,
            parentId: 3850,
            areaName: '新店区',
            areaPath: '中国,台湾,新北市,新店区',
            areaCode: '100007100020040000'
          },
          {
            id: 12634,
            parentId: 3850,
            areaName: '深坑区',
            areaPath: '中国,台湾,新北市,深坑区',
            areaCode: '100007100020050000'
          },
          {
            id: 12635,
            parentId: 3850,
            areaName: '石碇区',
            areaPath: '中国,台湾,新北市,石碇区',
            areaCode: '100007100020060000'
          },
          {
            id: 12636,
            parentId: 3850,
            areaName: '坪林区',
            areaPath: '中国,台湾,新北市,坪林区',
            areaCode: '100007100020070000'
          },
          {
            id: 12637,
            parentId: 3850,
            areaName: '乌来区',
            areaPath: '中国,台湾,新北市,乌来区',
            areaCode: '100007100020080000'
          },
          {
            id: 12638,
            parentId: 3850,
            areaName: '五股区',
            areaPath: '中国,台湾,新北市,五股区',
            areaCode: '100007100020090000'
          },
          {
            id: 12639,
            parentId: 3850,
            areaName: '八里区',
            areaPath: '中国,台湾,新北市,八里区',
            areaCode: '100007100020100000'
          },
          {
            id: 12640,
            parentId: 3850,
            areaName: '林口区',
            areaPath: '中国,台湾,新北市,林口区',
            areaCode: '100007100020110000'
          },
          {
            id: 12641,
            parentId: 3850,
            areaName: '淡水区',
            areaPath: '中国,台湾,新北市,淡水区',
            areaCode: '100007100020120000'
          },
          {
            id: 12642,
            parentId: 3850,
            areaName: '中和区',
            areaPath: '中国,台湾,新北市,中和区',
            areaCode: '100007100020130000'
          },
          {
            id: 12643,
            parentId: 3850,
            areaName: '永和区',
            areaPath: '中国,台湾,新北市,永和区',
            areaCode: '100007100020140000'
          },
          {
            id: 12644,
            parentId: 3850,
            areaName: '三重区',
            areaPath: '中国,台湾,新北市,三重区',
            areaCode: '100007100020150000'
          },
          {
            id: 12645,
            parentId: 3850,
            areaName: '芦洲区',
            areaPath: '中国,台湾,新北市,芦洲区',
            areaCode: '100007100020160000'
          },
          {
            id: 12646,
            parentId: 3850,
            areaName: '泰山区',
            areaPath: '中国,台湾,新北市,泰山区',
            areaCode: '100007100020170000'
          },
          {
            id: 12647,
            parentId: 3850,
            areaName: '树林区',
            areaPath: '中国,台湾,新北市,树林区',
            areaCode: '100007100020180000'
          },
          {
            id: 12648,
            parentId: 3850,
            areaName: '莺歌区',
            areaPath: '中国,台湾,新北市,莺歌区',
            areaCode: '100007100020190000'
          },
          {
            id: 12649,
            parentId: 3850,
            areaName: '三峡区',
            areaPath: '中国,台湾,新北市,三峡区',
            areaCode: '100007100020200000'
          },
          {
            id: 12650,
            parentId: 3850,
            areaName: '汐止区',
            areaPath: '中国,台湾,新北市,汐止区',
            areaCode: '100007100020210000'
          },
          {
            id: 12651,
            parentId: 3850,
            areaName: '金山区',
            areaPath: '中国,台湾,新北市,金山区',
            areaCode: '100007100020220000'
          },
          {
            id: 12652,
            parentId: 3850,
            areaName: '万里区',
            areaPath: '中国,台湾,新北市,万里区',
            areaCode: '100007100020230000'
          },
          {
            id: 12653,
            parentId: 3850,
            areaName: '三芝区',
            areaPath: '中国,台湾,新北市,三芝区',
            areaCode: '100007100020240000'
          },
          {
            id: 12654,
            parentId: 3850,
            areaName: '石门区',
            areaPath: '中国,台湾,新北市,石门区',
            areaCode: '100007100020250000'
          },
          {
            id: 12655,
            parentId: 3850,
            areaName: '瑞芳区',
            areaPath: '中国,台湾,新北市,瑞芳区',
            areaCode: '100007100020260000'
          },
          {
            id: 12656,
            parentId: 3850,
            areaName: '贡寮区',
            areaPath: '中国,台湾,新北市,贡寮区',
            areaCode: '100007100020270000'
          },
          {
            id: 12657,
            parentId: 3850,
            areaName: '双溪区',
            areaPath: '中国,台湾,新北市,双溪区',
            areaCode: '100007100020280000'
          },
          {
            id: 12658,
            parentId: 3850,
            areaName: '平溪区',
            areaPath: '中国,台湾,新北市,平溪区',
            areaCode: '100007100020290000'
          }
        ]
      },
      {
        id: 3851,
        parentId: 1465,
        areaName: '宜兰县',
        areaPath: '中国,台湾,宜兰县',
        areaCode: '100007100100000000',
        children: [
          {
            id: 7453,
            parentId: 3851,
            areaName: '宜兰市',
            areaPath: '中国,台湾,宜兰县,宜兰市',
            areaCode: '100007100100010000'
          }
        ]
      },
      {
        id: 3852,
        parentId: 1465,
        areaName: '桃园市',
        areaPath: '中国,台湾,桃园市',
        areaCode: '100007100030000000',
        children: [
          {
            id: 12659,
            parentId: 3852,
            areaName: '桃园区',
            areaPath: '中国,台湾,桃园市,桃园区',
            areaCode: '100007100030010000'
          },
          {
            id: 12660,
            parentId: 3852,
            areaName: '中坜区',
            areaPath: '中国,台湾,桃园市,中坜区',
            areaCode: '100007100030020000'
          },
          {
            id: 12661,
            parentId: 3852,
            areaName: '平镇区',
            areaPath: '中国,台湾,桃园市,平镇区',
            areaCode: '100007100030030000'
          },
          {
            id: 12662,
            parentId: 3852,
            areaName: '八德区',
            areaPath: '中国,台湾,桃园市,八德区',
            areaCode: '100007100030040000'
          },
          {
            id: 12663,
            parentId: 3852,
            areaName: '杨梅区',
            areaPath: '中国,台湾,桃园市,杨梅区',
            areaCode: '100007100030050000'
          },
          {
            id: 12664,
            parentId: 3852,
            areaName: '芦竹区',
            areaPath: '中国,台湾,桃园市,芦竹区',
            areaCode: '100007100030060000'
          },
          {
            id: 12665,
            parentId: 3852,
            areaName: '大溪区',
            areaPath: '中国,台湾,桃园市,大溪区',
            areaCode: '100007100030070000'
          },
          {
            id: 12666,
            parentId: 3852,
            areaName: '龙潭区',
            areaPath: '中国,台湾,桃园市,龙潭区',
            areaCode: '100007100030080000'
          },
          {
            id: 12667,
            parentId: 3852,
            areaName: '龟山区',
            areaPath: '中国,台湾,桃园市,龟山区',
            areaCode: '100007100030090000'
          },
          {
            id: 12668,
            parentId: 3852,
            areaName: '大园区',
            areaPath: '中国,台湾,桃园市,大园区',
            areaCode: '100007100030100000'
          },
          {
            id: 12669,
            parentId: 3852,
            areaName: '观音区',
            areaPath: '中国,台湾,桃园市,观音区',
            areaCode: '100007100030110000'
          },
          {
            id: 12670,
            parentId: 3852,
            areaName: '新屋区',
            areaPath: '中国,台湾,桃园市,新屋区',
            areaCode: '100007100030120000'
          },
          {
            id: 12671,
            parentId: 3852,
            areaName: '复兴区',
            areaPath: '中国,台湾,桃园市,复兴区',
            areaCode: '100007100030130000'
          }
        ]
      },
      {
        id: 3853,
        parentId: 1465,
        areaName: '苗栗县',
        areaPath: '中国,台湾,苗栗县',
        areaCode: '100007100110000000',
        children: [
          {
            id: 7491,
            parentId: 3853,
            areaName: '苗栗市',
            areaPath: '中国,台湾,苗栗县,苗栗市',
            areaCode: '100007100110010000'
          },
          {
            id: 7495,
            parentId: 3853,
            areaName: '头份市',
            areaPath: '中国,台湾,苗栗县,头份市',
            areaCode: '100007100110020000'
          }
        ]
      },
      {
        id: 3854,
        parentId: 1465,
        areaName: '彰化县',
        areaPath: '中国,台湾,彰化县',
        areaCode: '100007100120000000',
        children: [
          {
            id: 7509,
            parentId: 3854,
            areaName: '彰化市',
            areaPath: '中国,台湾,彰化县,彰化市',
            areaCode: '100007100120010000'
          },
          {
            id: 7518,
            parentId: 3854,
            areaName: '员林市',
            areaPath: '中国,台湾,彰化县,员林市',
            areaCode: '100007100120020000'
          }
        ]
      },
      {
        id: 3855,
        parentId: 1465,
        areaName: '南投县',
        areaPath: '中国,台湾,南投县',
        areaCode: '100007100130000000',
        children: [
          {
            id: 7535,
            parentId: 3855,
            areaName: '南投市',
            areaPath: '中国,台湾,南投县,南投市',
            areaCode: '100007100130010000'
          }
        ]
      },
      {
        id: 3856,
        parentId: 1465,
        areaName: '云林县',
        areaPath: '中国,台湾,云林县',
        areaCode: '100007100140000000',
        children: [
          {
            id: 7548,
            parentId: 3856,
            areaName: '斗六市',
            areaPath: '中国,台湾,云林县,斗六市',
            areaCode: '100007100140010000'
          }
        ]
      },
      {
        id: 3857,
        parentId: 1465,
        areaName: '屏东县',
        areaPath: '中国,台湾,屏东县',
        areaCode: '100007100150000000',
        children: [
          {
            id: 7586,
            parentId: 3857,
            areaName: '屏东市',
            areaPath: '中国,台湾,屏东县,屏东市',
            areaCode: '100007100150010000'
          }
        ]
      },
      {
        id: 3858,
        parentId: 1465,
        areaName: '台东县',
        areaPath: '中国,台湾,台东县',
        areaCode: '100007100160000000',
        children: [
          {
            id: 7619,
            parentId: 3858,
            areaName: '台东市',
            areaPath: '中国,台湾,台东县,台东市',
            areaCode: '100007100160010000'
          }
        ]
      },
      {
        id: 3859,
        parentId: 1465,
        areaName: '花莲县',
        areaPath: '中国,台湾,花莲县',
        areaCode: '100007100270000000',
        children: [
          {
            id: 7635,
            parentId: 3859,
            areaName: '花莲市',
            areaPath: '中国,台湾,花莲县,花莲市',
            areaCode: '100007100270010000'
          }
        ]
      },
      {
        id: 3860,
        parentId: 1465,
        areaName: '澎湖县',
        areaPath: '中国,台湾,澎湖县',
        areaCode: '100007100170000000',
        children: [
          {
            id: 7648,
            parentId: 3860,
            areaName: '马公市',
            areaPath: '中国,台湾,澎湖县,马公市',
            areaCode: '100007100170010000'
          }
        ]
      },
      {
        id: 3861,
        parentId: 1465,
        areaName: '金门县',
        areaPath: '中国,台湾,金门县',
        areaCode: '100007100180000000'
      },
      {
        id: 3862,
        parentId: 1465,
        areaName: '连江县',
        areaPath: '中国,台湾,连江县',
        areaCode: '100007100190000000'
      },
      {
        id: 12617,
        parentId: 1465,
        areaName: '高雄县',
        areaPath: '中国,台湾,高雄县',
        areaCode: '100007100200000000'
      },
      {
        id: 12619,
        parentId: 1465,
        areaName: '桃园县',
        areaPath: '中国,台湾,桃园县',
        areaCode: '100007100210000000'
      },
      {
        id: 12620,
        parentId: 1465,
        areaName: '台中县',
        areaPath: '中国,台湾,台中县',
        areaCode: '100007100220000000'
      },
      {
        id: 12621,
        parentId: 1465,
        areaName: '台南县',
        areaPath: '中国,台湾,台南县',
        areaCode: '100007100230000000'
      },
      {
        id: 12622,
        parentId: 1465,
        areaName: '嘉义县',
        areaPath: '中国,台湾,嘉义县',
        areaCode: '100007100240000000'
      },
      {
        id: 12624,
        parentId: 1465,
        areaName: '台北县',
        areaPath: '中国,台湾,台北县',
        areaCode: '100007100250000000'
      },
      {
        id: 12686,
        parentId: 1465,
        areaName: '新竹县',
        areaPath: '中国,台湾,新竹县',
        areaCode: '100007100260000000'
      }
    ]
  },
  {
    id: 12673,
    parentId: 1,
    areaName: '香港',
    areaPath: '中国,香港',
    areaCode: '100008100000000000',
    children: [
      {
        id: 1466,
        parentId: 12673,
        areaName: '香港特别行政区',
        areaPath: '中国,香港,香港特别行政区',
        areaCode: '100008100010000000',
        children: [
          {
            id: 3863,
            parentId: 1466,
            areaName: '香港岛',
            areaPath: '中国,香港,香港特别行政区,香港岛',
            areaCode: '100008100010180000'
          },
          {
            id: 3864,
            parentId: 1466,
            areaName: '九龙',
            areaPath: '中国,香港,香港特别行政区,九龙',
            areaCode: '100008100010190000'
          },
          {
            id: 3865,
            parentId: 1466,
            areaName: '新界',
            areaPath: '中国,香港,香港特别行政区,新界',
            areaCode: '100008100010200000'
          },
          {
            id: 7664,
            parentId: 1466,
            areaName: '中西区',
            areaPath: '中国,香港,香港特别行政区,中西区',
            areaCode: '100008100010010000'
          },
          {
            id: 7665,
            parentId: 1466,
            areaName: '湾仔区',
            areaPath: '中国,香港,香港特别行政区,湾仔区',
            areaCode: '100008100010060000'
          },
          {
            id: 7666,
            parentId: 1466,
            areaName: '东区',
            areaPath: '中国,香港,香港特别行政区,东区',
            areaCode: '100008100010020000'
          },
          {
            id: 7667,
            parentId: 1466,
            areaName: '南区',
            areaPath: '中国,香港,香港特别行政区,南区',
            areaCode: '100008100010210000'
          },
          {
            id: 7668,
            parentId: 1466,
            areaName: '油尖旺区',
            areaPath: '中国,香港,香港特别行政区,油尖旺区',
            areaCode: '100008100010080000'
          },
          {
            id: 7669,
            parentId: 1466,
            areaName: '深水埗区',
            areaPath: '中国,香港,香港特别行政区,深水埗区',
            areaCode: '100008100010050000'
          },
          {
            id: 7670,
            parentId: 1466,
            areaName: '九龙城区',
            areaPath: '中国,香港,香港特别行政区,九龙城区',
            areaCode: '100008100010030000'
          },
          {
            id: 7671,
            parentId: 1466,
            areaName: '黄大仙区',
            areaPath: '中国,香港,香港特别行政区,黄大仙区',
            areaCode: '100008100010070000'
          },
          {
            id: 7672,
            parentId: 1466,
            areaName: '观塘区',
            areaPath: '中国,香港,香港特别行政区,观塘区',
            areaCode: '100008100010040000'
          },
          {
            id: 7673,
            parentId: 1466,
            areaName: '荃湾区',
            areaPath: '中国,香港,香港特别行政区,荃湾区',
            areaCode: '100008100010160000'
          },
          {
            id: 7674,
            parentId: 1466,
            areaName: '屯门区',
            areaPath: '中国,香港,香港特别行政区,屯门区',
            areaCode: '100008100010140000'
          },
          {
            id: 7675,
            parentId: 1466,
            areaName: '元朗区',
            areaPath: '中国,香港,香港特别行政区,元朗区',
            areaCode: '100008100010170000'
          },
          {
            id: 7676,
            parentId: 1466,
            areaName: '北区',
            areaPath: '中国,香港,香港特别行政区,北区',
            areaCode: '100008100010110000'
          },
          {
            id: 7677,
            parentId: 1466,
            areaName: '大埔区',
            areaPath: '中国,香港,香港特别行政区,大埔区',
            areaCode: '100008100010150000'
          },
          {
            id: 7678,
            parentId: 1466,
            areaName: '西贡区',
            areaPath: '中国,香港,香港特别行政区,西贡区',
            areaCode: '100008100010120000'
          },
          {
            id: 7679,
            parentId: 1466,
            areaName: '沙田区',
            areaPath: '中国,香港,香港特别行政区,沙田区',
            areaCode: '100008100010130000'
          },
          {
            id: 7680,
            parentId: 1466,
            areaName: '葵青区',
            areaPath: '中国,香港,香港特别行政区,葵青区',
            areaCode: '100008100010100000'
          },
          {
            id: 7681,
            parentId: 1466,
            areaName: '离岛区',
            areaPath: '中国,香港,香港特别行政区,离岛区',
            areaCode: '100008100010090000'
          }
        ]
      }
    ]
  },
  {
    id: 12674,
    parentId: 1,
    areaName: '澳门',
    areaPath: '中国,澳门',
    areaCode: '100008200000000000',
    children: [
      {
        id: 1467,
        parentId: 12674,
        areaName: '澳门特别行政区',
        areaPath: '中国,澳门,澳门特别行政区',
        areaCode: '100008200010000000',
        children: [
          {
            id: 3866,
            parentId: 1467,
            areaName: '澳门半岛',
            areaPath: '中国,澳门,澳门特别行政区,澳门半岛',
            areaCode: '100008200010020000'
          },
          {
            id: 3867,
            parentId: 1467,
            areaName: '氹仔岛',
            areaPath: '中国,澳门,澳门特别行政区,氹仔岛',
            areaCode: '100008200010040000'
          },
          {
            id: 3868,
            parentId: 1467,
            areaName: '路环岛',
            areaPath: '中国,澳门,澳门特别行政区,路环岛',
            areaCode: '100008200010030000'
          },
          {
            id: 7682,
            parentId: 1467,
            areaName: '花地玛堂区',
            areaPath: '中国,澳门,澳门特别行政区,花地玛堂区',
            areaCode: '100008200010001070'
          },
          {
            id: 7683,
            parentId: 1467,
            areaName: '圣安多尼堂区',
            areaPath: '中国,澳门,澳门特别行政区,圣安多尼堂区',
            areaCode: '100008200010001060'
          },
          {
            id: 7684,
            parentId: 1467,
            areaName: '大堂区',
            areaPath: '中国,澳门,澳门特别行政区,大堂区',
            areaCode: '100008200010001040'
          },
          {
            id: 7685,
            parentId: 1467,
            areaName: '望德堂区',
            areaPath: '中国,澳门,澳门特别行政区,望德堂区',
            areaCode: '100008200010001020'
          },
          {
            id: 7686,
            parentId: 1467,
            areaName: '风顺堂区',
            areaPath: '中国,澳门,澳门特别行政区,风顺堂区',
            areaCode: '100008200010001060'
          },
          {
            id: 7687,
            parentId: 1467,
            areaName: '嘉模堂区',
            areaPath: '中国,澳门,澳门特别行政区,嘉模堂区',
            areaCode: '100008200010002020'
          },
          {
            id: 7688,
            parentId: 1467,
            areaName: '圣方济各堂区',
            areaPath: '中国,澳门,澳门特别行政区,圣方济各堂区',
            areaCode: '100008200010003000'
          }
        ]
      }
    ]
  }
]
