<script lang="ts" setup>
import { ref, computed } from 'vue'
import { useUserStore } from '@/store/user'
import {
  openGuestAuthGenCaptcha,
  openGuestAuthSendVerifyCode,
  openGuestAuthResetPass,
  type CaptchaQuestion,
  type GuestResetPasswordRequest
} from '@/api/saasMallAppOpenApi'
import code from '@/static/icon/code.png'
import Verify from '@/components/Verify/index.vue'
import { aesEncrypt } from '@/components/Verify/util'
import type { VERIFY_TYPE } from '@/components/Verify/types'
import { onLoad } from '@dcloudio/uni-app'

const userStore = useUserStore()

const showPassword = ref(true) // 是否显示密码
const forgetLoading = ref(false) // 按钮是否显示加载中
const codeLoading = ref(false)

const forgetPwdForm = ref<GuestResetPasswordRequest>({
  loginId: '',
  newPassword: '',
  deviceType: undefined,
  verifyCode: ''
})
const formRef = ref()
const uCodeRef = ref()
const countdown = ref(0)

// 本地调试数据
if (import.meta.env.DEV) {
  forgetPwdForm.value.loginId = '13652725969'
  // forgetPwdForm.value.newPassword = 'Abc123456'
}

const rules = {
  loginId: [
    {
      required: true,
      message: '账号不能为空',
      trigger: ['blur', 'change']
    }
  ],
  newPassword: {
    required: true,
    message: '密码不能为空',
    trigger: ['blur', 'change']
  },
  verifyCode: {
    required: true,
    // len: 6,
    message: '请填写验证码',
    trigger: ['change', 'blur']
  }
}
const getCodeTips = computed(() => {
  return countdown.value > 0 ? `${countdown.value}s后重新获取` : '获取验证码'
})

// 临时函数变量存储
const temporaryFun = ref()
// 校验参数
const resPonCaptcha = ref<CaptchaQuestion>({})
// 加密的签名
const validateSign = ref('')

// 是否显示验证弹窗
const showCaptcha = ref(false)
const captchaRef = ref()

// if (import.meta.env.DEV) {
//   showCaptcha.value = true
//   resPonCaptcha.value = {
//     captchaId: '9a6da7530e2d428cb0bb453150f6b36d',
//     captchaTTL: 180,
//     captchaType: 'StringCaptchaStrategy',
//     mainImageBase64:
//       'iVBORw0KGgoAAAANSUhEUgAAAWgAAACMCAIAAADeJaSiAAAnB0lEQVR4Xu2dB7w9R1XHfwSU3kRKaKGIgKGKgkiJiCAoRXoJJHSN9CZChFClCQklUg1FegtBJfQQCFV6CzWJ9NACISAQHvru7tt5s/M7c+bM7Mzefe+fz+f7uZ99vzm7971375ydnTlzDjZO/z87wL+Nf/xD7/gwtp8IcFsWdwfABotGgOuy2BrgQBZFgEuw2AjgMSzusQA/Z7ERYKkiwOtYbATwChbbARzO4p4D8GQWlwlwPIsM8C8s5pLlNN1tGPgxcElqPYpPKQY4gsVigCduOQ7gysBr2CIX4NHAW1kns7NL4j4sMsBfskg2B7OYC/As7/hlbCACXIrFPQrgv1gUAc7D4jwAb2axAOB9LI4NXsvi2OCpLM4J8GsWk1QecQD/wCLZ/EISb03Kr7rXP2JjI8ADWVwIwEO84yewQRLgK6Qc6v8bgb/js+YBuAKLOsA7WVwXwINYJJsXsTgF4CnDwc24dWlUdxzfGA6uIrWehcWh6aTxj7dkGxHg9Swq9P6oAODuLE4H+CKLXuvXhoPC+xJwERanA5yLxRkAzsniegGuA3yadc/gHSwWANyelL9ms3kAcFZWRYDPesc/YIPlAxwEfIF1C8C3WFwIZWOW1gDPlsRHsigCXH384ye718+NResNJgvg3SwuBN9lA29jg1yAV7OYxM1x/Dm3JQHu4B2brgD8I4tjg6NZHBv87/jHP2WbWgDvJ8XkPizPjcC/sjgbwEtZ3NEA92exIsCtWLTjP5xOB/gUi2TziqA3AX/PZmODxCOI8/sJu/E5+7OYi+UPbgHwShbJ5nrAfbqDZ3JrDOAvWBwb5M3DARdisTVuCOkeNset284a+HAwFlgUwLlZbARwZxZzCRYlgmdSP+LBiDiHaMc4JB85DudTOSgjOV1UfUWdF6hiAHcd/6j1ZOA2LOYCnHn849fZZlHUvd1trC54ORZnBvgeixMxLu2NTwk7iwXgNEm8F4vtAP6dRSNZI46Ls+i13pTFGMCNSLmWZPbQ7nWmO7DlMcQ9Gen/jVwKQncUTw3cl0WF2HAM+DKLnf4H3vFV2aAKwCNYJJvnsTg2iM7H71CAP2HRa9Xump3BV1ksIOo4CpbHgI+xODbYh5Q/ZrNOfyGLScRHOOC8LBpZ46z1rgR4CYstAJ7E4gwkZ+h2DTB2UeC7LMYAPs/iYgGewWJr2t2os3Az6vYHw+kAx4oRgNUBPsDiWgBexaKOH0i5rogkXhzYbmLJgjiFtisBDmFxaBpNXPXzCFO6BHACiyIz3LqDpT7g7Wyj0J8O/D43VQQ4QBKPY7EAe6SCEeAIy+PwogAey+JK9ywuzM1DU3ln0AkeyYrDnM5AYUr0bQzgp8PBW7hVBzidxWUCHMriogj2nRagL9zE4h6DVZU3soWRKTO0M2BcZNrdJFfpcwGOYdECcArwhu7g29yqI4YFAOcqmJXr6UPLLABPY5FsLsBiFZQgaeAGLFoAvsOiBRcA9rfASWUP3rFApqzfCfhdFscGWoBZ1ggQuB2LRoD/ZrEWwPVYjAF8iMWJxD7KhVB3QBrbydpiQmEhC/bAqSyWkb4F8V0FuDab5eIvpPnRn8DP2Hi9WMarbtIB+Di3JrG8RWd28nAQXYv1jJ/IokhTb+gAvknKlYCbsOUey5QVQAXLzLe7m4q7SYRtMmy0i+myB7yL9UYYI5Q2h3ssigD3ZjEGcEUWO30UvUatq9iZ2ajeVRSXClw82EvZDv9rxtF3liwNWYPoJMXBvrFvy05yHMk4kSyAvSXxri4EoJ8RcMFOwNnYXgH4KItTmLiPG3iwJFYYPJ5BAaXTAqPQUnEbYRWAj7A4NvBi+y1Dmixi7orMrsmiQqNFPksykYn0W8sqxpXVDWCN4YeKtqNgojRGv70V+DNu6vSCON3LDwcncmsxwJEseq37eccfZINOt6ZNCrAk3FKIjjiqfrnrJCbJXRWuu12yXlaFaruwLPs1xXwcsW9hC4DLsmihrk9MBqcncXkwq+xtUwAOdlmagv/ePLNRFqKOY6fjD3bsgVVnYCcYhix8PX7JtFjHmUgynFp2HMbARCWqcl3kzkR0p6wCCs4gALgOi0PTdiQFr5WQcdRrcxZ7S0LZJBzUUPBsogA8dzhI/LazLW8D/8OihX5oI46h9AwYsuNggM+wWBHgJyyKWPbFD2k1VtGywaNB8otuxM3U1lobt6ytJO8DSdyz+nSAy7AYY+ITNaMH/sT2+45t5ECYIH99kHNsCsD9WJwBy38jSRB+5oec5804AreQxC3/YpwW9ake17ixuualWPRahSXrTj+IxbooX8fcqRyGrwD8HpvtdNqtKVjoq9uU7aNz08DF0a4zA5wSKuHP2JdPU5geKr9MxMfOYNfT5pA4yGNoJwjxiG0lagrwABa91t94x+tJTawTpHEv/izqojyaxXAPBb4bSibOqBhHm0zTxYSOI4lfgiwI3S9OmetyeXfHxyfjNYyPjrlOsJiCagBV8OPBcofBTWd2gLuwSDYZOxKWjyWma2yvBUps9ojcjJMO4K9YtKNPbWybsbRn0uJBae241NDAObh1OuwgsrbbzEOwIM3FN4Pcf1zrYGIWz/kJKiiKw+dcgr2FfXBk1LcZ3Y8R4Boseq1TZ/4cuRFlIsCjWZyI5ZEY+CGLFnjbqGUImrtvGLgocEFJ//BwUCFoPbYDbWhN/12D5VX1IKumtNspa6RgWCdWJu5n7v1Uklu3WeDK3evUkBv74kgW/twecE9qHc2A8iLfoG/9E+uGPwGXLys1AFyJRR3gxizuaCzl5orj4oHnZI2ANh83lGrHsXkoS1gtcGkW58Tyf44hniuPz90ET8xl9rd0/2bl11gpZnrhX+C3Sbkcm8UAvs+i17pdkmpOjOkdl4BYNyd3ULMuWmQ8Whf2bEllu+lQHPAXpAay+N1GLDAOTcelz5pI1u10N8G3h1w47VVsQKHjCr5WhzN7D/qqJJK7l/i3uv4eqQQEubQM3bE8JjASjjjEmnrAm1hcI9O/N9OJ5WdvShCb5OlCevcpKGGjSdQQlcONe3wti5rA9VlM4i/hLRDg8SwukJHjcJUsujXR/di6GOAJlq/C/PA0qpJ7lSwn+eyN1RVW2/BikzKMsobXf159QiA3T6mjpKLT0bOx2VH+1cDB3atQbcA+MyoCnImUwjACC8AdeXTT6Sey6LVubXJrweb3bXogeDji2MUkI2oKAB5W67ljF6CHgc9MWVFhvejv5sfNoteqlUoaW0arJeizbK0B3sOiCMTQT+A5LE5EDJh3+4VIL5xIbw3wOyxOQfwPiFn/dzeto/U4fGPhzBYIm5VWzuGWY/140LzIM+AoFncWs9XsdM//yczauXdv4EAWjfRZHoC/GX4suW0oc3J1EW91XutooNFnEgSez5atcbsf7d8ucROAcVbICPBuLsBawPajirKCnQR4QfdqerTuLL/EYozk5uXpiNuKyWZ7RjqGvOJtm+4C7sGihSlJ20XEr28VkrFtsZxdjL9yz3E0FdNQ+bhk5XNmrl0m0TkOMSXZqSfvs8nmIEqfz7PER3Zm0R20vBtPoY9em06saoYxYhd4LYtDU8O5rjLEzzcL4HgWjfCu5f73Ac7JxmOzVQnB6imOLYgLjl5rSTREAVn/duBO3rFwX/dvmcAN2SCGP+JIZE/tvUbAcG5e5ExWVojkDDDwanFSIJlDFHh9LGVRQdrBZKFwxv9ci+mHQuJgZzB4DYudbq2fYMcyLjMyvVBG8pszBeDlLCoATx8OrsatIrndysg4Dnt7D3QW0REHw16DPcjM+ImPYgEzTQFOY3EnUjx3WOBhfYBP6iVac9PEWOhjqLKwr5gkaV1KBrgbi0lyqzgKjuNeN7iiCDuLGHzNAoDvSuKtWZwZfqJmamU2digRHBayhng+fRq+fv+hWGChBbHACq5Tq/9d+sNFXcqi0Xyqf2d0JuZ2CgLA5PBz4Gj2DkaGK5QsqhsBDlE2+LZD+aOAw2IPCJ5NYmHFQvH8TvG2K/FRWaHuooBO8bhpCSTnd7KYUupE31O7+YECpweOYyuSry9L4cMeoQAexYgEb63Q/4U80zaR2B1vfowpi1rAt3edWB5GJhirc6JDhbo7m5fA9LoNxfDNY/zsLyxQAG/bOuC2weIK/o/sBabAb+fDriQJX2Rj9SdMzRKwBIx1JD379JNUZ7a9LlbsKIEXs7gQqq9S+yRXEnYi4uRAjKjjiMFeoAy+sogrgApci1sd7EqSdNdsu129xdZJ4P0sxrD8gW6DkpGFFF6vS3F5gaYAb2dRhLdcdWIiaiYGcFJyQSrqOIAfsRjA7sAIXwo4D4vtAE5kV6LDF/E56qnn7hm/yzO711XwYndwcz5RBLjp+EdTIEl1OIxKiVUZmz2WxR1BnyWwf3pSVrgt+DHjtdaGgI+zOAPAEaEiGaXjEYJvNrsGHe86T+ECkcosUSxGawbYlThn4WP3NRurP2e02akgZFPZw+7Z1M3/+N7hYJSQpVP2W+Z4BPgPFjv9qSx6rfux6LVmzG0DT/aOTZMawSCIuy5Td80R+BWL260sbbdlPl33sJtgekvg1Xy6Bf9jmAG/P7OnCPBPZF+ThN9dBNibRQXgWFLSS5XAVbrX23evYUJTMt5XXOHrN8gPx4ewQS3ETKhrJ9hz5Nyuhc3nhbJRT910ueLmIM1xbFmoSWJEr8yegr0GAzzOO14tDIvxoHb8rLliToQkfVydn0mEPYXiONwEjQhwURbZlSThi3QXP19WzsSACak68qoEFHPUWY9wcGtFgPuy6LWGmZmDwbinm1ad+q1xyr77rlX+0OdEcxziMNiyd5adRdJx6OOiWsSWD+xjH/YUDJ+l08e86rO/Y/vRrj92JUn4mkZyb2XAQ1js9OwlD99TBF7Df7gumBHst2h2B7eSWrVNKN04Sw792uzeez/qGBGyfEX3OpPPtdAFa8idZcuAJSOxjF7sKQKvwUEiOwX2ESLG6F3L6lcfx1F9xzq7kqRPAc7CYqfvxSLjVve55xtHDXxKcGIs623fAfQcPDHi9WWjT/HsJhT49Cq0WM7zAe4ddRz24RBwdXfMniLwGuMTa87l9FhKUhfDPkKET5wCz0FWJMicap/a5A5cq//H4FP8s/Su4iJ67Nv2C2C/YMRdQazHHEOfpSpLqsLwltn+Xw09V1oW7CkUr7FwOLqBHUQM6WqjYmKDaP3PZwXUWybt+yKb/gNa7kZM7sOW/s/2xnPZOHkKExuSTId9QQF82Rj6tItnZppVKWM14ujD2oGzcbMd9hQ7zmv0G7q6A+Hpjh1EDHs1STEZbzuAy7CYhRuHch+29GS2N57LxslTZoNdQDF8cR8/9by4gJXFxIQs6a+4pRYBe4od5zV6+iR6DPBJdhAK3onrT+ETJEzqpxL1zexJuA9bejLb87n+Ol2/mYIte7rU+Z/nd9FRpicK4M4/EX6LGC7V4/Dj0cAX2cwOcB8WRYCHpB3H+IQ7srjRxnEYM+7Ng+gaWGTHUZey3Z8tZqO5G/udX4SNjeeypbOf7Usirq1wt2e8KxzErQy/i4gYBiESZB4oyLbtb3d0Rflkx5EV48yeIuY1ygo75S4BtkB0DSy2dhyMZWdAEj1qoDMIS8ZxN9Y7v3JK8ly21O3ngfu8sf+zcexcsZ7mQpAdhwLwW93rO7vXh7OniHmN4fTjWFwjem2hfiQc8wusz+84ZgP4J/9H7sZ6Z2ZLhs8CbshmMeMWAL9kcSPV+dk+63TLFQoA9oqFnBQQOg7gfGwUgz2F7jWSJLOf8zOtJcZxlXdk2FmgrGXEcp/E/ALrbENvsb10TU37G7eQLQHuyXqXZjOGz1JODMyGKujXHYvyB9o1raLpu4NHDQcZIYjc1ZN93i2rAz/Xr6BcZDmMHEfW2i97ioleQydrA1i/LbU72PpaFLP5LKA4BW5im3WRm4knC+7JsS4t2rPin+iHrrCZbzkbfnwQ9/Nkh+9vV0HIL59uuZR3zfLvNvC+4SAxRw48z99f43xxOOIwwp4i5jX86i96xJcY8Lt2RI/gshVwa8xxKGvvwIVYHJoekByGtC75JWaC2oh0abFXizaimDwxZhkAfJTFWnAn596ufNyW64wvdQKfK2KJRa5FieNgT6E4jo3V37OVbqw1wLNZNBIrAswewQ/T4NaY4yiGk2J4TVv3jboYK31xf/Z7tUt6uDkyF21EMestqtCH8wd/MnADpW4Ad3Lu7Ub4CuKlcjPLTryXcKYLpr7jCIyBi/EVdgpJd8AGMcvpiCuCFjiezbJTMZgNpdYncn+O9WrRIHkiGzgz4Cf8LjpSfs1DutfVjIMd7uEOXntS6AO3+SIOshfCQIGXA59lPQsxvxT/u0IDlnTYUyheY2P1G4zG4X2MCnANtpyOmDhgCkl3wAaK8QwoTz0xXFkm3VMw3KWN/b/XNx/BYk2xE9nG0S/2xfB3shTnguozM3APj3V1C3yRsgsGYR36WqGOcepEcBxKAi72FLrX6K52IotlBB7d7YYms6+xWEbSFwD3ZJvAeGpsL97TvR7KTeuFu7TYsRUDpUlsDWyAfw7ea9CFJ1beBQd8oqAYNXdvez8Hvs8iX8d+QSPGqtd+zho/vb6427vfq7IPNzDsKUSv0UfUx5K1taZi1tmYI0ia6fYiYrXKrDC8LPRHleQwtYe7tN+xgccD14y1xq6gNPHpOn5V6opw93aUbQXi6zjYWCdYR0tW9snFH9ELIw4R9hSi1zACHMni2EDYTppE/64EmSOSJUuMjoDNdPvpBLstgCuxjYK/KBgUwWCU5Qnu1X7f7r+13Oo/q3Or0hQY+ATLnArA4Sx2+qdZFOHuHfTzPvEacL/gxFghK75OcEFGyYwHvJJFssn7woj0I45E+AZ7CtFxAA/iczv9mywuAVeASkTxAv7eRPYXCsFbTMzB6cJVZqPPP9rDvZr7dm6rK47HTXx6dSxJibh7B/08lvEoBl8nuGCS4sdYfUiruKdVK0sMewr2Ghb8cQRw/nHTVoiHnp3VBbYCD+fWGFmfZb8yl+zzPmwcY3iLqRWMjU+tueiedGz5be7VQd9WmnQD1sXTu1/jE93rBYYfV/lxgXOQ2fVJKRzGc/f2+3lBHim+jsPf7Vo28Q88nRRtVG4niBxdVVQMYE9R5jV2FmKf76LCRxk0Nr+pbKnAb9Rd5MYsTsS+ebzPjmvEXxLmjh308JiuXCGmi6f3AKex2A7u3o6N1S+TnRObr+MomzQxwmmWs0iMONhT+AB34VMc9ppjwAdYzMWePidJssOzgRF+LwfwYxaZILlGU/SRGnfsoIeLon6FmC6e3gMc6yc9Sz53T4S7t09vEyRkdABvYJEvElxtmWidzW0PYZdxanysoSdoA+7A4tB0MotrgTt8RYCv8js2gifkXLXXIIVUkIwTuHNwogh3b9fJRTFYjxRtWHRN3RVWdTPsWCIaYsk7YzkvuIdP6ep8kdjVYnPAQekWBeAbLOoAx7C40llS2PwVh7GGMC1nXNZNMnHKUEGv3OXg3l4RfjumT64thvR5NutP1sDdW+n/ltNFMXb6PHD1Ru7h8a6+vYUMuEnQmn+1n/HpXutPWbQjTlMoyI4jlhV+IQC3CuLbLGUr7XBvrwW/V3VihUWUHf3FcPeO9X8+l20U+Nxipkctcw8XuzpwIJ/L8EXEq+WSLN9r/PVi9Mux1YKmdMS9N2IQ/szwgzH3+WL47bp3nPrAIhaCswC8lUWyCRetxH1W3MNj8LlZV+ATFYCrsVhALEyOe3ist8dS2BqvxsbLQR5xLB/gWSxWhPt/MX7sQ4/9pscl5ioG1GfhRw25UTH38Bh8wawr8IkKwDNYtKAnZ/U/Ne7kZb2dTy+7Ti2Mz/Iry+GEdF5PZf0GeCSLRoJkzUsAuBv3f4WNlKPht9iJALcNFO7hInSdfbKuEJy+BLifl/V5Ple8SFb/4s3QLWg+4hCXoKajl8KeDnf+pC9gG8V4Y/UnbE8wAwcD92SbMtyG19ZwJxfhE7OuwGc1IhmYB7y9e12Ndrmrx7p9DD7LcvrmV4XF+Uk7jqwspEz1KYw+u6T3o+yMgZePf4wuAw8Gx/o/Kp0fOI8YdMSnBOcWjK1cjSjSt4o528ON+1UY4MvcFCOZKIg7OcNn1b3CBn3WOpy2thOzvTb3dnvnT57O9sDxLA5N92exNWnHsRPR98gZ47W9Dr/d2YAzsWWnn8D+InAcg2X2vuHY/nGRTRcJHABcm/SPsLFOMkkMd3KGz/KDRNg+eXou9nqxwGEsKnCHT/b/4rPWCxB+EJrj4Fm9YoC7sbguXBCUBZcOuzt2G2qEGxT7C/YaRvrZR/0br0w5zQb3c4bPyroCn1JAMm9rGdznp8PvkiRYoeN0p/3+lC7/SLh1pdNj8W/CjmHgMVsH3LbrAV7H4kSAfX1PEQs6FAE+yGIx+j6A6nBXz+r2fErW6QHu+R+401h/XPd6Dz5lItzzJ9JfFniQHu7VAiWFAj/pt3IcsSE94+bYK36uwINZzMUSrZxFMhV9O7iqqKvlNxHu7Vk9v+CU6cQmQfUIl/774O9D6eOSuPOXwe/IKJmrGTH0ZmwQTczhV6gRt94A+AWrY4vtYlbjhYC8LK86wLdZHBvkdWN/oMXRVrn5Ne1wLJkC8HUWh6boc4q3izxcH43hbl+u3HwtuOf79DnEp9DXOrX/pQpdWea9lf+5hVj5XnYEWfAFy3AJTVqTN+LImh1oB/Dk4WA7Pp/ypplmQHVm+xj2ZIC7sliFZKUe4Dgeefn13/p0XkbYHeTC12wKb8gGPi6ZjcpWb4ksjc8JLz1uFSYL9GezzZFFwfT+dMRfVcRtaqp+c54T4FwsVsFlJBUjdPrMOkayqhwAd+xeraGNreHHYeCo/oA9gh3xuWC4/i1YFOHERTrAI1jUcZGjD+M2O2VP7/4zmB7tu1iq3y0rTvQkUdJtAPft6/iuJUagFsmNXmUUZOtxAL+9kfIsfJZCbK99a6IjDn6qLN5VJeKqQC8BYy0JC9KN6OJsNjQJwUgWgFexWAAn7JgC8CPv+Dfe8X3IcmtVzwhwOosFAPt6xxkTjYziUoH/ZDGA/UWx75gT4M1bB9w2WIzSEMQ2a7fDUjjSn7gtBngJiyJZpbo6+60KNcC1uLXT781iLi6KdGfhpngZnsz2miYNjdshBhPrsL+IuY+siusxxHIzBfRPi1HH0ZpYYv6mYQjFd3hHXzVmZxEJ+0kEj2z6o2Tk6GB5vmBfQjBRXRcurTQF4EUszgn7C9F3xKi4pS0vcp+lptTdfwXcjsVcknmfgcsC5+0OPgN8ZdxUf2omHmVwgYJJrBYUFJosw5jBsDWx5F0KyvwRk/QUwDH9svRycJOjwk1pCgUbusoIwt02H7PFUNlaAD8HPsf6/PRLEslfJmsWQywoV4vclNTVN0CLaw3JzabAe1mcgWAz57gpuuFtMPgYiyIFt95+jDN1xGH5FfUF2rGlsIzstW4PgDdv/mzQ6dbErbsGvd7yYJMoW1dAvP7WaqUpa102ScHHGsuymwXwKxarwEHcXtOo5NA8AIcD9+lj8y2MHAfwAEtGn4B+GK+QddNbC/0i2bpY1z1tY/XWL2FRxFJbcLCcuqPMn0vWC3RloYRIKBTsZo5RlqNTmUW2E9TuSc5wJdl2HJb8iBOJfQlqLbZVB3hH93oJT9n2kpYOD3zKOxYW8ICHi6lYm5L7wJwcG58Bk8xmkks/EvGr7QEvYLOJGKftrI8qyZJ5yhMpcJ7uNUwz7y+s6I+aXNRvBvwN9YMi71Ow48/IbB7bFwiAx7O4owHOzqJObJtJUCNmEKPPAmX08+LBvtsygF+zmET/DohPc+1Wr62Ow8ePomHcg0m/wUl51NR3vvAmAq9p6kCrmIJHuR4uX94U4KYsLoGmy+0bq+uPRrX6Lm09MEePeAyKSw3iKNLfWPBV8XG5Czqb3s24iD6RhOMAjmNRZC0l6YG9gEuxPhEpajZjs1NFNm8jsS+fvxdradijXcoCiPvH6io3fx+XqGlduKGT7u+WQMJxrAVeFIztUu3nILJQQgOAG7JYAHBzDjz3WisMPZS6vC2+/bHFBa7e0IL+UTeJEm8aQ9/DuaMBnjT+Mb36aQG4+9YBty2H4ueCnUutTSjTAfYH3sT60HozFkXc7gYjTaNON1bXP5DFTr8gi17rS1kcmoRanC1yZSqRHYOB5h2UsD37Kuz2KSzpABdjsS5DqqUjuSnJWtbALeT2H0af7gY+bdy1Kdb9FZmY4P4MHFmpJDv7miVNFYoDNaOOoy8hURGuKug1abcv/tv0LjQzylKLn3+t+/HE7lVIi9LprSbAFZTI6LoZ3nz6jy+rRLnRJ5aRXDEcG3+3ez2GmwaD/Vicn4rhJyKh4wiy1wAndK+rCjTKc3sWehF2nSkhD5z9uRb68lASZcLCs6kf+mmhLGapHcB7WBSxL3XvRCZG2SVzoyUJHUcSTi0VdMjkHNU8QRnTdw32YfzAZbip07MTqIiRC0r8Sy7iU3r1pYeFEwsy9AzW4wrnTNHUgnBIwRae6dai2jhcMkzKsjsAXshiLrkBJuNST4ewwdAkLPfEaqln4QY7wP7c2ulapEMWwd6WPvH6Qvb7zkM7n+UHMQNlpXzOxqKC5jhEkts6lMfmtQDchsUpGNMgV1l2tRDcyjiNY8EOSJ26G9jmQcnnwJNoCsmdWTr6AjBwVUmcutvbnnDXTrbjaErFcfueA/Cy4eAgbi1gvDcnYzcEsBeLuwkxE5dxMiVZAIQRCwaSTcbMbkU0x5EMWwZOYdEIbdfLSHhdhpi6tixycc8hme+jNUrRIB2ePiyYliqjIC4xIMtfrwXNcZxBdWJrsV3THEXMiulX1hSWtsV5eu9dI/p+tiUgOw7gxUGOvAKU7N5jswPGP57oHW8VLgS+xScuk778x7rwB7fAu9igGOB7LA5N1gdMP8YBOJwNGHvGkB3NxKmTuljSX8uOIxfg6ix2+tdYZMREFWewB6JUb23kQYBDSUk8oSv0KezEraHruqMokS9ZZVWBp41+HNS8pCPAG1lMwo+dnShvoBrbTI1XSeLfNms5MuAcxgcQ8T8TgzfvjltNs0UzbB1IItaCs9OVdN9apFDiku0on7vS/VrTYk1kOiUjDv9pFniNm9VvhH1dk8Pk9T7WGUz67tbFWx8ZLanW2OciFNkGLjv+0c+rVB6hW4yYisaCF3BUYS+CIeu98M/U2fxk7SH24hce2O6qwDvZoCnAYaTMG3ax6dSNYTB9Zem6OyZm27WlRA3kwqG6RnLXvIDvsJgLcJFFPa4vEPvuAUtuynWRPeLInazmzTbAN9hMRIyhLiA2BaPAcfFluXz82FCm9XOvizfvarJYnWb1gLEeY+DcEgjyjIhxWQzwhXVFssQCf9uR7TiKyQ3HjhFLpgYcy2IS+6gP+DbwXNZjTBx0SClaJy0tlU1LzUOwD0InmZaiClWeejZW1xGzdQjRMf26VVkqdp0W2zsTjgP4AYte6yvtSeLaYcwQNQ9uK71eIyaLZAxFLXicNW61blMSx9jAmVmsi5K8U6Efl4k9nCwTk02cvM6IfXBtfNIvALg9iyLAxfwZl4yI/dmw9Jl2v7meAWC7cjeex61LQCx5MSUyXckilQtwy+7V+tzalNyCzBXvl7G0mJ6BcZmsJOlv1sBq8y3cfsvEiKOz3qqoPiXBZJABkVpNH1u/RFIQ8++wnAtcr/U60S7Dcq9uAXADMaNfWQWj6XkYlsBsu401x1E2trSMETzj1QYh4MrctGSAU1weamBvNhiawhQMwKPYrNMvwqIF4Bks7mim3J9aYwxonI1N1+kdn8gGMZJJJIAPsTgyYKkR+vOzwkL6RqyI/MJZ/nYpI2J0wwIRFwHWnk+wz3g4HCeiPcXI16Fpq5qM5jiAp3rH4c2zFvy4GBuA8NOg4oyAB7KYi3GKG3hk9/obbpqOcQYHuLZ3/CU2aIeSgLNr1WLJYgnWsgCOYnFHYF8jF4nFqgEns1gXzXGM7LpIdQ4gKwM42hVomIgSOu3XLm4HcKp3HP5RyUx2u5V2d5oqVLmvNEKsEVeA2+4A/JBbJ2J1HDNTHC65NPT17JkBHiqJo7sT8Bi22YkYN2eLzJa5Y+H0VVxFluI4WsdQFhB7RuBnqxgFXsO+nu/TL20aaTrrYQl709Plz7wHohH2EkfA01mMMWVrFXBpFospcRyWWtux9A3A/WKltJYAcGEWvdYbsZhF1tR3Rbw1oOdz65zEQmOkrQlC1Qh/ks+I0dHbY4gZQyLe7WyMtdiuxjhOARvsXbSQFRK9dQpLOlWSa9vxYwSAb4n5vqtQNqHoR3xUz4q8+6h701sIWZW0ghpdTfF30wFfZwMGuD6LIn7k6Nu4eWj6AIsKWaOvuvQpsJYcC6AwJYVMMcAvWVw79qF+Z7xa1WqNW2TMrSQwD8AlWWxH9ohjBjjMFPjpcLC99bvuZifgnN3rz7jJgjiuziU54p3OxKJz7VjC1MYODdVZC1Mdh15QHrgKixaU6dwdgTjkaT2g8BeGG9G71zJyt343rRe7sbr+apHS/wIDr2QzO97y50uoKWNLiA9XyWmKPd4i6jiqB9UALyIlY6JOyQ+eRTKWVkTcBy3iVvKSUb0z4HoC8FluNWLZeQB8mEVGHySK8fix5CBl9cqqMDGX35ToLD9L23qJOg47uQ/JYuzN/HVl/Dj/3c0yC68VJODbNUwZuC2ECo5DhFfXdMR8an08cmy1Qs8D7A9wgAOA09hmIuLvLLJ5jwJOGCvCVkB7WsrOuCQcA/gMizNTnLRChDMekYH2jwIuOhwIn0inJ9LWMrxTQdkJubMAfrF1wG0x1ph1Ivn0rmxasQOcxKKI/mXqt2MBR3JTEhdwUUDWumAtXELALHcQuxk0AvgRiwrOiQC34Nax5VYwLvDSoED3bDE7/UyivzNtSpyYkZHjcCkq1wjwTO/YOlkFXI1Fsjk7i2OD6CiJr7/5vxIribZDSd5fEXcHzqWg/hPwWFeCMxanWwXgYyzuVvR9g8rEQlbyzYwRx3SAs1RZttyTKe7YIpw2CvgUmy2frKylxYjTtzHc4m71REeWYtTTAfZT5qFmdRxZVMxSZ6FFULCIy6gWo+mqbdZKlqN/SnU5b/3NJmXptnq4itoU+oTydZMb2FfTyqhSI7Z4rXcKW46jTzQC3KTiczKvZusAb2GxLsmJNBHgTd7xqOJpWawBcH4WY8x1L51vJFjxEU/fL5ekytSYnawBSy4T/xUiwN0k8carV25YOzwpnQtwFxbnwZ+jsTDDNvY1li+0Y4l0mlggYn6CuZWyJOw664q4/X/PjQ00QLpe3gAAAABJRU5ErkJggg=='
//   }
// }

// 处理机器验证响应
const handleAuthGenCaptcha = async (tempCb?: () => void) => {
  try {
    const res = await openGuestAuthGenCaptcha({
      captchaId: resPonCaptcha.value.captchaId || ''
    })
    // 赋值临时函数
    temporaryFun.value = tempCb
    if (res.state !== 'success') {
      // 需要弹窗机器验证
      if (res.data && res.data.captchaId) {
        resPonCaptcha.value = { ...res.data }
        showCaptcha.value = true
      } else if (res.state === 'error' && res.msg) {
        showCaptcha.value = false
        // const matchData = extractContentFromBrackets(res.msg)
        uni.showToast({
          title: res.msg,
          icon: 'error',
          duration: 60 * 1000
        })
      } else {
        uni.showToast({
          title: res.msg,
          icon: 'none'
        })
      }
      return
    }
    // success resolve
    return res
  } catch (error) {
    console.log('openGuestAuthGenCaptcha error', error)
    throw error
  }
}

// 获取getCaptchaSign
const getCaptchaSign = (verifyObj: VERIFY_TYPE) => {
  // 机器验证组件抛出的最后结果
  validateSign.value = aesEncrypt(
    JSON.stringify({
      captchaType: resPonCaptcha.value && resPonCaptcha.value.captchaType,
      opTime: verifyObj.opTime,
      answerData: verifyObj.answerData
    }),
    resPonCaptcha.value && resPonCaptcha.value.captchaId
  )

  if (temporaryFun.value && typeof temporaryFun.value === 'function') {
    console.log('getCaptchaSign 执行验证回调方法')
    // 取得结果后 执行回调方法
    temporaryFun.value()
    showCaptcha.value = false
  }
}

// 处理表单提交
const handleAuthForget = async () => {
  try {
    const res = await openGuestAuthResetPass(forgetPwdForm.value)
    return res
  } catch (error) {
    console.log('openGuestAuthLogin error', error)
    throw error
  }
}

// 忘记密码提交逻辑执行函数
const handleForgetPwdFunction = () => {
  handleAuthForget().then(async (result) => {
    if (result.state === 'success' && result.data) {
      userStore.LogOut()
      userStore.clearLoginCache()
      uni.reLaunch({
        url: '/pages/login/index'
      })
      uni.showToast({
        title: '重置成功',
        icon: 'success',
        duration: 2000
      })
    } else {
      uni.showToast({
        title: result.msg,
        icon: 'none',
        duration: 2000
      })
    }
  })
}

// 忘记密码表单提交
const handleForgetPwd = () => {
  if (formRef.value) {
    formRef.value
      .validate()
      .then((valid: boolean) => {
        if (valid) {
          // forgetLoading.value = true
          handleForgetPwdFunction()

          // handleAuthGenCaptcha(handleForgetPwdFunction)
          //   .then((res: ResponseData<CaptchaQuestion> | undefined) => {
          //     forgetLoading.value = false
          //     if (res?.state === 'success') {
          //       handleForgetPwdFunction()
          //     }
          //   })
          //   .catch((error) => {
          //     console.log('handleAuthGenCaptcha error', error)
          //     forgetLoading.value = false
          //   })
        } else {
          uni.showToast({
            title: '校验失败!',
            icon: 'none'
          })
        }
      })
      .catch(() => {
        // 处理验证错误
        uni.showToast({
          title: '校验失败!',
          icon: 'none',
          duration: 2000
        })
      })
  }
}

const codeChange = () => {
  if (countdown.value > 0) {
    countdown.value--
  }
}

// 获取验证码
const handleSendVerifyCodeFunction = () => {
  codeLoading.value = true
  openGuestAuthSendVerifyCode({
    deviceType: 22, //手机号类型  邮箱22  手机短信23
    deviceId: forgetPwdForm.value.loginId, // 设备Id（手机号或邮箱地址）
    captchaId: resPonCaptcha.value.captchaId, //验证码Id
    captchaSign: validateSign.value //验证码用户答案
  })
    .then((result) => {
      if (result.state === 'success') {
        countdown.value = 60
        uCodeRef.value.start()
      } else {
        uni.showToast({
          title: result.msg,
          icon: 'none',
          duration: 2000
        })
      }
    })
    .catch((err) => {
      console.error(err)
    })
    .finally(() => {
      codeLoading.value = false
    })
}

const getCode = () => {
  console.log('getCode')
  if (forgetPwdForm.value.loginId && countdown.value === 0) {
    handleAuthGenCaptcha(handleSendVerifyCodeFunction).then((res) => {
      if (res?.state === 'success') {
        handleSendVerifyCodeFunction()
      }
    })
  }
}

onLoad(() => {
  //
})
</script>

<template>
  <view class="page">
    <view class="tips">忘记密码</view>

    <up-form
      class="forgetPwdForm"
      labelPosition="left"
      labelWidth="160rpx"
      :model="forgetPwdForm"
      :rules="rules"
      ref="formRef"
    >
      <up-form-item
        label="账户"
        prop="loginId"
      >
        <up-input
          v-model="forgetPwdForm.loginId"
          prefixIcon="phone"
          clearable
          placeholder="请输入手机号"
        ></up-input>
      </up-form-item>
      <up-form-item
        label="验证码"
        prop="verifyCode"
      >
        <up-input
          v-model="forgetPwdForm.verifyCode"
          clearable
          placeholder="请输入验证码"
        >
          <template #prefix>
            <!-- <up-icon name="@/static/icon/null-box.png"></up-icon> -->
            <img
              class="img"
              :src="code"
              lazy-load
            />
          </template>
          <template #suffix>
            <up-code
              ref="uCodeRef"
              @change="codeChange"
              seconds="60"
            ></up-code>
            <up-button
              @tap="getCode"
              :text="getCodeTips"
              type="primary"
              size="mini"
              :disabled="countdown > 0"
              :loading="codeLoading"
            ></up-button>
          </template>
        </up-input>
      </up-form-item>
      <up-form-item
        label="新密码"
        prop="newPassword"
      >
        <up-input
          v-model="forgetPwdForm.newPassword"
          prefixIcon="lock"
          :type="showPassword ? 'newPassword' : 'text'"
          clearable
          placeholder="请输入新密码"
        >
          <template #suffix>
            <view class="input__icon">
              <up-icon
                v-if="!showPassword"
                name="eye"
                @click="showPassword = !showPassword"
              ></up-icon>
              <up-icon
                v-if="showPassword"
                name="eye-off"
                @click="showPassword = !showPassword"
              ></up-icon>
            </view>
          </template>
        </up-input>
      </up-form-item>
    </up-form>
    <up-button
      type="primary"
      text="提交"
      @click="handleForgetPwd()"
      :loading="forgetLoading"
    ></up-button>
  </view>

  <!-- 验证码组件 -->
  <Verify
    v-model="showCaptcha"
    ref="captchaRef"
    :resPonCaptcha="resPonCaptcha"
    @closeCaptcha="showCaptcha = false"
    @getGenCaptcha="handleAuthGenCaptcha"
    @getCaptchaSign="getCaptchaSign"
  />
</template>

<style lang="scss" scoped>
.page {
  height: 100vh;
  background: #fff;
  padding: 0 40rpx;
  .tips {
    font-size: 60rpx;
    padding-top: 60rpx;
    font-weight: 700;
  }
  .text {
    font-size: 30rpx;
    opacity: 0.5;
  }
  .forgetPwdForm {
    margin: 20rpx 0;

    .img {
      height: 36rpx;
      width: 36rpx;
    }
  }
}
</style>
