# 统一身份认证中心 (UW-Admin-Web)

基于 Vue 3 + TypeScript + Vite 构建的企业级统一身份认证管理系统，提供用户认证、租户管理、权限控制、审计日志等核心功能。

## 技术栈

- **核心框架**: Vue 3.5.16 (Composition API + `<script setup>`)
- **开发语言**: TypeScript 5.7.3
- **构建工具**: Vite 8.0.0-beta.0
- **UI 组件库**: Element Plus 2.10.2
- **状态管理**: Pinia 2.3.1
- **路由管理**: Vue Router 4.5.1
- **国际化**: Vue I18n 9.2.2
- **CSS 预处理器**: Sass 1.79.5 / SCSS
- **代码规范**: Oxlint + Oxfmt
- **Git 规范**: Husky + Commitlint (Conventional Commits)

## 项目特性

- 基于 Vue 3 Composition API 和 `<script setup>` 语法
- 完整的 TypeScript 类型支持
- 自动化按需引入组件和 API (unplugin-auto-import / unplugin-vue-components)
- 多语言国际化支持（简体中文、繁体中文、英文、日文、韩文）
- 动态权限路由和菜单管理
- 多种布局模式（默认、垂直、侧边栏）
- 主题定制（亮色/暗色模式、主题色切换）
- 丰富的内置组件（富文本编辑器、图表、文件上传、验证码等）
- 代码提交前自动格式化和校验
- 生产环境 gzip 压缩和代码分割

## 功能模块

```mermaid
graph TD
    A[统一身份认证中心] --> B[用户认证]
    A --> C[租户与账号管理]
    A --> D[权限与分组]
    A --> E[审计与日志]
    A --> F[系统配置]
    B --> B1[登录认证]
    B --> B2[多因素认证]
    B --> B3[密码管理]
    B2 --> B2a[二维码扫描]
    B2 --> B2b[短信验证]
    B2 --> B2c[邮箱验证]
    C --> C1[商户管理]
    C --> C2[SAAS租户]
    C --> C3[用户档案]
    D --> D1[角色权限]
    D --> D2[组织分组]
    E --> E1[操作日志]
    E --> E2[查询日志]
    E --> E3[数据变更日志]
    E --> E4[审批日志]
    F --> F1[多语言支持]
    F --> F2[主题定制]
    F --> F3[富文本编辑]
    F --> F4[系统升级]
```

## 快速开始

### 环境要求

- Node.js >= 22
- pnpm (推荐) 或 npm

### 安装依赖

```bash
pnpm install
```

### 启动开发服务器

```bash
pnpm dev
```

### 构建生产环境

```bash
# 生产构建（带类型检查）
pnpm build

# 仅构建（跳过类型检查）
pnpm build:prod
```

### 预览生产构建

```bash
pnpm preview
```

## 项目结构

```
├── public/                 # 静态资源（不经过构建）
│   └── systemUpgradeRefresh.js  # 系统更新提示脚本
├── src/
│   ├── api/               # API 接口定义
│   │   ├── uwAuthCenterAuthApi.ts
│   │   ├── uwAuthCenterOpsApi.ts
│   │   └── uwAuthCenterUserApi.ts
│   ├── assets/            # 静态资源（图片、字体等）
│   │   ├── font/          # 图标字体
│   │   └── headerImg/     # 头像图片
│   ├── components/        # 公共组件
│   │   ├── Captcha/       # 验证码组件
│   │   ├── ContextMenu/   # 右键菜单
│   │   ├── CritLog/       # 关键日志
│   │   ├── DataDiffTable/ # 数据对比表格
│   │   ├── DataHistoryLog/# 数据历史日志
│   │   ├── ECharts/       # 图表组件
│   │   ├── HistoryLog/    # 操作历史日志
│   │   ├── Icon/          # 图标组件
│   │   ├── InputNumberRange/ # 数字范围输入
│   │   ├── InputTag/      # 标签输入
│   │   ├── LangSelect/    # 语言选择器
│   │   ├── MenuIcon/      # 菜单图标选择器
│   │   ├── ParamsConfigTable/ # 参数配置表格
│   │   ├── ParamsConfigTableByAdd/ # 新增参数配置表格
│   │   ├── QueryLog/      # 查询日志
│   │   ├── SearchForm/    # 搜索表单
│   │   ├── SettingForTheme/ # 主题设置
│   │   ├── TitleHeader/   # 标题头部
│   │   ├── ToolTipText/   # 提示文本
│   │   └── Pagination.vue # 分页组件
│   ├── config/            # 配置文件
│   │   ├── common.ts      # 全局常量配置
│   │   ├── appVersion.ts  # 应用版本信息
│   │   └── icon.ts        # 菜单图标配置
│   ├── directives/        # 自定义指令
│   │   ├── index.ts       # 指令入口
│   │   └── permission.ts  # 权限控制指令
│   ├── hooks/             # 组合式函数
│   │   ├── useAbnormalMessage.ts
│   │   ├── useActivated.ts
│   │   ├── useCountdown.ts
│   │   ├── useCrud.ts
│   │   ├── useCustomDark.ts
│   │   ├── useExportExcel.ts
│   │   ├── usePermissionCode.ts
│   │   ├── usePolling.ts
│   │   ├── usePostMessage.ts
│   │   ├── usePrompt.ts
│   │   ├── useSimplifyPrompt.ts
│   │   └── useValidate.ts
│   ├── i18n/              # 国际化配置
│   │   ├── zh-CN/         # 简体中文
│   │   ├── zh-TW/         # 繁体中文
│   │   ├── en/            # 英文
│   │   ├── ja/            # 日文
│   │   ├── ko/            # 韩文
│   │   └── index.ts       # i18n配置入口
│   ├── layout/            # 布局组件
│   │   ├── default/       # 默认布局
│   │   ├── vertical/      # 垂直布局
│   │   └── slide/         # 侧边栏布局
│   ├── pages/             # 页面视图
│   │   ├── 404/           # 404页面
│   │   ├── home/          # 首页
│   │   ├── login/         # 登录页
│   │   ├── password/      # 密码管理
│   │   ├── userInfo/      # 用户信息
│   │   └── uwAuthCenter/  # 权限中心模块
│   ├── router/            # 路由配置
│   │   ├── index.ts
│   │   ├── typings.d.ts
│   │   └── uwAuthCenterRouter.ts
│   ├── store/             # Pinia状态管理
│   │   ├── index.ts
│   │   └── main.ts
│   ├── styles/            # 全局样式
│   │   ├── element/       # Element Plus样式覆盖
│   │   ├── basics.scss
│   │   ├── flex.scss
│   │   ├── layout.css
│   │   ├── normalize.css
│   │   └── var.css
│   ├── utils/             # 工具函数
│   │   ├── PubSub/        # 发布订阅
│   │   ├── buildTreeMenu.ts
│   │   ├── encryptionAndDecryption.ts
│   │   ├── idValidate.ts
│   │   ├── request.ts     # Axios请求封装
│   │   ├── selectOptions.ts
│   │   └── tool.ts
│   ├── App.vue            # 根组件
│   ├── main.ts            # 应用入口
│   ├── types.ts           # 全局类型定义
│   └── vite-env.d.ts      # Vite类型声明
├── .husky/                # Git hooks
├── .vscode/               # VSCode配置
├── index.html             # HTML模板
├── vite.config.ts         # Vite配置
├── tsconfig.json          # TypeScript配置
├── package.json           # 项目依赖
└── components.d.ts        # 组件自动导入声明
```

## 配置文件

### config 目录

| 文件 | 说明 |
|------|------|
| [common.ts](src/config/common.ts) | 全局常量配置（RSA公钥、菜单显示、请求白名单等） |
| [appVersion.ts](src/config/appVersion.ts) | 应用版本信息（从 package.json 读取） |
| [icon.ts](src/config/icon.ts) | 菜单图标配置（路由路径映射图标名称） |

**common.ts 配置项说明：**

```typescript
// RSA 公钥 - 用于加密敏感数据
export const PUBLIC_KEY = '...'

// 是否显示二级菜单图标
export const SHOW_SECOND_MENU_ICON = false

// 隐藏的菜单路径 - 对应的路由不会被注册
export const HIDE_MENU = ['/saasMallApp/saas/poi/hotel']

// 请求白名单 - 不需要携带 token 的接口
export const REQUEST_WHITE_LIST = [
  '/uw-auth-center/auth/login',
  '/uw-auth-center/auth/refreshToken',
  // ...
]
```

**icon.ts 图标配置说明：**

用于配置菜单路由对应的图标，以路由路径为 key，Element Plus 图标名称为 value：

```typescript
/**
 * 图标配置
 * 用法：路由路径作为 key，图标作为 value
 * 图标名称使用 Element Plus 的图标组件名
 */
const iconEnum: Record<string, string> = {
  // 日志管理
  "/uwAuthCenter/ops/log": "Memo",
  "/uwAuthCenter/ops/log/actionLog": "DocumentChecked",
  "/uwAuthCenter/ops/log/loginLog": "Document",
  "/uwAuthCenter/ops/log/critLog": "DocumentChecked",
  "/uwAuthCenter/ops/log/dataHistory": "Document",
  
  // 首页仪表盘
  "/uwAuthCenter/ops/home/dashboard": "Odometer",
  
  // 系统管理
  "/uwAuthCenter/ops/msc": "Operation",
};

// 导出函数：根据权限码获取对应图标
// 如果未配置则返回默认的 "Menu" 图标
export default (permCode: string) => {
  if (iconEnum[permCode]) return iconEnum[permCode];
  return "Menu";
};
```

**配置说明：**

| 属性 | 说明 |
|------|------|
| key | 路由路径（与菜单路由配置对应） |
| value | Element Plus 图标组件名称 |
| 默认值 | `Menu` - 当路由未配置图标时显示 |

**常用图标参考：**

| 图标名称 | 说明 |
|----------|------|
| `Memo` | 备忘录/日志 |
| `Document` | 文档 |
| `DocumentChecked` | 已检查文档 |
| `Odometer` | 仪表盘 |
| `Operation` | 操作/设置 |
| `Menu` | 菜单（默认） |

## 路由配置

### router 目录

| 文件 | 说明 |
|------|------|
| [index.ts](src/router/index.ts) | 路由入口配置，包含路由守卫、进度条、基础路由定义 |
| [uwAuthCenterRouter.ts](src/router/uwAuthCenterRouter.ts) | 权限中心业务路由配置 |
| [typings.d.ts](src/router/typings.d.ts) | 路由类型扩展声明 |

**路由配置特点：**

1. **自动导入路由模块** - 使用 `import.meta.glob` 自动导入 router 目录下的所有路由文件

```typescript
const RouterList = import.meta.glob(['./*', '!./index', '!./typings.d.ts'], {
  import: 'default',
  eager: true
})
```

2. **路由守卫** - 实现了完整的权限控制和页面进度条
   - Token 验证
   - 登录状态检查
   - 404 页面处理
   - 页面刷新路由恢复

3. **RouteMeta 扩展字段**

| 字段 | 类型 | 说明 |
|------|------|------|
| title | string | 路由标题 |
| icon | string | 路由图标 |
| isOwnHand | boolean | 是否手动添加的路由（无需权限限制） |
| isShowInSlideMenu | boolean | 是否在侧边栏菜单显示 |
| isHomePage | boolean | 是否是首页 |
| dynamicRoute | string | 动态路由匹配路径 |
| keepAlive | boolean | 是否缓存页面 |
| onlyShowContent | boolean | 是否只显示内容（隐藏头部、侧边栏等） |

**路由示例：**

```typescript
// 首页路由，不存在子级
{
  path: '/uwAuthCenter/ops/home/dashboard',
  name: 'uwAuthCenter.opsHomeDashboard',
  component: () =>
    import('@/pages/uwAuthCenter/ops/home/dashboard/index.vue'),
  meta: {
    title: '仪表盘',
    isOwnHand: true,  // 手动添加的路由
    isShowInSlideMenu: true,  // 是否显示在侧边菜单
    isHomePage: true,  // 是否是首页
  }
}

// 默认普通路由
{
  path: "/uwAuthCenter/ops/msc/mscPerm",
  name: "uwAuthCenter.opsMscMscPerm",
  component: () => import("@/pages/uwAuthCenter/ops/msc/mscPerm/index.vue"),
  meta: {
    title: "MSC权限管理",
  },
}

// 编辑页面的动态路由
{
  path: "/uwAuthCenter/ops/msc/mscAppHost/:type",
  name: "uwAuthCenter.opsMscMscAppHost",
  component: () =>
    import("@/pages/uwAuthCenter/ops/msc/mscAppHost/index.vue"),
  meta: {
    title: "MSC应用主机编辑页面",
    isOwnHand: true,  // 手动添加的路由
    isShowInSlideMenu: false,  // 是否显示在侧边菜单, 不显示在菜单栏上
    dynamicRoute: "/uwAuthCenter/ops/msc/mscAppHost",  // 动态路由真正的值，用于tab页签上匹配
  },
}
```

## 开发规范

### 自动引入

项目配置了自动引入，无需手动导入以下内容：

```typescript
// Vue API 自动引入
// 无需导入: ref, reactive, computed, watch, onMounted 等

// Vue Router API 自动引入
// 无需导入: useRoute, useRouter

// 组件自动引入
// src/components 下的组件自动引入，文件夹名即为组件名
```

### 国际化 (i18n)

项目支持 5 种语言：

| 语言代码 | 名称 |
|---------|------|
| zh-CN | 简体中文 |
| zh-TW | 繁體中文 |
| en | English |
| ja | 日本語 |
| ko | 한어 |

**在组件中使用：**

```vue
<script setup>
import { useI18n } from 'vue-i18n'
const { t, locale } = useI18n()
</script>

<template>
  <div>{{ t('hello') }}</div>
</template>
```

## 代码规范

### 提交规范

使用 Conventional Commits 规范：

| 类型 | 说明 |
|------|------|
| feat | 新功能 |
| fix | 修复问题 |
| docs | 文档更新 |
| style | 代码格式（不影响功能） |
| refactor | 重构 |
| perf | 性能优化 |
| test | 测试相关 |
| chore | 构建/工具相关 |
| revert | 还原提交 |
| build | 打包 |

**示例：**

```bash
git commit -m 'feat: 新增首页路由'
git commit -m 'fix: 修复登录页样式问题'
```

### 代码检查

```bash
# 运行代码检查并自动修复
pnpm lint
```

提交前会自动运行 lint-staged 检查 staged 文件。

## 布局系统

支持三种布局模式，可通过设置切换：

1. **default** - 默认布局（顶部导航 + 侧边菜单）
2. **vertical** - 垂直布局
3. **slide** - 侧边栏布局

## 主题定制

- **暗色模式**: 支持系统级暗色主题切换
- **主题色**: 支持动态修改主色调
- **侧边栏主题**: 支持自定义侧边栏背景色

## 内置组件

### 验证码组件 (Captcha)

| 组件 | 文件 | 说明 |
|------|------|------|
| ImageInputVerification | [ImageInputVerification.vue](src/components/Captcha/ImageInputVerification.vue) | 图片输入验证 |
| RotateVerify | [RotateVerify.vue](src/components/Captcha/RotateVerify.vue) | 旋转验证 |
| SliderCaptcha | [SliderCaptcha.vue](src/components/Captcha/SliderCaptcha.vue) | 滑块验证码 |
| TextClickCaptcha | [TextClickCaptcha.vue](src/components/Captcha/TextClickCaptcha.vue) | 文字点击验证码 |

### 其他组件

| 组件 | 说明 |
|------|------|
| Captcha | 验证码组件（图片、滑块、点击、旋转等类型） |
| ECharts | 图表封装组件 |
| LangSelect | 语言选择下拉框 |
| SearchForm | 搜索表单（支持配置化） |
| DataDiffTable | 数据对比表格 |
| DataHistoryLog | 数据历史日志 |
| HistoryLog | 操作历史日志 |
| CritLog | 关键日志 |
| QueryLog | 查询日志 |
| InputNumberRange | 数字范围输入 |
| InputTag | 标签输入 |
| MenuIcon | 菜单图标选择器 |
| ParamsConfigTable | 参数配置表格 |
| ParamsConfigTableByAdd | 新增参数配置表格 |
| TitleHeader | 标题头部 |
| ToolTipText | 提示文本 |
| Pagination | 分页组件 |
| ContextMenu | 右键菜单 |
| Icon | 图标组件（i18n/iAudit） |
| SettingForTheme | 主题设置 |

## API 模块

| 模块 | 文件 | 说明 |
|------|------|------|
| uwAuthCenterAuth | [uwAuthCenterAuthApi.ts](src/api/uwAuthCenterAuthApi.ts) | 认证中心认证接口 |
| uwAuthCenterOps | [uwAuthCenterOpsApi.ts](src/api/uwAuthCenterOpsApi.ts) | 认证中心运营管理接口 |
| uwAuthCenterUser | [uwAuthCenterUserApi.ts](src/api/uwAuthCenterUserApi.ts) | 认证中心用户接口 |

## Hooks 组合式函数

| Hook | 文件 | 说明 |
|------|------|------|
| useAbnormalMessage | [useAbnormalMessage.ts](src/hooks/useAbnormalMessage.ts) | 异常消息处理 |
| useActivated | [useActivated.ts](src/hooks/useActivated.ts) | 组件激活状态 |
| useCountdown | [useCountdown.ts](src/hooks/useCountdown.ts) | 倒计时功能 |
| useCrud | [useCrud.ts](src/hooks/useCrud.ts) | CRUD 操作封装 |
| useCustomDark | [useCustomDark.ts](src/hooks/useCustomDark.ts) | 暗色主题控制 |
| useExportExcel | [useExportExcel.ts](src/hooks/useExportExcel.ts) | Excel 导出功能 |
| usePermissionCode | [usePermissionCode.ts](src/hooks/usePermissionCode.ts) | 权限码校验 |
| usePolling | [usePolling.ts](src/hooks/usePolling.ts) | 轮询功能 |
| usePostMessage | [usePostMessage.ts](src/hooks/usePostMessage.ts) | 跨窗口通信 |
| usePrompt | [usePrompt.ts](src/hooks/usePrompt.ts) | 提示弹窗 |
| useSimplifyPrompt | [useSimplifyPrompt.ts](src/hooks/useSimplifyPrompt.ts) | 简化提示弹窗 |
| useValidate | [useValidate.ts](src/hooks/useValidate.ts) | 表单验证 |

## 自定义指令

| 指令 | 文件 | 说明 |
|------|------|------|
| v-permission | [permission.ts](src/directives/permission.ts) | 权限控制指令 |

## 工具函数

| 工具 | 文件 | 说明 |
|------|------|------|
| buildTreeMenu | [buildTreeMenu.ts](src/utils/buildTreeMenu.ts) | 构建树形菜单 |
| encryptionAndDecryption | [encryptionAndDecryption.ts](src/utils/encryptionAndDecryption.ts) | 加解密工具 |
| request | [request.ts](src/utils/request.ts) | Axios 请求封装 |
| selectOptions | [selectOptions.ts](src/utils/selectOptions.ts) | 下拉选项配置 |
| idValidate | [idValidate.ts](src/utils/idValidate.ts) | ID 验证 |
| tool | [tool.ts](src/utils/tool.ts) | 通用工具函数 |

## VSCode 插件推荐

### Vue3 项目必备

- **Vue Language Features (Volar)** - Vue 3 官方插件
- **TypeScript Vue Plugin (Volar)** - TypeScript 支持

> 注意：使用 Volar 时需要禁用 Vetur 插件

### 通用插件

- **Oxc** - 代码规范检查
- **Auto Rename Tag** - 自动重命名配对标签
- **Auto Close Tag** - 自动闭合标签
- **i18n Ally** - i18n 拓展提示工具
- **Code Spell Checker** - 代码拼写检查

## 浏览器兼容性

- Chrome >= 88
- Firefox >= 78
- Safari >= 14
- Edge >= 88

## 许可证

[MIT](LICENSE)
