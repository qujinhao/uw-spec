package uw.app;

import uw.auth.service.AuthServiceHelper;
import uw.auth.service.constant.UserType;
import uw.auth.service.token.AuthTokenData;

import java.lang.reflect.Method;

/**
 * 测试Auth注入工具类
 */
public class TestAuthUtils {

    /**
     * 测试SAAS ID
     */
    public static final Long TEST_SAAS_ID = 666L;
    /**
     * 测试商户ID
     */
    public static final Long TEST_MCH_ID = 666L;
    /**
     * 测试USER ID
     */
    public static final Long TEST_USER_ID = 666L;

    /**
     * 测试ROOT用户
     */
    public static void setRootUser() {
        setUserToken(UserType.ROOT, 0L, 0L, TEST_USER_ID);
    }

    /**
     * 测试RPC用户
     */
    public static void setRpcUser() {
        setUserToken(UserType.RPC, 0L, 0L, TEST_USER_ID);
    }

    /**
     * 测试OPS用户
     */
    public static void setOpsUser() {
        setUserToken(UserType.OPS, 0L, 0L, TEST_USER_ID);
    }

    /**
     * 测试ADMIN用户
     */
    public static void setAdminUser() {
        setUserToken(UserType.ADMIN, 0L, 0L, TEST_USER_ID);
    }

    /**
     * 设置为SAAS用户
     */
    public static void setSaasUser() {
        setUserToken(UserType.SAAS, TEST_SAAS_ID, 0L, TEST_USER_ID);
    }

    /**
     * 设置为商户用户
     */
    public static void setMchUser() {
        setUserToken(UserType.MCH, TEST_SAAS_ID, TEST_MCH_ID, TEST_USER_ID);
    }

    /**
     * 设置为游客。
     */
    public static void setGuestUser() {
        setUserToken(UserType.GUEST, TEST_SAAS_ID, TEST_MCH_ID, TEST_USER_ID);
    }

    /**
     * 设置为匿名用户。
     */
    public static void setAnyUser() {
        setUserToken(UserType.ANY, 0L, 0L, -1L);
    }

    /**
     * 设置测试用户token
     */
    public static void setUserToken(UserType userType, Long saasId, Long mchId, Long userId) {
        AuthTokenData tokenData = createAuthTokenData(saasId, mchId, userId, userType);
        try {
            Method method = AuthServiceHelper.class.getDeclaredMethod("setContextToken", AuthTokenData.class);
            method.setAccessible(true);
            method.invoke(null, tokenData);
        } catch (Exception e) {
            throw new RuntimeException("设置测试用户失败", e);
        }
    }

    /**
     * 清除测试用户token
     */
    public static void clearUserToken() {
        try {
            Method method = AuthServiceHelper.class.getDeclaredMethod("destroyContextToken");
            method.setAccessible(true);
            method.invoke(null);
        } catch (Exception e) {
            throw new RuntimeException("清除测试用户token失败", e);
        }
    }

    /**
     * 创建测试用户数据
     */
    private static AuthTokenData createAuthTokenData(Long saasId, Long mchId, Long userId, UserType userType) {
        AuthTokenData data = new AuthTokenData();
        data.setSaasId(saasId);
        data.setMchId(mchId);
        data.setUserId(userId);
        data.setUserType(userType.ordinal());
        data.setUserName("test_user_" + userId);
        data.setRealName("测试用户");
        data.setNickName("测试");
        data.setCreateAt(System.currentTimeMillis());
        data.setExpireAt(System.currentTimeMillis() + 3600000);
        return data;
    }
}
