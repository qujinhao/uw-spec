<script lang="ts" setup></script>

<template>
  <view class="m-button">
    <slot></slot>
  </view>
</template>

<style lang="scss" scoped>
.m-button {
  display: inline-block;
  padding: 8rpx 16rpx;
}
</style>
