<script lang="ts" setup>
import { useMainStore } from '@/store/main'

//  通用字典表类型，通用只读
interface commonType {
  readonly label: string
  readonly value: number | string
}

const mainStore = useMainStore()
const props = withDefaults(
  defineProps<{
    title: string
    subTitle?: string
    headerHeight?: string | number
    type?: 'status' | 'title'
    statusList?: commonType[]
    statusListPaddingLeft?: string | number
  }>(),
  {
    headerHeight: '22px',
    type: 'title',
    statusList: () => []
  }
)

const isDark = computed(() => mainStore.systemDark)

const title = computed(() => props.title)
</script>

<template>
  <div
    class="title-header-wrapper"
    :style="{ marginBottom: props.type === 'title' ? '15px' : 0 }"
  >
    <div
      :style="{
        height:
          typeof props.headerHeight === 'string'
            ? props.headerHeight
            : props.headerHeight + 'px'
      }"
      class="title-content"
    >
      <div
        class="space-between"
        style="align-items: center"
      >
        <div class="title-border"></div>
        <span
          :style="{
            color: isDark ? 'var(--el-table-header-text-color)' : '#1D3043'
          }"
        >
          {{ title }}
        </span>
        <span
          :style="{
            color: isDark ? 'var(--el-table-header-text-color)' : '#1D3043'
          }"
          v-if="props.subTitle"
          class="margin-left-5"
        >
          {{ props.subTitle }}
        </span>
      </div>
      <div>
        <slot></slot>
      </div>
    </div>
    <div
      v-if="props.type === 'status'"
      class="status-item-wrapper"
      :style="{
        paddingLeft:
          typeof statusListPaddingLeft === 'string'
            ? props.statusListPaddingLeft
            : props.statusListPaddingLeft + 'px'
      }"
    >
      <div
        class="item"
        v-for="item in props.statusList"
        :key="item.label"
      >
        <div
          class="label"
          :style="{
            background: isDark
              ? 'var(--el-main-container-background)'
              : '#F0F2F5',
            color: isDark ? 'var(--el-table-header-text-color)' : '#58585B'
          }"
        >
          {{ item.label }}
        </div>
        <div
          class="value"
          :style="{
            color: isDark ? 'var(--el-color-white)' : 'var(--el-color-black)'
          }"
        >
          {{ item.value }}
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped lang="scss">
.title-header-wrapper {
  .title-content {
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: 16px;
    font-weight: bold;
    margin: 5px 0 15px 0;
    padding-left: 20px;

    .title-border {
      width: 3px;
      height: 16px;
      background-color: var(--el-color-primary);
      border-radius: 2px;
    }

    span {
      padding-left: 5px;
    }
  }

  .status-item-wrapper {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    padding-left: 5px;

    .item {
      display: flex;
      align-items: center;
      box-sizing: border-box;
      padding: 5px 20px 5px 0;
      font-size: 14px;

      .label {
        padding: 5px 10px;
        height: 22px;
        color: #58585b;
        line-height: 22px;
        border-radius: 5px;
      }

      .value {
        height: 22px;
        line-height: 22px;
        padding-left: 10px;
      }
    }
  }
}
</style>
