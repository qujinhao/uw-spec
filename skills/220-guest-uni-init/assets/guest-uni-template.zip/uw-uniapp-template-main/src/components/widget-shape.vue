<template>
  <view
    class="shape"
    @click="setCurWidgetId(widget.id)"
  >
    <view
      v-if="curWidgetId == widget.id"
      class="shape-solid"
    ></view>

    <view class="shape-dashed"></view>

    <slot></slot>
  </view>
</template>

<script setup>
import { inject } from 'vue'
const curWidgetId = inject('curWidgetId')
const setCurWidgetId = inject('setCurWidgetId')
defineProps({
  widget: {
    type: Object,
    default: () => ({})
  }
})
</script>

<style lang="scss" scoped>
.shape {
  position: relative;

  &:hover {
    .shape-dashed {
      display: block;
    }
  }

  .shape-dashed {
    display: none;
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    border: dashed 1px #155bd4;
    z-index: 100;
  }

  .shape-solid {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    border: solid 1px #155bd4;
    z-index: 100;
  }
}
</style>
