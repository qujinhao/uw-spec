import type { commonType } from '@/api/type/API_TYPE'
import { computed } from 'vue'
import { useI18n } from 'vue-i18n'

/**
 * 返回多项公共的下拉类型，支持多语言切换
 * @returns
 */
export const useCommonSelectTypes = () => {
  const { t } = useI18n()
  // 依据value得到label
  const handleTypeForLabel = (
    data: string | number,
    findList: commonType[],
    staticValue?: string
  ): string => {
    const target = findList.find((item) => item.value === data)
    if (target) {
      return target.label
    } else {
      return staticValue ? staticValue : '--'
    }
  }
  //  登录类型
  const loginTypes = computed<commonType[]>(() => [
    {
      label: t('repeatedLogin'),
      value: -2
    },
    {
      label: t('kickOutUsers'),
      value: -4
    },
    {
      label: t('logOut'),
      value: -1
    },
    {
      label: t('TOKENRefresh'),
      value: 0
    },
    {
      label: t('loginWithUsernamePassword'),
      value: 1
    },
    {
      label: t('phoneNumberAndPasswordLogin'),
      value: 2
    },
    {
      label: t('emailPasswordLogin'),
      value: 3
    },
    {
      value: 20,
      label: t('TOTPRecoveryCodeLogin')
    },
    {
      value: 21,
      label: t('TOTPValidateCodeLogin')
    },
    {
      label: t('phoneValidateCodeLogin'),
      value: 23
    },
    {
      label: t('emailValidateCodeLogin'),
      value: 22
    },
    {
      label: t('WeChatCodeLogin'),
      value: 31
    }
  ])
  // 登录结果类型
  const loginResultTypes = computed<commonType[]>(() => {
    return [
      {
        label: t('success'),
        value: 'success'
      },
      {
        label: t('error'),
        value: 'error'
      },
      {
        label: t('catch'),
        value: 'warn'
      }
    ]
  })
  // 登录设备类型
  const loginDeviceTypes = computed<commonType[]>(() => {
    return [
      {
        label: 'PC-WEB',
        value: 0
      },
      {
        label: 'MOBILE-WEB',
        value: 2
      },
      {
        label: 'MOBILE-APP',
        value: 3
      },
      {
        label: 'WEIXIN-APP etc',
        value: 4
      }
    ]
  })
  // 状态类型
  const stateTypes = computed<commonType[]>(() => {
    return [
      {
        label: t('normal'),
        value: 1
      },
      {
        label: t('stop'),
        value: 0
      },
      {
        label: t('delete'),
        value: -1
      }
    ]
  })
  // 通用类型
  const commonTypes = computed<commonType[]>(() => {
    return [
      {
        label: t('enable'),
        value: 1
      },
      {
        label: t('disabled'),
        value: 0
      },
      {
        label: t('delete'),
        value: -1
      }
    ]
  })
  //  用户类型
  const userTypes = computed<commonType[]>(() => {
    return [
      {
        value: 0,
        label: '任意用户'
      },
      {
        value: 1,
        label: t('CStationUser')
      },

      {
        value: 10,
        label: t('RPCUser')
      },
      {
        value: 100,
        label: t('systemAdministrator')
      },
      {
        value: 110,
        label: t('DevelopOperationAndMaintenanceUsers')
      },

      {
        value: 200,
        label: t('SASSAdmin')
      },
      {
        value: 300,
        label: t('SASSOperator')
      },
      {
        value: 310,
        label: t('SAASMerchant')
      }
    ]
  })

  // 全部用户类型列表
  const getAllUserTypes = computed<commonType[]>(() => {
    return userTypes.value.filter((item) =>
      [100, 1, 10, 110, 0, 200, 300, 310].includes(Number(item.value))
    )
  })

  // 获得有菜单的用户类型
  const getMscMenuUserTypes = computed<commonType[]>(() => {
    return userTypes.value.filter((item) =>
      [100, 110, 200, 300, 310].includes(Number(item.value))
    )
  })
  // 获得ROOT可管理类型列表
  const getRootManageTypes = computed<commonType[]>(() => {
    return userTypes.value.filter((item) =>
      [100, 1, 110, 200].includes(Number(item.value))
    )
  })

  // 获得SAASROOT可管理类型列表
  const getSaasAdminManageTypes = computed<commonType[]>(() => {
    return userTypes.value.filter((item) => [200].includes(Number(item.value)))
  })

  // 获得SAASAdmin可管理类型列表
  const getSaasOperatorManageTypes = computed<commonType[]>(() => {
    return userTypes.value.filter((item) =>
      [300, 310].includes(Number(item.value))
    )
  })
  // 商户等级
  const gradeLevelTypes = computed<commonType[]>(() => {
    return [
      {
        value: 0,
        label: t('ordinaryDistributor')
      },
      {
        value: 1,
        label: t('youHaoGoodsDistribution')
      }
    ]
  })
  // 系统语言
  const systemLangTypes = computed(() => [
    {
      value: 'zh-CN',
      label: t('zh-cn')
    },
    {
      value: 'zh-TW',
      label: t('zh-tw')
    },
    {
      value: 'ja',
      label: t('ja')
    },
    {
      value: 'en',
      label: t('en')
    },
    {
      value: 'ko',
      label: t('ko')
    }
  ])
  // 货币类型
  const currencyTypes = computed<commonType[]>(() => [
    {
      value: 'CNY',
      label: t('CNY')
    },
    {
      value: 'USD',
      label: t('USD')
    },
    {
      value: 'HKD',
      label: t('HKD')
    },
    {
      value: 'JPY',
      label: t('JPY')
    },
    {
      value: 'MOP',
      label: t('MOP')
    },
    {
      value: 'TWD',
      label: t('TWD')
    },
    {
      value: 'EUR',
      label: t('EUR')
    },
    {
      value: 'GBP',
      label: t('GBP')
    },
    {
      value: 'THB',
      label: t('THB')
    },
    {
      value: 'VND',
      label: t('VND')
    },
    {
      value: 'KRW',
      label: t('KRW')
    },
    {
      value: 'SGD',
      label: t('SGD')
    },
    {
      value: 'BND',
      label: t('BND')
    },
    {
      value: 'INR',
      label: t('INR')
    },
    {
      value: 'KPW',
      label: t('KPW')
    },
    {
      value: 'MUR',
      label: t('MUR')
    },
    {
      value: 'USN',
      label: t('USN')
    },
    {
      value: 'USS',
      label: t('USS')
    },
    {
      value: 'CAD',
      label: t('CAD')
    },
    {
      value: 'IDR',
      label: t('IDR')
    },
    {
      value: 'NPR',
      label: t('NPR')
    },
    {
      value: 'LRD',
      label: t('LRD')
    },
    {
      value: 'MYR',
      label: t('MYR')
    },
    {
      value: 'RUR',
      label: t('RUR')
    },
    {
      value: 'CUP',
      label: t('CUP')
    },
    {
      value: 'BZD',
      label: t('BZD')
    },
    {
      value: 'GIP',
      label: t('GIP')
    },
    {
      value: 'HUF',
      label: t('HUF')
    },
    {
      value: 'GYD',
      label: t('GYD')
    },
    {
      value: 'KWD',
      label: t('KWD')
    },
    {
      value: 'CLP',
      label: t('CLP')
    },
    {
      value: 'HRK',
      label: t('HRK')
    },
    {
      value: 'SKK',
      label: t('SKK')
    },
    {
      value: 'XUA',
      label: t('XUA')
    },
    {
      value: 'DKK',
      label: t('DKK')
    },
    {
      value: 'BMD',
      label: t('BMD')
    },
    {
      value: 'FJD',
      label: t('FJD')
    },
    {
      value: 'SEK',
      label: t('SEK')
    },
    {
      value: 'XFU',
      label: t('XFU')
    },
    {
      value: 'SIT',
      label: t('SIT')
    },
    {
      value: 'XBD',
      label: t('XBD')
    },
    {
      value: 'VEF',
      label: t('VEF')
    },
    {
      value: 'CSD',
      label: t('CSD')
    },
    {
      value: 'XOF',
      label: t('XOF')
    },
    {
      value: 'XPF',
      label: t('XPF')
    },
    {
      value: 'FKP',
      label: t('FKP')
    },
    {
      value: 'SYP',
      label: t('SYP')
    },
    {
      value: 'BYN',
      label: t('BYN')
    },
    {
      value: 'OMR',
      label: t('OMR')
    },
    {
      value: 'ADP',
      label: t('ADP')
    },
    {
      value: 'NOK',
      label: t('NOK')
    },
    {
      value: 'AWG',
      label: t('AWG')
    },
    {
      value: 'IEP',
      label: t('IEP')
    },
    {
      value: 'LYD',
      label: t('LYD')
    },
    {
      value: 'ESP',
      label: t('ESP')
    },
    {
      value: 'KYD',
      label: t('KYD')
    },
    {
      value: 'BWP',
      label: t('BWP')
    },
    {
      value: 'LAK',
      label: t('LAK')
    },
    {
      value: 'DZD',
      label: t('DZD')
    },
    {
      value: 'MNT',
      label: t('MNT')
    },
    {
      value: 'SRG',
      label: t('SRG')
    },
    {
      value: 'MKD',
      label: t('MKD')
    },
    {
      value: 'LKR',
      label: t('LKR')
    },
    {
      value: 'TRL',
      label: t('TRL')
    },
    {
      value: 'GRD',
      label: t('GRD')
    },
    {
      value: 'MZM',
      label: t('MZM')
    },
    {
      value: 'DJF',
      label: t('DJF')
    },
    {
      value: 'ANG',
      label: t('ANG')
    },
    {
      value: 'MGA',
      label: t('MGA')
    },
    {
      value: 'BBD',
      label: t('BBD')
    },
    {
      value: 'BOB',
      label: t('BOB')
    },
    {
      value: 'GMD',
      label: t('GMD')
    },
    {
      value: 'XBC',
      label: t('XBC')
    },
    {
      value: 'IRR',
      label: t('IRR')
    },
    {
      value: 'BAM',
      label: t('BAM')
    },
    {
      value: 'AOA',
      label: t('AOA')
    },
    {
      value: 'RSD',
      label: t('RSD')
    },
    {
      value: 'TRY',
      label: t('TRY')
    },
    {
      value: 'RUB',
      label: t('RUB')
    },
    {
      value: 'KMF',
      label: t('KMF')
    },
    {
      value: 'TPE',
      label: t('TPE')
    },
    {
      value: 'ZWD',
      label: t('ZWD')
    },
    {
      value: 'JOD',
      label: t('JOD')
    },
    {
      value: 'NZD',
      label: t('NZD')
    },
    {
      value: 'ZMK',
      label: t('ZMK')
    },
    {
      value: 'PKR',
      label: t('PKR')
    },
    {
      value: 'NIO',
      label: t('NIO')
    },
    {
      value: 'SLL',
      label: t('SLL')
    },
    {
      value: 'FIM',
      label: t('FIM')
    },
    {
      value: 'GHC',
      label: t('GHC')
    },
    {
      value: 'ITL',
      label: t('ITL')
    },
    {
      value: 'UYU',
      label: t('UYU')
    },
    {
      value: 'AFA',
      label: t('AFA')
    },
    {
      value: 'ATS',
      label: t('ATS')
    },
    {
      value: 'LSL',
      label: t('LSL')
    },
    {
      value: 'SCR',
      label: t('SCR')
    },
    {
      value: 'ETB',
      label: t('ETB')
    },
    {
      value: 'XFO',
      label: t('XFO')
    },
    {
      value: 'COP',
      label: t('COP')
    },
    {
      value: 'MXN',
      label: t('MXN')
    },
    {
      value: 'LTL',
      label: t('LTL')
    },
    {
      value: 'UGX',
      label: t('UGX')
    },
    {
      value: 'ALL',
      label: t('ALL')
    },
    {
      value: 'BOV',
      label: t('BOV')
    },
    {
      value: 'AUD',
      label: t('AUD')
    },
    {
      value: 'DOP',
      label: t('DOP')
    },
    {
      value: 'XBA',
      label: t('XBA')
    },
    {
      value: 'BYB',
      label: t('BYB')
    },
    {
      value: 'MXV',
      label: t('MXV')
    },
    {
      value: 'XPD',
      label: t('XPD')
    },
    {
      value: 'XCD',
      label: t('XCD')
    },
    {
      value: 'GTQ',
      label: t('GTQ')
    },
    {
      value: 'RWF',
      label: t('RWF')
    },
    {
      value: 'HTG',
      label: t('HTG')
    },
    {
      value: 'SDG',
      label: t('SDG')
    },
    {
      value: 'ZAR',
      label: t('ZAR')
    },
    {
      value: 'CHW',
      label: t('CHW')
    },
    {
      value: 'BTN',
      label: t('BTN')
    },
    {
      value: 'AMD',
      label: t('AMD')
    },
    {
      value: 'PTE',
      label: t('PTE')
    },
    {
      value: 'AYM',
      label: t('AYM')
    },
    {
      value: 'TMM',
      label: t('TMM')
    },
    {
      value: 'KGS',
      label: t('KGS')
    },
    {
      value: 'PHP',
      label: t('PHP')
    },
    {
      value: 'BHD',
      label: t('BHD')
    },
    {
      value: 'PAB',
      label: t('PAB')
    },
    {
      value: 'MAD',
      label: t('MAD')
    },
    {
      value: 'BIF',
      label: t('BIF')
    },
    {
      value: 'XAF',
      label: t('XAF')
    },
    {
      value: 'MZN',
      label: t('MZN')
    },
    {
      value: 'NLG',
      label: t('NLG')
    },
    {
      value: 'CHF',
      label: t('CHF')
    },
    {
      value: 'TTD',
      label: t('TTD')
    },
    {
      value: 'ROL',
      label: t('ROL')
    },
    {
      value: 'YER',
      label: t('YER')
    },
    {
      value: 'PEN',
      label: t('PEN')
    },
    {
      value: 'STD',
      label: t('STD')
    },
    {
      value: 'SAR',
      label: t('SAR')
    },
    {
      value: 'XAG',
      label: t('XAG')
    },
    {
      value: 'SZL',
      label: t('SZL')
    },
    {
      value: 'AZM',
      label: t('AZM')
    },
    {
      value: 'ILS',
      label: t('ILS')
    },
    {
      value: 'ISK',
      label: t('ISK')
    },
    {
      value: 'XDR',
      label: t('XDR')
    },
    {
      value: 'ARS',
      label: t('ARS')
    },
    {
      value: 'BYR',
      label: t('BYR')
    },
    {
      value: 'YUM',
      label: t('YUM')
    },
    {
      value: 'TZS',
      label: t('TZS')
    },
    {
      value: 'IQD',
      label: t('IQD')
    },
    {
      value: 'SDD',
      label: t('SDD')
    },
    {
      value: 'BDT',
      label: t('BDT')
    },
    {
      value: 'GHS',
      label: t('GHS')
    },
    {
      value: 'ERN',
      label: t('ERN')
    },
    {
      value: 'TJS',
      label: t('TJS')
    },
    {
      value: 'GNF',
      label: t('GNF')
    },
    {
      value: 'XPT',
      label: t('XPT')
    },
    {
      value: 'CZK',
      label: t('CZK')
    },
    {
      value: 'UAH',
      label: t('UAH')
    },
    {
      value: 'MRO',
      label: t('MRO')
    },
    {
      value: 'GEL',
      label: t('GEL')
    },
    {
      value: 'MWK',
      label: t('MWK')
    },
    {
      value: 'HNL',
      label: t('HNL')
    },
    {
      value: 'AFN',
      label: t('AFN')
    },
    {
      value: 'LBP',
      label: t('LBP')
    },
    {
      value: 'NGN',
      label: t('NGN')
    },
    {
      value: 'XAU',
      label: t('XAU')
    },
    {
      value: 'VUV',
      label: t('VUV')
    },
    {
      value: 'TND',
      label: t('TND')
    },
    {
      value: 'EEK',
      label: t('EEK')
    },
    {
      value: 'CLF',
      label: t('CLF')
    },
    {
      value: 'MGF',
      label: t('MGF')
    },
    {
      value: 'XBB',
      label: t('XBB')
    },
    {
      value: 'SRD',
      label: t('SRD')
    },
    {
      value: 'ZWL',
      label: t('ZWL')
    },
    {
      value: 'CYP',
      label: t('CYP')
    },
    {
      value: 'ZWN',
      label: t('ZWN')
    },
    {
      value: 'CVE',
      label: t('CVE')
    },
    {
      value: 'QAR',
      label: t('QAR')
    },
    {
      value: 'DEM',
      label: t('DEM')
    },
    {
      value: 'BGL',
      label: t('BGL')
    },
    {
      value: 'VEB',
      label: t('VEB')
    },
    {
      value: 'MDL',
      label: t('MDL')
    },
    {
      value: 'MVR',
      label: t('MVR')
    },
    {
      value: 'CUC',
      label: t('CUC')
    },
    {
      value: 'KES',
      label: t('KES')
    },
    {
      value: 'LUF',
      label: t('LUF')
    },
    {
      value: 'GWP',
      label: t('GWP')
    },
    {
      value: 'TMT',
      label: t('TMT')
    },
    {
      value: 'BEF',
      label: t('BEF')
    },
    {
      value: 'PYG',
      label: t('PYG')
    },
    {
      value: 'CDF',
      label: t('CDF')
    },
    {
      value: 'UYI',
      label: t('UYI')
    },
    {
      value: 'NAD',
      label: t('NAD')
    },
    {
      value: 'LVL',
      label: t('LVL')
    },
    {
      value: 'CHE',
      label: t('CHE')
    },
    {
      value: 'EGP',
      label: t('EGP')
    },
    {
      value: 'RON',
      label: t('RON')
    },
    {
      value: 'ZMW',
      label: t('ZMW')
    },
    {
      value: 'PLN',
      label: t('PLN')
    },
    {
      value: 'PGK',
      label: t('PGK')
    },
    {
      value: 'MTL',
      label: t('MTL')
    },
    {
      value: 'KHR',
      label: t('KHR')
    },
    {
      value: 'SSP',
      label: t('SSP')
    },
    {
      value: 'SHP',
      label: t('SHP')
    },
    {
      value: 'MMK',
      label: t('MMK')
    },
    {
      value: 'WST',
      label: t('WST')
    },
    {
      value: 'JMD',
      label: t('JMD')
    },
    {
      value: 'COU',
      label: t('COU')
    },
    {
      value: 'TOP',
      label: t('TOP')
    },
    {
      value: 'BSD',
      label: t('BSD')
    },
    {
      value: 'SOS',
      label: t('SOS')
    },
    {
      value: 'SBD',
      label: t('SBD')
    },
    {
      value: 'CRC',
      label: t('CRC')
    },
    {
      value: 'AED',
      label: t('AED')
    },
    {
      value: 'XSU',
      label: t('XSU')
    },
    {
      value: 'UZS',
      label: t('UZS')
    },
    {
      value: 'BRL',
      label: t('BRL')
    },
    {
      value: 'KZT',
      label: t('KZT')
    },
    {
      value: 'ZWR',
      label: t('ZWR')
    },
    {
      value: 'BGN',
      label: t('BGN')
    },
    {
      value: 'FRF',
      label: t('FRF')
    },
    {
      value: 'XXX',
      label: t('XXX')
    }
  ])
  // 周数
  const weekTypes = computed(() => [
    {
      label: t('Sunday'),
      value: 0
    },
    {
      label: t('Monday'),
      value: 1
    },
    {
      label: t('Tuesday'),
      value: 2
    },
    {
      label: t('Wednesday'),
      value: 3
    },
    {
      label: t('Thursday'),
      value: 4
    },
    {
      label: t('Friday'),
      value: 5
    },
    {
      label: t('Saturday'),
      value: 6
    }
  ])
  // 订单状态类型
  const orderStateTypes = computed<commonType[]>(() => {
    return [
      {
        value: 0,
        label: t('initialState')
      },
      {
        value: 1,
        label: t('paid')
      },
      {
        value: 2,
        label: t('startExecution')
      },
      {
        value: 3,
        label: t('inProgress')
      },
      {
        value: 6,
        label: t('completed')
      },
      {
        value: -1,
        label: t('delete')
      }
    ]
  })
  // 发票类型
  const invoiceTypes = computed(() => [
    {
      label: t('valueAddedTaxOrdinaryInvoice'),
      value: 1
    },
    {
      label: t('VATInvoice'),
      value: 2
    }
  ])
  // 产品状态
  const productStatusTypes = computed<commonType[]>(() => [
    {
      label: t('onShelf'),
      value: 1
    },
    {
      label: t('offShelf'),
      value: 0
    },
    {
      label: t('delete'),
      value: -1
    }
  ])
  // 发票申请状态
  const invoiceStateTypes = computed<commonType[]>(() => {
    return [
      {
        label: t('invoiced'),
        value: 3
      },
      {
        label: t('rejected'),
        value: 2
      },
      {
        label: t('approved'),
        value: 1
      },
      {
        label: t('pendingApproval'),
        value: 0
      },
      {
        label: t('cancelled'),
        value: -1
      }
    ]
  })
  // 交易状态
  const StateAipBalanceDeal = computed(() => [
    {
      value: 0,
      label: t('unconfirmed')
    },
    {
      value: 1,
      label: t('auditConfirmation')
    },
    {
      value: -1,
      label: t('auditRefuse')
    },
    {
      value: 2,
      label: t('auditComplete')
    },
    {
      value: -2,
      label: t('auditFail')
    },
    {
      value: 3,
      label: t('success')
    },
    {
      value: -3,
      label: t('error')
    }
  ])
  // 常用枚举
  const commonTypeForShop = computed(() => [
    {
      label: t('normal'),
      value: 1
    },
    {
      label: t('expired'),
      value: 0
    },
    {
      label: t('delete'),
      value: -1
    }
  ])
  // 授权类型
  const TypeAipVendor = computed(() => [
    {
      label: t('quantityLicensingService'),
      value: 1
    },
    {
      label: t('applicationLicenseService'),
      value: 2
    },
    {
      label: t('applicationQuantityLicenseService'),
      value: 3
    },
    {
      label: t('taskService'),
      value: 6
    }
  ])

  // 日期选择器，快捷选项
  const shortcuts = computed(() => [
    {
      text: t('lastDay'),
      value: () => {
        const end = new Date()
        const start = new Date()
        start.setTime(start.getTime() - 3600 * 1000 * 24)
        return [start, end]
      }
    },
    {
      text: t('lastWeek'),
      value: () => {
        const end = new Date()
        const start = new Date()
        start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
        return [start, end]
      }
    },
    {
      text: t('lastMonth'),
      value: () => {
        const end = new Date()
        const start = new Date()
        start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
        return [start, end]
      }
    },
    {
      text: t('inThePastThreeMonths'),
      value: () => {
        const end = new Date()
        const start = new Date()
        start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
        return [start, end]
      }
    }
  ])
  // 组织类型
  const organizationalTypes = computed<commonType[]>(() => [
    {
      label: t('person'),
      value: 1
    },
    {
      label: t('enterprise'),
      value: 2
    }
  ])
  // 付费类型
  const payTypes = computed(() => [
    {
      label: t('unpaid'),
      value: 0
    },
    {
      label: t('payAnnualFee'),
      value: 1
    },
    {
      label: t('shareRevenue'),
      value: 2
    }
  ])

  // 在线支付方式
  const payTypeForOnline = computed(() => [
    {
      label: t('WECHATPay'),
      value: 'WECHAT'
    },
    {
      label: t('UNIONPAY'),
      value: 'UNIONPAY'
    },
    {
      label: t('ALIPAY'),
      value: 'ALIPAY'
    }
  ])

  // 公告状态
  const noticeState = computed(() => [
    {
      value: -1,
      label: t('delete')
    },
    {
      value: 0,
      label: t('unpublished')
    },
    {
      value: 1,
      label: t('published')
    },
    {
      value: 2,
      label: t('published')
    }
  ])
  // 工单状态
  const stateSupportTicket = computed(() => [
    {
      value: -1,
      label: t('delete')
    },
    {
      value: 0,
      label: t('pendingProcessing')
    },
    {
      value: 1,
      label: t('processing')
    },
    {
      value: 2,
      label: t('resolved')
    },
    {
      value: 3,
      label: t('closed')
    }
  ])
  // 紧急程度
  const levelType = computed(() => [
    { value: 1, label: t('general') },
    { value: 2, label: t('medium') },
    { value: 3, label: t('emergency') }
  ])

  // 入网状态
  const entryStates = computed(() => [
    { value: 'INIT', label: t('pendingApproval') },
    { value: 'AUDITED', label: t('approved') },
    { value: 'OVERRULE', label: t('applicationRejected') }
  ])

  // 结算卡类型
  const settleBankTypes = computed(() => [
    { value: 'TOPUBLIC', label: t('ofThePublic') },
    { value: 'TOPRIVATE', label: t('forPrivate') }
  ])

  // 结算方式
  const settlementModeTypes = computed(() => [
    { value: 'AUTO', label: t('automaticSettlement') },
    { value: 'SELF', label: t('selfSettlement') }
  ])

  // 结算周期
  const settlementPeriodTypes = computed(() => [
    { value: 'T1', label: t('settlementEveryOtherDay') },
    { value: 'D1', label: t('settlementNaturalOtherDay') }
  ])

  // 商户类型
  const merchantTypes = computed(() => [
    { value: 'ENTERPRISE', label: t('enterpriseMerchant') },
    { value: 'INSTITUTION', label: t('publicInstitutionMerchants') },
    { value: 'INDIVIDUALBISS', label: t('individualBusiness') },
    { value: 'PERSON', label: t('individualMerchant') },
    { value: 'SUBJECT_TYPE_OTHERS', label: t('otherOrganizations') }
  ])

  // 经营类别
  const merchantCategoryTypes = computed(() => [
    { value: 'OFFLINE_RETAIL', label: t('offlineRetail') },
    { value: 'FOOD_BEVERAGE', label: t('cateringFood') },
    { value: 'TICKETING_TRAVEL', label: t('ticketingTravel') },
    { value: 'EDUCATION_TRAINING', label: t('educationTraining') },
    { value: 'LIFE_ADVISORY_SERVICE', label: t('lifeConsultingServices') },
    {
      value: 'ENTERTAINMENT_FITNESS_SERVICES',
      label: t('entertainmentFitnessServices')
    },
    { value: 'MEDICAL_CARE', label: t('medicalTreatment') },
    { value: 'COLLECTION_AUCTION', label: t('collectAuction') },
    { value: 'LOGISTICS_EXPRESS', label: t('logisticsExpressDelivery') },
    { value: 'COMMUNICATION', label: t('communication') },
    { value: 'LIVING_PAYMENT', label: t('livingExpenses') },
    { value: 'HOTEL', label: t('hotel') },
    { value: 'HOME_FURNISHING', label: t('homeFurnishing') },
    { value: 'FASHION', label: t('fashion') },
    { value: 'REAL_ESTATE', label: t('realEstate') },
    { value: 'TRANSPORTATION_SERVICE', label: t('transportationServices') },
    { value: 'MACHINE_ELECTRON', label: t('mechanicalElectronic') },
    { value: 'DECORATION', label: t('decoration') },
    { value: 'GREEN_SEEDLING', label: t('nurseryGreening') },
    { value: 'MATERNAL_CHILD_PRODUCT', label: t('motherBabyToys') },
    { value: 'COLLECTION_PET', label: t('collectionPets') },
    {
      value: 'BOOK_STATIONERY_AUDIO_VIDEO',
      label: t('booksAudiovisualStationery')
    },
    { value: 'DIGITAL', label: t('numericalCode') },
    { value: 'DIGITAL_ENTERTAINMENT', label: t('digitalEntertainment') },
    { value: 'ABROAD', label: t('abroad') },
    { value: 'DIRECT_SELLING', label: t('directSales') },
    { value: 'OTHER', label: t('other') },
    { value: 'GOVERNMENT', label: t('governmentOrgans') },
    { value: '使领馆', label: t('embassiesConsulates') }
  ])

  // 信息发送状态
  const EnumMsgStates = computed(() => [
    { value: 0, label: t('notSent') },
    { value: 1, label: t('sending') },
    { value: 2, label: t('failInSend') },
    { value: 3, label: t('successfullySent') }
  ])

  // Aip对账状态
  const EnumAipBalanceBillStates = computed(() => [
    { value: 0, label: t('unconfirmed') },
    { value: 1, label: t('reconciliationInProgress') },
    { value: 2, label: t('reconciliationCompleted') },
    { value: -2, label: t('reconciliationFailed') },
    { value: 3, label: t('invoiceApplication') },
    { value: 4, label: t('invoiced') },
    { value: -4, label: t('invoiceFail') }
  ])

  // Aip交易类型
  const EnumAipBalanceDealStates = computed(() => [
    {
      value: 10,
      label: t('depositRecharge')
    },
    {
      value: -10,
      label: t('rechargeAndRefund')
    },
    {
      value: -11,
      label: t('depositConsumption')
    },
    {
      value: 11,
      label: t('depositConsumptionRefund')
    },
    {
      value: 12,
      label: t('depositIncome')
    },
    {
      value: -12,
      label: t('refundOfDepositIncome')
    },
    {
      value: -13,
      label: t('withdrawalOfDepositIncome')
    },
    {
      value: -33,
      label: t('rebateWithdrawal')
    },
    {
      value: 30,
      label: t('rebateIncome')
    },
    {
      value: -30,
      label: t('rebateCancellation')
    },
    {
      value: 20,
      label: t('creditRepayment')
    },
    {
      value: -21,
      label: t('creditConsumption')
    },
    {
      value: 21,
      label: t('creditConsumptionRefund')
    }
  ])
  // 余额类型
  const TypeAipBalance = computed(() => [
    {
      value: 1,
      label: t('prestore')
    }
  ])
  // 日志记录类型
  const recordType = computed(() => [
    {
      value: '0',
      label: t('notLogged')
    },
    {
      value: '1',
      label: t('record')
    },
    {
      value: '2',
      label: t('recordQuery')
    },
    {
      value: '3',
      label: t('recordTheReturnedResults')
    },
    {
      value: '4',
      label: t('recordAllInformation')
    }
  ])
  // 资质类型
  const qualificationTypes = computed(() => [
    {
      value: 'ORG_CERT',
      label: t('businessLicense')
    },
    {
      value: 'ID_CARD_INFO',
      label: t('idCardInfo')
    },
    {
      value: 'ID_CARD_SIGN',
      label: t('idCardSign')
    },
    {
      value: 'ID_CARD_HOLD',
      label: t('idCardHold')
    },
    {
      value: 'BANK_CARD',
      label: t('bankCard')
    },
    {
      value: 'BANK_CARD_HOLD',
      label: t('bankCarHold')
    },
    {
      value: 'ORG_IMG_SIGN',
      label: t('orgImgSign')
    },
    {
      value: 'ORG_IMG_INNER',
      label: t('orgImgInner')
    }
  ])
  // 审核状态
  const auditStateTypes = computed(() => [
    {
      value: -1,
      label: t('auditRefuse')
    },
    {
      value: 0,
      label: t('pendingApproval')
    },
    {
      value: 1,
      label: t('approved')
    }
  ])
  // 公告对象类型
  const announcementObjectType = computed(() => [
    {
      value: 1,
      label: t('guestUser')
    },
    {
      value: 16,
      label: t('operator')
    },
    {
      value: 32,
      label: t('merchant')
    }
  ])
  // 公告发布类型
  const noticeReleaseTypes = computed(() => [
    {
      value: 1,
      label: t('publishNow')
    },
    {
      value: 2,
      label: t('scheduledRelease')
    },
    {
      value: 3,
      label: t('notYetReleased')
    }
  ])
  // 授权管理状态
  const aipLicenseStates = computed(() => [
    {
      value: -1,
      label: t('deactivated')
    },
    {
      value: 0,
      label: t('notEffective')
    },
    {
      value: 1,
      label: t('enablingInProgress')
    }
  ])

  // 优惠券类型---暂时，枚举没出来
  const couponTypesForSassMall = computed(() => [
    {
      value: 1,
      label: t('fullReduction')
    },
    {
      value: 2,
      label: t('discount')
    }
  ])
  // 优惠券限制类型---暂时，枚举没出来
  const couponLimitTypeForSassMall = computed(() => [
    {
      value: 1,
      label: '限制1'
    },
    {
      value: 2,
      label: '限制2'
    }
  ])

  // 预约日期类型--暂时，枚举没出来
  const useDateTypesForSassMall = computed(() => [
    {
      value: 1,
      label: t('panicBuyingInDay')
    },
    {
      value: 1,
      label: t('panicBuyingInDate')
    },
    {
      value: 3,
      label: t('panicBuyingInDateRange')
    }
  ])
  // saas-mall 订单状态--暂时，枚举没出来
  const orderStateForSassMall = computed(() => [
    {
      value: 0,
      label: t('lockOrder')
    },
    {
      value: 1,
      label: t('unlockOrder')
    }
  ])

  // poi 类型
  const typePoiForSassMall = computed(() => [
    {
      value: 0,
      label: t('scenicSpot')
    },
    {
      value: 1,
      label: t('hotel')
    }
  ])
  // 开放类型
  const openTypeForSassMall = computed(() => [
    {
      value: 0,
      label: '开放1'
    },
    {
      value: 1,
      label: '开放2'
    }
  ])
  // 申请类型
  const applyTypeForSassMall = computed(() => [
    {
      value: -1,
      label: t('delete')
    },
    {
      value: 0,
      label: t('add')
    },
    {
      value: 1,
      label: t('change')
    }
  ])
  // 供应商端状态
  const supplierStateForSassMall = computed(() => [
    {
      value: 0,
      label: t('offShelf')
    },
    {
      value: 1,
      label: t('onShelf')
    }
  ])
  // 海报类型
  const posterTypeForSassMall = computed(() => [
    {
      value: 1,
      label: t('productLinkCodePoster')
    },
    {
      value: 2,
      label: t('publicNumberPoster')
    },
    {
      value: 3,
      label: t('miniProgramCodePoster')
    }
  ])
  // 客人资料要求
  const guestFormTypeForSassMall = computed(() => [
    {
      value: 0,
      label: t('noNeedToFillIn')
    },
    {
      value: 1,
      label: t('needOnPersonFillIn')
    },
    {
      value: 2,
      label: t('needEveryoneFillIn')
    }
  ])
  // 联系人资料
  const guestFormForSassMall = computed(() => [
    {
      value: 0,
      label: t('name')
    },
    {
      value: 1,
      label: t('namePinyin')
    },
    {
      value: 2,
      label: t('gender')
    },
    {
      value: 3,
      label: t('mobileNumberMainlandChina')
    },
    {
      value: 4,
      label: t('phoneNumber')
    },
    {
      value: 5,
      label: t('email')
    }
  ])
  // 游客基本信息
  const guestDataType = computed(() => [
    {
      value: 0,
      label: t('guestName')
    },
    {
      value: 1,
      label: t('pinyinOfTouristName')
    },
    {
      value: 2,
      label: t('guestGender')
    },
    {
      value: 3,
      label: t('mobileNumberMainlandChina')
    },
    {
      value: 4,
      label: t('phoneNumber')
    },
    {
      value: 5,
      label: t('guestAddress')
    },
    {
      value: 6,
      label: t('guestEmail')
    }
  ])
  // 游玩有效期
  const useDateTypeForSassMall = computed(() => [
    {
      value: 0,
      label: t('playInToday')
    },
    {
      value: 1,
      label: t('orderInDay')
    },
    {
      value: 2,
      label: t('orderInDateRange')
    },
    {
      value: 3,
      label: t('playAfterDay')
    },
    {
      value: 4,
      label: t('playAfterDateRange')
    },
    {
      value: 5,
      label: t('specifyDateInRange')
    }
  ])
  // 验证类型
  const validateTypeForSassMall = computed(() => [
    {
      value: 0,
      label: t('oneCodeOneVerificationCode')
    },
    {
      value: 1,
      label: t('oneCodeMoreVerificationCode')
    }
  ])
  // 凭证类型
  const voucherTypeForSassMall = computed(() => [
    {
      value: 1,
      label: t('qrCode')
    },
    {
      value: 2,
      label: t('idCard')
    },
    {
      value: 3,
      label: t('qrcodeOrIdCard')
    },
    {
      value: 4,
      label: t('digital')
    },
    {
      value: 5,
      label: t('phoneNumber')
    },
    {
      value: 6,
      label: t('other')
    }
  ])
  // 是否导入全球货仓
  const shareTypeForSassMall = computed(() => [
    {
      value: 0,
      label: t('yes')
    },
    {
      value: 1,
      label: t('no')
    }
  ])
  // 确认类型
  const confirmTypeForSassMall = computed(() => [
    {
      value: 0,
      label: t('manualConfirmation')
    },
    {
      value: 1,
      label: t('automaticConfirmation')
    }
  ])
  // 产品类型
  const skuTypeForSassMall = computed(() => [
    {
      value: 0,
      label: t('hotel')
    },
    {
      value: 1,
      label: t('scenicSpot')
    }
  ])
  // 是否提示 0:无需弹屏提示,1:需要弹屏提示
  const msgTypeForSassMall = computed(() => [
    {
      value: 0,
      label: t('noPopUp')
    },
    {
      value: 1,
      label: t('needPopUp')
    }
  ])

  // 凭证模板管理类型
  const templateManageTypeForSassMall = computed(() => [
    {
      value: 0,
      label: t('email')
    },
    {
      value: 1,
      label: t('electron')
    },
    {
      value: 2,
      label: t('ticketIssuingSMS')
    },
    {
      value: 3,
      label: t('bookSMS')
    }
  ])
  // saas-mall 规格、单位、产品多语言
  const langTypesForSaasMall = computed(() => [
    {
      value: 'zh-CN',
      label: t('zh-cn')
    },
    {
      value: 'zh-TW',
      label: t('zh-tw')
    },
    {
      value: 'en',
      label: t('en')
    },
    {
      value: 'ja',
      label: t('ja')
    },
    {
      value: 'ko',
      label: t('ko')
    },
    {
      value: 'fr',
      label: t('fr')
    },
    {
      value: 'de',
      label: t('de')
    },
    {
      value: 'ru',
      label: t('ru')
    },
    {
      value: 'es',
      label: t('es')
    },
    {
      value: 'ar',
      label: t('ar')
    }
  ])
  // 销售范围
  const typeSaleRange = computed(() => [
    {
      value: 0,
      label: t('peersDirectCustomers')
    },
    {
      value: 1,
      label: t('onlyForPeers')
    },
    {
      value: 2,
      label: t('onlyForDirectCustomers')
    }
  ])
  // 性别
  const TypeGender = computed(() => [
    {
      label: t('man'),
      value: 0
    },
    {
      value: 1,
      label: t('woman')
    }
  ])

  // 证件类型
  const idTypes = computed(() => [
    {
      value: 0,
      label: '身份证'
    },
    {
      value: 1,
      label: '护照'
    },
    {
      value: 2,
      label: '香港身份证'
    },
    {
      value: 3,
      label: '澳门身份证'
    },
    {
      value: 4,
      label: '台胞证'
    },
    {
      value: 5,
      label: '外国人永久居留证'
    },
    {
      value: 10,
      label: '警官证'
    },
    {
      value: 11,
      label: '军官证'
    },
    {
      value: 12,
      label: '士兵证'
    },
    {
      value: 13,
      label: '外交官证'
    }
  ])
  // 订单完成类型
  const autoFinishType = computed(() => [
    {
      label: t('completedOrderAfterExpirationDate'),
      value: 1
    },
    {
      label: t('manualVerification'),
      value: 2
    },
    {
      label: t('refundForExpiredUnusedItems'),
      value: 3
    }
  ])
  // 游客证件类型
  const guestPapersType = computed(() => [
    {
      label: t('guestIdCard'),
      value: 0
    },
    {
      label: t('touristPassport'),
      value: 1
    },
    {
      label: t('passport'),
      value: 2
    },
    {
      label: t('taiwanCompatriotCertificate'),
      value: 3
    },
    {
      label: t('taiwanPass'),
      value: 4
    },
    {
      label: t('certificateOfOfficers'),
      value: 5
    },
    {
      label: t('policeOfficerCertificate'),
      value: 6
    },
    {
      label: t('driverLicense'),
      value: 7
    },
    {
      label: t('seamanBook'),
      value: 8
    },
    {
      label: t('residencePermitByHK'),
      value: 9
    },
    {
      label: t('idCardByHK'),
      value: 10
    },
    {
      label: t('idCardByForeigner'),
      value: 11
    },
    {
      label: t('mainlandTravelPermitByHK'),
      value: 12
    }
  ])
  // 分销商退款规则
  const refundTypesForDistributor = computed(() => [
    {
      label: t('distributionUnitPrice') + '-',
      value: 0
    },
    {
      label: t('distributionUnitPrice') + '*',
      value: 1
    },
    {
      label: t('totalDistributionAmount') + '-',
      value: 2
    },
    {
      label: t('totalDistributionAmount') + '*',
      value: 3
    }
  ])
  // 供应商退款规则
  const refundTypesForSupplier = computed(() => [
    {
      label: t('purchaseUnitPrice') + '-',
      value: 0
    },
    {
      label: t('purchaseUnitPrice') + '*',
      value: 1
    },
    {
      label: t('totalPurchaseAmount') + '-',
      value: 2
    },
    {
      label: t('totalPurchaseAmount') + '*',
      value: 3
    }
  ])
  // 游客退款规则
  const refundTypesForGuest = computed(() => [
    {
      label: t('retailUnitPrice') + '-',
      value: 0
    },
    {
      label: t('retailUnitPrice') + '*',
      value: 1
    },
    {
      label: t('totalRetailAmount') + '-',
      value: 2
    },
    {
      label: t('totalRetailAmount') + '*',
      value: 3
    }
  ])

  // 用户性别
  const genderTypes = computed(() => [
    {
      label: '男',
      value: 1
    },
    {
      label: '女',
      value: 0
    },
    {
      label: '未知',
      value: -1
    }
  ])

  // 订单状态
  const StateOrderOptions = [
    { label: '初始状态', value: 0 },
    { label: '新订单', value: 10 },
    { label: '已审核', value: 11 },
    { label: '下单失败', value: 19 },
    { label: '支付中', value: 20 },
    { label: '支付成功', value: 21 },
    { label: '支付超时', value: 28 },
    { label: '支付失败', value: 29 },
    { label: '预定中', value: 30 },
    { label: '已确认', value: 31 },
    { label: '已拒单', value: 39 },
    { label: '取消审核中', value: 40 },
    { label: '允许取消', value: 41 },
    { label: '已取消', value: 42 },
    { label: '订单超时取消', value: 47 },
    { label: '取消失败', value: 49 },
    { label: '开始退款', value: 50 },
    { label: '退款成功', value: 51 },
    { label: '退款失败', value: 59 },
    { label: '发货中', value: 60 },
    { label: '已发货', value: 61 },
    { label: '已签收', value: 62 },
    { label: '发货失败', value: 69 },
    { label: '预约中', value: 70 },
    { label: '预约成功', value: 71 },
    { label: '订单离线', value: 76 },
    { label: '预约失败', value: 79 },
    { label: '核销中', value: 90 },
    { label: '核销完毕', value: 91 },
    { label: '核销失败', value: 99 }
  ]

  // SKU 产品类型
  const TypeSkuOptions = [
    { label: '产品', value: 1 },
    { label: '场次', value: 2 },
    { label: '规格', value: 3 }
  ]

  return {
    handleTypeForLabel,
    stateTypes,
    TypeAipVendor,
    commonTypeForShop,
    invoiceStateTypes,
    orderStateTypes,
    loginTypes,
    loginResultTypes,
    loginDeviceTypes,
    commonTypes,
    userTypes,
    gradeLevelTypes,
    systemLangTypes,
    currencyTypes,
    getAllUserTypes,
    getMscMenuUserTypes,
    getRootManageTypes,
    getSaasAdminManageTypes,
    getSaasOperatorManageTypes,
    invoiceTypes,
    shortcuts,
    organizationalTypes,
    payTypes,
    payTypeForOnline,
    noticeState,
    stateSupportTicket,
    levelType,
    entryStates,
    settleBankTypes,
    settlementModeTypes,
    settlementPeriodTypes,
    merchantTypes,
    merchantCategoryTypes,
    EnumMsgStates,
    EnumAipBalanceBillStates,
    EnumAipBalanceDealStates,
    TypeAipBalance,
    StateAipBalanceDeal,
    recordType,
    qualificationTypes,
    auditStateTypes,
    announcementObjectType,
    noticeReleaseTypes,
    aipLicenseStates,
    weekTypes,
    couponTypesForSassMall,
    couponLimitTypeForSassMall,
    useDateTypesForSassMall,
    orderStateForSassMall,
    typePoiForSassMall,
    openTypeForSassMall,
    applyTypeForSassMall,
    supplierStateForSassMall,
    posterTypeForSassMall,
    guestFormTypeForSassMall,
    guestFormForSassMall,
    validateTypeForSassMall,
    voucherTypeForSassMall,
    shareTypeForSassMall,
    confirmTypeForSassMall,
    useDateTypeForSassMall,
    skuTypeForSassMall,
    productStatusTypes,
    msgTypeForSassMall,
    templateManageTypeForSassMall,
    langTypesForSaasMall,
    typeSaleRange,
    TypeGender,
    autoFinishType,
    guestDataType,
    guestPapersType,
    refundTypesForDistributor,
    refundTypesForSupplier,
    refundTypesForGuest,
    genderTypes,
    idTypes,
    StateOrderOptions,
    TypeSkuOptions
  }
}
