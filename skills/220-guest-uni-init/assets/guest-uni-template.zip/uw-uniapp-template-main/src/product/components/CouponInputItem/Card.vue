<template>
  <view class="item">
    <view
      class="top"
      @click="select"
    >
      <view class="left">
        <view
          class="price"
          :class="{ fontAaa: tabIndex === 1 }"
        >
          {{ currency }}
          <text :class="{ fontAaa: tabIndex === 1 }">
            {{ data.couponMoney }}
          </text>
        </view>
      </view>
      <view class="center">
        <text
          class="title"
          :class="{ fontAaa: tabIndex === 1 }"
        >
          {{ data.couponName }}
        </text>
      </view>
      <view
        class="select"
        v-if="tabIndex !== 1"
      >
        <u-icon
          v-if="active"
          name="checkmark-circle-fill"
          size="40"
          color="#F47F02"
        />
        <view
          v-else
          class="icon"
        />
      </view>
    </view>
    <view class="bottom">
      <view class="info">
        <view
          class="time"
          :class="{ fontAaa: tabIndex === 1 }"
        >
          {{ formatData(data) }}
        </view>
        <view
          class="show_tips"
          @click.stop="showTipsStatus = !showTipsStatus"
        >
          <text>详细规则</text>
          <u-icon :name="showTipsStatus ? 'arrow-up' : 'arrow-down'" />
        </view>
      </view>
      <view
        v-if="showTipsStatus"
        class="rules"
      >
        {{ showTips(data.useRules, data.useNote) }}
      </view>
    </view>
  </view>
</template>

<script lang="ts" setup>
import { ref, computed } from 'vue'
import { showTips, formatData } from '@/utils/coupon/tool'
import { useUserStore } from '@/store/user'

interface CouponData {
  couponMoney: string | number
  couponName: string
  receiveId: string | number
  useRules: any
  useNote: string
  // 其他可能的数据字段
}

const props = defineProps<{
  data: CouponData
  tabIndex: number
  selectList: Array<string | number>
}>()

const emit = defineEmits<{
  (
    e: 'select',
    receiveId: string | number,
    isCheck: boolean,
    data: CouponData
  ): void
}>()

const userStore = useUserStore()
const showTipsStatus = ref(false)

const currency = computed(() => userStore.currencyCN)
const active = computed(() => props.selectList.includes(props.data.receiveId))

const select = () => {
  emit('select', props.data.receiveId, false, props.data)
}
</script>

<style lang="scss" scoped>
.item {
  display: flex;
  flex-direction: column;
  min-height: 245rpx;
  margin-top: 20rpx;
  padding: 0 32rpx;
  background: #fff;
  border-radius: 20rpx;
  > .top {
    display: flex;
    height: 182rpx;
    border-bottom: 1rpx solid #f6f6f6;
    > .left {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      width: 220rpx;
      margin: 32rpx 0 26rpx;
      border-right: 1rpx solid #f6f6f6;
      > .price {
        margin-left: -20rpx;
        font-size: 30rpx;
        font-weight: 500;
        color: #f47f02;
        > text {
          font-size: 68rpx;
          color: #f47f02;
        }
      }
      > .sub {
        font-size: 26rpx;
        color: #666;
      }
    }
    > .center {
      flex-grow: 1;
      display: flex;
      flex-direction: column;
      justify-content: center;
      padding-left: 27rpx;
      > .title {
        margin-bottom: 16rpx;
        font-size: 30rpx;
        font-weight: 500;
        color: #28303a;
      }
      > .time {
        font-size: 24rpx;
        font-weight: 400;
        color: #bcbcbc;
      }
    }
    > .select {
      flex-shrink: 0;
      display: flex;
      justify-content: center;
      align-items: center;
      padding-right: 31rpx;
    }
  }
  > .bottom {
    display: flex;
    flex-direction: column;
    padding: 20rpx 0;
    > .info {
      display: flex;
      justify-content: space-between;
      font-size: 26rpx;
      > .time {
        color: #bcbcbc;
      }
      > .show_tips {
        color: #999;
        > text:first-child {
          margin-right: 20rpx;
        }
      }
    }
    > .rules {
      word-break: break-all;
      margin-top: 20rpx;
      font-size: 26rpx;
      color: #aaa;
    }
  }
}
</style>

<style lang="scss">
.icon {
  width: 34rpx;
  height: 34rpx;
  border: 1rpx solid #d5d5d5;
  border-radius: 50%;
}
.fontAaa {
  color: #aaa !important;
}
</style>
