<script lang="ts" setup>
import { useMainStore } from '@/store/main'
import LangSelect from '@/components/LangSelect/index.vue'
import { useI18n } from 'vue-i18n'
import { ElNotification } from 'element-plus'
// 头像图片
import header1 from '@/assets/headerImg/img1.png'
import header2 from '@/assets/headerImg/img2.png'
import header3 from '@/assets/headerImg/img3.png'
import header4 from '@/assets/headerImg/img4.png'
import header5 from '@/assets/headerImg/img5.png'
import header6 from '@/assets/headerImg/img6.png'
import header7 from '@/assets/headerImg/img7.png'
import header8 from '@/assets/headerImg/img8.png'
import header9 from '@/assets/headerImg/img9.png'
import header10 from '@/assets/headerImg/img10.png'
import header11 from '@/assets/headerImg/img11.png'
import header12 from '@/assets/headerImg/img12.png'
import header13 from '@/assets/headerImg/img13.png'
import header14 from '@/assets/headerImg/img14.png'
import header15 from '@/assets/headerImg/img15.png'
import header16 from '@/assets/headerImg/img16.png'

const emits = defineEmits<{
  (e: 'showSettingForTheme', val: boolean): void
  (e: 'showSystemInfo', val: boolean): void
  (e: 'updateActiveMenu', val: string): void
}>()

const { t } = useI18n()
const router = useRouter()
const route = useRoute()
const mainStore = useMainStore()

const userInfo = computed(() => {
  return mainStore.userInfo
})

const clickUser = (index: number) => {
  // 用户资料
  if (index === 1) router.push('/userInfo')
  // 关于
  if (index === 2) emits('showSystemInfo', true)
  // 退出
  if (index === 3) mainStore.Logout()
  // 个性化设置
  if (index === 4) emits('showSettingForTheme', true)
}

// 点击全屏
const clickFullScreen = () => {
  if (!document.fullscreenElement) {
    document.documentElement.requestFullscreen()
  } else {
    document.exitFullscreen()
  }
}

// 强制登录提示
const loginNotice = computed(() => mainStore.loginInfo.loginNotice)
// 是否加载过强制登录提示
const hasLoadLoginNotice = computed(() => mainStore.hasLoadLoginNotice)
// 强制登录提示
const handleForceLoginTip = () => {
  // 网站打开后是否加载了
  if (loginNotice.value && !hasLoadLoginNotice.value) {
    ElNotification({
      title: t('tip'),
      message: loginNotice.value,
      type: 'warning',
      duration: 0
    })
    mainStore.setHasLoadLoginNotice(true)
  }
}

// 头像列表
const headerImgList = [
  header1,
  header2,
  header3,
  header4,
  header5,
  header6,
  header7,
  header8,
  header9,
  header10,
  header11,
  header12,
  header13,
  header14,
  header15,
  header16
]

// 用户头像回显
const userIcon = computed(() => {
  return userInfo.value.userIcon
    ? headerImgList[Number(userInfo.value.userIcon)]
    : header1
})

// 面包屑
const breadcrumbList = computed(() => {
  const returnRoutes: any[] = []
  const matchRoutes = route.matched.filter(item => item.meta && item.meta.title)
  matchRoutes.forEach(item => {
    if (item.path.includes(':')) {
      item.path = route.path
    }
    returnRoutes.push(item)
  })
  let index = returnRoutes.length - 1
  const target = returnRoutes[index]
  if (!target.meta.isHomePage && target.path !== '/userInfo') {
    const lastIndex = target.path.lastIndexOf('/')
    returnRoutes[index] = {
      path: target.path.slice(0, lastIndex)
    }
    ++index
    // 如果是手动添加的路由，可能匹配的值会出现问题
    if (target.meta.dynamicRoute) {
      returnRoutes[index] = {
        ...target,
        path: route.path
      }
    } else {
      returnRoutes[index] = target
    }
  }
  return returnRoutes
})

// 当前的一级菜单名
const currentAppName = computed(() => {
  return mainStore.appMenu[mainStore.navIndex]?.appName || ''
})

const currentHomePath = computed(() => {
  if (mainStore.appMenu.length === 0) return '/'
  let path = ''
  const route = mainStore.appMenu[mainStore.navIndex]
  if (route.children) {
    const childrenItem = route.children
    for (let i = 0; i < childrenItem.length; i++) {
      const item = childrenItem[i]
      if (item.children && item.children.length) {
        const li = item.children
        path = li[0].permCode!
        break
      } else {
        path = item.permCode!
        break
      }
    }
  }
  return path
})

// 处理点击首页
const handleGoHome = () => {
  emits('updateActiveMenu', currentHomePath.value)
}

const clickCollapse = () => {
  mainStore.setCollapse()
}

const asideWidth = computed(() => {
  return !mainStore.collapse ? '200px' : '60px'
})

onMounted(() => {
  if (!userInfo.value.id) {
    // 获取当前用户信息
    mainStore.handleUserProfile()
  }
  // 处理强制登录提示
  handleForceLoginTip()
})
</script>

<template>
  <el-header class="layout-header space-between">
    <div class="layout-header__main flex-align space-between">
      <!-- 面包屑 -->
      <div class="flex-align layout-breadcrumb padding-10">
        <el-icon
          size="20px"
          class="layout-collapse__icon padding-right-5"
          @click="clickCollapse"
        >
          <svg
            data-v-92973da6=""
            viewBox="0 0 1024 1024"
            xmlns="http://www.w3.org/2000/svg"
            width="64"
            height="64"
            class="hamburger is-active"
            :style="{
              transform: mainStore.collapse ? 'rotate(0deg)' : 'rotate(180deg)'
            }"
          >
            <path
              data-v-92973da6=""
              d="M408 442h480c4.4 0 8-3.6 8-8v-56c0-4.4-3.6-8-8-8H408c-4.4 0-8 3.6-8 8v56c0 4.4 3.6 8 8 8zm-8 204c0 4.4 3.6 8 8 8h480c4.4 0 8-3.6 8-8v-56c0-4.4-3.6-8-8-8H408c-4.4 0-8 3.6-8 8v56zm504-486H120c-4.4 0-8 3.6-8 8v56c0 4.4 3.6 8 8 8h784c4.4 0 8-3.6 8-8v-56c0-4.4-3.6-8-8-8zm0 632H120c-4.4 0-8 3.6-8 8v56c0 4.4 3.6 8 8 8h784c4.4 0 8-3.6 8-8v-56c0-4.4-3.6-8-8-8zM142.4 642.1L298.7 519a8.84 8.84 0 0 0 0-13.9L142.4 381.9c-5.8-4.6-14.4-.5-14.4 6.9v246.3a8.9 8.9 0 0 0 14.4 7z"
            ></path>
          </svg>
        </el-icon>
        <el-breadcrumb separator-icon="ArrowRight">
          <el-breadcrumb-item
            :to="{ path: currentHomePath }"
            @click="handleGoHome"
          >
            {{ t(currentAppName) }}
          </el-breadcrumb-item>
          <TransitionGroup>
            <el-breadcrumb-item
              v-for="(item, index) in breadcrumbList"
              :key="item.path"
              :class="{
                specialStyle: breadcrumbList.length === 2 && index === 0
              }"
            >
              <span>{{ $t(item.path) }}</span>
            </el-breadcrumb-item>
          </TransitionGroup>
        </el-breadcrumb>
      </div>
      <!-- 顶部 右侧菜单栏 -->
      <div class="header-main__right flex-align">
        <div
          class="padding-right-20 flex-align cursor-p"
          @click="clickFullScreen"
        >
          <el-tooltip
            effect="dark"
            :content="t('fullScreen')"
            placement="bottom"
          >
            <el-icon color="var(--el-text-color-primary)">
              <FullScreen />
            </el-icon>
          </el-tooltip>
        </div>
        <div class="padding-right-20 flex-align cursor-p">
          <LangSelect />
        </div>
        <el-dropdown @command="clickUser">
          <div class="layout-header__label layout-header__locale flex-align">
            <el-image
              :src="userIcon"
              class="user-avatar"
            ></el-image>
            <span>{{ userInfo.realName }}</span>
            <el-icon>
              <ArrowDown />
            </el-icon>
          </div>
          <template #dropdown>
            <el-dropdown-menu>
              <el-dropdown-item
                :command="1"
                icon="User"
              >
                <span class="font12">{{ $t('user.userInfo') }}</span>
              </el-dropdown-item>
              <el-dropdown-item
                :command="4"
                icon="Connection"
              >
                <span class="font12">{{ $t('personalizationSetting') }}</span>
              </el-dropdown-item>
              <el-dropdown-item
                :command="2"
                icon="More"
              >
                <span class="font12">{{ $t('user.about') }}</span>
              </el-dropdown-item>
              <el-dropdown-item
                :command="3"
                icon="Promotion"
              >
                <span class="font12">{{ $t('user.logOut') }}</span>
              </el-dropdown-item>
            </el-dropdown-menu>
          </template>
        </el-dropdown>
      </div>
    </div>
  </el-header>
</template>

<style lang="scss" scoped>
.layout-header {
  position: relative;
  background-color: $headerBackgroundColor;
  color: var(--el-text-color-primary);
  width: calc(100vw - v-bind(asideWidth));
  height: var(--header-height);
  padding: 0;
  transition: all 0.4s;

  &::after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 0;
    width: 100%;
    height: 1px;
    background-color: var(--el-border-color-light);
    transform: scaleY(0.5);
  }

  .layout-header__label {
    color: var(--el-text-color-primary);

    &:focus-visible,
    &:focus {
      outline: none;
    }

    .user-avatar {
      display: inline-block;
      width: 35px;
      height: 35px;
      line-height: 35px;
      text-align: center;
      border-radius: 50%;
      vertical-align: middle;
      color: #fff;
      font-size: 22px;
      margin-right: 10px;
    }
  }

  .layout-header__main {
    width: 100%;
    height: 100%;

    .header-main__nav {
      height: 100%;

      .main-nav__item {
        cursor: pointer;
        height: 100%;
        font-weight: 400;
        font-size: 14px;
        color: var(--el-text-color-primary);
        transition: all 0.2s;
        line-height: 54px;

        &.active {
          position: relative;
          color: var(--el-color-primary);

          &::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            height: 2px;
            background-color: var(--el-color-primary);
          }

          &:hover {
            background-color: transparent;
          }
        }
      }

      .darkHover {
        &:hover {
          background: rgba(255, 255, 255, 0.1);
        }
      }

      .lightHover {
        &:hover {
          background: rgb(204, 204, 204);
        }
      }
    }

    .layout-header__locale {
      margin-right: 20px;

      span {
        margin-right: 4px;
      }
    }
  }
}

.build-info__title {
  font-size: 16px;
  line-height: 30px;
  color: #333;
  border-bottom: 1px solid var(--el-color-primary);
}

.font12 {
  font-size: 12px;
}
</style>
