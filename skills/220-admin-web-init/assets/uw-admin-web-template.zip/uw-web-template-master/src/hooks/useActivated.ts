import { ref, onActivated } from 'vue'
/**
 * 缓存过期时间
 * @param {Function} fn 生命周期中要执行的函数
 * @param {number} ttl 缓存过期时间 单位 秒  默认 120 秒
 */
export default function useActivated(fn: () => void, ttl?: number) {
  const timeActivate = ref(0)
  onActivated(() => {
    const nowTime = new Date().getTime()
    if (nowTime - timeActivate.value > (ttl || 120) * 1000) {
      timeActivate.value = nowTime
      fn()
    }
  })
}
