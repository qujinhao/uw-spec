<script lang="ts" setup>
import { onMounted } from 'vue'

const props = withDefaults(
  defineProps<{
    list: any[] // 订单状态列表
  }>(),
  {
    // num: 1
  }
)
// const emits = defineEmits<{
//   (e: 'click', item: any): void
// }>()
// const handleClick = (item: any) => {
//   emits('click', item)
// }
onMounted(() => {})
</script>

<template>
  <div class="relative bg-white overflow-hidden">
    <div
      class="flex flex-nowrap gap-[50rpx] h-[90rpx] py-[10rpx] overflow-x-scroll mx-[30rpx]"
    >
      <div
        class="item"
        :class="{
          active: index === 0
        }"
        v-for="(item, index) in props.list"
        :key="index"
      >
        {{ item.name }}
        <span
          class="bd"
          v-show="index === 0"
        ></span>
      </div>
    </div>
    <div class="right-mask"></div>
  </div>
</template>

<style lang="scss" scoped>
.item {
  // border: 1px solid #000;
  position: relative;
  font-size: 30rpx;
  color: #01060c;
  @apply flex items-center shrink-0;
  &.active {
    color: #0078f6;
    font-weight: 500;
  }
  .bd {
    width: 100%;
    position: absolute;
    bottom: 0;
    border: 1rpx solid #0078f6;
  }
}
.right-mask {
  position: absolute;
  right: 0;
  top: 0;
  bottom: 0;
  width: 34rpx;
  background: #fff;
  box-shadow: -10rpx 0 20rpx 5rpx rgba(179, 179, 179, 0.4);
}
</style>
