<template>
  <div :class="{ wordPreview: !dialogExpand?.fullscreen }">
    <el-dialog
      v-model="isShow"
      :title="title"
      :width="dialogWidth"
      draggable
      v-bind="dialogExpand"
      :close-on-click-modal="false"
      @close="closePreview"
    >
      <div
        :style="{ height: contentHeight }"
        v-loading="loading"
        ref="docDom"
      ></div>
    </el-dialog>
  </div>
</template>

<script lang="ts" setup>
import { renderAsync } from 'docx-preview'
import { docProps } from './type'
import { ElMessage } from 'element-plus'

const props = withDefaults(defineProps<docProps>(), {
  title: 'Word文档预览',
  width: '1000px',
  height: '620px',
  dialogExpand: () => ({}),
  renderedHandler: () => {
    console.log('渲染成功')
  },
  errorHandler: () => {
    ElMessage.error('Docx文档渲染异常')
  }
})

const emits = defineEmits<{
  (e: 'update:modelValue', val: boolean): void
}>()

// 是否展示
const isShow = computed({
  get() {
    return props.modelValue
  },
  set(val) {
    emits('update:modelValue', val)
  }
})

// excel高度
const contentHeight = computed(() => {
  if (props.dialogExpand?.fullscreen) {
    return '93vh'
  }
  if (typeof props.height === 'number') {
    return props.height + 'px'
  }
  return props.height
})

// 弹窗宽度
const dialogWidth = computed(() => {
  if (typeof props.width === 'number') {
    return props.width + 'px'
  }
  return props.width
})

// dom元素
const docDom = ref<HTMLElement>()
// loading效果
const loading = ref(false)

// 获取文件流，解析数据，进行展示
const loadDocx = () => {
  // 使用fetch获取文件流
  fetch(props.src)
    .then(response => {
      if (!response.ok) {
        // 给出提示，渲染异常
        props.errorHandler()
      }
      return response.blob() // 将响应转换为Blob对象
    })
    .then(blob => {
      // 如果需要读取文件内容（例如使用FileReader）
      const reader = new FileReader()
      reader.onload = async function (e) {
        const file = e.target?.result
        if (!file) return
        // 渲染docx文档
        renderAsync(file as ArrayBuffer, docDom.value as HTMLElement)
          .then(res => {
            console.log(res)
            props.renderedHandler()
          })
          .catch(() => {
            props.errorHandler()
          })
      }
      reader.readAsArrayBuffer(blob) // 读取为ArrayBuffer
    })
    .catch(() => {
      props.errorHandler()
    })
    .finally(() => {
      loading.value = false
    })
}

// 关闭预览窗口
const closePreview = () => {
  destroy()
}

// 销毁各项实例
const destroy = () => {
  if (docDom.value) {
    docDom.value.innerHTML = ''
  }
  timer.value && clearTimeout(timer.value)
}

// 定时器ID
const timer = ref()
const stopWatch = watch(
  () => isShow.value,
  val => {
    if (val) {
      loading.value = true
      nextTick(() => {
        timer.value = setTimeout(() => {
          loadDocx()
        }, 1000)
      })
    }
  },
  {
    immediate: true
  }
)

onUnmounted(() => {
  destroy()
  stopWatch()
})
</script>

<style scoped lang="scss">
.wordPreview {
  :deep(.el-dialog__body) {
    height: 650px;
    overflow: hidden auto;
    .vue-office-docx-main {
      .docx-wrapper {
        background: gray;
        padding: 15px;
        display: flex;
        flex-flow: column;
        align-items: center;
        height: 600px;
        overflow: hidden auto;
      }
    }
  }
}
</style>
