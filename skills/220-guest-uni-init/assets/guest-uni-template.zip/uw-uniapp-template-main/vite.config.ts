import { defineConfig } from 'vite'
import path from 'path'
import VueMacros from 'unplugin-vue-macros/vite'
import uni from '@dcloudio/vite-plugin-uni'
// import commonjs from '@rollup/plugin-commonjs'
import { vitePluginVersionMark } from 'vite-plugin-version-mark'
import viteCompression from 'vite-plugin-compression'
import vueDevTools from 'vite-plugin-vue-devtools' // 导入Vue开发者工具插件
import { UnifiedViteWeappTailwindcssPlugin } from 'weapp-tailwindcss/vite'
import tailwindcss from '@tailwindcss/postcss'
// import basicSsl from '@vitejs/plugin-basic-ssl'

// https://vitejs.dev/config/
const pathSrc = path.resolve(__dirname, 'src')

export default defineConfig({
  base: './', // 这里更改打包相对绝对路径
  plugins: [
    // basicSsl(),
    // commonjs(),
    // tailwindcss(),
    UnifiedViteWeappTailwindcssPlugin({
      rem2rpx: true,
      cssEntries: [
        // 你 @import "tailwindcss"; 那个文件绝对路径
        path.resolve(import.meta.dirname, './src/styles/tailwind.css')
      ]
    }),
    vueDevTools(), // 启用Vue开发者工具
    vitePluginVersionMark({
      // ifGitSHA: true, // 使用 git 提交 SHA 作为版本
      ifShortSHA: true, // 使用 git 提交短 SHA
      ifMeta: true, //  在<head>中添加<meta name=“application-name” content=“{APPNAME_VERSION}： {version}”>
      ifLog: false, // 在控制台中打印信息（默认）true
      ifGlobal: true // 在窗口中设置一个名为“__${APPNAME}_VERSION__”的变量 APPNAME 是 package.json 中的 name 值的大写
    }),
    viteCompression({
      verbose: true,
      disable: false,
      deleteOriginFile: false,
      algorithm: 'gzip',
      ext: '.gz',
      threshold: 512
    }),
    VueMacros({
      plugins: {
        /*
        升级package.json uniapp相关插件后就不支持该方式了
        failed to load config from D:\WorkCode\ui-rd\scsz-caigou-md-ui\vite.config.ts
        uni is not a function
        Build failed with errors.
        */
        // vue: uni()
        // @ts-ignore
        vue: uni.default()
      }
    })
  ],
  server: {
    host: '0.0.0.0', // 监听所有网络接口
    port: 6656
  },
  build: {
    // 构建相关配置
    target: 'es2015', // 目标浏览器支持的ES版本
    cssTarget: 'chrome80', // CSS目标浏览器
    cssCodeSplit: true,
    chunkSizeWarningLimit: 2000, // 文件大小警告阈值，单位KB
    minify: 'terser', // 使用terser进行代码压缩
    // sourcemap: false,
    // 需主动开启 sourcemap App，小程序端源码调试，需要在 vite.config.js 中主动开启 sourcemap
    sourcemap: process.env.NODE_ENV === 'development',
    terserOptions: {
      // terser压缩选项
      compress: {
        // 压缩配置
        drop_console: process.env.NODE_ENV === 'production', // 移除console语句
        drop_debugger: process.env.NODE_ENV === 'production' // 移除debugger语句
      }
    }
  },
  css: {
    preprocessorOptions: {
      scss: {
        api: 'modern-compiler',
        silenceDeprecations: ['legacy-js-api']
      }
    },
    postcss: {
      plugins: [tailwindcss()]
    }
  },
  resolve: {
    alias: {
      '@': pathSrc
    }
  },
  define: {
    // https://github.com/intlify/vue-i18n-next/issues/391
    // __FEATURE_ESM_BUNDLER_WARN__: false,
    __VUE_I18N_FULL_INSTALL__: true, // 启用/禁用，除了 Vue-i18n API，组件和指令都完全支持安装：true
    __VUE_I18N_LEGACY_API__: false, // 启用/禁用 vue-i18n 传统样式 API 支持，默认：true
    __INTLIFY_PROD_DEVTOOLS__: false // 在生产中启用/禁用支持，默认：@intlify/devtoolsfalse
  }
})
