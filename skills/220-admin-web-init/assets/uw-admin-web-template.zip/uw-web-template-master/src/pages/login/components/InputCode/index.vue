<template>
  <div class="verification-container">
    <input
      v-for="(code, index) in verificationCodes"
      :key="index"
      v-model="verificationCodes[index]"
      @input="handleInput(index, $event)"
      @keydown="handleKeyDown(index, $event)"
      @paste="handlePaste"
      ref="inputFieldRef"
      maxlength="1"
      class="verification-input"
    />
  </div>
</template>

<script setup lang="ts">
const props = withDefaults(
  defineProps<{
    modelValue?: Array<string> // 是否显示
  }>(),
  {
    modelValue: () => ['', '', '', '', '', '']
  }
)

const emits = defineEmits<{
  (e: 'update:modelValue', value: string[]): void
  (e: 'complete', value: string[]): void
}>()

const verificationCodes = computed({
  get() {
    return props.modelValue
  },
  set(value: Array<string>) {
    emits('update:modelValue', value)
  }
})

// 输入事件
const handleInput = (index: number, event: any) => {
  const value = event.target.value
  if (value.charCodeAt(0) >= 48 && value.charCodeAt(0) <= 57) {
    verificationCodes.value[index] = value
    if (verificationCodes.value.join('').length === 6) {
      emits('complete', verificationCodes.value)
    }
    if (value && index < verificationCodes.value.length - 1) {
      const nextInput = event.target.nextElementSibling
      if (nextInput) {
        nextTick(() => {
          nextInput.focus()
        })
      }
    }
  } else {
    event.target.value = ''
  }
}

// 键盘事件
const handleKeyDown = (index: number, event: any) => {
  if (event.key === 'Backspace' && !event.target.value && index > 0) {
    const prevInput = event.target.previousElementSibling
    if (prevInput) {
      nextTick(() => {
        prevInput.focus()
      })
    }
  }
}

// 输入框的ref元素数组
const inputFieldRef = ref(null)
// 粘贴事件
const handlePaste = (event: any) => {
  // @ts-expect-error
  const clipboardData = event.clipboardData || window.clipboardData
  const pastedText = clipboardData.getData('text')
  const codes = pastedText.trim().substring(0, 6).split('')
  const isAllNumbers = codes.every(
    (code: string) => code.charCodeAt(0) >= 48 && code.charCodeAt(0) <= 57
  )
  if (isAllNumbers) {
    verificationCodes.value = codes.concat(Array(6 - codes.length).fill(''))
    nextTick(() => {
      const lastInput = inputFieldRef.value![
        verificationCodes.value.length - 1
      ] as HTMLInputElement
      if (lastInput) {
        lastInput.focus()
      }
    })
  }
}

// 聚集事件
const handleInputFocus = (index: number) => {
  nextTick(() => {
    const inputDom = inputFieldRef.value![index] as HTMLInputElement
    if (inputDom) {
      inputDom.focus()
    }
  })
}

defineExpose({
  handleInputFocus
})
</script>

<style lang="scss" scoped>
.verification-container {
  width: 100%;
  display: flex;
  justify-content: space-between;
}
.verification-input {
  width: 38px;
  height: 38px;
  // margin-right: 15px;
  text-align: center;
  font-size: 20px;
  border: 1px solid #ebebeb;
  border-radius: 5px;
  &:last-child {
    margin-right: 0;
  }
  &:focus {
    outline: none;
    border-color: #007bff;
    box-shadow: 0 0 5px #007bff;
  }
}
</style>
