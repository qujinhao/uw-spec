export default (
  validityType?: any,
  validityCon?: any,
  isExpress?: any,
  treeId?: any,
  travelDate?: any,
  ticketTimes?: any,
  parentCustId?: any
) => {
  validityType = Number(validityType)
  // 除了门票
  if (Number(treeId) !== 0 && treeId) {
    switch (validityType) {
      case 1: {
        if (validityCon === '0') {
          // 1：预订日期延后0天
          let hold = ''
          if (![6000511, 6248734].includes(Number(parentCustId))) hold = '当天'
          return `预订后${hold}${isExpress ? '发货' : '有效'}`
        }
        return `预订日期延后${validityCon}天${isExpress ? '发货' : '有效'}`
      }
      case 2: {
        return `预订日期截止到指定日期${validityCon}${isExpress ? '发货' : '有效'}`
      }
      case 3: {
        validityCon = validityCon.split(',')
        if (Number(treeId) === 5) {
          return `有效日期：${validityCon[0]} ~ ${validityCon[1]}`
        }
        return `预订日期${validityCon[0]}到${validityCon[1]}${isExpress ? '发货' : '有效'}`
      }
      case 5: {
        try {
          if (validityCon.length > 0) {
            const [start, end] = validityCon.split(',')
            return `${start}到${end}期间${isExpress ? '发货' : '有效'}`
          } else {
            return ''
          }
        } catch (e) {
          console.error(e)
        }
        break
      }
      default: {
        return false
      }
    }
  } else {
    switch (validityType) {
      case 0: {
        if (ticketTimes && ticketTimes.length) {
          // 注释这里是为了防止有多个场次时间段可选择 和 这里的时间段冲突而产生误会
          // let time = ''
          // ticketTimes && ticketTimes.forEach(item => {
          //   time = item.name + ' '
          // })
          // return `选定日期 ${time}期间${isExpress ? '发货' : '有效'}`
          return `选定日期 期间${isExpress ? '发货' : '有效'}`
        }
        let hold = ''
        if (![6000511, 6248734].includes(Number(parentCustId))) {
          hold = '当天有效'
        }
        return `选定日期 ${travelDate || ''} ${hold}`
      }
      case 1: {
        return `预订日期起 ${validityCon} 天内有效`
      }
      case 2: {
        return `预订日期截止到指定日期 ${validityCon} 有效`
      }
      case 3: {
        return `选定日期延后 ${validityCon} 天有效`
      }
      case 4: {
        return `选定日期截止到指定日期 ${validityCon} 天有效`
      }
      case 5: {
        try {
          if (validityCon.length > 0) {
            const [start, end] = validityCon.split(',')
            return `${start}到${end}期间${isExpress ? '发货' : '有效'}`
          } else {
            return ''
          }
        } catch (e) {
          console.error(e)
        }
        break
      }
      default: {
        return false
      }
    }
  }
}
