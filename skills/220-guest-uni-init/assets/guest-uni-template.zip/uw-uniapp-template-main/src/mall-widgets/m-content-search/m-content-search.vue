<template>
  <!-- 内容搜索 -->
  <view
    class="ticket-filter"
    :style="[getStyle()]"
  >
    <!-- 城市选择 -->
    <view class="filter-item">
      <view
        class="filter-icon"
        :style="[getImgStyle()]"
      >
        <i class="icon location-icon"></i>
      </view>

      <view class="filter-select">
        <text>广州</text>
        <i class="select-icon park-icon"></i>
      </view>
    </view>

    <!-- 类型选择 -->
    <view class="filter-item">
      <view
        class="filter-icon"
        :style="[getImgStyle()]"
      >
        <i class="icon park-icon"></i>
      </view>
      <view class="filter-select">
        <text>乐园</text>
        <i class="select-icon park-icon"></i>
      </view>
    </view>

    <!-- 景点选择 -->
    <view
      class="filter-item"
      style="grid-column: span 2 / span 2"
    >
      <view
        class="filter-icon"
        :style="[getImgStyle()]"
      >
        <i class="icon attraction-icon"></i>
      </view>

      <view class="filter-select">
        <text>广州欢乐世界</text>
        <i class="select-icon park-icon"></i>
      </view>
    </view>

    <!-- 日期选择 -->
    <view
      class="filter-item"
      style="grid-column: span 2 / span 2"
    >
      <view
        class="filter-icon"
        :style="[getImgStyle()]"
      >
        <i class="icon date-icon"></i>
      </view>

      <view class="filter-select">
        <text>广州欢乐世界</text>
        <i class="select-icon park-icon"></i>
      </view>
    </view>

    <!-- 按钮 -->
    <view
      v-if="mergedAttrs.btnText"
      class="filter-item"
      style="grid-column: span 2 / span 2"
    >
      <button
        class="details-button"
        @click="showDetails"
        :style="[getImgStyle()]"
      >
        {{ mergedAttrs.btnText }}
      </button>
    </view>
  </view>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue'
import type { Attrs, Styles } from './type'
import { unit } from '../utils/registerBaseStyle'

const props = withDefaults(
  defineProps<{
    attrs: Partial<Attrs>
    styles: Partial<Styles>
    list: Record<string, string>[]
  }>(),
  {
    attrs: () => ({}),
    styles: () => ({}),
    list: () => []
  }
)
const mergedAttrs = computed(() => ({
  btnText: '价目详情', // 按钮文本
  ...props.attrs
}))

const mergedStyles = computed(() => ({
  pagePadding: 30, //	页面边距
  cmpUpperPadding: 30, //	上边距
  cmpLowerPadding: 30, //	下边距
  iconColor: '#b9995c', //	图标颜色
  cmpBackground: '', //	组件背景
  ...props.styles
}))
// 定义响应式数据
const selectedCity = ref('广州')
const selectedType = ref('乐园')
const selectedAttraction = ref('广州欢乐世界')
const selectedDate = ref('')

const getStyle = () => {
  return {
    padding: unit(mergedStyles.value.pagePadding),
    paddingTop: unit(mergedStyles.value.cmpUpperPadding),
    paddingBottom: unit(mergedStyles.value.cmpLowerPadding),
    backgroundColor: mergedStyles.value.cmpBackground
  }
}
const getImgStyle = () => {
  return {
    backgroundColor: mergedStyles.value.iconColor
  }
}

// 按钮点击事件
const showDetails = () => {
  console.log('选择的城市：', selectedCity.value)
  console.log('选择的类型：', selectedType.value)
  console.log('选择的景点：', selectedAttraction.value)
  console.log('选择的日期：', selectedDate.value)
  // 这里可以添加调用接口或跳转页面的逻辑
}
</script>

<style lang="scss" scoped>
.ticket-filter {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 20rpx;
  background-color: #fff;
  border-radius: 60rpx;
  padding: 80rpx;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  font-family: Arial, sans-serif;
}

.filter-item {
  display: flex;
  align-items: center;

  .filter-icon {
    display: flex;
    height: 58rpx;
    width: 58rpx;
    flex-shrink: 0;
    align-items: center;
    justify-content: center;
    border-radius: 12rpx;
  }
}

.icon {
  width: 32rpx;
  height: 32rpx;
  background-size: contain;
  background-repeat: no-repeat;
}

.location-icon {
  background-image: url('./images/location.svg'); /* 替换为实际图标路径 */
}

.park-icon {
  background-image: url('./images/park.svg'); /* 替换为实际图标路径 */
}

.attraction-icon {
  background-image: url('./images/attraction.svg'); /* 替换为实际图标路径 */
}

.date-icon {
  background-image: url('./images/date.svg'); /* 替换为实际图标路径 */
}

.filter-select {
  position: relative;
  margin-left: 1.466667vw;
  height: 68rpx;
  width: 100%;
  border-radius: 12rpx;
  background-color: #f5f5f5;
  padding-inline: 30rpx 16rpx;
  line-height: 68rpx;
  font-size: 28rpx;

  .select-icon {
    position: absolute;
    top: 30rpx;
    right: 20rpx;
    width: 18rpx;
    height: 18rpx;
    background-size: contain;
    background-repeat: no-repeat;
    background-image: url('./images/down.svg');
  }
}

.filter-date {
  padding: 8px;
  border: 1px solid #ccc;
  border-radius: 4px;
  background-color: #fff;
  cursor: pointer;
}

.details-button {
  height: 88rpx;
  width: 100%;
  color: #fff;
  border: none;
  border-radius: 12rpx;
  cursor: pointer;
  font-size: 32rpx;
  transition: background-color 0.3s ease;
  line-height: 88rpx;
}
</style>
