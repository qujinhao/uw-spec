<!-- 下单页 -->
<script lang="ts" setup>
import { reactive, ref, computed, nextTick } from 'vue'
import { onLoad, onReady } from '@dcloudio/uni-app'
import {
  guestOrderInfoSave,
  type OrderRequest,
  type OrderGuestRequest,
  guestProductInfoLimitLiteList,
  type ProductLimitQueryParam,
  type ProductLimit,
  guestProductInfoLoad,
  type ProductInfo,
  type ProductPrice,
  type GuestProductPriceQueryParam,
  guestProductInfoPriceList,
  guestProductInfoSpecList,
  type SpecInfo,
  type ProductSession,
  guestProductInfoSessionList,
  type ProductSpecVo,
  guestOrderInfoPay,
  type MallOrderPayParam,
  // guestPoiInfoLoad,
  // type PoiInfo,
  type OrderInfo
} from '@/api/saasMallAppGuestApi'
import { useUserStore } from '@/store/user'
import {
  isJSON,
  decimalToBinary,
  CalculationPrice,
  formatParam,
  getCurrentPath,
  getFullMonthRange
} from '@/utils/tool'
import {
  productLimitKeyEnum,
  ContactFormFieldArray,
  type GuestFormField,
  GuestFormFieldArray
} from '@/config/EnumExtend'
import { useCommonSelectTypes } from '@/utils/enumeration'
import { useI18n } from 'vue-i18n'
import { cloneDeep } from 'lodash-es'
import type { commonType } from '@/api/type/API_TYPE'
import dayjs from 'dayjs'
import PaymentPopup from '@/components/PaymentPopup/index.vue'
import { useMainStore } from '@/store/main'
import type { Extend_AisLinkerConfigInfo } from '@/components/PaymentPopup/type'
import { TypeSku } from '@/config/EnumConst'
import GuestSpecForm from './components/GuestSpecForm/index.vue'
import GuestProductForm from './components/GuestProductForm/index.vue'
import ZDateScrollView from '@/components/ZDateScrollView/index.vue'

// 扩展规格
interface Extend_ProductSpecVo extends ProductSpecVo {
  buyNum: number
}

/**
 * 1 只需填写一个人的资料 | 2 需填写每个人的资料
 */
type GuestDataType = 1 | 2

const mainStore = useMainStore()
const { t } = useI18n()
const userStore = useUserStore()
const {
  // handleTypeForLabel,
  // typeSaleRange,
  // TypeGender,
  // shareTypeForSassMall,
  // confirmTypeForSassMall,
  // validateTypeForSassMall,
  // useDateTypeForSassMall,
  // autoFinishType,
  // guestFormForSassMall,
  // guestFormTypeForSassMall,
  // guestDataType,
  guestPapersType,
  genderTypes
  // voucherTypeForSassMall,
  // refundTypesForDistributor,
  // refundTypesForSupplier,
  // refundTypesForGuest
} = useCommonSelectTypes()

const state = reactive({
  productId: undefined as undefined | number, // 产品ID
  poiId: undefined as undefined | number, // 景点ID
  curTravelDate: '', // 景点下单日期
  currentPath: '' // 当前页面路径
})

// 产品价格请求入参变量
const productState = ref({
  productSpecId: undefined as undefined | number, //规格产品id
  productStockId: undefined as undefined | number, //库存id
  productSessionId: undefined as undefined | number //场次时段id
})

// 下单备注
const remark = ref('')

// 下单游客资料限制 // 1 只需填写一个人的资料 | 2 需填写每个人的资料
const guestType = computed<GuestDataType>(() => {
  return ProofGuestDataTypeLimiter.value?.guestDataType || 1
})

// 客人信息
// const orderGuestRequestsList = computed<OrderGuestRequest[]>(() => {
//   const list = formGuestModel.value.guests.map((item) => {
//     return {
//       guestName: item.name as string,
//       guestNamePinyin: item.namePinyin as string,
//       guestGender: item.gender as number,
//       guestMobileArea: item.phoneCN as string,
//       guestMobile: item.phone as string,
//       guestAddress: item.address as string,
//       guestEmail: item.email as string,
//       idType: item.idType as number,
//       idInfo: item.idInfo as string
//     }
//   })
//   return list
// })

// 客人信息
const orderGuestRequestsList = computed<OrderGuestRequest[]>(() => {
  let list: OrderGuestRequest[] = []
  // 购买多规格数量 并且 按需填写游客
  if (buySpecNums.value > 0 && guestType.value === 2) {
    specInfos.value
      .filter((specItem) => specItem.buyNum)
      .forEach((specItem) => {
        formSpecGuestModel.value[specItem.specId!]?.guests.forEach((item) => {
          list.push({
            guestName: item.name as string,
            guestNamePinyin: item.namePinyin as string,
            guestGender: item.gender as number,
            guestMobileArea: item.phoneCN as string,
            guestMobile: item.phone as string,
            guestAddress: item.address as string,
            guestEmail: item.email as string,
            idType: item.idType as number,
            idInfo: item.idInfo as string
          })
        })
      })
  } else {
    list = formGuestModel.value.guests.map((item) => {
      return {
        guestName: item.name as string,
        guestNamePinyin: item.namePinyin as string,
        guestGender: item.gender as number,
        guestMobileArea: item.phoneCN as string,
        guestMobile: item.phone as string,
        guestAddress: item.address as string,
        guestEmail: item.email as string,
        idType: item.idType as number,
        idInfo: item.idInfo as string
      }
    })
  }
  return list
})

// 选择数量
const currentNum = ref(1)

// 是否为产品类型
const isProductType = computed(() => {
  return productDetail.value.skuType === TypeSku.PRODUCT
})
// 是否为场次类型
const isSessionType = computed(() => {
  return productDetail.value.skuType === TypeSku.SESSION
})
// 是否为规格类型
const isSpecType = computed(() => {
  return productDetail.value.skuType === TypeSku.SPEC
})

// 订单总价格,含税费/服务费/配送费
const priceTotal = computed(() => {
  if (isProductType.value) {
    return currentNum.value * (productPriceInfo.value?.priceSale || 0)
  } else if (specInfos.value.length) {
    return specInfos.value.reduce((cur, pre) => {
      return cur + (pre.priceSale || 0) * pre.buyNum
    }, 0)
  }
  return 0
})

// 是否高亮日期价格
const isActivePrice = (item: ProductPrice) => {
  return dayjs(item.priceDate).format('YYYY-MM-DD') === state.curTravelDate
}

// 退款规则信息
// const refundRuleInfo = computed(() => {
//   return ''
// })

// 是否展示支付弹窗
const isShowPayPopup = ref(false)

// -------------------产品规则-------------------
// 根据limiterClass字段响应限制条件对应的数据
const getLimiterDataByLimiterClass = (limiterClass: string) => {
  if (!productLimitList.value.length) return {}
  const item = productLimitList.value.find(
    (item) => item.limiterClass === limiterClass
  )
  if (item && isJSON(item.limiterConfig)) {
    return JSON.parse(item.limiterConfig || '{}')
  }
  return item || {}
}

// #region 销售规则
/**
 * 销售时间
{
  "saleEndTime": "2025-12-31 00:00:00",
  "saleStartTime": "2025-11-04 00:00:00"
}
*/
const SaleTimeLimiter = computed(() => {
  return getLimiterDataByLimiterClass(productLimitKeyEnum.SaleTimeLimiter)
})
//
/**
 * 销售范围
EnumMap -- TypeSaleRange
 */
const SaleRangeLimiter = computed(() => {
  return getLimiterDataByLimiterClass(productLimitKeyEnum.SaleRangeLimiter)
})
/**
 * 每日售卖时间
{
  "dailySaleEndTime": "23:59:59",
  "dailySaleStartTime": "00:00:00"
}
*/
const SaleDailyTimeLimiter = computed(() => {
  return getLimiterDataByLimiterClass(productLimitKeyEnum.SaleDailyTimeLimiter)
})
// #endregion

// #region 预定规则
/**
 * 最小预定数量
{
  "bookQuantityGte": 1,
  "bookQuantityLte": 99
}
*/
const BookQuantityLimiter = computed(() => {
  return getLimiterDataByLimiterClass(productLimitKeyEnum.BookQuantityLimiter)
})
/**
 * 最大预定天数
{
  "bookMaxBookDay": 30
}
{
  "bookMaxBookDay": -1 // 不限制
}
*/
const BookMaxDayLimiter = computed(() => {
  return getLimiterDataByLimiterClass(productLimitKeyEnum.BookMaxDayLimiter)
})
/**
 * 预定时间限制
{
  "bookHour": 1,
  "bookMinute": 2
}
*/
const BookTimeLimiter = computed(() => {
  return getLimiterDataByLimiterClass(productLimitKeyEnum.BookTimeLimiter)
})
// #endregion

// #region 资料凭证
/*
全部为十进制数据 需对应PC后台配置的枚举 依次排序取转换后二进制后的值 二进制项中1为true说中是选中的checkbox
Number(36).toString(2)
'100100'
姓名 姓名拼音 性别 手机号(大陆) 手机号码 邮箱
由此可见选中项伟 姓名 & 手机号(大陆)
tips:后续新增项都是前置补0而非后置补0 ！！！  否则的话会导致产品表单回显与PC配置不对应！！！
*/
/**
 * 联系人资料
{
  "contactDataType": 36
}
 */
const ProofContactDataTypeLimiter = computed(() => {
  return getLimiterDataByLimiterClass(
    productLimitKeyEnum.ProofContactDataTypeLimiter
  )
})
/**
 * 游客资料
{
  "guestDataType": 1
}
 */
const ProofGuestDataTypeLimiter = computed(() => {
  return getLimiterDataByLimiterClass(
    productLimitKeyEnum.ProofGuestDataTypeLimiter
  )
})
/**
 * 游客基本信息
{
  "guestInfoType": 65
}
 */
const ProofGuestInfoTypeLimiter = computed(() => {
  return getLimiterDataByLimiterClass(
    productLimitKeyEnum.ProofGuestInfoTypeLimiter
  )
})
/**
 * 游客证件类型
{
  "guestPapersType": 4096
}
 */
const ProofGuestPapersTypeLimiter = computed(() => {
  return getLimiterDataByLimiterClass(
    productLimitKeyEnum.ProofGuestPapersTypeLimiter
  )
})

// #endregion

// #region 限购规则
/**
 * 游客游玩日期限购

 */
const GuestTravelDayLimiter = computed(() => {
  return getLimiterDataByLimiterClass(productLimitKeyEnum.GuestTravelDayLimiter)
})
/**
 * 游客预定日期限购

 */
const GuestBookDayLimiter = computed(() => {
  return getLimiterDataByLimiterClass(productLimitKeyEnum.GuestBookDayLimiter)
})
/**
 * 产品时间段限购

 */
const GuestTimeRangeLimiter = computed(() => {
  return getLimiterDataByLimiterClass(productLimitKeyEnum.GuestTimeRangeLimiter)
})
/**
 * 场次限购

 */
const GuestSessionLimiter = computed(() => {
  return getLimiterDataByLimiterClass(productLimitKeyEnum.GuestSessionLimiter)
})
/**
 * 身份证限购

 */
const GuestIdAreaLimiter = computed(() => {
  return getLimiterDataByLimiterClass(productLimitKeyEnum.GuestIdAreaLimiter)
})
/**
 * 性别限购

 */
const GuestGenderLimiter = computed(() => {
  return getLimiterDataByLimiterClass(productLimitKeyEnum.GuestGenderLimiter)
})
/**
 * 年龄限购

 */
const GuestAgeLimiter = computed(() => {
  return getLimiterDataByLimiterClass(productLimitKeyEnum.GuestAgeLimiter)
})
// #endregion

// -------------------产品规则-------------------

// 根据十进制转为二级制的字符串拆分为数组
const decimalToBinaryArray = (decimal: number): string[] => {
  const binary = decimalToBinary(decimal) // 0101110101 ...
  return [...binary]
}

const productLimitList = ref<ProductLimit[]>([])
// 获取表单限制条件
const getFormLimit = async () => {
  const params: ProductLimitQueryParam = {
    $pg: 1,
    $rn: 9999,
    state: 1,
    productId: state.productId
  }
  const res = await guestProductInfoLimitLiteList(params)
  if (res.state === 'success') {
    productLimitList.value = res.data?.results || []
  } else {
    productLimitList.value = []
  }

  // 初始化表单UI
  initContactForm()
}

const productDetail = ref<ProductInfo>({})

// 获取产品信息
const getProductInfo = async () => {
  const res = await guestProductInfoLoad({ id: state.productId! })
  try {
    if (res.state === 'success' && res.data) {
      // console.log('guestProductInfoLoad', res.data)
      productDetail.value = res.data
    } else {
      productDetail.value = {}
    }

    // 产品类型为 场次 时拉取场次信息
    if (isSessionType.value) {
      getProductSessions()
    } else {
      // 除了场次类型都需要拉取规格信息 skuType 1 默认规格，2 多规格）
      getProductSpecInfos()
      getProductPriceList()
    }
  } catch (error) {
    console.log('guestProductInfoLoad error', error)
  }
}

// const poiDetail = ref<PoiInfo>({})
// // 获取POI详情
// const getPoiDetail = async () => {
//   const res = await guestPoiInfoLoad({ poiId: state.poiId! })
//   if (res.state === 'success') {
//     poiDetail.value = res.data || {}
//   } else {
//     poiDetail.value = {}
//   }
// }

// -----------------------------------联系人相关 start-------------------------------------
const formContactRef = ref()

// 联系人资料
const formContactModel = ref({
  name: undefined, //姓名
  namePinyin: undefined, //姓名拼音
  gender: undefined, //性别
  phoneCN: undefined, //手机号(大陆)
  phone: undefined, //手机号
  email: undefined //邮箱
})
const formContactRules: Record<string, any> = ref({
  name: {
    type: 'string',
    required: true,
    message: '请填写姓名',
    trigger: ['blur', 'change']
  },
  namePinyin: [
    {
      type: 'string',
      required: true,
      message: '请填写姓名拼音',
      trigger: ['blur', 'change']
    },
    {
      // 此为同步验证，可以直接返回true或者false，如果是异步验证，稍微不同，见下方说明
      validator: (_rule: any, value: any) => {
        // 调用uview-plus自带的js验证规则，详见：https://uview-plus.jiangruyi.com/js/test.html
        // console.log(uni.$u, test, uni.$u.test === test) // true
        return /^[a-zA-Z\u00C0-\u017F\s\-.'']+(?:\s+[a-zA-Z\u00C0-\u017F\s\-.'']+)*$/.test(
          value
        )
      },
      message: '请填写正确的姓名拼音',
      // 触发器可以同时用blur和change，二者之间用英文逗号隔开
      trigger: ['change', 'blur']
    }
  ],
  gender: {
    type: 'number',
    required: true,
    message: '请选择性别',
    trigger: ['blur']
  },
  phoneCN: [
    {
      type: 'string',
      required: true,
      message: '请输入手机号(大陆)',
      trigger: ['blur']
    },
    {
      type: 'string',
      validator: (_rule: any, value: any) => {
        return /^1[3-9]\d{9}$/.test(value)
      },
      message: '请输入正确的大陆手机号',
      trigger: ['blur', 'change']
    }
  ],
  phone: [
    {
      type: 'string',
      required: true,
      message: '请输入手机号',
      trigger: ['blur']
    },
    {
      type: 'string',
      validator: (_rule: any, value: any) => {
        return /^\d{6,}$/.test(value)
      },
      message: '请输入正确的手机号',
      trigger: ['blur', 'change']
    }
  ],
  email: [
    {
      type: 'string',
      required: true,
      message: '请输入邮箱',
      trigger: ['blur']
    },
    {
      type: 'string',
      validator: (_rule: any, value: any) => {
        return /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(value)
      },
      message: '请输入正确的邮箱',
      trigger: ['blur', 'change']
    }
  ]
})

// 根据LimitClass名取得需要的FiledList
const getContactFiledListByLimitClass = (className: string) => {
  // 根据className获取对应的二进制字符串
  const binaryStr: string =
    getLimiterDataByLimiterClass(className).contactDataType
  if (binaryStr) {
    // ['1', '0' , '0' , '0' , '0' ,'1']
    const binaryNumArr = decimalToBinaryArray(Number(binaryStr))
    // obj: {0: true, 5: true}
    const obj: Record<string, boolean> = {}
    for (let i = 0; i < binaryNumArr.length; i++) {
      if (binaryNumArr[i] === '1') {
        // 取出值为1 也就是后台勾选的项
        obj[i] = true
      }
    }
    // 需要展示的filed字段
    let filterFiledList: string[] = []
    Object.keys(obj).forEach((key) => {
      const index = Number(key)
      filterFiledList.push(ContactFormFieldArray[index])
    })
    // console.log('getContactFiledListByLimitClass', filterFiledList)
    return filterFiledList
  }
  return []
}

// 联系人须填写的表单项
const concatFormList = computed(() => {
  const list = getContactFiledListByLimitClass(
    productLimitKeyEnum.ProofContactDataTypeLimiter
  )
  return list
})

// 初始化联系人表单
const initContactForm = () => {
  // 根据['name', 'phone', ...]需填写的表单项创建表单
  const copyContactFormRules: typeof formContactRules.value = cloneDeep(
    formContactRules.value
  )
  // 更新rules规则
  formContactRules.value = {}
  concatFormList.value.forEach((field) => {
    formContactRules.value[field] = copyContactFormRules[field]
  })
  nextTick(() => {
    formContactRef.value?.setRules?.(formContactRules)
  })
}

// -----------------------------------联系人相关 end-------------------------------------

// -----------------------------------游客相关 start-------------------------------------
const formGuestRef = ref<typeof GuestProductForm>()
// 动态表单规则 - 初始化时为空，后续根据配置动态设置
const formGuestRules = ref<Record<string, any>>({})

// 游客资料
const formGuestModel = ref({
  guests: [] as Record<GuestFormField, string | number | undefined>[]
})

const formSpecGuestRef = ref()
// 动态表单规则 - 初始化时为空，后续根据配置动态设置
const formSpecGuestRules = ref<Record<string, any>>({})

// 规格ID: {...规格信息， guests: [{}, {}, ...]}
type FormSpecGuestType = Record<
  number, // 数字 ID 作为 key
  Extend_ProductSpecVo & {
    guests: Record<GuestFormField, string | number | undefined>[]
  }
>
// 多规格游客表单
const formSpecGuestModel = ref<FormSpecGuestType>({})

// 根据LimitClass名取得需要的FiledList
const getGuestFiledListByLimitClass = (className: string) => {
  // 根据className获取对应的二进制字符串
  const binaryStr: string =
    getLimiterDataByLimiterClass(className).guestInfoType
  if (binaryStr) {
    // ['1', '0' , '0' , '0' , '0' ,'1']
    const binaryNumArr = decimalToBinaryArray(Number(binaryStr))
    // obj: {0: true, 5: true}
    const obj: Record<string, boolean> = {}
    for (let i = 0; i < binaryNumArr.length; i++) {
      if (binaryNumArr[i] === '1') {
        // 取出值为1 也就是后台勾选的项
        obj[i] = true
      }
    }
    // 需要展示的filed字段
    let filterFiledList: string[] = []
    Object.keys(obj).forEach((key) => {
      const index = Number(key)
      filterFiledList.push(GuestFormFieldArray[index])
    })
    // console.log('getGuestFiledListByLimitClass', filterFiledList)
    return filterFiledList
  }
  return []
}

// 游客须填写的表单项
const guestFormList = computed(() => {
  const list = getGuestFiledListByLimitClass(
    productLimitKeyEnum.ProofGuestInfoTypeLimiter
  )
  return list
})

// 完整的验证规则模板
const guestFormRulesTemplate: Record<string, any> = {
  name: {
    type: 'string',
    required: true,
    message: '请填写姓名',
    trigger: ['blur', 'change']
  },
  namePinyin: [
    {
      type: 'string',
      required: true,
      message: '请填写姓名拼音',
      trigger: ['blur', 'change']
    },
    {
      validator: (_rule: any, value: any) => {
        return /^[a-zA-Z\u00C0-\u017F\s\-.'']+(?:\s+[a-zA-Z\u00C0-\u017F\s\-.'']+)*$/.test(
          value
        )
      },
      message: '请填写正确的姓名拼音',
      trigger: ['change', 'blur']
    }
  ],
  gender: {
    type: 'number',
    required: true,
    message: '请选择性别',
    trigger: ['blur']
  },
  phoneCN: [
    {
      type: 'string',
      required: true,
      message: '请输入手机号(大陆)',
      trigger: ['blur']
    },
    {
      type: 'string',
      validator: (_rule: any, value: any) => {
        return /^1[3-9]\d{9}$/.test(value)
      },
      message: '请输入正确的大陆手机号',
      trigger: ['blur', 'change']
    }
  ],
  phone: [
    {
      type: 'string',
      required: true,
      message: '请输入手机号',
      trigger: ['blur']
    },
    {
      type: 'string',
      validator: (_rule: any, value: any) => {
        return /^\d{6,}$/.test(value)
      },
      message: '请输入正确的手机号',
      trigger: ['blur', 'change']
    }
  ],
  email: [
    {
      type: 'string',
      required: true,
      message: '请输入邮箱',
      trigger: ['blur']
    },
    {
      type: 'string',
      validator: (_rule: any, value: any) => {
        return /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(value)
      },
      message: '请输入正确的邮箱',
      trigger: ['blur', 'change']
    }
  ],
  idType: {
    type: 'number',
    required: true,
    message: '请选择证件类型',
    trigger: ['blur', 'change']
  },
  idInfo: {
    type: 'string',
    required: true,
    message: '请输入证件号码',
    trigger: ['blur', 'change']
  }
}

// 默认游客信息
const defaultGuestInfo = {
  name: undefined,
  namePinyin: undefined,
  gender: undefined,
  phoneCN: undefined,
  phone: undefined,
  address: undefined,
  email: undefined,
  idType: undefined,
  idInfo: undefined
}

// 初始化游客表单
const initGuestForm = () => {
  // 清空现有游客信息
  formGuestModel.value.guests = []

  if (guestType.value === 1) {
    const copyGuestInfo = cloneDeep(defaultGuestInfo)
    formGuestModel.value.guests = [copyGuestInfo]
    // 动态设置验证规则
    updateGuestFormRules()
    return
  }

  // 根据最少购买数 初始游客表单
  // BookQuantityLimiter?.bookQuantityGte
  for (let i = 0; i < BookQuantityLimiter.value?.bookQuantityGte; i++) {
    const copyGuestInfo = cloneDeep(defaultGuestInfo)
    formGuestModel.value.guests.push(copyGuestInfo)
  }
  updateGuestFormRules()
}

// 更新游客表单验证规则
const updateGuestFormRules = () => {
  const tempRules: Record<string, any> = {}

  // 证件类型相关字段
  const idFields = ['idType', 'idInfo']

  formGuestModel.value.guests.forEach((guest, index) => {
    // 游客基本信息
    guestFormList.value.forEach((field) => {
      if (guestFormRulesTemplate[field]) {
        const ruleKey = `guests.${index}.${field}`
        tempRules[ruleKey] = cloneDeep(guestFormRulesTemplate[field])
      }
    })

    // 游客证件类型
    if (idTypeOption.value.length) {
      idFields.forEach((field) => {
        const ruleKey = `guests.${index}.${field}`
        tempRules[ruleKey] = cloneDeep(guestFormRulesTemplate[field])
      })
    }
  })

  formGuestRules.value = tempRules

  // 使用setRules方法更新表单规则
  nextTick(() => {
    formGuestRef.value?.setRules?.(formGuestRules.value)
  })
}

// 初始化多规格表单
const initSpecGuestForm = () => {
  // 清空现有多规格游客信息
  formSpecGuestModel.value = {}

  if (guestType.value === 1) {
    return
  }

  // 创建相应的游客表单
  specInfos.value.forEach((specInfo) => {
    // const copyGuestInfo = cloneDeep(defaultGuestInfo)
    formSpecGuestModel.value[specInfo.specId!] = {
      ...specInfo,
      guests: []
    }
  })
  updateSpecGuestFormRules()
}

// 更新游客表单验证规则
const updateSpecGuestFormRules = () => {
  nextTick(() => {
    // if (!specInfos.value.length) return
    const tempRules: Record<string, any> = {}

    // 证件类型相关字段
    const idFields = ['idType', 'idInfo']

    specInfos.value.forEach((specItem) => {
      // formSpecGuestModel.value[specInfo.specId!].guests = []
      formSpecGuestModel.value[specItem.specId!].guests.forEach(
        (guest, index) => {
          // 游客基本信息
          guestFormList.value.forEach((field) => {
            if (guestFormRulesTemplate[field]) {
              const ruleKey = `${specItem.specId}.guests.${index}.${field}`
              tempRules[ruleKey] = cloneDeep(guestFormRulesTemplate[field])
            }
          })

          // 游客证件类型
          if (idTypeOption.value.length) {
            idFields.forEach((field) => {
              const ruleKey = `${specItem.specId}.guests.${index}.${field}`
              tempRules[ruleKey] = cloneDeep(guestFormRulesTemplate[field])
            })
          }
        }
      )
    })

    formSpecGuestRules.value = tempRules

    // 使用setRules方法更新表单规则
    formSpecGuestRef.value?.setRules?.(formSpecGuestRules.value)

    // debugger
  })
}

// -----------------------------------游客相关 end-------------------------------------

// -----------------------------------证件相关 start-------------------------------------
// ProofGuestPapersTypeLimiter 游客证件类型

// 获取所有可选的证件列表
const getIdTypeOptionsByLimitClass = (className: string) => {
  // 根据className获取对应的二进制字符串
  const binaryStr: string =
    getLimiterDataByLimiterClass(className).guestPapersType
  if (binaryStr) {
    // ['1', '1', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0']
    const binaryNumArr = decimalToBinaryArray(Number(binaryStr))
    // 都为0说明后台没有勾选证件类型 返回[]即可
    if (binaryNumArr.every((item) => [0, '0'].includes(item))) {
      return []
    }
    // obj: {0: true, 1: true} // 游客身份证 游客护照
    const obj: Record<string, boolean> = {}
    for (let i = 0; i < binaryNumArr.length; i++) {
      if (binaryNumArr[i] === '1') {
        // 取出值为1 也就是后台勾选的项
        obj[i] = true
      }
    }
    // 需要展示的filed字段
    let filterFiledList: commonType[] = []
    Object.keys(obj).forEach((key) => {
      const index = Number(key)
      filterFiledList.push(guestPapersType.value[index])
    })
    // console.log('getIdTypeOptionsByLimitClass', filterFiledList)
    return filterFiledList
  }
  return []
}

// 证件类型列表
const idTypeOption = computed(() => {
  const list = getIdTypeOptionsByLimitClass(
    productLimitKeyEnum.ProofGuestPapersTypeLimiter
  )
  return list
})

// -----------------------------------证件相关 end-------------------------------------

// -----------------------------------限购规则相关 start-------------------------------------
// 游客游玩日期限购

// -----------------------------------限购规则相关 end-------------------------------------

// 处理数量变化 // value：输入框当前值，name：步进器标识符
const handleCurrentNumChange = ({ value }: { value: string | number }) => {
  nextTick(() => {
    // console.log('handleCurrentNumChange', value)
    // 产品限制 只需要一个游客信息
    if (guestType.value === 1) {
      return
    }
    const newValue = typeof value === 'string' ? Number.parseInt(value) : value
    const oldLength = formGuestModel.value.guests.length

    if (newValue > oldLength) {
      // 增加游客，保留已有数据
      for (let i = 0; i < newValue - oldLength; i++) {
        const copyGuestInfo = cloneDeep(defaultGuestInfo)
        formGuestModel.value.guests.push(copyGuestInfo)
      }
    } else if (newValue < oldLength) {
      // 减少游客，保留前面的数据
      formGuestModel.value.guests = formGuestModel.value.guests.slice(
        0,
        newValue
      )
    }

    // 数量变化后更新验证规则
    updateGuestFormRules()
  })
}

// 多规格 总购买数
const buySpecNums = computed(() => {
  if (!specInfos.value.length) return 0
  let nums = specInfos.value.reduce((cur, pre) => {
    return cur + pre.buyNum
  }, 0)
  return nums
})
// 多规格 总购买数
const buySpecNumList = computed(() => {
  if (!specInfos.value.length) return []
  let nums = specInfos.value.map((item) => {
    return item.buyNum
  })
  return nums
})

// // 处理数量变化 // value：输入框当前值，name：步进器标识符
// const handleSpecNumChange = ({ value }: { value: string | number }) => {
//   nextTick(() => {
//     // 产品限制 只需要一个游客信息
//     if (guestType.value === 1) {
//       return
//     }

//     console.log('handleSpecNumChange', value)
//     // console.log(specInfos.value) // 从规格信息表取每个规格购买的数量

//     const newValue = buySpecNums.value
//     const oldLength = formGuestModel.value.guests.length

//     if (newValue > oldLength) {
//       // 增加游客，保留已有数据
//       for (let i = 0; i < newValue - oldLength; i++) {
//         const copyGuestInfo = cloneDeep(defaultGuestInfo)
//         formGuestModel.value.guests.push(copyGuestInfo)
//       }
//     } else if (newValue < oldLength) {
//       // 减少游客，保留前面的数据
//       formGuestModel.value.guests = formGuestModel.value.guests.slice(
//         0,
//         newValue
//       )
//     }

//     // 数量变化后更新验证规则
//     updateGuestFormRules()
//   })
// }

// 处理数量变化 // value：输入框当前值，name：步进器标识符
const handleSpecNumChange = () => {
  // console.log('handleSpecNumChange buySpecNumList', buySpecNumList.value)
  const oldSpecNumsList = buySpecNumList.value
  // -----------------------
  nextTick(() => {
    // 产品限制 只需要一个游客信息
    if (guestType.value === 1) {
      return
    }

    // console.log('handleSpecNumChange2 buySpecNumList', buySpecNumList.value)
    // console.log(specInfos.value) // 从规格信息表取每个规格购买的数量
    const newSpecNumsList = buySpecNumList.value
    // 根据旧的数量oldSpecNumsList 对比 新的数量newSpecNumsList 得到哪个索引 加了 还是 减少 来控制formSpecGuestModel.value[specItem.specId!]的加减

    specInfos.value.forEach((specItem, specIndex) => {
      const newValue = newSpecNumsList[specIndex]
      const oldValue = oldSpecNumsList[specIndex]
      if (newValue > oldValue) {
        // 增加游客，保留已有数据
        for (let i = 0; i < newValue - oldValue; i++) {
          const copyGuestInfo = cloneDeep(defaultGuestInfo)
          formSpecGuestModel.value[specItem.specId!].guests.push(copyGuestInfo)
        }
      } else if (newValue < oldValue) {
        // 减少游客，保留前面的数据
        formSpecGuestModel.value[specItem.specId!].guests.pop()
      }
    })
    updateSpecGuestFormRules()
  })
}

// 产品价格信息
const productPriceInfo = computed(() => {
  if (!priceList.value.length) return {}
  const findItem = priceList.value.find((item) => {
    return dayjs(item.priceDate).format('YYYY-MM-DD') === state.curTravelDate
  })
  return findItem
})

// 获取产品价格列表
const priceList = ref<ProductPrice[]>([])
const getProductPriceList = async () => {
  const params: GuestProductPriceQueryParam = {
    productId: state.productId,
    $pg: 1,
    $rn: 999,
    productSpecId: productState.value?.productSpecId, //规格产品id
    productStockId: productState.value?.productStockId, //库存id
    productSessionId: productState.value?.productSessionId, //场次时段id
    // 价格列表 默认从当天 ~ +两个月来查询
    priceDateRange: getFullMonthRange(dayjs().format('YYYY-MM-DD'), 2),
    // priceDateRange: getFullMonthRange(state.curTravelDate, 2),
    state: 1
  }
  // debugger
  const res = await guestProductInfoPriceList(params)
  if (res.state === 'success') {
    priceList.value = res.data?.results || []
  } else {
    priceList.value = []
  }

  if (!priceList.value.length) {
    uni.showToast({
      icon: 'none',
      title: '未获取产品规格',
      duration: 2000
    })
  } else if (
    dayjs(state.curTravelDate).format('YYYY-MM-DD') <
    dayjs().format('YYYY-MM-DD')
  ) {
    uni.showToast({
      icon: 'none',
      title: '请重新选择您的日期',
      duration: 2000
    })
    setTimeout(() => {
      uni.navigateBack()
    }, 2000)
  } else {
    scrollToHighlight()
  }
}

// 产品规格集合
const specInfos = ref<Extend_ProductSpecVo[]>([])
// 获取产品规格 sessionId = 0 默认规格
const getProductSpecInfos = async (sessionId = 0) => {
  const res = await guestProductInfoSpecList({
    productId: state.productId!, //
    sessionId, //
    stockType: productDetail.value.stockType!, //1 日历库存  2 非日历库存 3 场次库存
    currency: 'CNY', //货币类型
    date: dayjs(state.curTravelDate).format('YYYY-MM-DD') //
  })
  if (res.state === 'success') {
    // console.log('guestProductInfoSpecList', res.data)
    const resResults = res.data || []
    specInfos.value = resResults.map((item) => {
      return {
        ...item,
        buyNum: 0 // 定义初始化规格数量为0
      }
    })
  } else {
    specInfos.value = []
  }

  // TODO
  if (specInfos.value.length === 0) {
    uni.showToast({
      icon: 'none',
      title: '未获取产品规格',
      duration: 3000
    })
  }

  if (isProductType.value || guestType.value === 1) {
    initGuestForm()
  } else {
    initSpecGuestForm()
  }
}

// 当前选的场次
const curSessionItem = ref<ProductSession>()

// 产品场次集合
const sessionList = ref<ProductSession[]>([])
// 获取产品场次
const getProductSessions = async () => {
  const res = await guestProductInfoSessionList({
    $pg: 1,
    $rn: 9999,
    state: 1,
    sessionDateRange: [
      dayjs(state.curTravelDate).format('YYYY-MM-DD 00:00:00'),
      dayjs(state.curTravelDate).format('YYYY-MM-DD 23:59:59')
    ],
    productId: productDetail.value.id
  })
  if (res.state === 'success') {
    sessionList.value = res.data?.results || []

    // 默认高亮场次项
    curSessionItem.value = sessionList.value?.length
      ? sessionList.value[0]
      : undefined
    // 更新sessionId
    initProductState()
    productState.value.productSessionId = curSessionItem.value?.id
    // 根据场次ID查询规格数据
    getProductSpecInfos(curSessionItem.value?.id)
  } else {
    sessionList.value = []
  }
}

// 选择场次
const handleSelectSession = (item: ProductSession) => {
  // console.log('handleSelectSession', item)
  curSessionItem.value = item

  // 更新sessionId
  initProductState()
  productState.value.productSessionId = curSessionItem.value.id

  // 根据场次ID查询规格数据
  getProductSpecInfos(curSessionItem.value.id)

  // 初始化游客表单 (因为重新拉取新的规格信息)
  initGuestForm()
}

// 初始化产品请求参数
const initProductState = () => {
  productState.value = {
    productSpecId: undefined,
    productStockId: undefined,
    productSessionId: undefined
  }
}

const scrollBoxRef = ref<HTMLDivElement>() // 外层滚动盒子
const itemRef = ref<HTMLDivElement[]>([]) // 所有子项 DOM 数组

// 根据选中日期滚动到高亮项
const scrollToHighlight = () => {
  nextTick(() => {
    // 找到当前高亮项对应的 DOM
    const idx = priceList.value.findIndex((it) => isActivePrice(it))
    const targetEl = itemRef.value[idx]
    if (!targetEl || !scrollBoxRef.value) return

    // 计算滚动距离，让高亮项位于可视区中间
    const box = scrollBoxRef.value
    const boxWidth = box.clientWidth
    const targetLeft = targetEl.offsetLeft
    const targetWidth = targetEl.offsetWidth

    // 目标滚动位置 = 目标中心 - 盒子中心
    const scrollLeft = targetLeft - (boxWidth - targetWidth) / 2

    box.scrollTo({ left: scrollLeft, behavior: 'smooth' })
  })
}

// 日期选择器
const selectDate = async (item: ProductPrice) => {
  console.log('selectDate', item)
  state.curTravelDate = dayjs(item.priceDate).format('YYYY-MM-DD')

  scrollToHighlight()
}

// dayjs 格式化日期
const formatDate = (d: string | Date, tpl: string) => {
  const input = dayjs(d).startOf('day')
  const today = dayjs().startOf('day')
  const tomorrow = today.add(1, 'day')

  if (input.isSame(today)) return '今天'
  if (input.isSame(tomorrow)) return '明天'

  return input.format(tpl)
}

// dayjs 格式化周期
const formatDay = (d: string | Date, tpl: string) => {
  return dayjs(d).locale('zh-CN').format(tpl)
}

// 下单响应数据
const orderDetailInfo = ref<OrderInfo>({})

// 提交订单
const handleSubmit = async () => {
  if (!userStore.userInfo?.id) {
    uni.showToast({
      icon: 'none',
      title: '请先登录',
      duration: 2000
    })
    setTimeout(() => {
      const obj = {
        redirectUrl: state.currentPath
      }
      uni.navigateTo({
        url: '/pages/login/index?' + formatParam(obj)
      })
    }, 2000)
    return
  }

  let specInfosList: SpecInfo[] = []
  specInfosList = specInfos.value.map((item) => {
    const obj = {
      specId: item.specId,
      sessionId: item.sessionId,
      purchaseNum: 0
    }
    if (isProductType.value) {
      obj.purchaseNum = currentNum.value
    } else {
      obj.purchaseNum = item.buyNum
    }
    return obj
  })
  const params: OrderRequest = {
    saasId: userStore.siteInfo.saasId, // 运营商ID
    // distributorMchId: //分销商商户编号
    // agentId?: number //合伙人ID
    currencyType: 'CNY', //货币类型
    // orderLan?: string //订单语言
    remark: remark.value, //客人备注
    orderPrice: priceTotal.value, //订单总价格,含税费/服务费/配送费
    orderDate: dayjs().format('YYYY-MM-DD HH:mm:ss'), //订单时间
    orderGuestRequests: orderGuestRequestsList.value.length
      ? orderGuestRequestsList.value
      : undefined, //客人信息
    productId: state.productId, //产品ID
    travelDate: dayjs(state.curTravelDate).format('YYYY-MM-DD'), //游玩日期
    // travelEndDate:  // 酒店的结束日期
    specInfos: specInfosList // Array<SpecInfo> //产品规格集合
  }
  console.log('handleSubmit', params)
  // debugger

  if (isProductType.value) {
    if (currentNum.value === 0) {
      uni.showToast({
        icon: 'none',
        title: t('请先选择购买数量')
      })
      return
    }
  } else if (specInfos.value.length) {
    if (buySpecNums.value === 0) {
      uni.showToast({
        icon: 'none',
        title: t('请选择规格及购买数量')
      })
      return
    }
  }

  // console.log('formContactRef', formContactRef.value)
  // console.log('formContactModel', formContactModel.value)
  // console.log('formContactRules', formContactRules.value)

  // 校验表单
  await formContactRef.value?.validate({ showErrorMsg: true })

  // console.log('formGuestRef', formGuestRef.value)
  // console.log('formGuestModel', formGuestModel.value)
  // console.log('formGuestRules', formGuestRules.value)

  console.log('formGuestRef', formGuestRef.value)
  console.log('formSpecGuestRef', formGuestRef.value)

  await formGuestRef.value?.validate({ showErrorMsg: true })
  await formSpecGuestRef.value?.validate({ showErrorMsg: true })

  const res = await guestOrderInfoSave(params)

  if (res.state === 'success') {
    // navToUrl('/packages/order/orderPay/index')
    console.log('guestOrderInfoSave', res.data)

    uni.showToast({
      icon: 'success',
      duration: 3000,
      title: t('下单成功，请及时完成支付！')
    })

    orderDetailInfo.value = res.data || {}
    isShowPayPopup.value = true
    // 获取支付配置
    mainStore.handleGetPaymentListConfig()

    /*
        "id": 1553127025128821909,
        "saasId": 8821909,
        "poiId": 216714,
        "siteId": 0,
        "agentId": 0,
        "guestId": 220,
        "orderInfo": "{\"poiName\":\"临沂市博物馆\",\"poiTag\":\"{\\\"139\\\":\\\"博物馆\\\"}\",\"poiPrice\":0,\"address\":\"临沂市北城新区兰陵路10号\",\"openInfo\":\"[{\\\"desc\\\": \\\"全年 周二-周日 09:00-16:00开放;全年 周一 全天不开放\\\", \\\"time\\\": \\\"\\\"}]\",\"productName\":\"jsw普通产品\",\"buyNum\":1,\"imgMain\":\"{\\\"2552\\\":\\\"8821909/product_info/0_2552.png\\\"}\",\"areaCode\":\"100001200010020000\",\"catCode\":0,\"skuType\":1,\"refundInfo\":\"退款说明退款说明\",\"noticeInfo\":\"注意事项注意事项\",\"nights\":0,\"breakfast\":0,\"unpayCancelMinutes\":0}",
        "unpayCancelMinutes": 0,
        "areaCode": 100001200010020000,
        "saleType": 0,
        "payType": 0,
        "payMoney": 0,
        "useDateType": 0,
        "deliveryType": 0,
        "deliveryState": 0,
        "confirmType": 0,
        "finishNum": 0,
        "finishMoney": 0,
        "remark": "11",
        "channelId": 0,
        "distributorMchId": 0,
        "distributorParentId": 0,
        "distributorMoney": 0,
        "distributorOrderState": 0,
        "distributorMoneyReceipted": 0,
        "distributorMoneyRefund": 0,
        "distributorVerifyState": 0,
        "distributorRebate": 0,
        "issueType": 0,
        "issueState": 0,
        "refundNum": 0,
        "refundMoney": 0,
        "refundState": 0,
        "orderCurrency": "CNY",
        "orderMoney": 8400,
        "orderState": 10,
        "orderDate": 1765418942780,
        "state": 1
    */
  } else {
    uni.showToast({
      title: '下单失败:' + res.msg,
      icon: 'none'
    })
  }
}

// 微信支付链接 通过二维码展示 "weixin://wxpay/bizpayurl?pr=m3p8pIvz1"
// const scanPayInfoUrl = ref('')

// 支付弹窗提交
const handlePaySubmit = (payItem: Extend_AisLinkerConfigInfo) => {
  console.log('handlePaySubmit', payItem)
  /*
  {
    "id": 90,
    "state": 1,
    "appName": "saas-finance-app",
    "saasId": 8821909,
    "createDate": 1765243324164,
    "linkerId": 53,
    "linkerFunction": "payOrderNotify,payRefundNotify,payRefund,payOrder",
    "linkerVersion": "1.0.5",
    "linkerIcon": "",
    "mchId": 0,
    "configSid": "",
    "configName": "微信支付接口",
    "modifyDate": 1765275767758,
    "pubParamMap": {
        "pay.channel": "WECHAT"
    },
    "payRemark": "22"
}
  */

  uni.showToast({
    icon: 'loading',
    title: '提交申请中...',
    duration: 3000
  })

  /* payTradeType：
  APP( "APP", "APP支付" ),
  JSAPI_MP( "JSAPI_MP", "公众号支付" ),
  JSAPI_MA( "JSAPI_MA", "小程序支付" ),
  NATIVE( "NATIVE", "native支付" ),
  H5( "H5", "H5支付" )
  */
  const params: MallOrderPayParam = {
    payConfigId: payItem.id,
    payChannel: payItem.payChannel,
    payTradeType: 'NATIVE', // TODO 等后端完善后再根据情况使用对应的
    payCurrency: 'CNY', // 货币类型 人民币:CNY;
    payAmount: priceTotal.value, // 支付金额，单位分
    // bizOrderExt: '', // 应用订单扩展信息
    payRemark: payItem.payRemark,
    orderId: orderDetailInfo.value.id // 类型忽略 不可强转大数字number （后端定义ID长度大于17位及以上）
  }
  guestOrderInfoPay(params)
    .then(async (res) => {
      /*
      {
        "payOrderId": 8251212345908821909,
        "saasId": 0,
        "userId": 220,
        "userType": 1,
        "userInfo": "13652725969@163.com",
        "userIp": "192.168.89.212",
        "payConfigId": 90,
        "payChannel": "WECHAT",
        "payTradeType": "NATIVE",
        "orderInfo": "商城订单支付：123333",
        "orderCurrency": "CNY",
        "orderAmount": 2400,
        "bizAppInfo": "saas-mall-app",
        "bizOrderType": "saas.mall.entity.OrderInfo",
        "bizOrderId": "1251212347188821909",
        "scanPayInfo": "weixin://wxpay/bizpayurl?pr=m3p8pIvz1"
    }
      */
      if (res.state === 'success') {
        isShowPayPopup.value = false
        // scanPayInfoUrl.value = res.data?.scanPayInfo || ''
        // 跳转到订单详情页面
        const params = {
          id: orderDetailInfo.value.id
        }
        uni.navigateTo({
          url: '/user/orderDetail/index?' + formatParam(params)
        })

        // if (res.data && res.data.webPayInfo) {
        //   const url = res.data.webPayInfo.url
        //   // if (res.data.webUrl) {
        //   //   resolve(`${res.data.webUrl}`)
        //   // } else {
        //   //   payVISAPAY(res.data)
        //   // }
        //   // return
        //   if (['VISAPAY', 'MASTERCARDPAY'].includes(info.payChannel)) {
        //     payVISAPAY(res.data)
        //   } else if (
        //     ['ALIPAY', 'WXPAY', 'ALIPAYHK'].includes(info.payChannel)
        //   ) {
        //     loadingPage.value?.close()
        //     if (['ALIPAY', 'ALIPAYHK'].includes(info.payChannel)) {
        //       console.log('支付宝支付 --->', info)
        //       if (url) {
        //         // window.location.href = url
        //         window.location.replace(url)
        //         console.log('res.data', res.data)
        //       } else {
        //         loadingPage.value?.close()
        //         showFailToast(res.msg || t('orderStatus.orderFailed'))
        //         reject(res.msg)
        //       }
        //       resolve(`${res.data.webUrl}`)
        //     } else {
        //       resolve(res.data.scanPayInfo || '')
        //     }
        //   } else if (['UNIONPAY', 'CUPPAY'].includes(info.payChannel)) {
        //     // loadingPage.value?.close()
        //     // resolve(res.data.webUrl || '')
        //     payVISAPAY(res.data)
        //   }
        // } else {
        //   loadingPage.value?.close()
        //   showFailToast(res.msg || t('orderStatus.orderFailed'))
        //   reject(res.msg)
        // }
      } else {
        uni.showToast({
          icon: 'error',
          title: t('提交失败:') + res.msg,
          duration: 3000
        })
      }
    })
    .catch((err) => {
      uni.showToast({
        icon: 'error',
        title: t('提交失败') + err.msg,
        duration: 3000
      })
    })
    .finally(() => {
      setTimeout(() => {
        uni.hideToast()
      }, 2000)
    })
}

onReady(() => {
  // 如果需要兼容微信小程序，并且校验规则中含有方法等，只能通过setRules方法设置规则
  // this.$refs.form1.setRules(this.rules)
  // nextTick(() => {
  //   formContactRef.value?.setRules?.(formContactRules)
  //   // 初始化游客表单规则
  //   updateGuestFormRules()
  // })
  // nextTick(() => {
  //   calendarRef.value?.setFormatter()
  // })
})
onLoad((options) => {
  console.log('placeOrder index options', options)
  state.productId = options?.productId
  state.poiId = options?.poiId
  state.curTravelDate = options?.curTravelDate || dayjs().format('YYYY-MM-DD')
  state.currentPath = getCurrentPath(options)

  if (state.productId && state.poiId) {
    getProductInfo()
    // getPoiDetail()
    getFormLimit()
  }
})
</script>

<template>
  <view class="placeOrder-page p-[20rpx] pb-[100rpx]">
    <div v-if="false">
      <!-- 限定条件 -->
      <div>{{ SaleTimeLimiter }}</div>
      <div>{{ SaleRangeLimiter }}</div>
      <div>{{ SaleDailyTimeLimiter }}</div>
      <br />

      <div>{{ BookQuantityLimiter }}</div>
      <div>{{ BookMaxDayLimiter }}</div>
      <div>{{ BookTimeLimiter }}</div>
      <br />

      <div>
        {{ ProofContactDataTypeLimiter }}--{{
          decimalToBinary(Number(ProofContactDataTypeLimiter?.contactDataType))
        }}--{{ concatFormList }}
      </div>
      <div>
        {{ ProofGuestDataTypeLimiter }}
      </div>
      <div>
        {{ ProofGuestInfoTypeLimiter }}--{{
          decimalToBinary(Number(ProofGuestInfoTypeLimiter?.guestInfoType))
        }}--{{ guestFormList }}
      </div>
      <div>
        {{ ProofGuestPapersTypeLimiter }}--{{
          decimalToBinary(Number(ProofGuestPapersTypeLimiter?.guestPapersType))
        }}--{{ idTypeOption }}
      </div>
      <br />

      <div>GuestTravelDayLimiter{{ GuestTravelDayLimiter }}</div>
      <div>{{ GuestBookDayLimiter }}</div>
      <div>{{ GuestTimeRangeLimiter }}</div>
      <div>{{ GuestSessionLimiter }}</div>
      <div>{{ GuestIdAreaLimiter }}</div>
      <div>{{ GuestGenderLimiter }}</div>
      <div>{{ GuestAgeLimiter }}</div>
      <br />

      <div>产品： {{ productDetail.productName }}</div>
      <div>
        价格： {{ CalculationPrice(productPriceInfo?.priceSale! / 100) }}
      </div>
    </div>

    <div class="div-shadow">
      <!-- <u-title>产品信息</u-title>
      <up-divider></up-divider> -->
      <up-row class="font-bold text-xl">{{ productDetail.productName }}</up-row>

      <template v-if="isProductType">
        <up-divider></up-divider>

        <u-title>选择日期</u-title>
        <div
          ref="scrollBoxRef"
          class="flex gap-2 py-[10rpx] overflow-x-auto scroll-hide"
        >
          <div
            v-for="item in priceList"
            :key="item.priceDate"
            ref="itemRef"
            class="shrink-0 rounded-2xl border p-[10rpx] transition-all active:scale-95 text-center cursor-pointer"
            :class="[
              isActivePrice(item)
                ? 'border-primary text-primary'
                : 'bg-white border-gray-300'
            ]"
            @click.stop="selectDate(item)"
          >
            <div class="text-base font-semibold">
              {{ formatDate(item.priceDate!, 'MM-DD') }}
            </div>
            <div class="text-xs mt-1">
              {{ formatDay(item.priceDate!, 'dddd') }}
            </div>
            <div class="text-sm font-bold mt-2 text-primary-buy">
              ¥{{ CalculationPrice(item.priceSale! / 100) }}
            </div>
          </div>
        </div>
      </template>
      <template v-else-if="isSpecType">
        <div class="pt-[20rpx]">
          <ZDateScrollView v-model="state.curTravelDate" />
        </div>
      </template>

      <!-- <template v-if="isProductType">
        <div class="p-[0rpx_0_20rpx]">
          <up-calendar
            ref="calendarRef"
            :show="isShowCalendar"
            :pageInline="true"
            :showTitle="false"
            :showSubtitle="true"
            :showConfirm="false"
            :defaultDate="state.curTravelDate"
            :formatter="handleCalendarFormatter"
            @confirm="handleCalendarConfirm"
          ></up-calendar>
        </div>
      </template> -->

      <p
        class="flex gap-2"
        v-if="productDetail.bookInfo"
      >
        <span class="shrink-0">{{ t('预订说明') }}</span>
        <span class="text-[#999999]">{{ productDetail.bookInfo }}</span>
      </p>
      <p
        class="flex gap-2"
        v-if="productDetail.refundInfo"
      >
        <span class="shrink-0">{{ t('退款说明') }}</span>
        <span class="text-[#999999]">{{ productDetail.refundInfo }}</span>
      </p>

      <up-divider></up-divider>

      <template v-if="isProductType || isSpecType">
        <template v-if="isProductType">
          <u-title>选择数量</u-title>
          <div class="flex items-center justify-between">
            <span>
              至少购买{{ BookQuantityLimiter?.bookQuantityGte }}张，限购{{
                BookQuantityLimiter?.bookQuantityLte
              }}张
            </span>
            <up-number-box
              v-model="currentNum"
              :min="BookQuantityLimiter?.bookQuantityGte"
              :max="BookQuantityLimiter?.bookQuantityLte"
              @change="handleCurrentNumChange"
            />
          </div>
        </template>
        <template v-else-if="isSpecType">
          <u-title>选择规格及数量</u-title>
          <div class="flex flex-col gap-2">
            <div
              class="flex items-center justify-between"
              v-for="(item, index) in specInfos"
              :key="index"
            >
              <div class="flex">
                {{ item.specName }}({{ item.specId }})(CNY
                {{ CalculationPrice(item.priceSale! / 100) }})
              </div>
              <up-number-box
                v-model="item.buyNum"
                :min="0"
                @change="handleSpecNumChange"
              />
            </div>
          </div>
        </template>
      </template>
      <template v-else-if="isSessionType">
        <u-title>选择场次</u-title>
        <div class="flex flex-wrap gap-2 pt-2">
          <div
            class="flex items-center justify-between rounded-2xl border border-gray-300"
            :class="{
              ' border-primary text-primary bg-primary/10':
                curSessionItem?.id === item.id
            }"
            v-for="(item, index) in sessionList"
            :key="index"
            @click="handleSelectSession(item)"
          >
            <div class="p-[6rpx_12rpx]">
              {{ dayjs(item.sessionStartTime).format('HH:mm') }}-{{
                dayjs(item.sessionEndTime).format('HH:mm')
              }}
            </div>
          </div>
        </div>

        <up-divider></up-divider>

        <u-title>购买数量</u-title>
        <div class="flex flex-col gap-[10rpx]">
          <div
            class="flex items-center justify-between"
            v-for="item in specInfos"
            :key="item.specId"
          >
            <div class="flex">
              {{ item.specName }} (CNY
              {{ CalculationPrice(item.priceSale! / 100) }})
            </div>
            <up-number-box
              v-model="item.buyNum"
              :min="0"
              @change="handleSpecNumChange"
            />
          </div>
        </div>
      </template>
    </div>

    <div class="div-br"></div>

    <div class="div-shadow">
      <div class="p-[20rpx_0]">
        <!-- 表单区域 -->
        <!-- 注意，如果需要兼容微信小程序，最好通过setRules方法设置rules规则 -->
        <u-title>联系人信息</u-title>
        <up-form
          ref="formContactRef"
          :model="formContactModel"
          :rules="formContactRules"
          labelWidth="150rpx"
        >
          <up-form-item
            v-if="concatFormList.includes('name')"
            label="姓名"
            prop="name"
            :borderBottom="true"
          >
            <up-input
              v-model="formContactModel.name"
              border="none"
              placeholder="请输入姓名"
              clearable
            ></up-input>
          </up-form-item>
          <up-form-item
            v-if="concatFormList.includes('namePinyin')"
            label="姓名拼音"
            prop="namePinyin"
            :borderBottom="true"
          >
            <up-input
              v-model="formContactModel.namePinyin"
              border="none"
              placeholder="请输入姓名拼音"
              clearable
            ></up-input>
          </up-form-item>
          <up-form-item
            v-if="concatFormList.includes('gender')"
            label="性别"
            prop="gender"
            :borderBottom="true"
          >
            <up-radio-group v-model="formContactModel.gender">
              <up-radio
                :customStyle="{ marginRight: '16px' }"
                v-for="(item, index) in genderTypes"
                :key="index"
                :label="item.label"
                :name="item.value"
              ></up-radio>
            </up-radio-group>
          </up-form-item>
          <up-form-item
            v-if="concatFormList.includes('phoneCN')"
            label="手机号(大陆)"
            prop="phoneCN"
            :borderBottom="true"
          >
            <up-input
              placeholder="请输入手机号(大陆)"
              border="surround"
              type="number"
              v-model="formContactModel.phoneCN"
              clearable
            ></up-input>
          </up-form-item>
          <up-form-item
            v-if="concatFormList.includes('phone')"
            label="手机号"
            prop="phone"
            :borderBottom="true"
          >
            <up-input
              placeholder="请输入手机号"
              border="surround"
              type="number"
              v-model="formContactModel.phone"
              clearable
            ></up-input>
          </up-form-item>
          <up-form-item
            v-if="concatFormList.includes('email')"
            label="邮箱"
            prop="email"
            :borderBottom="true"
          >
            <up-input
              placeholder="请输入邮箱"
              border="surround"
              type="text"
              v-model="formContactModel.email"
              clearable
            ></up-input>
          </up-form-item>
        </up-form>
      </div>
    </div>

    <div class="div-br"></div>

    <template v-if="buySpecNums > 0 && guestType === 2">
      <div class="div-shadow">
        <div class="p-[20rpx_0]">
          <GuestSpecForm
            ref="formSpecGuestRef"
            v-model="formSpecGuestModel"
            :rules="formSpecGuestRules"
            :specInfos="specInfos"
            :guestFormList="guestFormList"
            :idTypeOption="idTypeOption"
          />
        </div>
      </div>

      <div class="div-br"></div>
    </template>

    <template v-if="formGuestModel.guests.length">
      <div class="div-shadow">
        <div class="p-[20rpx_0]">
          <GuestProductForm
            ref="formGuestRef"
            v-model="formGuestModel"
            :rules="formGuestRules"
            :guestFormList="guestFormList"
            :idTypeOption="idTypeOption"
          />
        </div>
      </div>

      <div class="div-br"></div>
    </template>

    <div class="div-shadow">
      <div class="p-[20rpx_0] flex flex-col gap-2">
        <u-title>备注</u-title>
        <div class="mt-1">
          <up-textarea
            placeholder="请输入备注"
            v-model="remark"
            clearable
          ></up-textarea>
        </div>
      </div>
    </div>

    <div class="div-br"></div>

    <!-- 底部悬浮总计 -->
    <div
      class="fixed bottom-0 left-0 right-0 z-50 bg-white flex h-[100rpx] items-center justify-between p-[0_30rpx] shadow-[0rpx_-1rpx_10rpx_0rpx_rgba(0,0,0,0.11)]"
    >
      <div class="font-family-Bold flex items-center text-[26rpx]">
        {{ t('总计') }}：
        <span class="font-family-Bold ml-[15rpx] text-[14px] text-primary-buy">
          CNY {{ CalculationPrice(priceTotal / 100) }}
        </span>
      </div>
      <div
        @click="handleSubmit"
        class="bg-primary font-family-Bold flex h-[58rpx] items-center justify-center rounded-[29rpx] p-[0_50rpx] text-[26rpx] text-white"
      >
        {{ t('提交订单') }}
      </div>
    </div>

    <!-- 支付弹窗 -->
    <PaymentPopup
      v-model="isShowPayPopup"
      :priceTotal="priceTotal"
      @submit="handlePaySubmit"
    >
      123订单信息slot?
      <!-- <up-qrcode
       v-if="scanPayInfoUrl"
        cid="ex1"
        :size="200"
        :val="scanPayInfoUrl"
      ></up-qrcode> -->
    </PaymentPopup>
  </view>
</template>

<style lang="scss" scoped>
.placeOrder-page {
  position: relative;
  overflow: hidden;

  .session-info {
    .session-info__item {
      display: flex;
      justify-content: space-between;
      align-items: center;
      border-radius: 20rpx;
      padding: 6rpx 10rpx;
      border: 1px solid #eee;
      margin: 0 20rpx;
      margin-bottom: 20rpx;
      &.active {
        background-color: #eee;
        border: 1px solid #ff0000;
      }
    }
  }
}
</style>
