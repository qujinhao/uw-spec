import request from '@/utils/request'

//重置密码
export const authResetPassword = (params: {
  saasId: number // saasId
  deviceType: number // 设备类型
  deviceId: string // 设备ID
  deviceCode: string // 设备验证码
  newPassword: string // 新密码
  captchaId?: string // CaptchaId
  captchaSign?: string // captchaSign
}): Promise<ResponseData<void>> => {
  return request('/uw-auth-center/auth/resetPassword', {
    method: 'PUT',
    params
  })
}
//发送设备验证码
export const authSendDeviceCode = (
  data: LoginRequest
): Promise<ResponseData<void>> => {
  return request('/uw-auth-center/auth/sendDeviceCode', {
    method: 'POST',
    data
  })
}
//重刷Token
export const authRefreshToken = (params: {
  refreshToken: string // 刷新Token
  loginAgent: string // 登录代理
  forceRefresh?: boolean // 强制刷新
}): Promise<ResponseData<TokenResponse>> => {
  return request('/uw-auth-center/auth/refreshToken', {
    method: 'POST',
    params
  })
}
//用户登录
export const authLogin = (
  data: LoginRequest
): Promise<ResponseData<Array<TokenResponse>>> => {
  return request('/uw-auth-center/auth/login', {
    method: 'POST',
    data
  })
}
//生成Captcha
export const authGenCaptcha = (params: {
  captchaId?: string // CaptchaId
}): Promise<ResponseData<CaptchaQuestion>> => {
  return request('/uw-auth-center/auth/genCaptcha', {
    method: 'GET',
    params
  })
}

//登录请求对象
export interface LoginRequest {
  loginAgent?: string //登录代理
  loginType?: number //登录类型
  loginId?: string //登录信息
  loginSecret?: string //登录加密密码
  loginPass?: string //登录明文密码
  saasId?: number //saasId
  userId?: number //userId
  userType?: number //用户类型
  captchaId?: string //CaptchaId
  captchaSign?: string //Captcha用户答案
  forceLogin?: boolean //强制登录
}
//token返回结果
export interface TokenResponse {
  tokenType?: number //token类型
  saasId?: number //saasId
  saasName?: string //saas名称
  userType?: number //用户类型
  userId?: number //用户Id
  mchId?: number //商户编号
  groupId?: number //所属用户组ID
  userName?: string //登录名
  realName?: string //真实名称
  nickName?: string //别名 [用于业务前台匿名]
  mobile?: string //手机号码
  email?: string //email
  lastPasswdDate?: string //最后更新密码时间
  loginNotice?: string //登录提示信息
  token?: string //token
  refreshToken?: string //刷新token
  expiresIn?: number //token过期时间
  refreshExpiresIn?: number //刷新token过期时间
  createAt?: number //创建时间
}
//captcha问题信息
export interface CaptchaQuestion {
  captchaId?: string //captchaId
  captchaTTL?: number //captcha有效期
  captchaType?: string //captcha类型
  mainImageBase64?: string //原生图片base64
  subImageBase64?: string //拼图图片base64
  subData?: string //附加数据
}

export interface ResponseData<T> {
  code?: string | number
  data?: T
  state: 'success' | 'error' | 'warn'
  msg?: string
}

export interface DataList<T> {
  startIndex?: number //
  resultNum?: number //
  size?: number //
  sizeAll?: number //
  page?: number //
  pageCount?: number //
  results?: Array<T> //
}

export interface ESDataList<T> {
  startIndex?: number //
  resultNum?: number //
  size?: number //
  sizeAll?: number //
  page?: number //
  pageCount?: number //
  results?: Array<T> //
}

//Enum结构
export interface EnumStruct {
  value?: number //数值
  label?: string //名称
}
