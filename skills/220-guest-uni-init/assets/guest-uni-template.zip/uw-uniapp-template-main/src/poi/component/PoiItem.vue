<script setup lang="ts">
import type { PoiInfo } from '@/api/saasMallAppGuestApi'
import dummy from '@/static/images/dummy.png'
import { useI18n } from 'vue-i18n'
import { formatPrice, getProductSingleImg } from '@/utils/tool'
import { computed } from 'vue'
import ZTag from '@/components/ZTag/index.vue'

const props = defineProps<{
  item: PoiInfo // POI信息
}>()

const dummyImg = dummy
const { t } = useI18n()

// 标签列表
const poiTags = computed(() => {
  let list: { id: string; name: string }[] = []
  try {
    // "{\"104033\":\"遛娃宝藏地\",\"296\":\"自然山水\",\"1658245\":\"公园&植物园\",\"66028\":\"避暑纳凉\",\"254012\":\"赏秋叶\"}"
    if (props.item?.poiTag) {
      const obj = JSON.parse(props.item?.poiTag)
      Object.keys(obj).forEach((key) => {
        list.push({
          id: key,
          name: obj[key]
        })
      })
    }
  } catch (error) {
    console.log('poiTags', error)
  }
  return list
})
</script>
<template>
  <div
    class="flex flex-col gap-[10rpx] rounded-xl overflow-hidden border border-[#E5E5E5] bg-white shadow-[0_2px_10px_0_rgba(0,0,0,0.1)]"
  >
    <div class="flex items-center w-full">
      <image
        class=""
        mode="widthFix"
        :src="getProductSingleImg(props.item.imgMain) || dummyImg"
      />
    </div>
    <div class="flex flex-col gap-[10rpx] p-[18rpx_20rpx]">
      <div class="font-bold text-[#303133]">
        {{ props.item.poiName }}
      </div>

      <template v-if="poiTags.length">
        <div class="flex gap-4 overflow-x-scroll">
          <ZTag
            v-for="item in poiTags"
            :key="item.id"
            :text="item.name"
          />
        </div>
      </template>

      <div class="mt-auto flex items-center gap-[6rpx] text-[#B6BBC1]">
        <span class="text-[24rpx] leading-[28rpx]">
          {{ t('最低') }}
        </span>
        <div class="flex items-center gap-1 text-[#FF6100]">
          <span>{{ t('CNY') }}</span>
          <span class="font-bold">
            {{ formatPrice(props.item?.poiPrice as number) }}
          </span>
          <span class="text-[#8A9098] text-[12px]">起</span>
        </div>
      </div>
    </div>
  </div>
</template>
