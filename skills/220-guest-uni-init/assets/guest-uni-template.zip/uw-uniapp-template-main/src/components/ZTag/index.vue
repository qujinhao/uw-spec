<script lang="ts" setup>
const props = withDefaults(
  defineProps<{
    text: string // 文案
  }>(),
  {
    text: ''
  }
)
</script>

<template>
  <div
    class="tag-item flex shrink-0 bg-[#f6f8fa] text-[#979a9e] text-[12px] p-[6rpx_12rpx] rounded-[12rpx]"
  >
    {{ props.text }}
  </div>
</template>

<style lang="scss" scoped></style>
