<script lang="ts" setup>
import type { ProductSpecVo } from '@/api/saasMallAppGuestApi'
import type { GuestFormField } from '@/config/EnumExtend'
import { useCommonSelectTypes } from '@/utils/enumeration'
import { findAreaLabelPath } from '@/utils/tool'
import { ref, onMounted } from 'vue'
import areaInfo from '@/utils/areaInfo'
import type { commonType } from '@/api/type/API_TYPE'

// 扩展规格
interface Extend_ProductSpecVo extends ProductSpecVo {
  buyNum: number
}
// 规格ID: {...规格信息， guests: [{}, {}, ...]}
type FormSpecGuestType = Record<
  number, // 数字 ID 作为 key
  Extend_ProductSpecVo & {
    guests: Record<GuestFormField, string | number | undefined>[]
  }
>

const props = withDefaults(
  defineProps<{
    rules: Record<string, any>
    specInfos: Extend_ProductSpecVo[]
    guestFormList: string[]
    idTypeOption: commonType[]
  }>(),
  {
    // num: 1
  }
)
// const emits = defineEmits<{
//   (e: 'click', item: any): void
// }>()

const { genderTypes } = useCommonSelectTypes()

// const formSpecGuestModel = defineModel<FormSpecGuestType>('formSpecGuestModel')
const formSpecGuestModel = defineModel<FormSpecGuestType>({
  default: {},
  required: true
})

// 地区控件
const isShowCascader = ref(false)
const curCascaderList = ref([])

// 100001300000000000,100001300010000000,100001300010040000
const curCascaderShowList = ref<string>()
// 河北省/唐山市/路北区
const curCascaderShowLabelList = ref<string>()
// 级联选择器确认
const handleCascaderConfirm = (list: string[]) => {
  // console.log('handleCascaderConfirm', list)
  curCascaderShowList.value = list.join(',')
  const lastCode = list[list.length - 1]
  const areaList = findAreaLabelPath(areaInfo, lastCode)
  // console.log('areaList', areaList) // ['河北省', '唐山市', '路北区']
  curCascaderShowLabelList.value = areaList?.join('/')
}

// 选择证件类型
const handleSelectIdType = (
  obj: commonType,
  specItem: Extend_ProductSpecVo,
  index: number
) => {
  // console.log('handleSelectIdType', obj, index)
  formSpecGuestModel!.value[specItem.specId!].guests[index].idType =
    obj.value as string
}

onMounted(() => {})

const formSpecGuestRef = ref()
defineExpose({
  setRules: () => formSpecGuestRef.value?.setRules({}),
  validate: () => formSpecGuestRef.value?.validate()
})
</script>

<template>
  <!-- 游客表单 -->
  <up-form
    ref="formSpecGuestRef"
    :model="formSpecGuestModel"
    :rules="props.rules"
    labelWidth="150rpx"
  >
    <div class="flex flex-col">
      <div
        v-for="(specItem, specIndex) in specInfos"
        :key="specItem.specId"
      >
        <div
          class="flex flex-col gap-2.5"
          v-if="specItem.buyNum > 0"
        >
          <!-- {{ formGuestModel }}
      {{ formSpecGuestRules }} -->
          <!-- {{ formSpecGuestRules }} -->
          <u-title
            :class="{
              'pt-[20rpx]': specIndex > 0
            }"
          >
            {{ specItem.specName }}
          </u-title>
          <div
            v-for="(guest, index) in formSpecGuestModel?.[specItem.specId!]
              ?.guests"
            :key="index"
          >
            <u-title>游客信息 {{ index + 1 }}</u-title>
            <up-form-item
              v-if="props.guestFormList.includes('name')"
              label="姓名"
              :prop="`${specItem.specId}.guests.${index}.name`"
              :borderBottom="true"
            >
              <up-input
                v-model="guest.name"
                border="none"
                placeholder="请输入姓名"
                clearable
              ></up-input>
            </up-form-item>
            <up-form-item
              v-if="props.guestFormList.includes('namePinyin')"
              label="姓名拼音"
              :prop="`${specItem.specId}.guests.${index}.namePinyin`"
              :borderBottom="true"
            >
              <up-input
                v-model="guest.namePinyin"
                border="none"
                placeholder="请输入姓名拼音"
                clearable
              ></up-input>
            </up-form-item>
            <up-form-item
              v-if="props.guestFormList.includes('gender')"
              label="性别"
              :prop="`${specItem.specId}.guests.${index}.gender`"
              :borderBottom="true"
            >
              <up-radio-group v-model="guest.gender">
                <up-radio
                  :customStyle="{ marginRight: '16px' }"
                  v-for="(item, idx) in genderTypes"
                  :key="idx"
                  :label="item.label"
                  :name="item.value"
                ></up-radio>
              </up-radio-group>
            </up-form-item>
            <up-form-item
              v-if="props.guestFormList.includes('phoneCN')"
              label="手机号(大陆)"
              :prop="`${specItem.specId}.guests.${index}.phoneCN`"
              :borderBottom="true"
            >
              <up-input
                placeholder="请输入手机号(大陆)"
                border="surround"
                type="number"
                v-model="guest.phoneCN"
                clearable
              ></up-input>
            </up-form-item>
            <up-form-item
              v-if="props.guestFormList.includes('phone')"
              label="手机号"
              :prop="`${specItem.specId}.guests.${index}.phone`"
              :borderBottom="true"
            >
              <up-input
                placeholder="请输入手机号"
                border="surround"
                type="number"
                v-model="guest.phone"
                clearable
              ></up-input>
            </up-form-item>
            <up-form-item
              v-if="props.guestFormList.includes('address')"
              label="地址"
              :prop="`${specItem.specId}.guests.${index}.address`"
              :borderBottom="true"
            >
              <div
                class="flex flex-col"
                @click="isShowCascader = true"
              >
                {{ curCascaderShowLabelList ?? '请选择地区' }}
                <up-input
                  placeholder="请输入地址"
                  v-model="guest.address"
                  clearable
                ></up-input>
              </div>
              <up-cascader
                v-model:show="isShowCascader"
                v-model="curCascaderList"
                labelKey="areaName"
                valueKey="areaCode"
                :data="areaInfo"
                @confirm="handleCascaderConfirm"
              ></up-cascader>
            </up-form-item>
            <up-form-item
              v-if="props.guestFormList.includes('email')"
              label="邮箱"
              :prop="`${specItem.specId}.guests.${index}.email`"
              :borderBottom="true"
            >
              <up-input
                placeholder="请输入邮箱"
                border="surround"
                type="text"
                v-model="guest.email"
                clearable
              ></up-input>
            </up-form-item>
            <template v-if="idTypeOption.length">
              <up-form-item
                label="证件类型"
                :prop="`${specItem.specId}.guests.${index}.idType`"
                :borderBottom="true"
              >
                <up-select
                  v-model:current="guest.idType"
                  label="请选择证件类型"
                  labelName="label"
                  keyName="value"
                  :showOptionsLabel="
                    guest.idType || [0, '0'].includes(guest.idType!)
                      ? true
                      : false
                  "
                  :options="idTypeOption"
                  @select="handleSelectIdType($event, specItem, index)"
                ></up-select>
              </up-form-item>
              <up-form-item
                label="证件号码"
                :prop="`${specItem.specId}.guests.${index}.idInfo`"
                :borderBottom="true"
              >
                <up-input
                  placeholder="请输入证件号码"
                  border="surround"
                  type="text"
                  v-model="guest.idInfo"
                  clearable
                ></up-input>
              </up-form-item>
            </template>
          </div>
        </div>
      </div>
    </div>
  </up-form>
</template>

<style lang="scss" scoped></style>
