<script setup lang="ts">
import { type ComponentInternalInstance } from 'vue'
import { SearchFormType } from '@/components/SearchForm/type'
import {
  opsLogDataHistoryList,
  type SysDataHistoryQueryParam,
  type SysDataHistory
} from '@/api/uwAuthCenterOpsApi'
import { useCommonSelectTypes } from '@/utils/selectOptions'
import { useI18n } from 'vue-i18n'
import { useCrud } from '@/hooks/useCrud'
import { ResponseData, DataList } from '@/api/uwAuthCenterAuthApi'

// 获取全局挂载的方法
const { proxy } = getCurrentInstance() as ComponentInternalInstance
const { dayjs, useActivated } = proxy as any

const { t } = useI18n()
const { userTypes, handleTypeForLabel } = useCommonSelectTypes()

interface formParamsType extends SysDataHistoryQueryParam {
  dateTimeRange?: Array<string>
}
const {
  tableConfig, // 表格相关配置属性
  handleList, // 列表请求函数
  dialogConfig
} = useCrud<SysDataHistory, formParamsType>({
  // 列表请求接口
  listFn: (): Promise<ResponseData<DataList<SysDataHistory>>> => {
    tableConfig.queryParams.$sn = ['id']
    return opsLogDataHistoryList(tableConfig.queryParams)
  }
})

// 搜索表单 结构组成数据
const searchList = computed<SearchFormType[]>(() => {
  return [
    {
      field: 'id',
      formItem: {
        label: 'ID',
        labelWidth: '40'
      },
      formItemWidth: 280,
      clearable: true,
      componentType: 'input',
      placeholder: t('pleaseInput') + 'ID',
      value: ''
    },
    {
      field: 'entityClass',
      formItem: {
        label: '实例类',
        labelWidth: '110'
      },
      formItemWidth: 280,
      clearable: true,
      componentType: 'input',
      placeholder: t('pleaseInput') + '实例类'
    },
    {
      field: 'userName',
      formItem: {
        label: '登录名称',
        labelWidth: '90'
      },
      formItemWidth: 280,
      clearable: true,
      componentType: 'input',
      placeholder: t('pleaseInput') + '登录名称'
    },
    {
      field: 'realName',
      formItem: {
        label: t('user.realName'),
        labelWidth: '70'
      },
      formItemWidth: 280,
      clearable: true,
      componentType: 'input',
      placeholder: t('pleaseInput') + t('user.realName')
    },
    {
      field: 'userType',
      formItem: {
        label: '用户类型',
        labelWidth: '90'
      },
      formItemWidth: 280,
      clearable: true,
      componentType: 'select',
      options: userTypes.value,
      placeholder: t('pleaseSelect') + '用户类型'
    },
    {
      field: 'userIp',
      formItem: {
        label: '用户IP',
        labelWidth: '90'
      },
      formItemWidth: 280,
      clearable: true,
      componentType: 'input',
      placeholder: t('pleaseInput') + '用户IP'
    },
    {
      field: 'createDateRange',
      componentType: 'datePicker',
      formItem: {
        label: '变更日期',
        labelWidth: 90
      },
      clearable: true,
      formItemWidth: 480,
      type: 'datetimerange',
      startPlaceholder: t('pleaseSelect') + '开始时间',
      endPlaceholder: t('pleaseSelect') + '结束时间',
      defaultTime: [
        new Date(2000, 1, 1, 0, 0, 0),
        new Date(2000, 2, 1, 23, 59, 59)
      ],
      valueFormat: 'YYYY-MM-DD HH:mm:ss'
    }
  ]
})

const detailText = ref('')
const currentId = ref()
const showDataHistory = ref(false)
const dialogTitle = computed(() => {
  if (dialogConfig.dialogType === 0) {
    return '数据详情#' + currentId.value
  }
  return '变更信息#' + currentId.value
})

const handleDetailForEntityData = (item: SysDataHistory) => {
  detailText.value = item.entityData || ''
  currentId.value = item.id
  showDataHistory.value = true
}

const handleDetailForEntityUpdateInfo = (item: SysDataHistory) => {
  dialogConfig.dialogType = 1
  detailText.value = item.entityUpdateInfo || ''
  currentId.value = item.id
  dialogConfig.dialogShow = true
}

// 实体类显示
const handleShowTip = (row: SysDataHistory) => {
  if (row.entityId) {
    return row.entityClass + (row.entityId ? ':' + row.entityId : '')
  }
  return row.entityClass || '--'
}
useActivated(() => {
  handleList()
})
</script>

<template>
  <div class="flex_col">
    <div class="flex_col_header">
      <SearchForm
        v-model="tableConfig.queryParams"
        :bnt-loading="tableConfig.tableLoading"
        :list="searchList"
        @change="handleList"
        @search="handleList"
      ></SearchForm>
    </div>

    <el-table
      border
      style="width: 100%"
      :header-cell-style="{
        backgroundColor: 'var(--el-color-info-light-9)'
      }"
      :data="tableConfig.dataList"
      v-loading="tableConfig.tableLoading"
      class="flex_col_body"
      stripe
    >
      <el-table-column
        prop="id"
        label="ID"
        align="center"
        minWidth="60"
        fixed="left"
      ></el-table-column>
      <el-table-column
        prop="userName"
        label="登录名称"
        align="center"
        minWidth="100"
      ></el-table-column>
      <el-table-column
        prop="realName"
        :label="t('user.realName')"
        align="center"
        minWidth="100"
      ></el-table-column>
      <el-table-column
        prop="userType"
        label="用户类型"
        align="center"
        minWidth="100"
      >
        <template #default="scope">
          <span>{{ handleTypeForLabel(scope.row.userType, userTypes) }}</span>
        </template>
      </el-table-column>
      <el-table-column
        prop="userIp"
        label="用户IP"
        align="center"
        minWidth="100"
      ></el-table-column>
      <el-table-column
        prop="entityName"
        label="实体名"
        align="center"
        fixed="left"
        minWidth="120"
      >
        <template #default="{ row }">
          <el-tooltip
            class="box-item"
            effect="dark"
            :content="handleShowTip(row)"
            placement="bottom"
            trigger="click"
          >
            <el-link
              underline="never"
              :type="row.entityClass ? 'primary' : 'default'"
            >
              {{ row.entityName }}
            </el-link>
          </el-tooltip>
        </template>
      </el-table-column>
      <el-table-column
        prop="remark"
        label="备注信息"
        align="center"
        minWidth="180"
      ></el-table-column>
      <el-table-column
        prop="entityData"
        label="数据详情"
        align="center"
        width="180"
      >
        <template #default="scope">
          <el-link
            underline="never"
            type="success"
            @click="handleDetailForEntityData(scope.row)"
          >
            {{ t('showDetail') }}
          </el-link>
        </template>
      </el-table-column>
      <el-table-column
        prop="entityUpdateInfo"
        label="变更信息"
        align="center"
        width="180"
      >
        <template #default="scope">
          <el-link
            underline="never"
            type="success"
            @click="handleDetailForEntityUpdateInfo(scope.row)"
          >
            {{ t('showDetail') }}
          </el-link>
        </template>
      </el-table-column>
      <el-table-column
        prop="createDate"
        label="变更日期"
        align="center"
        width="180"
      >
        <template #default="scope">
          <span>
            {{ dayjs(scope.row.createDate).format('YYYY-MM-DD HH:mm:ss') }}
          </span>
        </template>
      </el-table-column>
    </el-table>
    <Pagination
      v-model:page-size="tableConfig.queryParams.$rn"
      @page-size-change="handleList(false)"
      :total="tableConfig.sizeAll"
      v-model:current-page="tableConfig.queryParams.$pg"
      @current-change="handleList(false)"
      class="flex_col_bottom"
    />
  </div>

  <DataDiffTable
    v-model:show="dialogConfig.dialogShow"
    :title="dialogTitle"
    :data="detailText"
  ></DataDiffTable>

  <DataHistoryLog
    v-model:show="showDataHistory"
    :data="detailText"
    :id="currentId"
  ></DataHistoryLog>
</template>

<style lang="scss" scoped>
.textAlignLeft {
  text-align: left;
}

.detailShow {
  :deep(.el-dialog__body) {
    height: 600px;
    overflow: auto;
  }
}
</style>
