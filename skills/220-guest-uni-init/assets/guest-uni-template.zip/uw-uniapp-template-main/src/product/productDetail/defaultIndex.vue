<!-- 商品详情页面 - 初版 -->
<template>
  <div class="detail">
    <!-- 轮播图 -->
    <ZDetailSwipe
      v-if="detail.infoId"
      :images="swipeList"
      :title="detail.infoTitle"
      :video="detail.signVedio"
      :scrollTop="scrollTop"
      :region="`${detail.areaName || ''} ${detail.areaName ? '·' : ''} ${
        treeNameMap[detail.treeId as keyof typeof treeNameMap]
      }`"
    />
    <!-- 基础信息栏 -->
    <div
      class="detail-info-box"
      :class="{ 'poi-detail-info-box': isPoiScene || userInfo.isPoi === 1 }"
      v-if="[0, 1, 2, 3, 5, 7, 8, 11, 12, 14].indexOf(detail.treeId) > -1"
    >
      <ZDetailInfo
        :treeId="detail.treeId"
        :title="detailInfoTitle"
        :sale-price="detail.salePrice"
        :market-price="detailMarketPrice"
        :price="userType > 0 ? detail.price : 0"
        :progress-bar="detail.progressBar"
        :sold="
          detail.ticketCount +
          detail.attentCount +
          `${detail.treeId === 8 ? '件' : ''}`
        "
        :soldText="detail.treeId === 8 ? '已办理' : '已售'"
        :longitude="detail.longitude"
        :latitude="detail.latitude"
        :area-name="detail.areaName || ''"
        :view-name="detail.viewName"
        :address="detail.address"
        :viewNames="detail.viewNames"
        :order-start-date="detail.orderStartDate"
        :order-end-date="detail.orderEndDate"
        :current-time="detail.currentTime"
        :brokerage="detail.salePrice - detail.price"
        :is-changeask="detail.isChangeask"
        :couponInfo="couponInfo"
        :productId="infoId"
        :isCancel="detail.isCancel"
        :cancelRule="cancelRule"
        :phone="detailPhone"
        :dyProductInfo="detail.dyProductInfo"
        :appointment="detail.sendContent || detail.sendContent2"
        :b2bCashback="detail.b2bCashback"
        :yyUrl="detail.yyUrl"
      ></ZDetailInfo>
      <template
        v-if="detail.qualificationsInfo && detail.qualificationsInfo.length > 0"
      >
        <view
          class="detail-certification space-between flex-align"
          @click="zzShow = true"
        >
          <view class="detail-certification-left flex-align">
            <image
              class="img"
              src="http://qnimg.zowoyoo.com/img/1198722/1626079040637.png"
            />
            <text>商家资质</text>
          </view>
          <view class="detail-certification-right"></view>
        </view>
      </template>
    </div>
    <!-- 期票展示 -->
    <template v-if="detail.isValidity === 1">
      <ZRichText title="价格说明">
        <div>
          <div class="snap-introduce">【使用日期】：{{ validityText }}</div>
          <div
            class="snap-introduce"
            v-if="Number(detail.marketPrice) > 0"
          >
            【市场价格】：
            <span class="line-through">{{ detail.marketPrice }}</span>
            {{ currencyCN }}
          </div>
          <div class="snap-introduce">
            【优惠价格】：{{ userType === 0 ? detail.salePrice : detail.price
            }}{{ currencyCN }}
          </div>
        </div>
      </ZRichText>
      <div class="interim"></div>
    </template>
    <!-- 抢购基本信息 -->
    <template v-if="detail.treeId === 12">
      <ZRichText title="抢购说明">
        <mp-html
          selectable
          :content="detail.prodTimeDesc"
          :copy-link="false"
          @linktap="clickLink"
          :tag-style="{
            img: 'display: block'
          }"
        ></mp-html>
      </ZRichText>
      <div class="interim"></div>
    </template>

    <!-- 套餐包含 -->
    <template
      v-if="
        (detail.treeId === 1 || detail.treeId === 2) &&
        detail.setMealDetail &&
        detail.setMealDetail.packageProdIncludes &&
        detail.setMealDetail.packageProdIncludes.length
      "
    >
      <DetailContent
        title="套餐包含"
        :maxHeight="9999"
      >
        <div
          v-for="(item, index) in detail.setMealDetail.packageProdIncludes"
          :key="item.id"
        >
          {{ Number(index) + 1 }}、{{ switchPackages(item) }}
        </div>
      </DetailContent>
      <div class="interim"></div>
    </template>
    <!-- 日历选择 -->
    <template v-if="calendarShow">
      <div
        class="calendar-title"
        v-if="pricePlans.planName"
      >
        <span class="title">发团计划</span>
        <picker
          :range="detail.pricePlans"
          range-key="planName"
          @change="handlePicker"
        >
          <span class="select">
            <span>{{ pricePlans.planName }}</span>
            <u-icon
              name="arrow-down"
              color="#999"
              size="28"
            ></u-icon>
          </span>
        </picker>
      </div>
      <ZCalendar
        ref="ZCalendar"
        date-type="price"
        :range="calendarRange"
        :days="calendarPrices"
        :defaultMonth="defaultMonth"
        :hiddenCurrency="hiddenCurrency"
        @change="handleChangeCalendar"
        @pre-month="handlePreMonth"
        @next-month="handleNextMonth"
        @pre-year="handlePreYear"
        @next-year="handleNextYear"
        @transmitDate="transmitDate"
      ></ZCalendar>
      <div class="interim"></div>
    </template>
    <!-- 酒店基本信息 -->
    <template v-if="detail.treeId === 5">
      <ZRichText title="基本信息">
        <div class="">
          <div class="snap-introduce">
            <span>产品编号：</span>
            {{ detail.infoId }}
          </div>
          <div class="snap-introduce">
            <span>对应酒店：</span>
            {{ detail.viewName }}
          </div>
          <div class="snap-introduce">
            <span>所在城市：</span>
            {{ detail.areaName }}
          </div>
          <div class="snap-introduce">
            <span>提前天数：</span>
            {{
              detail.startDay > 0
                ? `需提前${detail.startDay}天预订`
                : startTimeCal
            }}
          </div>
          <div class="snap-introduce">
            <span>确认方式：</span>
            {{ detail.isConfirm === 1 ? '预订后需人工确认订单才' : '预订后即'
            }}{{ detail.isOnlinePay === 1 ? '可支付' : '有效' }}
          </div>
          <div class="snap-introduce">
            <span>付款方式：</span>
            {{ detail.isOnlinepay === 1 ? '在线支付' : '窗口现付' }}
          </div>
          <template v-if="detail.hotelDetail">
            <div
              class="snap-introduce"
              v-if="detail.hotelDetail.nights !== 0"
            >
              <span>连住要求：</span>
              要求连住{{ detail.hotelDetail.nights }}晚以上
            </div>
            <div class="snap-introduce">
              <span>星级：</span>
              {{ detail.hotelDetail.roomGrade }}
            </div>
            <div class="snap-introduce">
              <span>早餐：</span>
              {{ detail.hotelDetail.brekker }}
            </div>
            <div class="snap-introduce">
              <span>宽带：</span>
              {{ detail.hotelDetail.internet }}
            </div>
            <div class="snap-introduce">
              <span>床型：</span>
              {{ detail.hotelDetail.bedtype }}（{{
                detail.hotelDetail.notaddbed === 0 ? '不能加床' : '可以加床'
              }}）
            </div>
          </template>
        </div>
      </ZRichText>
    </template>
    <!-- 线路基本信息-->
    <template v-if="detail.treeId === 3 && detail.lineDetail">
      <ZRichText title="基本信息">
        <div class="">
          <div class="snap-introduce">
            <span>产品编号</span>
            ：{{ detail.infoId }}
          </div>
          <div class="snap-introduce">
            <span>提前天数</span>
            ：{{
              detail.startDay > 0
                ? `需提前${detail.startDay}天预订`
                : startTimeCal
            }}
          </div>
          <div class="snap-introduce">
            <span>确认方式</span>
            ：{{ detail.isConfirm === 1 ? '预订后需人工确认订单才' : '预订后即'
            }}{{ detail.isOnlinePay === 1 ? '可支付' : '有效' }}
          </div>
          <div class="snap-introduce">
            <span>付款方式</span>
            ：{{ detail.isOnlinepay === 1 ? '在线支付' : '窗口现付' }}
          </div>
          <div class="snap-introduce">
            <span>适合人群</span>
            ：{{ detail.lineDetail.peoples || detail.peoples }}
          </div>
          <div class="snap-introduce">
            <span>线路类型</span>
            ：{{ detail.lineDetail.lineClassName }}
          </div>
          <div class="snap-introduce">
            <span>交通方式</span>
            ：{{ detail.lineDetail.lineTrafficName }}
          </div>
        </div>
      </ZRichText>
      <div style="height: 10px; background: #f0f0f0"></div>
    </template>

    <!-- 线路行程描述-自定义 -->
    <template
      v-if="
        detail.treeId === 3 &&
        lineDetails !== undefined &&
        lineDetails.length > 0 &&
        appId !== 'wxe4f357c6a8deda97'
      "
    >
      <LineTripDesc :lineProductJourneys="lineDetails"></LineTripDesc>
    </template>
    <!-- 商品基本信息 -->
    <template v-if="detail.treeId === 11">
      <ZRichText title="基本信息">
        <div class="">
          <div class="snap-introduce">产品编号：{{ infoId }}</div>
          <div class="snap-introduce">
            确认方式：{{
              detail.isConfirm === 1 ? '预订后需人工确认订单才' : '预订后即'
            }}{{ detail.isOnlinePay === 1 ? '可支付' : '有效' }}
          </div>
          <div class="snap-introduce">
            付款方式：{{ detail.isOnlinepay === 1 ? '在线支付' : '窗口现付' }}
          </div>
        </div>
      </ZRichText>
      <div class="interim"></div>
    </template>
    <!-- 租车基本信息 -->
    <template v-if="detail.treeId === 7 && detail.carProduct">
      <z-rich-text title="基本信息">
        <div class="snap-introduce">
          <span>租车城市</span>
          ：{{ detail.areaName }}
        </div>
        <div class="snap-introduce">
          <span>提前天数</span>
          ：{{
            detail.startDay > 0
              ? `需提前${detail.startDay}天预订`
              : startTimeCal
          }}
        </div>
        <div class="snap-introduce">
          <span>确认方式</span>
          ：{{ detail.isConfirm === 1 ? '预订后需人工确认订单才' : '预订后即'
          }}{{ detail.isOnlinePay === 1 ? '可支付' : '有效' }}
        </div>
        <div class="snap-introduce">
          <span>付款方式</span>
          ：{{ detail.isOnlinepay === 1 ? '在线支付' : '窗口现付' }}
        </div>
        <div class="snap-introduce">
          <span>租车类型</span>
          ：{{
            leasesType[detail.carProduct.leasesType as keyof typeof leasesType]
          }}
        </div>
        <div class="snap-introduce">
          <span>座位数量</span>
          ：{{ detail.carProduct.seatNum }}座
        </div>
        <div class="snap-introduce">
          <span>车辆品牌</span>
          ：{{ detail.carProduct.brandName }}
        </div>
        <div class="snap-introduce">
          <span>变速器</span>
          ：{{ detail.carProduct.isAuto === 1 ? '自动挡' : '手动挡' }}
        </div>
        <div class="snap-introduce">
          <span>司机费用</span>
          ：{{
            detail.carProduct.isDriver === 1 ? '含司机费用' : '不含司机费用'
          }}
        </div>
      </z-rich-text>
      <div style="height: 10px; background: #f0f0f0"></div>
    </template>
    <!-- 签证基本信息 -->
    <template v-if="detail.treeId === 8">
      <z-rich-text title="基本信息">
        <div class="snap-introduce">
          <span>产品编号</span>
          ：{{ infoId }}
        </div>
        <div class="snap-introduce">
          <span>签证国家</span>
          ：{{ detail.areaName }}
        </div>
        <div class="snap-introduce">
          <span>提前天数</span>
          ：{{
            detail.startDay > 0
              ? `需提前${detail.startDay}天预订`
              : startTimeCal
          }}
        </div>
        <div class="snap-introduce">
          <span>确认方式</span>
          ：{{ detail.isConfirm === 1 ? '预订后需人工确认订单才' : '预订后即'
          }}{{ detail.isOnlinePay === 1 ? '可支付' : '有效' }}
        </div>
        <div class="snap-introduce">
          <span>付款方式</span>
          ：{{ detail.isOnlinepay === 1 ? '在线支付' : '窗口现付' }}
        </div>
        <div class="snap-introduce">
          <span>受理范围</span>
          ：{{ detail.peoples }}
        </div>
        <div
          class="snap-introduce"
          v-if="visaDetail.stopDate"
        >
          <span>停留日期</span>
          ：{{ visaDetail.stopDate }}
        </div>
        <div
          class="snap-introduce"
          v-if="visaDetail.needDay"
        >
          <span>所需工作日</span>
          ：{{ visaDetail.needDay }}个工作日
        </div>
        <div
          class="snap-introduce"
          v-if="visaDetail.isView"
        >
          <span>面试情况</span>
          ：{{ visaDetail.isView }}
        </div>
        <div
          class="snap-introduce"
          v-if="visaDetail.isArrCon"
        >
          <span>入境情况</span>
          ：{{ visaDetail.isArrCon }}
        </div>
        <div class="snap-introduce">
          <span>包含签证费用</span>
          ：{{ visaDetail.incVisaFee === 0 ? '不包含' : '包含' }}
        </div>
      </z-rich-text>
      <div style="height: 10px; background: #f0f0f0"></div>
    </template>
    <template v-if="!isXiCheng">
      <view
        class="detail-yy space-between flex-align"
        v-if="
          (detail.yyUrl || (detail.groupYYInfo && detail.groupYYInfo.yyLink)) &&
          showYYStock
        "
      >
        <image
          class="yy-img"
          src="/static/images/yy_img.png"
        ></image>
        <view class="detail-yy__title">本产品需要预约</view>
        <view
          class="detail-yy__btn flex-align"
          @click="YyPopupFlag = true"
        >
          <text>查看预约库存</text>
          <u-icon name="arrow-right"></u-icon>
        </view>
      </view>
    </template>
    <!-- 全部套餐 类型b2b的相似产品-->
    <template v-if="productsList.length && isShowMeal">
      <ZSetMeal
        title="相关套餐"
        :num="3"
        :dataList="productsList"
        @click="handleClickSetMeal"
        @reserve="handleClickSetMeal"
      />
      <div class="interim"></div>
    </template>

    <template v-if="productsList.length && isShowMeal">
      <div class="xunlong-set_meal">
        <ZTitle
          title="相关套餐"
          :icon="false"
          :more="false"
        />
        <ZSlideCard
          :showTop="false"
          :list="productsList"
          :isShowModal="false"
          @click="handleClickSetMeal"
        />
      </div>
    </template>

    <!-- 富文本渲染 -->
    <!-- 预定须知 -->
    <div class="parse">
      <p
        class="parse-title"
        v-if="desc"
      >
        {{ explain[detail.treeId as keyof typeof explain] }}
      </p>
      <view class="detail-desc-box">
        <mp-html
          selectable
          :copy-link="false"
          @linktap="clickLink"
          :content="desc"
          :tag-style="{
            img: 'display: block'
          }"
          error-img="http://qnimg.zowoyoo.com/img/84826/1621847833863.png"
        ></mp-html>
      </view>
    </div>
    <div
      class="interim"
      v-if="desc"
    ></div>
    <!-- 产品描述 -->
    <div
      class="parse"
      v-if="
        (detail.contentImgs && detail.contentImgs.length > 0) || contentText
      "
    >
      <p
        class="parse-title"
        v-if="
          (detail.contentImgs && detail.contentImgs.length > 0) || contentText
        "
      >
        {{ contentDetails[detail.treeId as keyof typeof contentDetails] }}
      </p>
      <template v-if="detail.contentImgs && detail.contentImgs.length > 0">
        <view class="detail-desc-box">
          <image
            class="parse-image"
            v-for="(item, index) in detail.contentImgs"
            :key="index"
            :src="item"
            mode="widthFix"
            lazy-load
          />
        </view>
      </template>
      <template v-else>
        <view class="detail-desc-box">
          <mp-html
            selectable
            :copy-link="false"
            @linktap="clickLink"
            :content="contentText"
            :tag-style="{
              img: 'display: block'
            }"
            error-img="http://qnimg.zowoyoo.com/img/84826/1621847833863.png"
          ></mp-html>
        </view>
      </template>
    </div>

    <div
      class="interim"
      v-if="contentText"
    ></div>
    <!-- 其他需要渲染的富文本 -->
    <div
      v-for="(item, index) in parserList"
      :key="index"
    >
      <div class="parse">
        <p class="parse-title">{{ item.title }}</p>
        <view class="detail-desc-box">
          <mp-html
            selectable
            :copy-link="false"
            @linktap="clickLink"
            v-if="!item.type || item.type === 'rich'"
            :content="replaceSection(item.content)"
            :tag-style="{
              img: 'display: block'
            }"
            error-img="http://qnimg.zowoyoo.com/img/84826/1621847833863.png"
          ></mp-html>
          <template v-if="item.type === 'file'">
            <view
              class="flex-row flex-align file-item"
              v-for="(file, index) in item.fileList"
              :key="index"
            >
              <text class="custom-icon custom-icon-order"></text>
              <!-- 点击事件直接传file过去，点击时报错  原因未知  直接传对象可以 -->
              <view
                class="file-item-name"
                @click.stop="
                  clickDownloadFile({ name: file.name, value: file.value })
                "
              >
                {{ file.name }}
              </view>
            </view>
          </template>
        </view>
      </div>
      <div class="interim"></div>
    </div>
    <!-- 相关套餐 -->
    <template v-if="productsList.length">
      <ZSetMeal
        title="相关套餐"
        :num="3"
        :dataList="productsList"
        @click="handleClickSetMeal"
        @reserve="handleClickSetMeal"
      />
      <div class="interim"></div>
    </template>

    <Specification
      v-model="showSpecification"
      :btnText="specAddCart ? '加入购物车' : '立即预订'"
      :img="detail.signImg || ''"
      :packageList="specsInfo.packageList"
      :priceList="specsInfo.priceList"
      @clickBuy="goPlaceorder"
    />
    <!-- 优惠券框 -->
    <CouponInputItem
      :showCouponPop="showCouponPop"
      :productId="reserveDataReserve.infoId"
      @save="saveCouponId"
      :number="selectNum"
      :orderData="reserveDataReserve"
      :price="couponPrice"
      :salePrice="couponSalePrice"
      pageType="goodspopup"
    />

    <ZDetailButton
      v-if="detail.infoId"
      isShow
      :price="
        userType === 0
          ? calendarSalePrice || detail.salePrice
          : calendarPrice || detail.price
      "
      :typeUi="buttonTypeUi"
      :sale-price="detail.jpint ? detail.jpint.salePriceDesc : 0"
      :num="detail.joint ? detail.joint.groupMinNum : 0"
      :btnText="buttonText"
      :disabled="calendarPricesType"
      @click="clickBtn"
      @changeIsShowModal="changeIsShowModal"
      :posterImg="detail.posterImg"
      :posterType="detail.posterType"
      :detail="detail"
      :home="showHome"
      :cartNumber="cartNumber"
      :my="!isShowShopCart"
      :shopCart="isShowShopCart"
      :service="showService"
    />

    <SharePopup
      v-model="isShowModal"
      v-if="isShowModal"
      :signImg="detail.signImg"
      :infoId="detail.infoId"
    ></SharePopup>

    <ZUp :scrollTop="scrollTop" />
    <view
      class="certification-pop"
      v-if="zzShow"
    >
      <view
        class="mask"
        @click="zzShow = false"
        catchtouchmove="true"
      ></view>
      <view class="certification-box">
        <view
          class="certification-close"
          @click="zzShow = false"
        >
          <img
            class="img"
            src="http://qnimg.zowoyoo.com/img/84826/1626163495637.png"
          />
        </view>
        <view class="box-top"><text>服务资质</text></view>
        <view class="box-tips">
          【特别提醒】营业执照为官方展示，
          <text>严禁下载复印</text>
          ，违者后果自负
        </view>
        <scroll-view
          class="box-img"
          scroll-y
        >
          <image
            v-for="(item, index) in detail.qualificationsInfo"
            @click="toPrivewImage(item)"
            :key="index"
            class="image"
            :src="item"
            mode="widthFix"
          />
        </scroll-view>
      </view>
    </view>

    <!-- 查看预约库存数量、日历弹窗 -->
    <YYPopup
      v-model="YyPopupFlag"
      :infoId="detail.infoId || ''"
      :yyLink="detail.groupYYInfo ? detail.groupYYInfo.yyLink : ''"
    />
  </div>
</template>

<script lang="ts" setup>
// 导入组件
import mpHtml from 'mp-html/dist/uni-app/components/mp-html/mp-html'
import ZDetailSwipe from './components/ZDetailSwiper/index.vue'
import ZDetailInfo from '../components/ZDetailInfo/index.vue'
import ZRichText from '../components/ZRichText/index.vue'
import ZDetailButton from './components/ZBottomBtn/index.vue'
import SharePopup from '@/components/SharePopup/index.vue'
import ZCalendar from '@/components/ZCalendar/index.vue'
import ZSetMeal from './components/ZSetMeal/index.vue'
import ZUp from '@/components/ZUp/index.vue'
import Specification from '../components/GoodsPopup.vue/Specification.vue'
import LineTripDesc from '../components/LineTripDesc.vue/index.vue'
import CouponInputItem from '../components/CouponInputItem/GoodsCoupon.vue'
import DetailContent from '../components/DetailContent/index.vue'
import ZTitle from '@/components/ZTitle/index.vue'
import ZSlideCard from './components/ZSlideCard/index.vue'
import YYPopup from './components/YYPopup/index.vue'
// 导入工具函数
import {
  // parseTime,
  // getAllDate,
  // datedifference,
  CalculationPrice,
  getMonthStarEnd,
  formatParam,
  formatDate,
  replaceSection
  // replaceImgStyle
} from '@/utils/tool'
import { treeNameMap } from '@/product/treeIdMap'
import validityTypeSelect from '@/product/config/validityTypeSelect'
// 导入API函数
import {
  prodDetail,
  // content,
  priceCalendar,
  // listSubMsgTpl,
  prodSpecs,
  viewsDetail,
  // getProductDescUrl,
  subMsg,
  // couponList,
  getShoppingCartList,
  addShoppingCart
  // getTicketTypeInfo
} from '@/api/text'

import { ref, reactive, computed, nextTick } from 'vue'
import {
  onPageScroll,
  onLoad,
  // onHide,
  // onUnload,
  onShareAppMessage,
  onShareTimeline
} from '@dcloudio/uni-app'
// 导入Store
import { useUserStore } from '@/store/user'

// 使用store
const userStore = useUserStore()
const userInfo: any = computed(() => {
  return userStore.userInfo
})
// const token = computed(() => {
//   return userStore.token
// })
const appId = computed(() => {
  return userStore.appId
})
const scene = computed(() => {
  return userStore.appId
})
// const dyVideoId = computed(() => {
//   return userStore.dyVideoId
// })
// 响应式数据定义
const YyPopupFlag = ref(false)
const selectMoney = ref(0)
const couponForm = reactive({
  receiveIds: [] as string[],
  subCouponMoney: 0
})
const reserveDataReserve = ref<any>({})
const selectNum = ref(0)
const showCouponPop = ref(false)
const couponPrice = ref(0)
const couponSalePrice = ref(0)
const dyVideoIdLocal = ref('')
const showSpecification = ref(false)
const scrollTop = ref(0)
const infoId = ref('')
const detail = ref<any>({} as any)
const lineDetails = ref<any[]>([])
const validityText = ref('')
const contentText = ref('')
const desc = ref('')
const endDate = ref('')
const startDate = ref('')
const calendarPrices = ref<any[]>([])
const oldCalendarPrices = ref<any[]>([])
const calendarPricesFlag = ref(1)
const defaultMonth = ref('')
const pricePlans = ref<any>({} as any)
const travelDate = ref('')
const endTravelDate = ref('')
const parserList = ref<any[]>([])
const couponInfo = ref<any[]>([])
// const imageList = ref<string[]>([])
// const imageUrlList = ref<string[]>([])
// const percent = ref(0)
// const schedule = ref(false)
// const issuedNum = ref(0)
const isShowModal = ref(false)
const zzShow = ref(false)
// const zzImg = ref<string[]>([])
const phone = ref('')
const tmplIds = ref<any[]>([])
const specsInfo = ref<any>({
  packageList: [],
  priceList: []
})
const calendarSalePrice = ref(0)
const calendarPrice = ref(0)
const specId = ref('')
// const typeTicket = ref<any[]>([])
const treeId = ref(0)
const cartNumber = ref(0)
const specAddCart = ref(false)
const urlPlanId = ref(-99)

// 常量定义
const explain = {
  0: '预订须知',
  1: '预订须知',
  3: '参团须知',
  5: '房型预订说明',
  11: '预订须知',
  12: '抢购须知',
  7: '预订须知',
  8: '预订须知'
}

const contentDetails = {
  0: '产品描述',
  1: '产品描述',
  3: '行程描述',
  5: '房型详细说明',
  11: '产品描述',
  12: '产品描述',
  7: '详情说明',
  8: '详情说明'
}
const leasesType = {
  // 这里需要根据实际情况填充leasesType对象的内容
}
// 计算属性
const currencyCN = computed(() => {
  return '元' // 示例值
})

// 计算属性
const isShowShopCart = computed(() => {
  let flag = false
  // #ifdef MP-WEIXIN
  flag =
    ['wxc627db84bc3463e9'].includes(appId.value) &&
    [0, 1, 11, 12].includes(Number(treeId.value))
  // #endif
  return flag
})

const showHome = computed(() => {
  if (isNoBackCDTravelHome.value) return false
  return true
})

const showService = computed(() => {
  if ([6790071].includes(Number(parentCustId.value))) return false
  return true
})

const isNoBackCDTravelHome = computed(() => {
  return (
    [6790071].includes(Number(parentCustId.value)) &&
    uni.getStorageSync('noBackCDTravelHome')
  )
})

const isShowMeal = computed(() => true)

const hiddenCurrency = computed(() => {
  return [7111401].includes(Number(parentCustId.value))
})

const parentCustId = computed(() => userInfo.value.parentCustId)

const env = computed(() => process.env.VUE_APP_PLATFORM)

const detailPhone = computed(() => phone.value || '')

const detailInfoTitle = computed(() => detail.value.infoTitle || '')

const detailMarketPrice = computed(() => detail.value.marketPrice || 0)

// const yyImageShow = computed(() => {
//   if (isXhs.value) {
//     return (
//       detail.value.groupYYInfo && detail.value.groupYYInfo.yyLink && desc.value
//     )
//   }
//   return desc.value
// })

const buttonTypeUi = computed(() => {
  if (userType.value > 0) {
    return 'B2B'
  }
  return 'B2C'
})

const buttonText = computed(() => {
  if (detail.value.state === 1) {
    return '已下架'
  }
  if (detail.value.isSellOut) {
    return '已售罄'
  }
  if (
    detail.value.currentTime < detail.value.orderStartDate &&
    detail.value.saleNotify
  ) {
    return '已设置'
  }
  // #ifdef MP-WEIXIN
  if (detail.value.currentTime < detail.value.orderStartDate) {
    return '设置提醒'
  }
  // #endif
  return '立即预订'
})

const calendarPricesType = computed(() => {
  // 已下架直接禁用
  if (detail.value.state === 1) {
    return 1
  }
  const treeIdVal = Number(detail.value.treeId)
  const validityType = Number(detail.value.validityType)

  // #ifdef MP-WEIXIN
  // 已设置提醒
  if (
    detail.value.currentTime < detail.value.orderStartDate &&
    detail.value.saleNotify
  ) {
    return 3
  }
  // #endif

  // 判断是否已经开售
  if (detail.value.currentTime < detail.value.orderStartDate) {
    return 1
  }

  // 期票判断逻辑
  if ([0, 1, 2].includes(treeIdVal) && [1, 2, 5].includes(validityType)) {
    return 2
  }

  if ([5].includes(treeIdVal) && [2, 3].includes(validityType)) {
    return 2
  }

  // 普通门票和住宿判断
  if ([0, 1, 5].includes(treeIdVal) && calendarPrices.value.length !== 0) {
    return 2
  }

  // 线路判断
  if (
    [3].includes(treeIdVal) &&
    calendarPrices.value.length !== 0 &&
    detail.value.isSellOut !== 1
  ) {
    return 2
  }

  // 抢购产品判断
  if ([12, 11].includes(treeIdVal) && detail.value.isSellOut !== 1) {
    return 2
  }

  // 交通产品
  if ([14].includes(treeIdVal) && detail.value.isSellOut !== 1) {
    return 2
  }

  if (detail.value.state === 0 && treeIdVal === 8) {
    return 2
  }

  // 默认禁用
  return 1
})

const productsList = computed(() => {
  const { products } = detail.value
  if (products && products.length > 0) {
    let arr = detail.value.products.filter((e: any) => {
      return e.infoId !== Number(infoId.value)
    })
    return arr.map((el: any) => ({
      ...el,
      title: el.infoTitle,
      salePrice: el.salePrice,
      marketPrice: el.marketPrice,
      theme: [
        {
          name: el.startDay === 0 ? '当天预订' : `需提前${el.startDay}天预订`,
          color: '#78B1F6'
        }
      ]
    }))
  } else {
    return []
  }
})

const calendarShow = computed(() => {
  const arr = [0, 1, 3, 5, 8]
  const flag =
    arr.includes(detail.value.treeId) && detail.value.isValidity === 0
  return flag
})

const calendarRange = computed(() => [5, 7].includes(detail.value.treeId))

const swipeList = computed(() => {
  if (detail.value.pictures && detail.value.pictures.length) {
    return detail.value.pictures
  }
  return detail.value.signImg || ''
})

// const regionName = computed(() => {
//   return `${detail.value.areaName || ''} ${detail.value.areaName ? '·' : ''} ${
//     treeNameMap[detail.value.treeId as keyof typeof treeNameMap]
//   }`
// })

// const isShopCarScene = computed(() => {
//   return (
//     String(scene.value) === '990001' &&
//     process.env.VUE_APP_PLATFORM === 'mp-toutiao'
//   )
// })

// const isCardScene = computed(() => {
//   return (
//     String(scene.value) === '023010' &&
//     process.env.VUE_APP_PLATFORM === 'mp-toutiao'
//   )
// })

const isPoiScene = computed(() => {
  return (
    String(scene.value) === '023005' &&
    process.env.VUE_APP_PLATFORM === 'mp-toutiao'
  )
})

// const isBaidu = computed(() => process.env.VUE_APP_PLATFORM === 'mp-baidu')

// const isXhs = computed(() => process.env.VUE_APP_PLATFORM === 'mp-xhs')

const userType = computed(() => userInfo.value.userType || 0)

const startTimeCal = computed(() => {
  let res = ''
  if (CalculationPrice(detail.value.startTime / 60) > 0) {
    res = Math.floor(detail.value.startTime / 60) + '点'
    if (Math.floor(detail.value.startTime % 60) > 0) {
      res = `${res}${Math.floor(detail.value.startTime % 60)}分钟`
    }
    return '当天可预订，并在' + res + '前下单'
  } else {
    return ''
  }
})

const visaDetail = computed(() => detail.value.visaDetail)

const showYYStock = computed(() => {
  if (
    detail.value.yyUrl ||
    (detail.value.groupYYInfo && detail.value.groupYYInfo.yyLink)
  ) {
    return true
  }
  if (
    env.value === 'mp-xhs' &&
    detail.value.xhsProductInfo &&
    detail.value.xhsProductInfo.skuType === 2
  ) {
    return true
  }
  return false
})

const isXiCheng = computed(() => {
  return (
    appId.value === 'wx99bab2771579ff5c' || appId.value === 'wxc627db84bc3463e9'
  )
})

const cancelRule = computed(() => {
  let rule: any[] = []
  if (detail.value && detail.value.cancelRule) {
    rule = detail.value.cancelRule
  }
  return rule
})

// 购物车相关方法
const handleCartNumber = async (type?: string) => {
  try {
    const res: any = await getShoppingCartList({ autoCount: true })
    if (res.state === 1) {
      cartNumber.value = res.data.sizeAll
      if (type === 'update') {
        uni.showToast({
          title: '添加成功',
          icon: 'none',
          duration: 2000
        })
      }
    }
  } catch (error) {
    console.error('获取购物车数量失败:', error)
  }
}

const handleAddCart = async (specInfo?: any) => {
  // 需要选择日历的逻辑
  if (calendarShow.value) {
    if (calendarRange.value && !travelDate.value && !endTravelDate.value) {
      uni.showToast({
        title: '请选择日历范围',
        icon: 'none',
        duration: 2000
      })
      return
    } else if (!travelDate.value) {
      uni.showToast({
        title: '请选择日历',
        icon: 'none',
        duration: 2000
      })
      return
    }
  }

  // 多规格产品处理
  if (detail.value.specName === 1 && !specInfo) {
    showSpecification.value = true
    specAddCart.value = true
    uni.showToast({
      title: '请选择多规格',
      icon: 'none'
    })
    return
  }

  let price = 0
  if (specInfo) {
    price = userType.value === 0 ? specInfo.salePrice : specInfo.price
  } else {
    price =
      userType.value === 0
        ? calendarSalePrice.value || detail.value.salePrice
        : calendarPrice.value || detail.value.price
  }

  const params = {
    price,
    getType: treeId.value === 11 ? 0 : 1,
    img: detail.value.signImg,
    infoId: infoId.value,
    infoTitle: detail.value.infoTitle,
    num: detail.value.startNum || 1,
    specId: specInfo ? specInfo.id : '',
    specName: specInfo ? specInfo.spec : '',
    custId: detail.value.custId ? detail.value.custId : '',
    travelDate: treeId.value === 11 ? '' : travelDate.value,
    endTravelDate: treeId.value === 11 ? '' : endTravelDate.value,
    planId: pricePlans.value.planId || ''
  }

  try {
    const res: any = await addShoppingCart(params)
    if (res.state === 1) {
      handleCartNumber('update')
    }
  } catch (error) {
    console.error('添加购物车失败:', error)
  }
}

// 一键发圈优化
const changeIsShowModal = () => {
  isShowModal.value = true
}

// 放大图片（资质图片）
const toPrivewImage = (item: string) => {
  uni.previewImage({
    current: item,
    urls: detail.value.qualificationsInfo
  })
}

// 保存优惠券Id以及金额
const saveCouponId = (id: string[], money: number) => {
  selectMoney.value = money
  couponForm.receiveIds = id
  couponForm.subCouponMoney = money
}

// 获取当前产品优惠券信息
// const getCouponInfo = async () => {
//   try {
//     const res: any = await couponList({
//       productId: infoId.value,
//       receiveMode: 0
//     })
//     if (res.state === 1) {
//       couponInfo.value = res.data.results
//     }
//   } catch (error) {
//     console.error('获取优惠券信息失败:', error)
//   }
// }

// 发团计划选择
const handlePicker = (event: any) => {
  const { value } = event.detail
  pricePlans.value = detail.value.pricePlans[Number(value)]
  handlePriceCalendar()
}

// 相关产品点击
const handleClickSetMeal = (item: any) => {
  uni.pageScrollTo({
    scrollTop: 0
  })
  infoId.value = item.infoId
  handleInit()
}

// 日历月份切换
const handlePreMonth = (month: string) => {
  const arr = getMonthStarEnd(month)
  startDate.value = formatDate(arr[0], 'Y-M-D')
  endDate.value = formatDate(arr[1], 'Y-M-D')
  handlePriceCalendar()
}

const handleNextMonth = (month: string) => {
  const arr = getMonthStarEnd(month)
  startDate.value = formatDate(arr[0], 'Y-M-D')
  endDate.value = formatDate(arr[1], 'Y-M-D')
  handlePriceCalendar()
}

const handlePreYear = (year: string) => {
  // 实现上一年逻辑
  console.log('log输出的内容：year', year)
}

const handleNextYear = (year: string) => {
  // 实现下一年逻辑
  console.log('log输出的内容：year', year)
}

// 日历选择变化
const handleChangeCalendar = (Days: string[], daysInfo?: any) => {
  travelDate.value = Days[0]
  endTravelDate.value = Days[1] || ''
  if (daysInfo) {
    detail.value.price = daysInfo.price
    detail.value.salePrice = daysInfo.salePrice
    detail.value.marketPrice = daysInfo.marketPrice
  }
}

// 获取景区信息
const getView = async (viewIds: string) => {
  const viewId = viewIds.split(',')
  if (viewId.length) {
    try {
      const res: any = await viewsDetail({
        viewId: viewId[0]
      })
      if (res.state === 1) {
        phone.value = res.data.phone || detail.value.viewNames[0]?.phone || ''
      }
    } catch (error) {
      console.error('获取景区信息失败:', error)
    }
  }
}

// 产品详情获取
const handleProdDetail = async () => {
  uni.showLoading({
    title: '加载中...'
  })

  const params = {
    specId: specId.value
  }

  try {
    const res: any = await prodDetail(infoId.value, params)
    uni.hideLoading()

    if (res.state === 1) {
      detail.value = {
        ...res.data,
        orderCustId: userInfo.value.orderCustId
      }

      treeId.value = res.data.treeId

      if (isShowShopCart.value) handleCartNumber()

      uni.setNavigationBarTitle({
        title: res.data.infoTitle
      })

      validityText.value =
        validityTypeSelect(
          res.data.validityType,
          res.data.validityCon,
          res.data.isExpress,
          res.data.treeId
        ) || ''

      // 价格计划处理
      if (res.data.pricePlans && res.data.pricePlans.length) {
        const arr = res.data.pricePlans
        if (urlPlanId.value === -99) {
          pricePlans.value = arr[0] || {}
        } else {
          const foundPlan = arr.find(
            (item: any) => item.planId === Number(urlPlanId.value)
          )
          pricePlans.value = foundPlan || arr[0]
        }
      }

      // 费用包含等信息的处理
      if (res.data.chargeInclude) {
        parserList.value.push({
          title: '费用包含',
          content: res.data.chargeInclude
        })
      }

      // 其他信息处理...

      if (res.data.viewIds) {
        getView(res.data.viewIds)
      }

      // 多规格产品处理
      if (res.data.specName === 1) {
        getProdSpecs()
      }
    } else {
      uni.showToast({
        title: res.msg,
        icon: 'none',
        mask: true,
        duration: 2500
      })

      setTimeout(() => {
        const pages = getCurrentPages()
        if (pages.length > 1) {
          uni.navigateBack()
        } else {
          uni.redirectTo({
            url: '/pages/home/index',
            fail: () => {
              uni.switchTab({
                url: '/pages/home/index'
              })
            }
          })
        }
      }, 2500)
    }
  } catch (error) {
    uni.hideLoading()
    console.error('获取产品详情失败:', error)
  }
}

// 产品描述获取
// const handleContent = async () => {
//   try {
//     const res: any = await content(infoId.value)
//     if (res.state === 1) {
//       // #ifdef MP-TOUTIAO
//       if (isPoiScene.value || userInfo.value.isPoi === 1) {
//         res.data.replace(res.data.match('不设退款'), '可以退款')
//       }
//       // #endif
//       contentText.value = replaceImgStyle(
//         res.data,
//         'style="',
//         'style="max-width: 100% !important; height: 400px !important'
//       )
//     }
//   } catch (error) {
//     console.error('获取产品描述失败:', error)
//   }
// }

// 预订须知获取
// const handleDesc = async () => {
//   try {
//     const res: any = await getProductDescUrl(infoId.value)
//     if (res.state === 1) {
//       desc.value = replaceSection(res.data)
//     }
//   } catch (error) {
//     console.error('获取预订须知失败:', error)
//   }
// }

// 产品价格日历获取
const handlePriceCalendar = async (
  startDateParam?: string,
  endDateParam?: string
) => {
  const params = {
    infoId: infoId.value,
    endDate: endDateParam || endDate.value,
    startDate: startDateParam || startDate.value,
    planId: pricePlans.value.planId || '',
    startTime: detail.value.startTime,
    startDay: pricePlans.value.startDay
  }

  try {
    const res: any = await priceCalendar(params)
    if (res.state === 1) {
      oldCalendarPrices.value.push(...calendarPrices.value)
      calendarPrices.value = res.data

      if (res.data.length) {
        defaultMonth.value =
          formatDate(startDateParam || new Date(), 'Y/M') + '/01'
      } else if (!res.data.length && !defaultMonth.value) {
        defaultMonth.value =
          formatDate(startDateParam || new Date(), 'Y/M') + '/01'
      }

      if (res.data.length === 0 && calendarPricesFlag.value < 3) {
        calendarPricesFlag.value++
        nextTick(() => {
          let time = setTimeout(
            () => {
              clearTimeout(time)
              if (ZCalendar.value) {
                ZCalendar.value.rightClick()
              }
            },
            process.env.VUE_APP_PLATFORM === 'mp-xhs' ? 1500 : 600
          )
        })
      }
    }
  } catch (error) {
    console.error('获取价格日历失败:', error)
  }
}

// 套餐包含处理
const switchPackages = ({ infoTitle, treeId, num, roomNum, unit }: any) => {
  try {
    const treeIdNum = Number(treeId)
    const title = `${infoTitle}`

    switch (treeIdNum) {
      case 5: {
        return `${title} 包含${roomNum}间${num}晚`
      }
      case 7: {
        return `${title} 包含1辆${num}天`
      }
      default: {
        return `${title} 包含${num}${unit}`
      }
    }
  } catch (e) {
    uni.showToast({
      title: 'treeId 不存在' + e,
      icon: 'none',
      mask: true,
      duration: 2500
    })
    return ''
  }
}

// 线路数据处理
// const getLineTourProduct = (tourProduct: any) => {
//   const { feature, present, costDesc, nocostDesc, explain, tripDetails } =
//     tourProduct

//   lineDetails.value = tripDetails

//   if (feature) {
//     parserList.value.push({
//       title: '线路特色',
//       content: feature
//     })
//   }

//   if (present) {
//     parserList.value.push({
//       title: '赠送项目',
//       content: present
//     })
//   }

//   if (costDesc) {
//     parserList.value.push({
//       title: '费用包含',
//       content: costDesc
//     })
//   }

//   if (nocostDesc) {
//     parserList.value.push({
//       title: '费用不包含',
//       content: nocostDesc
//     })
//   }

//   if (explain) {
//     parserList.value.push({
//       title: '温馨提示',
//       content: explain
//     })
//   }
// }

// 底部按钮点击事件
const clickBtn = async (item?: string) => {
  if (!userInfo.value.maUserInfo || !userInfo.value.maUserInfo.openId) {
    uni.showToast({
      title: '请先登录！',
      icon: 'none',
      duration: 2000,
      success: () => {
        uni.navigateTo({
          url: '/user/login/index'
        })
      }
    })
    return
  }

  // 线路和酒店不支持加购
  if (
    isShowShopCart.value &&
    item === 'addCart' &&
    [3, 5].includes(Number(treeId.value))
  )
    return

  if (
    detail.value.currentTime < detail.value.orderStartDate &&
    detail.value.saleNotify
  ) {
    return
  }

  // 设置提醒逻辑
  if (
    detail.value.currentTime < detail.value.orderStartDate &&
    tmplIds.value.length &&
    item !== 'home' &&
    item !== 'user'
  ) {
    const tmplIdsList = tmplIds.value.map((item) => item.tplId)

    try {
      const res: any = await uni.requestSubscribeMessage({
        tmplIds: tmplIdsList
      })

      if (res.errMsg === 'requestSubscribeMessage:ok') {
        const acceptList = tmplIds.value.filter(
          (item, index) => res[tmplIdsList[index]] === 'accept'
        )

        if (acceptList.length > 0) {
          const resSub: any = await subMsg({
            refId: infoId.value,
            subList: acceptList
          })

          if (resSub.state === 1) {
            handleInit()
          } else {
            uni.showToast({
              title: resSub.msg,
              icon: 'none'
            })
          }
        }
      } else {
        uni.showToast({
          title: res.errMsg,
          icon: 'none'
        })
      }
    } catch (err: any) {
      uni.showToast({
        title: err.errMsg,
        icon: 'none'
      })
    }
    return
  }

  // 多规格处理
  if ((item === 'btn' || item === 'addCart') && detail.value.specName === 1) {
    specAddCart.value = item === 'addCart'
    showSpecification.value = true
    return
  }

  // 其他按钮处理
  switch (item) {
    case 'cart': {
      uni.navigateTo({
        url: '/shopCart/shoppingCart'
      })
      break
    }
    case 'addCart': {
      handleAddCart()
      break
    }
    case 'btn': {
      if (calendarShow.value) {
        if (calendarRange.value && !travelDate.value && !endTravelDate.value) {
          uni.showToast({
            title: '请选择日历范围',
            icon: 'none',
            duration: 2000
          })
        } else if (!travelDate.value) {
          uni.showToast({
            title: '请选择日历',
            icon: 'none',
            duration: 2000
          })
        } else {
          goPlaceorder()
        }
      } else {
        goPlaceorder()
      }
      break
    }
    case 'user': {
      if (isNoBackCDTravelHome.value) {
        uni.navigateTo({
          url: '/user/order/defaultOrderIndex'
        })
      } else {
        uni.reLaunch({
          url: '/user/index/index?'
        })
      }
      break
    }
    case 'joint': {
      const joint = detail.value.joint
      uni.navigateTo({
        url: `/joint/product/index?infoId=${infoId.value}&id=${joint.id}`
      })
      break
    }
    case 'home': {
      uni.reLaunch({
        url: '/pages/home/index?'
      })
      break
    }
    default: {
      break
    }
  }
}

// 跳转到下单页面
const goPlaceorder = (specInfo?: any) => {
  if (detail.value.specName === 1 && !specInfo) {
    showSpecification.value = true
    return false
  }

  // 酒店连住验证
  if (detail.value.treeId === 5) {
    const travelDateTime = new Date(travelDate.value).getTime()
    const endTravelDateTime = new Date(endTravelDate.value).getTime()
    const dayNum = (endTravelDateTime - travelDateTime) / 86400000

    const { hotelDetail } = detail.value
    if (hotelDetail.nights && hotelDetail.nights > dayNum) {
      uni.showToast({
        title: `该酒店至少需要连住${hotelDetail.nights}晚`,
        icon: 'none',
        duration: 5000
      })
      return
    }

    // 其他酒店验证逻辑...
  }

  // 多规格加购处理
  if (specAddCart.value) {
    handleAddCart(specInfo)
    return
  }

  // 立即购买
  const params = {
    treeId: treeId.value,
    infoId: infoId.value,
    travelDate: travelDate.value,
    endTravelDate: endTravelDate.value,
    planId: pricePlans.value.planId || '',
    planName: pricePlans.value.planName || '',
    specId: specInfo ? specInfo.id : ''
  }

  uni.navigateTo({
    url: '/product/placeorder/index?' + formatParam(params)
  })
}

// 获取多规格信息
const getProdSpecs = async () => {
  try {
    const res: any = await prodSpecs({
      infoId: infoId.value
    })
    if (res.state === 1) {
      specsInfo.value = res.data
    } else {
      uni.showToast({
        title: res.msg,
        icon: 'none',
        duration: 2000
      })
    }
  } catch (error) {
    console.error('获取多规格信息失败:', error)
  }
}

// 订阅消息
// const getListSubMsgTpl = async () => {
//   try {
//     const res: any = await listSubMsgTpl({
//       refId: infoId.value,
//       refType: 2
//     })
//     if (res.state === 1) {
//       tmplIds.value = res.data
//     }
//   } catch (error) {
//     console.error('获取订阅消息模板失败:', error)
//   }
// }

// 初始化
const handleInit = () => {
  const arr = getMonthStarEnd()
  startDate.value = formatDate(arr[0], 'Y-M-D')
  endDate.value = formatDate(arr[1], 'Y-M-D')

  // 重置数据
  detail.value = {} as any
  parserList.value = []
  validityText.value = ''
  pricePlans.value = {} as any

  handleProdDetail()
  // handleDesc()
  // getCouponInfo()
}
const clickLink = (e: any) => {
  uni.setClipboardData({
    data: e.href,
    success() {
      uni.showToast({
        title: '链接已复制，请在浏览器或微信中打开！',
        icon: 'none'
      })
    }
  })
}
// 附件下载
const clickDownloadFile = async (file: { name: string; value: string }) => {
  uni.showLoading({
    title: '处理中...',
    mask: true
  })

  try {
    const res: any = await uni.downloadFile({
      url: file.value,
      header: {
        'content-type': 'application/json'
      }
    })

    uni.hideLoading()

    if (res.statusCode === 200) {
      let type: string[] = []
      if (res.header) {
        type = res.header['content-type'] || res.header['Content-Type']
      }

      // 图片保存到相册
      if (type.includes('image')) {
        try {
          await uni.login({})
          const authRes: any = await uni.authorize({
            scope: 'scope.album'
          })
          if (authRes.errMsg === 'authorize:ok') {
            saveImage(res)
          }
        } catch (authError) {
          console.error('授权失败:', authError)
        }
      } else if (/\.(doc|xls|ppt|pdf|docx|xlsx|pptx)$/.test(res.tempFilePath)) {
        uni.openDocument({
          filePath: res.tempFilePath,
          fileType: res.tempFilePath.replaceAll(/.*\.(.*)/g, '$1'),
          showMenu: true,
          fileName: file.name
        })
      }
    } else {
      uni.showToast({
        title: '下载失败',
        icon: 'none'
      })
    }
  } catch (error) {
    uni.hideLoading()
    uni.showToast({
      title: '下载失败' + error,
      icon: 'none'
    })
  }
}

// 保存图片到相册
const saveImage = (res: any) => {
  uni.saveImageToPhotosAlbum({
    filePath: res.tempFilePath,
    success: () => {
      uni.showToast({
        title: '成功保存到相册',
        icon: 'success'
      })
    },
    fail: (err: any) => {
      const errType = err.errMsg.includes('saveImageToPhotosAlbum:fail cancel')
        ? '取消保存'
        : '保存失败'
      uni.showToast({
        title: errType,
        icon: 'none'
      })
    }
  })
}
// 获取日历价格
const transmitDate = (val: any) => {
  const { startDate: start, endDate: end } = val
  handlePriceCalendar(start, end)
}
// 页面滚动事件
onPageScroll((e) => {
  scrollTop.value = e.scrollTop
})

// 页面加载
onLoad((options: any) => {
  infoId.value = options.infoId || '26467419'
  if (options.planId) {
    urlPlanId.value = options.planId
  }
  if (options.specId) {
    specId.value = options.specId
  }
  if (options.dyVideoId) {
    dyVideoIdLocal.value = options.dyVideoId
    userStore.setDyVideoId(options.dyVideoId)
  }
  if (options.scene) {
    userStore.setScene(options.scene)
  }
  handleInit()
})

// 分享配置
onShareAppMessage(() => {
  return {
    title: detailInfoTitle.value,
    imageUrl: detail.value.signImg,
    path: `/product/detail/index?infoId=${infoId.value}`
  }
})

// 分享到朋友圈
onShareTimeline(() => {
  return {
    title: detailInfoTitle.value,
    imageUrl: detail.value.signImg,
    path: `/product/detail/index?infoId=${infoId.value}`
  }
})
</script>
<style lang="scss" scoped>
.xunlong-set_meal .z-slide-card .z-hot-sell {
  padding-top: 0 !important;
}
.detail-info-box {
  margin-top: -30rpx;
  border-radius: 30rpx;
  // padding-bottom: 16rpx;
  position: relative;
  background: #fff;
  overflow: hidden;
  margin-bottom: 16rpx;
}
.poi-detail-info-box {
  margin-top: 0;
  border-radius: 0 0 30rpx 30rpx;
}
// #ifdef MP-WEIXIN
.detail {
  /*checkbox 整体大小  */
  // .select-checkbox {
  //   // width: 240rpx;
  //   // height: 90rpx;
  // }
  /*checkbox 选项框大小  */
  .select-checkbox .wx-checkbox-input {
    width: 48rpx;
    height: 48rpx;
    border-radius: 50%;
    background-color: #c9c9c9;
    border: unset;
  }
  /*checkbox选中后样式  */
  .select-checkbox .wx-checkbox-input.wx-checkbox-input-checked {
    background-color: #67c2ce;
    width: 48rpx;
    height: 48rpx;
    border-radius: 50%;
    border: unset;
  }
  /*checkbox选中后图标样式  */
  .select-checkbox .wx-checkbox-input.wx-checkbox-input-checked::before {
    width: 28rpx;
    height: 28rpx;
    line-height: 28rpx;
    text-align: center;
    font-size: 22rpx;
    color: #fff;
    // color: transparent;
    background: transparent;
    transform: translate(-50%, -50%) scale(1);
    -webkit-transform: translate(-50%, -50%) scale(1);
  }
}
// #endif
.detail {
  width: 100vw;
  min-height: 100vh;
  padding-bottom: 140rpx;
  overflow: hidden;
  background-color: #f0f0f0;
  /* #ifdef MP-TOUTIAO */
  .z-detail-info-title-toutiao {
    background-color: #fff;
    box-sizing: border-box;
    padding: 0 32rpx;
    // padding-top: 24px;
    padding-bottom: 25rpx;
    overflow: hidden;
    color: rgba(34, 34, 34, 1);
    font-weight: bold;
    font-size: 38rpx;
  }
  /* #endif */
  .calendar-title {
    display: flex;
    align-items: center;
    justify-content: space-between;
    color: #222;
    font-weight: bold;
    padding: 20rpx;
    background-color: #fff;
    border-bottom: 1px solid #e5e5e5;
    box-sizing: border-box;
    .title {
      font-size: 32rpx;
    }
    .select {
      display: inline-flex;
      align-items: center;
      height: 60rpx;
      color: #666;
      line-height: 1;
      font-size: 28rpx;
      padding: 0 30rpx;
      border: 1rpx solid #d8d8d9;
      border-radius: 16rpx;
      box-sizing: border-box;
      span {
        margin-right: 8rpx;
      }
    }
  }
  .parse {
    background-color: #fff;
    padding-bottom: 20rpx;
    box-sizing: border-box;
    border-radius: 30rpx;
    overflow: hidden;
    .parse-title {
      color: #222222;
      font-weight: 600;
      font-size: 32rpx;
      line-height: 100rpx;
      border-bottom: 2rpx solid #e5e5e5;
      margin: 0 20rpx 4rpx;
    }
    .parse-image {
      width: 100%;
      image-rendering: -moz-crisp-edges;
      image-rendering: -o-crisp-edges;
      image-rendering: -webkit-optimize-contrast;
      image-rendering: crisp-edges;
      -ms-interpolation-mode: nearest-neighbor;
    }
    .detail-desc-box {
      width: 750rpx;
      padding: 0 20rpx;
      box-sizing: border-box;
      overflow-x: hidden;
      img,
      image,
      view {
        max-width: 710rpx;
        height: auto;
        vertical-align: middle;
        overflow-x: hidden;
      }
      .file-item {
        padding: 20rpx 0;
        .custom-icon {
          margin-right: 20rpx;
        }
        .file-item-name {
          color: rgb(244, 127, 2);
        }
        .lazy {
          // #ifdef MP-KUAISHOU
          height: auto !important;
          // #endif
        }
      }
    }
  }
  .snap-introduce {
    margin: 10rpx 0;
  }
  .line-through {
    // text-decoration: line-through;
    color: #666;
  }
  .detail-yylink {
    color: #f57f06;
  }
  .detail-certification {
    width: 100%;
    height: 70rpx;
    font-size: 26rpx;
    font-weight: 400;
    color: #333;
    padding: 0 32rpx;
    // border-radius: 20px;
    .detail-certification-left {
      .img {
        width: 32rpx;
        height: 32rpx;
        vertical-align: middle;
        margin-right: 10rpx;
      }
    }
    .detail-certification-right {
      position: relative;
      width: 34rpx;
      height: 34rpx;
      background: #fff4ec;
      border-radius: 50%;
      &::after {
        content: '';
        position: absolute;
        top: 10rpx;
        left: 4rpx;
        width: 12rpx;
        height: 12rpx;
        border: 2rpx solid #f47f02;
        transform: rotate(45deg);
        border-left-color: transparent;
        border-bottom-color: transparent;
      }
    }
  }
  .certification-pop {
    position: fixed;
    bottom: 0;
    z-index: 999;
    .mask {
      position: fixed;
      background-color: rgba(0, 0, 0, 0.6);
      width: 100vw;
      height: 100vh;
      top: 0;
      left: 0;
      z-index: 1;
    }
  }
  .certification-box {
    position: relative;
    z-index: 2;
    background-color: #fff;
    width: 750rpx;
    height: 70vh;
    overflow-x: hidden;
    overflow-y: auto;
    border-radius: 20rpx 20rpx 0 0;
    padding: 0 40rpx 20rpx 40rpx;
    box-sizing: border-box;
    animation: fadelogIn 0.4s;
    @keyframes fadelogIn {
      0% {
        -webkit-transform: translate3d(0, 100%, 0);
        -webkit-transform: translate3d(0, 100%, 0);
        transform: translate3d(0, 100%, 0);
        transform: translate3d(0, 100%, 0);
      }
      100% {
        -webkit-transform: none;
        transform: none;
      }
    }
    .box-top {
      color: #f47f02;
      position: relative;
      text-align: center;
      font-size: 30rpx;
      padding: 52rpx 0 20rpx 0;
      &::before,
      &::after {
        content: '';
        position: absolute;
        top: 65%;
        width: 30vw;
        height: 1px;
      }
      &::before {
        left: 0;
        background-image: linear-gradient(
          to left,
          rgba(244, 127, 2, 0.42),
          transparent
        );
      }
      &::after {
        right: 0;
        background-image: linear-gradient(
          to right,
          rgba(244, 127, 2, 0.42),
          transparent
        );
      }
    }
    .box-tips {
      font-size: 24rpx;
      color: #666;
      line-height: 40rpx;
      margin-bottom: 20rpx;
      > text {
        color: #000;
        font-weight: bold;
      }
    }
    .box-img {
      width: 100%;
      max-height: 51vh;
      .image {
        width: 100%;
      }
    }
    .certification-close {
      position: absolute;
      width: 40rpx;
      height: 40rpx;
      right: 20rpx;
      top: 16rpx;
      z-index: 999;
      .img {
        width: 100%;
        height: 100%;
      }
    }
  }
}
.detail-desc-box {
  ._img,
  img,
  image {
    max-width: 100%;
    height: auto;
  }
}
.detail {
  .detail-crowd {
    width: 100%;
    background: #ffffff;
    border-radius: 29rpx;
    margin-bottom: 32rpx;
    .detail-crowd__title {
      padding: 31rpx 31rpx 40rpx 31rpx;
      .crowd-title__icon {
        display: inline-block;
        width: 35rpx;
        height: 27rpx;
        background: url('http://qnimg.zowoyoo.com/img/84826/1679972275692.png')
          no-repeat center;
        background-size: contain;
        margin-right: 16rpx;
      }
      text {
        font-size: 28rpx;
        font-weight: 500;
        color: #2f2f2f;
      }
    }
    .detail-crowd__mian {
      display: grid;
      padding: 0 20rpx 58rpx;
      grid-template-columns: repeat(4, auto);
      // grid-gap: 32rpx 32rpx;
      row-gap: 10rpx;
      view {
        display: inline-block;
        font-size: 28rpx;
        font-weight: 400;
        color: #2f2f2f;
        text-align: center;
        padding: 15rpx 0;
        margin: 0 10rpx;
        border: 1px solid #ccc;
        border-radius: 19rpx;

        &.crowd-active {
          color: #f57f03;
          border: 1px solid #f57f03;
        }
      }
    }
  }
}

.detail-yy {
  position: relative;
  height: 90rpx;
  background: #fffaee;
  padding-right: 30rpx;
  border-radius: 30rpx;
  margin-bottom: 20rpx;
  .yy-img {
    position: absolute;
    top: 0;
    left: 10rpx;
    width: 90rpx;
    height: 90rpx;
  }
  .detail-yy__title {
    padding-left: 30rpx;
    font-size: 28rpx;
    color: #86734d;
    line-height: 31rpx;
  }
  .detail-yy__btn {
    height: 53rpx;
    font-size: 24rpx;
    font-weight: 400;
    color: #86734d;
    padding: 0 20rpx;
    border-radius: 27rpx;
    border: 1px solid #e7decc;
    text {
      line-height: 20rpx;
    }
  }
}
.detail-yyImage {
  display: block;
  width: 686rpx;
  height: 114rpx;
  margin: 0 auto 20rpx;
}
</style>
