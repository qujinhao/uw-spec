# uni-uw-ui

uniApp 生态物料组件库

#### 开始

```js
yarn add uni-uw
```

#### 配置

```js
// src/pages.json
{
	"easycom": {
		"autoscan": true,
		"custom": {
			"^m-(.*)": "uni-uw/m-$1/m-$1.vue"
		}
	},
}
```

#### 使用

```vue
<template>
  <view class="content">
    <m-swiper
      :attrs="{
        isAutoplay: true,
        autoplay: 2000,
        circular: true
      }"
      :styles="{
        width: 750,
        height: 400,
        padding: 20,
        radius: 10,
        vertical: true,
        indicatorDots: true,
        indicatorColor: 'red',
        backgroundColor: '#007aff',
        marginBottom: 20
      }"
      :list="list"
      imgKey="advLogo"
    ></m-swiper>
  </view>
</template>

<script setup lang="ts">
const list = [
  {
    advTitle: '亲子时光',
    advSubtitle: null,
    advLink: 'http://yanshi.zowoyoo.com/newb2c/particulars/1667814',
    advLogo: 'http://qnimg.zowoyoo.com/img/84826/1713259957865.jpg'
  },
  {
    advTitle: '2222',
    advSubtitle: null,
    advLink:
      'http://moketingzhou.ziwoyou.net/newb2c/productdetail/75567712?treeId=12&orderCustId=6996807&parentCustId=6996807&userId=',
    advLogo: 'https://qnimg.zowoyoo.com/img/84826/1716454786450.jpg'
  }
]
</script>

<style>
.content {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
}
</style>
```
