import type { UViewUI } from '@/uview-ui'

declare global {
  interface Uni {
    $u: UViewUI
  }
}
