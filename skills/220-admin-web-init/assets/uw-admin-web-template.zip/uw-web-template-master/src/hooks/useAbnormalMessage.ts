import {
  computed,
  onActivated,
  onDeactivated,
  onMounted,
  onUnmounted,
  ref,
  type WritableComputedRef
} from 'vue'
import { getT } from '@/i18n'
import { useRoute } from 'vue-router'
import { useI18n } from 'vue-i18n'
import { chkIdCard } from '@/utils/idValidate'
import { ElMessage, ElMessageBox, ElMessageBoxOptions } from 'element-plus'
import { useMainStore } from '@/store/main'
import { type ResponseData } from '@/api/uwAuthCenterAuthApi'
import request from '@/utils/request'
import dayjs from 'dayjs'
import { sleep } from '@/utils/tool'
import * as XLSX from 'xlsx-js-style'
import * as FileSaver from 'file-saver'

/**
 * 处理异常消息的钩子函数
 * 该函数根据响应状态显示警告或错误消息，并支持在特定情况下执行自定义回调函数
 *
 * @param config 包含响应数据和可选回调函数的配置对象
 * @param config.response 响应数据，包括状态、消息内容和可选的数据负载
 * @param config.warnNoReturnCallback 可选的警告回调函数，当响应状态为警告且没有数据负载时调用
 */ export const useAbnormalMessage = (config: {
  response: ResponseData<any>
  warnNoReturnCallback?: () => void
}) => {
  if (config.response.state === 'warn') {
    if (config.response) {
      ElMessage({
        type: 'warning',
        message: config.response.msg
      })
    } else {
      config.warnNoReturnCallback && config.warnNoReturnCallback()
    }
  } else {
    ElMessage({
      type: 'error',
      message: config.response.msg
    })
  }
}
