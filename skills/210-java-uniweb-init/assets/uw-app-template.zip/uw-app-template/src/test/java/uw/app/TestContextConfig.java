package uw.app;

import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.AnnotationBeanNameGenerator;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.FilterType;

/**
 * 测试用例配置类
 */
@SpringBootConfiguration
@EnableAutoConfiguration
@ComponentScan(
    excludeFilters = @ComponentScan.Filter(type = FilterType.ANNOTATION, classes = SpringBootApplication.class),
    nameGenerator = TestContextConfig.CustomBeanNameGenerator.class
)
public class TestContextConfig {

    public static class CustomBeanNameGenerator extends AnnotationBeanNameGenerator {
        @Override
        protected String buildDefaultBeanName(BeanDefinition definition) {
            String className = definition.getBeanClassName();
            if (className != null && className.startsWith(TestContextConfig.class.getPackage().getName())) {
                if (className.endsWith("Controller") || className.endsWith("SwaggerConfig")
                        || className.endsWith("Runner") || className.endsWith("Croner")
                        || className.contains("PackageInfo")) {
                    return className;
                }
            }
            return super.buildDefaultBeanName(definition);
        }
    }
}
