// import axios, { AxiosRequestConfig } from 'axios'
import { Observer, Subject } from '@/utils/PubSub/index'
import systemConfig from '@/config/common'
import { EnumHeaderLang } from '@/i18n/i18n.type'
import { i18n } from '@/i18n/instance'
import { getToken, getRefreshToken, getLoginAgent } from '@/utils/tokenManager'

let __API_LOGIN_ = false
const subject = new Subject()

/**
 * 格式化请求参数
 * @param {object} params 传参对象
 */
const formatParam = (params: Record<string, any>): string => {
  let parameter = ''
  for (const key in params) {
    if (params[key] !== undefined && params[key] !== null) {
      parameter += `${key}=${params[key]}&`
    }
  }
  parameter = parameter.slice(0, -1)
  return parameter
}

/**
 * 从 onLoad 的 options 中拼出当前页面完整 hash 路径（不含域名）
 * 兼容小程序 + H5（H5 下如需要完整 hash 可再拼一次，这里统一用 route + options 方式）
 * @param {Object} options  页面 onLoad 收到的参数
 * @returns {string}        形如：#/pages/demo/index?id=1&name=abc
 */
const getCurrentPath = (options?: AnyObject): string => {
  // 空对象直接返回兜底
  if (!options || JSON.stringify(options) === '{}') {
    // 仍然需要拿到当前页面路由
    const pages = getCurrentPages()
    const cur = pages[pages.length - 1]
    const route = cur && (cur.route || '')
    return route ? `/${route}` : ''
  }

  const pages = getCurrentPages()
  const cur = pages[pages.length - 1]
  if (!cur) return ''

  const route = cur.route || ''
  if (!route) return ''

  // 把 options 转成 query 字符串
  const query = formatParam(options)

  return encodeURIComponent(`/${route}${query ? '?' + query : ''}`)
}

interface CONFIG {
  baseURL?: string
  url: string
  // #ifndef MP-ALIPAY
  responseType?: 'text' | 'arraybuffer'
  // #endif
  method?:
    | 'OPTIONS'
    | 'GET'
    | 'HEAD'
    | 'POST'
    | 'PUT'
    | 'DELETE'
    | 'TRACE'
    | 'CONNECT'
  data?: string | AnyObject | ArrayBuffer
  header?: AnyObject
  params?: AnyObject
}

// 接口白名单  这些接口可以不登录获取数据
const APIwhiteList = new Set([
  '/saas-mall-app/guest/site/info/load',
  '/saas-mall-app/open/guest/auth/login', // 登录接口
  '/saas-mall-app/open/guest/auth/genCaptcha',
  '/saas-mall-app/open/guest/auth/sendVerifyCode', // 获取验证码
  '/saas-mall-app/open/guest/auth/registry', // 注册
  '/jtr-jwqs-app/open/account/info/registry',
  '/jtr-jwqs-app/open/account/info/login',
  '/jtr-jwqs-app/open/account/info/genCaptcha',
  '/jtr-jwqs-app/open/account/info/sendVerifyCode',
  '/jtr-jwqs-app/open/account/info/resetPassword',
  '/jtr-jwqs-app/open/account/info/getAllCountry', // 根据语言环境，获取全部国家信息
  '/jtr-jwqs-app/open/account/info/resetPasswordCheck',
  '/jtr-jwqs-app/open/account/info/resetPasswordSend',
  '/uw-auth-center/auth/login', // 登录接口
  '/uw-auth-center/auth/checkCaptcha', // 检查验证码状态
  '/uw-auth-center/auth/genCaptcha' // 获取验证码
])

// 错误信息提示 // uw-center 接口返回中文信息 i18n翻译
const handleErrorMsg = (val: string) => {
  const { t } = i18n().global
  let msg = ''
  if (val) {
    if (val.search('账号不可用') !== -1) {
      msg = t('AccountUnavailable')
    } else if (val.search('图形识别码验证错误') !== -1) {
      msg = t('imgCodeError')
    } else if (val.search('请输入图形识别码') !== -1) {
      msg = t('InputImgCode')
    } else if (val.search('用户名或密码不正确') !== -1) {
      msg = t('AccountOrPwdError')
    } else if (val.search('用户名密码错误或状态异常') !== -1) {
      msg = t('AccountPwdErrorOrStatusError')
    } else {
      msg = val
    }
  }
  return msg
}

/**
 * 不需要token权限的api地址
 */
const handlerVerify = (apiUrl: string) => {
  const token = getToken()
  // 如果有真实token（不是匿名token），则不需要检查白名单
  if (token && !token.startsWith('0$1!0@')) return false
  return !APIwhiteList.has(apiUrl)
}

// 替换大数字为String
function processLargeNumbersInJSON(jsonStr: string) {
  // 先处理字符串中的大数字，匹配16-20位数字，可以以L结尾
  const processedJsonStr = jsonStr.replaceAll(
    /:\s*(\d{16,20}L?)/g,
    (_match: any, number: any) => {
      return `: "${number}"`
    }
  )

  try {
    const parsed = JSON.parse(processedJsonStr)
    return parsed
  } catch (error) {
    console.error('JSON parsing error:', error)
    uni.showToast({ title: 'JSON parsing error', icon: 'none' })
    return null
  }
}

function request(config: CONFIG) {
  const { t, locale } = i18n().global
  const token = getToken()

  return new Promise((resolve, reject) => {
    // debugger
    const baseURL = config.baseURL || systemConfig.baseUrl
    let url = baseURL + config.url
    if (Object.keys(config.params || {}).length > 0) {
      url += `?${formatParam(config.params || {})}`
    }

    const requestInfo = {
      url,
      method: config.method,
      data: config.data,
      // #ifndef MP-ALIPAY
      responseType: config.responseType,
      // #endif
      header: {
        'Accept-Language':
          EnumHeaderLang[locale.value as keyof typeof EnumHeaderLang],
        'Content-type': 'application/json; charset=UTF-8',
        Authorization: 'Bearer ' + token,
        ...config.header
      },
      dataType: 'String' //把接收来的数据转换成字符串类型，而不直接解析
    }
    // console.log('request 入参 :', requestInfo)
    // debugger

    uni.request({
      ...requestInfo,
      success: async (res) => {
        // console.log('request 响应success:', res)
        // console.log('request url :', url)
        // console.log('request token :', 'Bearer ' + token)
        // console.log('request config.header :', config.header)

        let JSONResData: Record<string, any> = {}

        if (res.statusCode === 200) {
          // debugger
          // 由于id会有超长的数字情况 所以需要特殊处理长整数的问题
          JSONResData = processLargeNumbersInJSON(res.data as string)
          // debugger

          if (JSONResData && (JSONResData as Record<string, any>).msg) {
            ;(JSONResData as Record<string, any>).msg = handleErrorMsg(
              (JSONResData as Record<string, any>).msg
            )
          }
          resolve(JSONResData)
        } else if (
          res.statusCode === 401 &&
          ![
            '/uw-auth-center/auth/login',
            '/saas-mall-app/open/guest/auth/login'
          ].includes(config.url)
        ) {
          // 实例化订阅者
          const obs = new Observer(() => {
            request(config)
              .then((res) => {
                console.log('重新请求完成')
                console.log(res)
                // 移除订阅者
                subject.remove(obs)
                resolve(res)
              })
              .catch((err) => {
                console.log('res.statusCode === 401', err)
                // debugger
                reject(err)
              })
          })
          // 添加订阅者
          subject.add(obs)
          if (!__API_LOGIN_) {
            __API_LOGIN_ = true
            uni.reLaunch({
              url: '/pages/login/index',
              // url: '/',
              success: () => {
                __API_LOGIN_ = false
                // 通过事件通知 store 清除登录缓存
                uni.$emit('clearLoginCache')
              }
            })
          }
        } else if (res.statusCode === 403) {
          uni.showToast({
            title: t('curUserNotPerm'),
            icon: 'none',
            mask: true,
            duration: 5000
          })
          setTimeout(() => {
            const obj = {
              // redirectUrl: state.currentPath
              redirectUrl: getCurrentPath()
            }
            uni.navigateTo({
              url: '/pages/login/index?' + formatParam(obj)
            })
          }, 2000)
        } else if (
          res.statusCode === 498 &&
          !config.url.includes('/uw-auth-center/auth/refreshToken')
        ) {
          // 实例化订阅者
          const obs = new Observer(() => {
            request(config)
              .then((requestRes) => {
                // 移除订阅者
                subject.remove(obs)
                resolve(requestRes)
              })
              .catch((err) => {
                console.log('res.statusCode === 498  obs', err)
                reject(err)
              })
          })
          // 添加订阅者
          subject.add(obs)
          if (!__API_LOGIN_) {
            __API_LOGIN_ = true
            // 通过事件触发 token 刷新，由 store 层处理实际的 API 调用
            uni.$emit('doRefreshToken', {
              loginAgent: getLoginAgent(),
              refreshToken: encodeURIComponent(getRefreshToken()),
              onSuccess: () => {
                // 发布者 通知 订阅者
                subject.notify()
                __API_LOGIN_ = false
              },
              onError: () => {
                uni.navigateTo({
                  url: `/pages/login/index`
                })
              }
            })
          }
        } else if (res.statusCode! >= 500) {
          // console.log(res)
          // debugger
          if ((JSONResData as Record<string, any>).msg) {
            uni.showToast({
              // title: `请求过于频繁，请稍后再试(${res.statusCode})`,
              title: (JSONResData as Record<string, any>).msg,
              icon: 'none',
              duration: 3000,
              mask: true
            })
          }
          reject(JSONResData)
        } else {
          console.log('进入到 reject 条件')
          console.log(url)
          console.log(JSONResData)
          reject(JSONResData)
        }
      },
      fail: (error) => {
        console.log('request 响应fail error:', error)
        reject(error)
      },
      complete: () => {
        //
      }
    })
  })
}

// 代理拦截器，有token才正常放行，不然先去登录再放行
export default new Proxy(request, {
  get(target, key, receiver) {
    if (
      ['request', 'get', 'delete', 'head', 'post', 'put', 'patch'].includes(
        key as string
      )
    ) {
      return new Proxy(Reflect.get(target, key, receiver), {
        apply: this.apply
      })
    } else {
      return Reflect.get(target, key, receiver)
    }
  },
  apply(target: any, thisArg, args) {
    return new Promise((resolve, reject) => {
      const apiUrl = args[0].url.replace(/\/[0-9]+$/, '/')
      const permission = handlerVerify(apiUrl)
      // console.log('apiUrl')
      // console.log(apiUrl)
      // console.log('permission')
      // console.log(permission)
      if (permission) {
        // 登录判断
        console.log('new Proxy 来静默登录了')
        const token = getToken()
        // 实例化订阅者
        const obs = new Observer(() => {
          target(...args)
            .then((res: unknown) => {
              // 移除订阅者
              subject.remove(obs)
              resolve(res)
            })
            .catch((err: any) => {
              console.log('permission new Proxy(request', err)
              reject(err)
            })
        })
        // 添加订阅者
        subject.add(obs)
        if (!__API_LOGIN_) {
          if (token && !token.startsWith('0$1!0@')) {
            // 发布者 通知 订阅者
            subject.notify()
            __API_LOGIN_ = false
          } else {
            // uni.showToast({
            //   icon: 'none',
            //   duration: 3000,
            //   title: t('tokenExpired')
            // })
            // debugger
            uni.reLaunch({
              url: `/pages/login/index`
            })
          }
        }
      } else {
        target(...args)
          .then((res: unknown) => {
            resolve(res)
          })
          .catch((err: any) => {
            console.log('!permission new Proxy(request', err)
            reject(err)
          })
      }
    })
  }
})
