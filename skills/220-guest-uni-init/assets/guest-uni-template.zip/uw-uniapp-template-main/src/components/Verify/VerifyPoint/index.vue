<script lang="ts" setup>
/**
 * VerifyPoints
 * @description 点选
 * */
import { ref, onMounted, watch, getCurrentInstance, computed } from 'vue'
import defaultImg from '../default.jpg'
import { useI18n } from 'vue-i18n'
import type { CaptchaQuestion } from '@/api/authUwAuthCenterApiAuth'

const { t } = useI18n()

interface COORDINATE_TYPE {
  x: number
  y: number
}

const props = withDefaults(
  defineProps<{
    imgSize?: Record<string, string>
    wordList: string[]
    resPonCaptcha?: CaptchaQuestion
  }>(),
  {
    imgSize: () => {
      return {
        width: '360px',
        height: '140px'
      }
    }
  }
)

const emits = defineEmits<{
  (e: 'refresh'): void
  (e: 'getCaptchaSign', item: { answerData: string; opTime: number }): void
}>()

// 点击长度限制
const checkNum = 4
// 用户点击的坐标
const checkPosArr = ref<COORDINATE_TYPE[]>([])
// 点击的记数
const num = ref(1)
// 坐标点
const tempPoints = ref<any[]>([])
// 验证成功、失败 文案
const verifyText = ref('')
const barAreaColor = ref('#88949d')
const barAreaBorderColor = ref('#eeeeee')
// 点击图片距离
const imgLeft = ref(0)
const imgTop = ref(0)
const instance = getCurrentInstance() // 获取组件实例

const startVerifyTime = ref(0)
const endVerifyTime = ref(0)

const opTime = computed(() => {
  return endVerifyTime.value - startVerifyTime.value
})

watch(
  () => props.wordList,
  (newVal) => {
    if (newVal && newVal.length) {
      verifyText.value =
        t('pleaseSuccessivelyClick') + '【' + newVal.join(' , ') + '】'
    }
  },
  {
    immediate: true
  }
)

/**
 * 刷新人机验证码
 */
const handleRefresh = () => {
  num.value = 1
  checkPosArr.value = []
  tempPoints.value = []
  emits('refresh')
}

/**
 * canvasClick点击
 */
const canvasClick = (e: any) => {
  const query = uni.createSelectorQuery().in(instance)
  query
    .select('#image')
    .boundingClientRect((data: any) => {
      imgLeft.value = Math.ceil(data.left)
      imgTop.value = Math.ceil(data.top)
      checkPosArr.value.push(getMousePos(e))
      // debugger
      if (num.value === checkNum) {
        endVerifyTime.value = Date.now() // 验证结束时间
        num.value = createPoint(getMousePos(e))
        //按比例转换坐标值
        checkPosArr.value = pointTransform(checkPosArr.value, props.imgSize)
        //等创建坐标执行完
        setTimeout(() => {
          emits('getCaptchaSign', {
            answerData: JSON.stringify(checkPosArr.value),
            opTime: opTime.value
          })
        }, 400)
      } else if (num.value < checkNum) {
        if (num.value === 1) {
          startVerifyTime.value = Date.now() // 验证开始时间
        }
        num.value = createPoint(getMousePos(e))
      }
    })
    .exec()
}

/**
 * 创建坐标点
 */
const createPoint = (pos: Record<string, any>) => {
  tempPoints.value.push(Object.assign({}, pos))
  num.value++
  return num.value
}

/**
 * 获取坐标点
 */
const getMousePos = (e: any) => {
  let position = {
    x: Math.ceil(e.detail.x) - imgLeft.value,
    y: Math.ceil(e.detail.y) - imgTop.value
  }
  return position
}

/**
 * 坐标转换函数
 */
const pointTransform = (pointArr: any[], imgSize: Record<string, string>) => {
  let newPointArr = pointArr.map((p) => {
    let x = Math.round((360 * p.x) / Number.parseInt(imgSize.width))
    let y = Math.round((140 * p.y) / Number.parseInt(imgSize.height))
    return { x, y }
  })
  // console.log(newPointArr, 'newPointArr')
  return newPointArr
}

/**
 * 成功回调
 */
const verifySuccessCb = () => {
  // debugger
  barAreaColor.value = '#4cae4c'
  barAreaBorderColor.value = '#5cb85c'
  verifyText.value = t('verifySuccess')
}

/**
 * 失败回调
 */
const verifyErrorCb = () => {
  // debugger
  initVerifyData()
  barAreaColor.value = '#d9534f'
  barAreaBorderColor.value = '#d9534f'
  setTimeout(() => {
    barAreaColor.value = '#88949d'
    barAreaBorderColor.value = '#eeeeee'
    emits('refresh')
  }, 2000)
}

/**
 * 恢复初始变量
 */
const initVerifyData = () => {
  num.value = 1
  checkPosArr.value = []
  tempPoints.value = []
  verifyText.value = ''
  barAreaColor.value = '#88949d'
  barAreaBorderColor.value = '#eeeeee'
}

onMounted(() => {
  // console.log('verifyPoint Com ---')
})
defineExpose({
  verifySuccessCb,
  verifyErrorCb,
  initVerifyData
})
</script>

<template>
  <div class="relative flex flex-col items-center justify-center">
    <div class="verify-image-out">
      <div
        class="verify-image-panel"
        :style="{
          width: props.imgSize.width,
          height: props.imgSize.height
        }"
      >
        <div
          class="verify-refresh"
          @click="handleRefresh()"
        >
          <span class="iconfont icon-refresh"></span>
        </div>
        <image
          :src="
            props.resPonCaptcha?.mainImageBase64
              ? 'data:image/png;base64,' + props.resPonCaptcha?.mainImageBase64
              : defaultImg
          "
          id="image"
          ref="canvas"
          style="width: 100%; height: 100%; display: block"
          @click="canvasClick($event)"
        ></image>
        <div
          v-for="(tempPoint, index) in tempPoints"
          :key="index"
          class="point-area"
          :style="{
            'background-color': '#1abd6c',
            color: '#fff',
            'z-index': 9999,
            width: '20px',
            height: '20px',
            'text-align': 'center',
            'line-height': '20px',
            'border-radius': '50%',
            position: 'absolute',
            top: parseInt(String(tempPoint.y - 10)) + 'px',
            left: parseInt(String(tempPoint.x - 10)) + 'px'
          }"
        >
          {{ index + 1 }}
        </div>
      </div>
    </div>
    <div
      class="verify-bar-area"
      :style="{
        width: props.imgSize.width,
        'border-color': barAreaBorderColor,
        'line-height': '40px',
        'margin-top': '10rpx'
      }"
    >
      <span
        class="verify-msg"
        :style="{ color: barAreaColor }"
      >
        {{ verifyText }}
      </span>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.verify-image-panel {
  position: relative;
  border-top: 1px solid #ddd;
  border-bottom: 1px solid #ddd;
  border-radius: 8rpx;
  overflow: hidden;
  box-sizing: border-box;
}

/*滑动验证码*/
.verify-bar-area {
  position: relative;
  text-align: center;
  box-sizing: border-box;
  border-radius: 8rpx;
  background: #f2f3f5;
  .verify-msg {
    z-index: 3;
  }
}
</style>
