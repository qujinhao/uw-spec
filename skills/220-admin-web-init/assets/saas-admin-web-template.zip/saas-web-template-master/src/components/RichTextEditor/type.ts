// 富文本编辑器传入的props类型
export interface richTextEditorProps {
  ricText?: string // 显示内容文本
  width?: string | number // 编辑器宽度
  height?: string | number // 编辑器高度
  objectId?: string | number // 文件上传到的表ID
  objectType: string // 文件上传到的表名
  editorId: string | number // 编辑器ID 1. 同一个页面可能存在多个富文本编辑器，因此ID必须唯一 2. 如若同一个页面复用同一个组件，传的ID也必须不同
  disabled?: boolean // 是否禁用
  accessType?: 0 | 1 // 访问类型。0，公共文件；1.隐私文件
  expireDate?: string // 文件过期时间
  ossSite?: 'saasOssSite' | 'sysDomain'
}

// 富文本编辑器上传返回的值类型  uploadToService方法返回的类型
export interface returnPromiseType {
  state?: 'success' | 'error' // 成功与否
  url?: string // 图片路径
  posterUrl?: string // guest wap端ios可能需要封面图
}

// 富文本编辑器暴露出来的方法
export interface richTextEditorExposeMethods {
  clearCatch: () => void // 清除缓存
  // 什么时机外部必须调用clearCatch：
  // 提交保存后关闭页面但该页面有缓存的情况: 进来页面onActivated里调用
  handleUpdateRefId: (refId: number) => void // 更新关联id
  handleUnLinkFile: () => void // 解除文件关联
}
