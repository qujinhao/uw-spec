<script lang="ts" setup>
import { ref, onMounted, computed, watch } from 'vue'
// import { useI18n } from 'vue-i18n'
import VerifySlider from '@/components/Verify/VerifySlider/index.vue'
import VerifyPoint from '@/components/Verify/VerifyPoint/index.vue'
import verifyInput from '@/components/Verify/VerifyInput/index.vue'
import VerifyRotate from '@/components/Verify/VerifyRotate/index.vue'
// import { useMainStore } from '@/store/main'
import './iconfont.css'
import { aesDecrypt } from './util'
import type { CaptchaQuestion } from '@/api/authUwAuthCenterApiAuth'
import type { VERIFY_TYPE } from './types'

// const mainStore = useMainStore()

// const { t } = useI18n()

const props = withDefaults(
  defineProps<{
    modelValue: boolean // 是否展示验证
    padding?: number // imgSize 内边距 (单位rpx)
    resPonCaptcha?: CaptchaQuestion
  }>(),
  {
    padding: 30,
    modelValue: false
  }
)

const emits = defineEmits<{
  (e: 'update:modelValue', bool: boolean): void
  (e: 'getGenCaptcha'): void
  (e: 'getCaptchaSign', verifyObj: VERIFY_TYPE): void
  (e: 'closeCaptcha'): void
}>()

const isShow = ref(props.modelValue)

watch(
  () => props.modelValue,
  (value: boolean) => {
    isShow.value = value
    emits('update:modelValue', value)
  }
)

const verifyRef = ref()

// 接口返回的小图片的坐标信息
const jigsawPoint = computed(() => {
  const obj = {
    x: 0,
    y: 0
  }
  try {
    const subDataStr = props.resPonCaptcha?.subData || ''
    const subData = JSON.parse(
      aesDecrypt(subDataStr, props.resPonCaptcha?.captchaId)
    )
    obj.x = subData.x
    obj.y = subData.y
  } catch (error) {
    console.log('aesDecrypt error jigsawPoint', error)
  }
  return obj
})

// 接口返回的 点按验证的 字母 （依次排序）
const wordList = computed(() => {
  let list: string[] = []
  try {
    const subDataStr = props.resPonCaptcha?.subData || ''
    const subData = JSON.parse(
      aesDecrypt(subDataStr, props.resPonCaptcha?.captchaId)
    )
    list = subData
  } catch (error) {
    console.log('aesDecrypt error wordList', error)
  }
  return list
})

// 获取验证码
const getGenCaptcha = () => {
  emits('getGenCaptcha')
}

// 获取验证码签名
const getCaptchaSign = (verifyObj: VERIFY_TYPE) => {
  emits('getCaptchaSign', verifyObj)
}

// 关闭组件验证
const handleCloseCaptcha = () => {
  emits('closeCaptcha')
}

// 360 * 140 是接口返回的宽高 (单位px)
// 这里需要根据屏幕宽度进行适配
// 公式：  // (360 / 140) = 2.57
//        imgSize.width = screenWidth
//        imgSize.height = screenWidth / 2.57
//        blockSize.width = 50 * (screenWidth / 360)
//        blockSize.height = 50 * (screenWidth / 360)

const defaultImgHeight = 140
const defaultImgWeight = 360

const imgSizeWidth = ref('')
const imgSizeHeight = ref('')
// { width: '360px', height: '140px' }
const imgSize = computed(() => {
  return {
    width: imgSizeWidth.value,
    height: imgSizeHeight.value
  }
})
const blockSizeWidth = ref('')
const blockSizeHeight = ref('')
// { width: '50px', height: '50px' }
const blockSize = computed(() => {
  return {
    width: blockSizeWidth.value,
    height: blockSizeHeight.value
  }
})

// init初始化验证码组件宽高
const initVerify = () => {
  const { screenWidth, windowWidth } = uni.getSystemInfoSync()
  // console.log('screenWidth', screenWidth)
  // 定义 新宽度 （设备宽度 - 内边距的宽度）
  const padding = Math.floor((windowWidth! / 750) * props.padding)
  // debugger
  // const newScreenWidth = screenWidth
  const newScreenWidth = screenWidth! - padding * 2
  // console.log('newScreenWidth', newScreenWidth)
  imgSizeWidth.value = `${newScreenWidth}px`
  imgSizeHeight.value = `${newScreenWidth / (defaultImgWeight / defaultImgHeight)}px`
  blockSizeWidth.value = `${50 * (newScreenWidth / defaultImgWeight)}px`
  blockSizeHeight.value = blockSizeWidth.value
}

const verifySuccessCb = () => {
  console.log('verifySuccessCb')
  verifyRef.value?.verifySuccessCb()
}
const verifyErrorCb = () => {
  console.log('verifyErrorCb')
  verifyRef.value?.verifyErrorCb()
}
const initVerifyData = () => {
  console.log('initVerifyData')
  verifyRef.value?.verifySuccessCb()
}

onMounted(() => {
  // console.log('verify-component Com ---')
  initVerify()
})
defineExpose({
  verifySuccessCb,
  verifyErrorCb,
  initVerifyData
})
</script>

<template>
  <div
    v-if="isShow"
    class="verify-overlay"
  >
    <div
      class="verify-component flex flex-col item-center justify-center only-vertical-scroll w-full"
    >
      <template
        v-if="props.resPonCaptcha?.captchaType === 'SlidePuzzleCaptchaStrategy'"
      >
        <VerifySlider
          ref="verifyRef"
          :defaultPadding="props.padding"
          :defaultImgHeight="defaultImgHeight"
          :defaultImgWeight="defaultImgWeight"
          :imgSize="imgSize"
          :blockSize="blockSize"
          :jigsawPoint="jigsawPoint"
          :resPonCaptcha="props.resPonCaptcha"
          @refresh="getGenCaptcha"
          @getCaptchaSign="getCaptchaSign"
        ></VerifySlider>
      </template>
      <template
        v-else-if="
          props.resPonCaptcha?.captchaType === 'ClickWordCaptchaStrategy'
        "
      >
        <VerifyPoint
          ref="verifyRef"
          :imgSize="imgSize"
          :wordList="wordList"
          :resPonCaptcha="props.resPonCaptcha"
          @refresh="getGenCaptcha"
          @getCaptchaSign="getCaptchaSign"
        ></VerifyPoint>
      </template>
      <template
        v-else-if="
          props.resPonCaptcha?.captchaType === 'StringCaptchaStrategy' ||
          props.resPonCaptcha?.captchaType === 'CalculateCaptchaStrategy'
        "
      >
        <verifyInput
          ref="verifyRef"
          :imgSize="imgSize"
          :resPonCaptcha="props.resPonCaptcha"
          @refresh="getGenCaptcha"
          @getCaptchaSign="getCaptchaSign"
        />
      </template>
      <template
        v-else-if="
          props.resPonCaptcha?.captchaType === 'RotatePuzzleCaptchaStrategy'
        "
      >
        <VerifyRotate
          ref="verifyRef"
          :defaultPadding="props.padding"
          :defaultImgHeight="defaultImgHeight"
          :defaultImgWeight="defaultImgWeight"
          :imgSize="imgSize"
          :blockSize="blockSize"
          :jigsawPoint="jigsawPoint"
          :resPonCaptcha="props.resPonCaptcha"
          @refresh="getGenCaptcha"
          @getCaptchaSign="getCaptchaSign"
        ></VerifyRotate>
      </template>

      <div class="verify-close">
        <image
          class="image"
          src="./icon_close.png"
          @click="handleCloseCaptcha()"
        />
      </div>
      <!-- <div
        class="verify-component__btn"
        v-if="props.resPonCaptcha"
      >
        <button
          :style="{
            color: '#0473bd',
            minWidth: '42vw',
            ...mainStore.customButtonHeight
          }"
          @click="handleCloseCaptcha()"
        >
          {{ t('close') }}
        </button>
      </div> -->
    </div>
  </div>
</template>

<style lang="scss" scoped>
// @import './iconfont.scss';
.verify-overlay {
  position: fixed;
  left: 0;
  top: 0;
  z-index: 999;
  width: 100vw;
  height: 100vh;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  transition: 0.3s;
}
</style>
