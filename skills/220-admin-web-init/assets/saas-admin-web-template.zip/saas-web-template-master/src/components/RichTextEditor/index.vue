<script lang="ts" setup>
// tinymce.js 下载至public目录下，在index.html直接引入
import Editor from '@tinymce/tinymce-vue'
import { useMainStore } from '@/store/main'
import {
  saasCommonOssGenUploadParam,
  saasCommonOssUnlink,
  saasCommonOssUpdateRefId,
  saasCommonOssUploadSuccess
} from '@/api/saasBaseAppSaasApi'
import {
  mchCommonOssGenUploadParam,
  mchCommonOssUnlink,
  mchCommonOssUpdateRefId,
  mchCommonOssUploadSuccess
} from '@/api/saasBaseAppMchApi'
import { ElMessage } from 'element-plus'
import { uploadFileToken } from '@/types'
import { uploadFileUrl } from '@/components/UploadFile/type'
import { useI18n } from 'vue-i18n'
import { getUserTypeApi } from '@/utils/getUserTypeApi'
import {
  richTextEditorProps,
  returnPromiseType,
  richTextEditorExposeMethods
} from './type'
import Dompurify from 'dompurify'
import { extractFileId, getLowerExtName, pickFile } from '@/utils/tool'

const mainStore = useMainStore()
const { locale } = useI18n()
const props = withDefaults(defineProps<richTextEditorProps>(), {
  width: '100%',
  height: '400px',
  accessType: 0,
  ossSite: 'saasOssSite',
  disabled: false
})

// 加载状态
const loading = ref(false)
// 当前正在上传或者删除的文件uid数组
const currentOperatorUuids = ref<number[]>([])
// 存储需要解绑的文件URL数组
const unLinkFiles = ref<string[]>([])
// 富文本第一次初始化时 获取已绑定过的url
const initResourceUrls = ref<string[]>([])
// 确保只初始化一次
const resourcesInitialized = ref(false)

const emits = defineEmits<{
  (e: 'update:ricText', val: string): void
}>()

// 富文本编辑器的ID，必须唯一
const tinymceId = computed(() => {
  return `${props.editorId}-${new Date().getTime()}`
})

// 当前域名
const domain = computed(() => {
  return props.ossSite === 'saasOssSite'
    ? mainStore.saasDomain
    : mainStore.sysDomain
})

const editorRef = ref()

// 图片
const imageKeys = toRaw(['.jpeg', '.jpg', '.png', '.gif', '.jpe', '.jpe2'])
// 视频
const videoKeys = toRaw([
  '.avi',
  '.wmv',
  '.mpg',
  '.mov',
  '.rm',
  '.ram',
  '.swf',
  '.flv',
  '.mp4',
  '.mp3'
])

// 当前多语言
const currentLang = computed(() => {
  const langKey = {
    ja: 'ja',
    'zh-CN': 'zh_CN',
    'zh-TW': 'zh_TW',
    en: 'es',
    ko: 'ko_KR'
  }
  return langKey[locale.value as keyof typeof langKey]
})

// 是否暗黑模式
const isDark = computed(() => mainStore.systemDark)

// 编辑器宽度
const editorWidth = computed(() => {
  if (typeof props.width === 'number') {
    return props.width + 'px'
  }
  return props.width
})

// 编辑器高度
const editorHeight = computed(() => {
  if (typeof props.height === 'number') {
    return props.height + 'px'
  }
  return props.height
})

// 监听主题切换
const stopWatchDarkMode = watch(
  () => isDark.value,
  val => {
    const target = editorRef.value?.getEditor()
    const linkArray: HTMLLinkElement[] = Array.from(
      target?.dom.doc.getElementsByTagName('link')
    )
    for (const linkItem of linkArray) {
      if (val) {
        // 暗色
        if (linkItem.href.includes('skins/ui/oxide/')) {
          linkItem.href = linkItem.href.replace(
            'skins/ui/oxide/',
            'skins/ui/oxide-dark/'
          )
          break
        }
      } else {
        // 明亮
        if (linkItem.href.includes('skins/ui/oxide-dark/')) {
          linkItem.href = linkItem.href.replace(
            'skins/ui/oxide-dark/',
            'skins/ui/oxide/'
          )
          break
        }
      }
    }
    const links: HTMLLinkElement[] = Array.from(
      document.getElementsByTagName('link')
    )
    for (const linkItem of links) {
      if (val) {
        // 暗色
        if (linkItem.href.includes('skins/ui/oxide/')) {
          linkItem.href = linkItem.href.replace(
            'skins/ui/oxide/',
            'skins/ui/oxide-dark/'
          )
          break
        }
      } else {
        // 明亮
        if (linkItem.href.includes('skins/ui/oxide-dark/')) {
          linkItem.href = linkItem.href.replace(
            'skins/ui/oxide-dark/',
            'skins/ui/oxide/'
          )
          break
        }
      }
    }
  }
)

/**
 * 统一处理「上传 → 回填」完整链路
 * @param file      原始文件
 * @param successCallback  成功后回填函数（images_upload_handler 用 resolve，file_picker_callback 用 callback）
 * @param errorCallback  失败的回调函数
 */
async function compressThenUpload(
  // 压缩功能需要再同步过来
  file: File,
  successCallback: (url: string, extra?: any) => void,
  errorCallback: () => void
) {
  // 直接上传原文件
  try {
    const res = await uploadToService(file)
    if (res.state === 'success' && res.url) {
      successCallback(
        res.url,
        res.posterUrl ? { poster: res.posterUrl } : undefined
      )
    } else {
      errorCallback()
    }
  } catch {
    errorCallback()
  }
}
/* ------------------------------------------------------------------ */
// 多语言下载地址 https://www.tiny.cloud/get-tiny/language-packages/
/* 5. TinyMCE 初始化配置                                     */
const init = computed(() => ({
  selector: `#${tinymceId.value}`,
  width: editorWidth.value,
  height: editorHeight.value,
  promotion: false,
  branding: false,
  language: currentLang.value,
  skin: isDark.value ? 'oxide-dark' : 'oxide',
  // auto_focus: tinymceId.value, // auto_focus选项应该设置为编辑器ID或不设置，不支持boolean值
  language_url: `./tinymce/langs/${currentLang.value}.js`,
  toolbar_mode: 'sliding', // 工具栏抽屉模式
  plugins:
    'code preview searchreplace autolink directionality visualblocks visualchars link image media table charmap pagebreak nonbreaking anchor insertdatetime advlist lists wordcount autosave', //使用image插件
  // toolbar:
  //   'code preview undo redo  forecolor backcolor styles directionality fontfamily fontsize searchreplace image media link alignleft aligncenter alignright table charmap pagebreak nonbreaking anchor insertdatetime advlist lists wordcount autosave ', //工具栏显示
  // 工具栏包含了 'accordion' 插件，但在 plugins 列表中并没有加载这个插件，这导致了 'isEmpty' 方法调用错误
  toolbar:
    'code preview | undo redo |link image media | styles fontsize directionality | bold italic underline strikethrough | align | bullist numlist | wordcount autosave | table | searchreplace ',
  font_size_formats:
    '6px 8px 10px 12px 14px 16px 18px 20px 22px 24px 28px 32px 36px 48px 56px 72px', //字体大小
  // 参考文档 https://www.tiny.cloud/docs/general-configuration-guide/upload-images/#images_upload_handler
  /* 5-1 粘贴/拖拽图片 */
  // blobInfo 文件信息 progress 上传进度
  images_upload_handler: (blobInfo: any) =>
    // 通过 Promise 的 resolve/reject 返回结果
    // 文件由编辑器直接提供（blobInfo）
    new Promise((resolve, reject) => {
      const file = blobInfo.blob()
      if (!file) {
        reject(new Error('上传失败'))
        return
      }

      // resolve回填图片地址
      compressThenUpload(
        file,
        url => resolve(url),
        () =>
          reject({
            message: '上传失败',
            remove: true
          })
      )
    }),

  /* 5-2 点击图片图标 / 媒体图标 */
  file_picker_callback: (callback: any, _value: any, meta: any) => {
    if (meta.filetype === 'image') {
      // 动态创建上传input，并进行模拟点击上传操作，达到本地上传图片效果。
      pickFile(imageKeys.join(','), file => {
        if (!imageKeys.includes(getLowerExtName(file.name).ext))
          return ElMessage({
            message: '上传图片格式错误',
            type: 'error',
            customClass: 'upload-error-message'
          })
        compressThenUpload(file, callback, () =>
          ElMessage({
            message: '图片上传失败',
            type: 'error',
            customClass: 'upload-error-message'
          })
        )
      })
    }
    if (meta.filetype === 'media') {
      // 动态创建上传input，并进行模拟点击上传操作，达到本地上传视频效果。
      pickFile(videoKeys.join(','), file => {
        if (!videoKeys.includes(getLowerExtName(file.name).ext))
          return ElMessage({
            message: '上传视频格式错误',
            type: 'error',
            customClass: 'upload-error-message'
          })
        // callback 回调的作用是将所选择的视频的url显示在输入框中
        uploadToService(file)
          .then(res => {
            if (res.state === 'success')
              callback(res.url, { poster: res.posterUrl }) // ✅ 设置封面图
            else
              ElMessage({
                message: '视频上传失败',
                type: 'error',
                customClass: 'upload-error-message'
              })
          })
          .catch(() => {
            ElMessage({
              message: '视频上传错误',
              type: 'error',
              customClass: 'upload-error-message'
            })
          })
      })
    }
  },

  /* 5-3 监听删除资源 - 支持单个删除( Backspace / Delete )和全选批量删除 */
  // 当TinyMCE编辑器实例被创建并开始初始化时，setup 函数会被自动调用
  setup: (ed: any) => {
    // 防抖函数，限制资源检测频率
    let detectTimeout: number | null = null

    // 更新当前的引用资源集合
    const updateResourceUrls = () => {
      const newUrls = new Set<string>()

      // 检查ed和ed.dom是否存在
      if (!ed || !ed.dom) {
        console.warn('TinyMCE editor instance not fully initialized')
        return newUrls
      }

      try {
        // 收集所有图片资源
        const images = ed.dom.select('img')
        images.forEach(
          (img: { src: string; closest: (arg0: string) => any }) => {
            if (img.src) newUrls.add(img.src)
          }
        )

        // 收集所有视频资源
        const videos = ed.dom.select('video')
        videos.forEach(
          (video: { querySelector: (arg0: string) => any; poster: string }) => {
            const source = video.querySelector('source')
            if (source?.src) newUrls.add(source.src)
            if (video.poster) newUrls.add(video.poster)
          }
        )
      } catch (error) {
        console.warn('Error collecting resources:', error)
      }

      return newUrls
    }

    // 资源变更检测逻辑（初始化和增删的处理）
    const detectAndCleanDeletedResources = () => {
      try {
        if (!ed?.dom || !ed.getBody()) {
          console.warn(
            'TinyMCE editor instance not fully initialized or body not available'
          )
          return
        }

        // 当前的引用资源URL集合
        const currentUrls = updateResourceUrls()

        // TODO 当切换tab立即黏贴图片或视频 检测不到新增

        // 如果是首次检测且资源未初始化，则进行初始化
        if (!resourcesInitialized.value) {
          // console.log('init>>>>>>>>', tinymceId.value)
          initResourceUrls.value = [...currentUrls]
          resourcesInitialized.value = true
          console.log('initResourceUrls1', initResourceUrls.value)
          return
        }
        console.log('currentUrls', currentUrls)
        console.log('initResourceUrls2', initResourceUrls.value)
        // 直接对比currentUrls和initResourceUrls，实现更高效的资源变更检测
        // 创建新数组替代原数组修改操作，实现不可变数据处理
        const newUnLinkFiles: string[] = []
        const newUpdateRefFiles: uploadFileUrl[] = []

        // 1. 找出需要解绑的URL: 在初始化URL中但不在当前URL中的资源
        const urlsToRemove = new Set<string>()

        initResourceUrls.value.forEach(url => {
          if (typeof url !== 'string' || !url) return
          // 初始化时有但当前没有 → 需要解绑
          if (!currentUrls.has(url)) {
            urlsToRemove.add(url)
          }
        })

        // 2. 找出需要绑定的URL: 在当前URL中但不在初始化URL中的资源
        currentUrls.forEach(url => {
          if (typeof url !== 'string' || !url) return

          // 如果URL在初始化列表中，说明是已绑定资源，无需处理
          if (initResourceUrls.value.includes(url)) {
            console.log('跳过')
            return
          }

          // 检查是否需要绑定
          try {
            const updateFile = extractFileId(url)
            if (updateFile && updateFile.id) {
              newUpdateRefFiles.push({
                id: updateFile.id,
                realUrl: updateFile.filePath,
                blobUrl: updateFile.filePath
              })
            }
          } catch (error) {
            console.warn('Error extracting file ID for URL:', url, error)
          }
        })

        // 添加需要解绑的URL到新的解绑列表
        urlsToRemove.forEach(url => newUnLinkFiles.push(url))

        // 重新赋值，而不是修改原数组
        unLinkFiles.value = newUnLinkFiles
        updateRefFiles.value = newUpdateRefFiles
        // 开发环境可启用日志进行调试
        // console.log('updateRefFiles》》》》', [...updateRefFiles.value])
        // console.log('unLinkFiles>>>>', [...unLinkFiles.value])
      } catch (error) {
        console.error('Error in detectAndCleanDeletedResources:', error)
      }
    }

    // 但使用防抖处理避免频繁检测导致性能问题
    const debouncedDetect = () => {
      if (detectTimeout) {
        clearTimeout(detectTimeout)
      }
      detectTimeout = window.setTimeout(() => {
        detectAndCleanDeletedResources()
      }, 300) // 300ms防抖延迟
    }

    // 直接执行资源删除检测，TinyMCE的NodeChange事件在DOM更新后触发
    ed.on('NodeChange', debouncedDetect)

    // 清理定时器，避免内存泄漏
    ed.on('remove', () => {
      if (detectTimeout) {
        clearTimeout(detectTimeout)
        detectTimeout = null
      }
    })
  }
}))
/**
 * 删除文件
 * 处理unLinkFiles数组中的所有资源
 */
const handleUnLinkFile = () => {
  // 去重
  const unLinks = [...new Set(unLinkFiles.value)]
  clearCatch('unlink')
  if (unLinks.length) {
    unLinks.forEach(async fileUrl => {
      const params = extractFileId(fileUrl)
      if (params) {
        const request = getUserTypeApi({
          300: () => saasCommonOssUnlink(params),
          310: () => mchCommonOssUnlink(params),
          0: () => saasCommonOssUnlink(params)
        })
        const res = await request()
        if (res.state === 'success') {
          console.log('tinymceId.value----------解绑', tinymceId.value)
        }
      }
    })
  }
}

// ========================= 5. 截帧工具 =========================
const extractPosterAndUpload = (videoFile: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const video = document.createElement('video')
    video.src = URL.createObjectURL(videoFile)
    video.currentTime = 0.01
    video.muted = true
    video.playsInline = true
    video.onseeked = () => {
      const canvas = document.createElement('canvas')
      canvas.width = video.videoWidth || 640
      canvas.height = video.videoHeight || 360
      const ctx = canvas.getContext('2d')!
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height)
      canvas.toBlob(
        async blob => {
          if (!blob) return reject(new Error('canvas->blob 失败'))
          const posterFile = new File(
            [blob],
            videoFile.name.replace(/\.[^.]+$/, '.jpg'),
            { type: 'image/jpeg' }
          )
          try {
            // 直接设置为封面上传类型
            const { url } = await uploadToService(posterFile, 'poster')
            if (url) {
              resolve(url)
            } else {
              reject(new Error('上传失败，未获取到封面图地址'))
            }
          } catch (e) {
            reject(e)
          } finally {
            URL.revokeObjectURL(video.src)
          }
        },
        'image/jpeg',
        0.9
      )
    }
    video.onerror = () => reject(new Error('视频解码失败'))
  })
}

//  文本内容
const content = computed({
  get() {
    return props.ricText || ''
  },
  set(val) {
    emits('update:ricText', Dompurify.sanitize(val || ''))
  }
})

// ========================= 6. 上传封装 =========================
// 添加引用的数据
const updateRefFiles = ref<uploadFileUrl[]>([])
// 文件上传
// ========================= 上传封装（带真实进度） =========================
const uploadToService = (
  fileParams: File,
  uploadType: 'video' | 'poster' | 'image' = 'image'
): Promise<returnPromiseType> => {
  return new Promise((resolve, reject) => {
    /* ① 打开弹窗进度条 */
    // 自动判断文件类型
    let type = uploadType
    // 无论是否传入uploadType，都优先根据文件扩展名判断类型
    const lowerFile = getLowerExtName(fileParams.name)
    if (videoKeys.includes(lowerFile.ext)) {
      type = 'video'
    } else if (imageKeys.includes(lowerFile.ext)) {
      type = uploadType || 'image'
    }
    if (type !== 'poster') openUploadProgress(lowerFile.lowerName, type)

    // 生成文件唯一ID
    const fileUid = Date.now() + Math.floor(Math.random() * 1000)
    // 添加到当前操作列表
    currentOperatorUuids.value.push(fileUid)
    loading.value = true
    const params: uploadFileToken = {
      refType: props.objectType,
      fileName: lowerFile.lowerName,
      fileSize: fileParams.size,
      refId: props.objectId ? String(props.objectId) : '0',
      accessType: props.accessType,
      expireDate: props.expireDate || undefined
    }
    const saasId = mainStore.userInfo.saasId
    if (saasId) {
      params.saasId = saasId
    }
    const request = getUserTypeApi({
      300: () => saasCommonOssGenUploadParam(params),
      310: () => mchCommonOssGenUploadParam(params),
      0: () => saasCommonOssGenUploadParam(params)
    })
    request()
      .then(res => {
        if (res.state === 'success' && res.data && res.data?.key) {
          /* ---------- 1. 构造 FormData（顺序必须一致） ---------- */
          const formData = new FormData()
          formData.append('policy', res.data.uploadParam!.policy)
          formData.append(
            'x-amz-algorithm',
            res.data.uploadParam!['x-amz-algorithm']
          )
          formData.append(
            'x-amz-credential',
            res.data.uploadParam!['x-amz-credential']
          )
          formData.append('x-amz-date', res.data.uploadParam!['x-amz-date'])
          formData.append(
            'x-amz-signature',
            res.data.uploadParam!['x-amz-signature']
          )
          formData.append('key', res.data.key)
          // 获取文件格式类型
          formData.append('Content-Type', fileParams.type)
          formData.append('file', fileParams)

          /* ---------- 2. 拼装上传地址（代理 or 真实域名） ---------- */
          // const base = ('https://' + res.data.ossHost!).replace(
          //   /^https?:\/\/hqodss-uat-1332856274\.cos\.ap-hongkong\.myqcloud\.com/,
          //   '/cos'
          // )

          const base = 'https://' + res.data.ossHost

          /* ---------- 3. XMLHttpRequest 上传 + 真实进度 ---------- */
          const xhr = new XMLHttpRequest()
          // 每 200 ms 回抛一次
          xhr.upload.onprogress = e => {
            if (e.lengthComputable) {
              const p = Math.round((e.loaded / e.total) * 100)
              setProgressPercent(p) // 弹窗粗条
            }
          }
          xhr.onload = () => {
            // 只有非poster类型才关闭进度条
            if (type !== 'poster') {
              closeUploadProgress() // ② 关闭弹窗
            }
            // 从当前操作列表移除
            currentOperatorUuids.value = currentOperatorUuids.value.filter(
              uid => uid !== fileUid
            )
            loading.value = currentOperatorUuids.value.length > 0

            if (xhr.status === 204) {
              const fileUrl = `${mainStore.sysDomain}${res.data!.key}`

              // ✅ 如果是视频，截取第一帧作为封面
              const isVideo = videoKeys.includes(lowerFile.ext)
              if (isVideo) {
                // 从当前操作列表移除主文件ID，但保持loading状态，因为还有封面上传
                currentOperatorUuids.value = currentOperatorUuids.value.filter(
                  uid => uid !== fileUid
                )
                extractPosterAndUpload(fileParams)
                  .then(posterUrl => {
                    resolve({ state: 'success', url: fileUrl, posterUrl })
                  })
                  .catch(() => {
                    resolve({ state: 'success', url: fileUrl }) // 封面失败也返回视频地址
                  })
              } else {
                resolve({ state: 'success', url: fileUrl })
              }
              /* 记录引用 */
              updateRefFiles.value.push({ id: res.data!.id, realUrl: fileUrl })

              const uploadSuccessParams = {
                id: res.data!.id!,
                filePath: res.data!.key!
              }
              const request = getUserTypeApi({
                300: () => saasCommonOssUploadSuccess(uploadSuccessParams),
                310: () => mchCommonOssUploadSuccess(uploadSuccessParams),
                0: () => saasCommonOssUploadSuccess(uploadSuccessParams)
              })
              // 调用文件上传成功的请求
              request()
            } else {
              reject({
                type: 'error'
              })
            }
          }
          xhr.onerror = () => {
            // 只有非poster类型才关闭进度条
            if (type !== 'poster') {
              closeUploadProgress()
            }
            // 从当前操作列表移除
            currentOperatorUuids.value = currentOperatorUuids.value.filter(
              uid => uid !== fileUid
            )
            loading.value = currentOperatorUuids.value.length > 0
            reject({ type: 'error' })
          }
          xhr.open('POST', base, true)
          xhr.send(formData)
        } else {
          // 只有非poster类型才关闭进度条
          if (type !== 'poster') {
            closeUploadProgress()
          }
          // 从当前操作列表移除
          currentOperatorUuids.value = currentOperatorUuids.value.filter(
            uid => uid !== fileUid
          )
          loading.value = currentOperatorUuids.value.length > 0
          reject({
            type: 'error'
          })
        }
      })
      .catch(() => {
        // 只有非poster类型才关闭进度条
        if (type !== 'poster') {
          closeUploadProgress()
        }
        // 从当前操作列表移除
        currentOperatorUuids.value = currentOperatorUuids.value.filter(
          uid => uid !== fileUid
        )
        loading.value = currentOperatorUuids.value.length > 0
        reject({ type: 'error' })
      })
  })
}

/**
 * 更新文件上传的refID  需要在点击保存后调用
 * @param refId 关联表的ID
 */
const handleUpdateRefId = (refId?: number) => {
  // 重置缓存时，不影响异步操作
  const updateRef = [...updateRefFiles.value]
  // 重置状态
  clearCatch('update')
  if (updateRef.length) {
    updateRef.forEach(async item => {
      const url = item.realUrl!.replace(`${domain.value}`, '')
      const params = {
        refId: refId ? String(refId) : String(props.objectId!),
        id: item.id!,
        filePath: url
      }
      const request = getUserTypeApi({
        300: () => saasCommonOssUpdateRefId(params),
        310: () => mchCommonOssUpdateRefId(params),
        0: () => saasCommonOssUpdateRefId(params)
      })
      const res = await request()
      if (res.state === 'success') {
        console.log('tinymceId.value----------绑定', tinymceId.value)
      }
    })
  }
}

/* 1. 弹窗状态（模板用） */
const progressDialog = reactive({
  show: false,
  fileName: '',
  percent: 0,
  type: '', // 'video', 'poster', 'image'
  uid: 0
})

/* 2. 打开弹窗 */
const openUploadProgress = (
  fileName: string,
  type: 'video' | 'poster' | 'image' = 'image',
  uid?: number
) => {
  progressDialog.show = true
  progressDialog.fileName = fileName
  progressDialog.percent = 0
  progressDialog.type = type
  progressDialog.uid = uid || 0
}

/* 3. 更新进度 */
const setProgressPercent = (p: number) => {
  progressDialog.percent = p
}

/* 4. 关闭弹窗 */
const closeUploadProgress = () => {
  progressDialog.show = false
}

// 清除缓存
// 重新进来页面有缓存时调用此函数，故抛出组件外由外部调用
const clearCatch = (type?: 'unlink' | 'update') => {
  if (type === 'unlink') {
    // 单独重置解绑的状态，避免影响到绑定操作
    unLinkFiles.value = []
  } else if (type === 'update') {
    // 单独重置绑定的状态，避免影响到解绑操作
    updateRefFiles.value = []
  } else {
    // 全部重置
    updateRefFiles.value = []
    unLinkFiles.value = []
  }
  initResourceUrls.value = [] // 初始化的关键2
  resourcesInitialized.value = false // 初始化的关键1
  currentOperatorUuids.value = []
  editorRef.value = null
}

// 一旦编辑器ID变化 清除缓存
watch(
  () => props.editorId,
  () => {
    clearCatch()
  }
)

onUnmounted(() => {
  // 停止主题监听
  stopWatchDarkMode()
  // 清理编辑器实例引用
  if (editorRef.value) {
    try {
      // 销毁编辑器实例，释放资源
      editorRef.value.destroy?.()
    } catch (error) {
      console.warn('Error destroying editor:', error)
    }
  }
  // 清空相关引用，帮助垃圾回收
  editorRef.value = null
})

onMounted(() => {
  clearCatch()
})

onActivated(() => {
  clearCatch()
})

defineExpose<richTextEditorExposeMethods>({
  clearCatch,
  handleUpdateRefId,
  handleUnLinkFile
})
</script>

<template>
  <div class="rich-text-editor-wrapper">
    <Editor
      :id="tinymceId"
      v-model="content"
      :init="init"
      ref="editorRef"
    />
    <div
      class="mask"
      v-if="props.disabled"
    ></div>
    <!-- 上传进度弹窗 -->
    <el-dialog
      v-model="progressDialog.show"
      :title="
        progressDialog.type === 'video'
          ? '视频上传中'
          : progressDialog.type === 'poster'
            ? '视频封面上传中'
            : '图片上传中'
      "
      width="380px"
      :close-on-click-modal="false"
      :close-on-press-escape="false"
      :show-close="false"
      :z-index="3000"
    >
      <div
        style="text-align: center"
        v-loading="
          loading && (!progressDialog.percent || progressDialog.percent === 100)
        "
      >
        <div style="font-size: 14px; color: #909399; margin-bottom: 8px">
          {{ progressDialog.fileName }}
        </div>
        <el-progress
          :percentage="progressDialog.percent"
          :stroke-width="6"
          status=""
        />
      </div>
    </el-dialog>
  </div>
</template>

<style lang="scss">
.rich-text-editor-wrapper {
  width: v-bind(editorWidth);
  height: v-bind(editorHeight);
  position: relative;
  .mask {
    position: absolute;
    top: 0;
    left: 0;
    bottom: 0;
    right: 0;
    z-index: 4;
    cursor: not-allowed;
    background: var(--el-fill-color-light);
    opacity: 0.3;
    border-radius: 4px;
  }
}
.ck-powered-by {
  display: none;
}

.upload-error-message {
  z-index: 9999 !important;
}
</style>
