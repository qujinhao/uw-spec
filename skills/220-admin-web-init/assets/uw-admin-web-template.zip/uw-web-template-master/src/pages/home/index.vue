<script setup lang="ts"></script>

<template>
  <div class="container">
    <div class="content">
      <div class="title">Hello, World!</div>
    </div>
  </div>
</template>
