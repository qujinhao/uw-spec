<script lang="ts" setup>
import { useI18n } from 'vue-i18n'
import { useMainStore } from '@/store/main'
import logo from '@/assets/logo.png'
import codeForShow from '@/assets/code.jpg'
import { FormInstance, FormRules, ElMessageBox, ElMessage } from 'element-plus'
import LangSelect from '@/components/LangSelect/index.vue'
import {
  authLogin,
  authGenCaptcha,
  authSendDeviceCode,
  type TokenResponse,
  type CaptchaQuestion,
  type LoginRequest
} from '@/api/uwAuthCenterAuthApi'
import {
  openRegistrySave,
  openRegistrySendDeviceCode,
  openRegistryGenCaptcha,
  type SaasRegistryParam
} from '@/api/saasBaseAppOpenApi'
import { rsaEncrypt } from '@/utils/encryptionAndDecryption'
import { useParallax } from '@vueuse/core'
import { useCustomDark } from '@/hooks/useCustomDark'
import { extractContentFromBrackets } from '@/utils/tool'
import { name } from '../../../package.json'
import {
  userCommonInfoMyMchInfo,
  userCommonInfoMySaasInfo
} from '@/api/saasBaseAppUserApi'
import { I18N } from '@/i18n/i18n.type'
import { setLocale } from '@/i18n'

// 注册类型
interface newSaasRegistryParam extends SaasRegistryParam {
  repeatPassword?: string
  isCheck?: boolean
  code?: string // 手机校验码
}

// 菜单类型
interface MenuType {
  id: number
  permCode: string
  permName: string
  children?: Array<MenuType>
}

interface MenuAppType {
  appLabel: string
  appName: string
  appRank: number
  appVersion: string
  displayState: number
  id: number
  children: Array<MenuType>
}

// 登录表单类型
interface loginFormType {
  userType?: number
  loginId?: string
  loginSecret?: string
  code?: string
  captchaId?: string
  captchaInfo?: string
  userId?: number // 多用户情况下，所选择需要登录的用户ID
  loginPass?: string // 短信验证码方式 验证码
  forceLogin?: boolean // 默认不强制登录
  isCheck?: boolean
}

// 校验组件
const Captcha = defineAsyncComponent(
  () => import('@/components/Captcha/index.vue')
)

// 服务条款组件
const TermOfService = defineAsyncComponent(
  () => import('@/pages/login/components/termOfService/index.vue')
)

// MFA初始化组件
const MFACodeDialog = defineAsyncComponent(
  () => import('@/pages/login/components/MFACodeDialog/index.vue')
)

// MFA验证
const ForceMFADialog = defineAsyncComponent(
  () => import('@/pages/login/components/ForceMFADialog/index.vue')
)

// 多账户选择
const MultipartUserSelectDialog = defineAsyncComponent(
  () => import('@/pages/login/components/MultipartUserSelectDialog/index.vue')
)

// 更新密码
const UpdatePasswordDialog = defineAsyncComponent(
  () => import('@/pages/login/components/UpdatePasswordDialog/index.vue')
)

const mainStore = useMainStore()
const router = useRouter()
const route = useRoute()
const { t, locale } = useI18n()

// 登录开始----------------------------------------------------------
const formEl = ref<FormInstance>()
const loading = ref(false)
const loginForm = reactive<loginFormType>({
  userType: 300,
  loginId: '',
  loginSecret: '',
  code: '',
  captchaId: '',
  captchaInfo: '',
  userId: undefined, // 多用户情况下，所选择需要登录的用户ID
  loginPass: '', // 短信验证码方式 验证码
  forceLogin: false, // 默认不强制登录
  isCheck: false
})
// 校验参数
const validateParams = ref<CaptchaQuestion>({})
// 加密的签名
const validateSign = ref('')
// 是否显示校验
const showCaptcha = ref(false)
// 校验ref元素
const captchaRef = ref()

const rules = computed<FormRules>(() => {
  return {
    loginId: [
      {
        required: true,
        message:
          activeLoginType.value === 0 ? t('idOrPhoneOrEmail') : t('linkPhone')
      }
    ],
    loginSecret: [
      {
        required: activeLoginType.value === 0,
        message: t('login.pleaseInputPassWord')
      }
    ],
    code: [
      {
        validator: (rule: any, value: string, callback: any) => {
          if (validateParams.value.captchaId && activeLoginType.value === 0) {
            if (value === '') {
              callback(new Error(t('login.pleaseInputCode')))
            } else {
              callback()
            }
          } else {
            callback()
          }
        }
      }
    ],
    isCheck: [
      {
        validator: (rule: any, value: any, callback: any) => {
          if (value) {
            callback()
          } else {
            callback(new Error(t('pleaseCheckLoginRule')))
          }
        }
      }
    ],
    loginPass: [
      {
        required: activeLoginType.value === 1,
        message: t('pleaseInputValidateCode')
      }
    ]
  }
})

// 多次登录失败提示文字
const showFailuresText = ref('')
// 生成Captcha
const getGenCaptcha = () => {
  showFailuresText.value = ''
  loading.value = true
  authGenCaptcha({
    captchaId: validateParams.value.captchaId || ''
  })
    .then(res => {
      loading.value = false
      if (res.state === 'success') {
        validateParams.value = {}
        // 直接登录
        if (activeLoginType.value === 0) {
          // 密码登录
          loginForPassword()
        } else {
          // 判断是否是短信验证码登录
          loginForCode()
        }
      } else if (res.state === 'error' && res.msg) {
        // 失败
        showFailuresText.value = res.msg
        showCaptcha.value = false
        const matchData = extractContentFromBrackets(res.msg)
        ElMessage.error({
          message: showFailuresText.value,
          duration: matchData[matchData.length - 1]
            ? Number(matchData[matchData.length - 1]) * 1000
            : 60 * 1000,
          showClose: true
        })
      } else if (res.data && res.data.captchaId) {
        validateParams.value = { ...res.data }
        showCaptcha.value = true
      }
    })
    .catch(() => {
      loading.value = false
    })
}

// 获取路由菜单
const handleInfo = async () => {
  const menuList = await mainStore.handleUserLoadAppMenu()
  loading.value = true
  mainStore
    .setAppMenu(menuList)
    .then(() => {
      let targetIndex = 0
      // 不存在取有值的
      const navIndex = getMenuNavIndex(mainStore.appMenu as MenuAppType[])
      mainStore.setNavIndex(navIndex)
      targetIndex = navIndex
      // 默认取第一个
      const appMenu = mainStore.appMenu[targetIndex]
      let path = mainStore.defaultRoutePath
      // 判断菜单里面有没有route.query.fullPath，有执行，没有走默认
      if (route.query.fullPath) {
        const isHasPath = hasPath(
          appMenu.children as MenuType[],
          route.query.fullPath as string
        )
        if (isHasPath && isHasPath[0]) {
          path = route.query.fullPath as string
        } else {
          path = mainStore.defaultRoutePath
        }
      } else {
        path = mainStore.defaultRoutePath
      }
      // 没有页面的路由路径
      const time = setTimeout(() => {
        clearTimeout(time)
        loading.value = false
        if (path) {
          router.replace(path)
        } else {
          ElMessageBox.alert(t('loginByGetAuthError'), t('login.loginFail'), {
            type: 'error',
            showClose: false,
            confirmButtonText: t('confirm')
          })
        }
      }, 300)
    })
    .catch(() => {
      loading.value = false
    })
    .finally(() => {
      // 获取文件域名
      mainStore.handleGetOssSite()
      // 设置默认登录提示
      mainStore.setHasLoadLoginNotice(false)
      // 判断是否需要设置运营商中的多语言，并拿去运营商信息
      initLanguageAndGetSaasInfo()
    })
}

// 多语言初始化设置
const initLanguageAndGetSaasInfo = () => {
  const language = localStorage.getItem(`${name}-lang`)
  const userType = mainStore.loginInfo?.userType

  // 处理接口响应
  const handleResponse = (res: any, langField: string) => {
    if (res.state === 'success' && res.data) {
      mainStore.setSaasInfo(res.data)
      const targetLang =
        !language && res.data[langField]
          ? res.data[langField]
          : language || 'zh-CN'
      setLocale(targetLang as I18N)
    } else {
      mainStore.setSaasInfo({})
      setLocale((language || 'zh-CN') as I18N)
    }
  }

  // 处理错误
  const handleError = () => {
    mainStore.setSaasInfo({})
    setLocale((language || 'zh-CN') as I18N)
  }

  // 根据用户类型调用不同接口
  const apiCall =
    userType === 300 ? userCommonInfoMySaasInfo() : userCommonInfoMyMchInfo()

  const langField = userType === 300 ? 'saasLang' : 'mchLang'

  apiCall.then(res => handleResponse(res, langField)).catch(handleError)
}

// 获取一级菜单索引值
const getMenuNavIndex = (menu: MenuAppType[]): number => {
  let navIndex = 0
  for (let index in menu) {
    if (menu[index] && menu[index].children && menu[index].children?.length) {
      navIndex = Number(index)
      break
    }
  }
  return navIndex
}

// 判断菜单里面是否有对应的路径
const hasPath = (
  menu: MenuType[],
  target: string,
  data: boolean[] = []
): boolean[] => {
  for (const item of menu) {
    if (item.permCode === target) {
      data.push(true)
      return data
    }
    if (item.children && item.children.length) {
      hasPath(item.children, target, data)
    }
  }
  return data
}

// 点击登录
const clickLogin = () => {
  formEl.value?.validate(valid => {
    if (valid) {
      getGenCaptcha()
    }
  })
}

// 点击密码登录
const loginForPassword = () => {
  loading.value = true
  authLogin({
    loginId: loginForm.loginId,
    loginSecret: rsaEncrypt(loginForm.loginSecret) as string,
    loginType: getLoginTypeForPasswordLogin(),
    userType: loginForm.userType,
    captchaId: validateParams.value.captchaId || '',
    captchaSign: validateParams.value.captchaId ? validateSign.value : '',
    loginAgent: mainStore.loginAgent,
    forceLogin: loginForm.forceLogin,
    userId: loginForm.userId || undefined
  })
    .then(res => {
      if (res.state === 'success' && res.data?.length) {
        // 主账号
        const currentAccount = res.data.find(item => item.token)
        // 其余账号
        const otherAccount = res.data.filter(item => !item.token)
        if (currentAccount) {
          mainStore.setLoginInfo(currentAccount)
          mainStore.setOtherAccountsLoginInfo(otherAccount)
        } else {
          mainStore.setLoginInfo(res.data[0])
          mainStore.setOtherAccountsLoginInfo(res.data.slice(1))
        }
        handleInfo()
      } else {
        if (res.code === 'auth.center.passwd.expire.warn') {
          // 密码过期
          passwordExpiredTip(res.data![0])
        } else if (res.code === 'auth.center.passwd.init.warn') {
          // 密码初始化，需要修改密码
          defaultPasswordTip(res.data![0])
        } else if (res.code === 'auth.center.login.double.warn') {
          // 双登
          const msgArray = extractContentFromBrackets(res.msg!)
          const msg = `IP:${msgArray[0]}${
            t('in') + msgArray[1] + t('someoneIsLogin')
          },${t('loginNoticeByForce')}`
          // 双登
          unForceLoginTip(msg)
        } else if (res.code === 'auth.center.mfa.init.warn') {
          // MFA未初始化
          mfaNotInitTip(res.data![0])
        } else if (res.code === 'auth.center.mfa.force.warn') {
          // MFA强制校验
          mainStore.setLoginInfo(res.data![0])
          showMFACodeForceDialog.value = true
        } else if (res.code === 'auth.center.user.multi.warn') {
          // 存在多个用户，选择需要登录的用户
          showMultipartUserSelectDialogTip(res.data!)
        } else {
          ElMessage.error(res.msg)
        }
        loading.value = false
      }
    })
    .catch(err => {
      ElMessageBox.alert(err.response.data.msg, t('login.loginFail'), {
        type: 'error',
        showClose: false,
        confirmButtonText: t('confirm'),
        callback: () => {
          loading.value = false
        }
      })
    })
}

// 点击短信验证码登录
const loginForCode = () => {
  loading.value = true
  authLogin({
    loginId: loginForm.loginId,
    loginPass: loginForm.loginPass,
    loginType: 23,
    userType: loginForm.userType,
    captchaId: validateParams.value.captchaId || '',
    captchaSign: validateParams.value.captchaId ? validateSign.value : '',
    loginAgent: mainStore.loginAgent,
    forceLogin: loginForm.forceLogin,
    userId: loginForm.userId || undefined
  })
    .then(res => {
      if (res.state === 'success' && res.data?.length) {
        // 主账号
        const currentAccount = res.data.find(item => item.token)
        // 其余账号
        const otherAccount = res.data.filter(item => !item.token)
        if (currentAccount) {
          mainStore.setLoginInfo(currentAccount)
          mainStore.setOtherAccountsLoginInfo(otherAccount)
        } else {
          mainStore.setLoginInfo(res.data[0])
          mainStore.setOtherAccountsLoginInfo(res.data.slice(1))
        }
        handleInfo()
      } else {
        if (res.code === 'auth.center.passwd.expire.warn') {
          // 密码过期
          passwordExpiredTip(res.data![0])
        } else if (res.code === 'auth.center.passwd.init.warn') {
          // 密码初始化，需要修改密码
          defaultPasswordTip(res.data![0])
        } else if (res.code === 'auth.center.login.double.warn') {
          // 双登
          const msgArray = extractContentFromBrackets(res.msg!)
          const msg = `IP:${msgArray[0]}${
            t('in') + msgArray[1] + t('someoneIsLogin')
          },${t('loginNoticeByForce')}`
          // 双登
          unForceLoginTip(msg)
        } else if (res.code === 'auth.center.mfa.init.warn') {
          // MFA未初始化
          mfaNotInitTip(res.data![0])
        } else if (res.code === 'auth.center.mfa.force.warn') {
          // MFA强制校验
          mainStore.setLoginInfo(res.data![0])
          showMFACodeForceDialog.value = true
        } else if (res.code === 'auth.center.user.multi.warn') {
          // 存在多个用户，选择需要登录的用户
          showMultipartUserSelectDialogTip(res.data!)
        } else {
          ElMessage.error(res.msg)
        }
        loading.value = false
      }
    })
    .catch(err => {
      ElMessageBox.alert(err.response.data.msg, t('login.loginFail'), {
        type: 'error',
        showClose: false,
        confirmButtonText: t('confirm'),
        callback: () => {
          loading.value = false
        }
      })
    })
}

// 密码登录时获取登录的类型
const getLoginTypeForPasswordLogin = (): number => {
  // 手机号正则
  const phoneReg =
    /^(13[0-9]|14[01456879]|15[0-35-9]|16[2567]|17[0-8]|18[0-9]|19[0-35-9])\d{8}$/
  // 邮箱正则
  const emailReg = /^\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/
  if (phoneReg.test(loginForm.loginId!)) {
    return 2
  } else if (emailReg.test(loginForm.loginId!)) {
    return 3
  }
  // 普通账户密码登录
  return 1
}

// 激活的tab 0 登录 1 注册
const activeName = ref(0)

// 点击登录的tab
const handleClickTabForLogin = () => {
  activeName.value = 0
  registerFormRef.value?.resetFields()
}

// 点击注册的tab
const handleClickToRegister = () => {
  activeName.value = 1
  if (!loginName.value) {
    registerForm.value.orgType = 2
  }
}

// 点击登录
const handleClickToLogin = () => {
  activeName.value = 0
}

// 是否显示短信验证码登录  0 用户名密码登录  1 短信验证码登录  后续可能出现第三方登录
const activeLoginType = ref(0)
// 点击短信验证码登录
const handleTextMessageLogin = () => {
  activeLoginType.value = 1
}
// 点击用户名密码登录
const handleUserPasswordLogin = () => {
  activeLoginType.value = 0
  loginForm.loginPass = ''
}

// 获取验证码
const countdownForLogin = ref(60)
// 是否显示获取验证码按钮，用于判断倒计时以及获取验证码按钮
const showGetCodeForLogin = ref(true)

// 获取验证码是否禁用
const disabledGetCodeBtnForLogin = computed(() => {
  if (loginForm.loginId) {
    let reg = /^1[3456789]\d{9}$/
    if (reg.test(loginForm.loginId)) {
      return false
    }
    return true
  }
  return true
})

// 获取验证码
const getLoginCode = () => {
  // 点击之后验证码60s后才可点击
  loginForm.loginPass = ''
  // 获取手机验证码
  getGenCaptchaForLogin()
}

// 获取手机短信验证码判断是否需要填写验证码
const getGenCaptchaForLogin = () => {
  loading.value = true
  authGenCaptcha({
    captchaId: validateParams.value.captchaId || ''
  })
    .then(res => {
      loading.value = false
      if (res.state === 'success') {
        // 成功
        validateParams.value = {}
        // 获取手机验证码
        queryCodeForMessageNoCaptchaForLogin()
      } else if (res.state === 'error' && res.msg) {
        // 失败
        showFailuresText.value = res.msg
        showCaptcha.value = false
        const matchData = extractContentFromBrackets(res.msg)
        ElMessage.error({
          message: showFailuresText.value,
          duration: matchData[matchData.length - 1]
            ? Number(matchData[matchData.length - 1]) * 1000
            : 60 * 1000,
          showClose: true
        })
      } else if (res.data && res.data.captchaId) {
        validateParams.value = { ...res.data }
        showCaptcha.value = true
      }
    })
    .catch(() => {
      loading.value = false
    })
}

const timer = ref()
// 倒计时60s
const countdownTimeForLogin = () => {
  timer.value = setTimeout(() => {
    if (countdownForLogin.value > 0) {
      countdownForLogin.value--
      countdownTimeForLogin()
    } else {
      showGetCodeForLogin.value = true
      timer.value && clearInterval(timer.value)
    }
  }, 1000)
}

// 发送手机验证码--需机器校验
const queryCodeForMessageNoCaptchaForLogin = () => {
  authSendDeviceCode({
    loginType: 23,
    loginId: loginForm.loginId,
    captchaId: validateParams.value.captchaId!,
    captchaSign: validateParams.value.captchaId ? validateSign.value : '',
    userType: 300
  })
    .then((res: any) => {
      if (res.state === 'success') {
        captchaRef.value?.validateSuccess()
        // 倒计时
        showGetCodeForLogin.value = false
        if (countdownForLogin.value === 0) {
          countdownForLogin.value = 60
        }
        // 开始倒计时
        countdownTimeForLogin()
      } else {
        if (String(res.code).includes('auth.center.captcha.verify')) {
          // 验证码错误重新刷新
          captchaRef.value?.validateError()
          setTimeout(() => {
            handleRefreshCode()
          }, 1500)
        } else {
          ElMessage.error(res.msg)
          showCaptcha.value = false
        }
      }
      loading.value = false
    })
    .catch(() => {
      loading.value = false
    })
}

// 非强制登录弹窗
const unForceLoginTip = (msg: string) => {
  ElMessageBox.confirm(msg, t('tip'), {
    confirmButtonText: t('confirm'),
    cancelButtonText: t('cancel'),
    type: 'warning'
  }).then(() => {
    // 将forceLogin设置为true
    // 重新强制登录
    loginForm.forceLogin = true
    clickLogin()
  })
}

// 密码修改弹窗
const showUpdatePassword = ref(false)
const updatePasswordDialogRef = ref()
// MFA初始化弹窗
const showMFACodeDialog = ref(false)
const MFACodeDialogRef = ref()
// MFA强制验证
const showMFACodeForceDialog = ref(false)
// 多账户选择弹窗
const showMultipartUserSelectDialog = ref(false)
// 多账户信息
const multipartUserInfo = ref<TokenResponse[]>([])

// 初始化密码修改提示
const defaultPasswordTip = (loginIno: TokenResponse) => {
  const startTime = new Date().getTime()
  ElMessageBox.confirm(t('defaultPasswordEditTip'), t('tip'), {
    confirmButtonText: t('user.updatePassword'),
    cancelButtonText: t('cancel'),
    type: 'warning'
  })
    .then(() => {
      const endTime = new Date().getTime()
      const countTime = (endTime - startTime) / 1000
      const expiresIn = loginIno.expiresIn! / 1000
      // 防止长时间不点击导致临时token都失效了
      if (expiresIn - countTime > 0) {
        // 设置临时身份token
        mainStore.setLoginInfo(loginIno)
        //  打开修改密码弹窗
        showUpdatePassword.value = true
        // 直接倒计时
        updatePasswordDialogRef.value?.start(expiresIn - countTime)
      } else {
        ElMessage.warning(t('tempTokenExpired'))
      }
    })
    .catch(() => {
      mainStore.setLoginInfo({})
    })
}

// 密码过期修改提示
const passwordExpiredTip = (loginIno: TokenResponse) => {
  const startTime = new Date().getTime()
  ElMessageBox.confirm(t('passwordExpired'), t('tip'), {
    confirmButtonText: t('user.updatePassword'),
    cancelButtonText: t('cancel'),
    type: 'warning'
  })
    .then(() => {
      const endTime = new Date().getTime()
      const countTime = (endTime - startTime) / 1000
      const expiresIn = loginIno.expiresIn! / 1000
      // 防止长时间不点击导致临时token都失效了
      if (expiresIn - countTime > 0) {
        // 设置临时身份token
        mainStore.setLoginInfo(loginIno)
        //  打开修改密码弹窗
        showUpdatePassword.value = true
        // 直接倒计时
        updatePasswordDialogRef.value?.start(expiresIn - countTime)
      } else {
        ElMessage.warning(t('tempTokenExpired'))
      }
    })
    .catch(() => {
      mainStore.setLoginInfo({})
    })
}

// MFA未初始化提示
const mfaNotInitTip = (loginIno: TokenResponse) => {
  const startTime = new Date().getTime()
  ElMessageBox.confirm(t('mfaNotInitTip'), t('tip'), {
    confirmButtonText: t('confirm'),
    cancelButtonText: t('cancel'),
    type: 'warning'
  })
    .then(() => {
      const endTime = new Date().getTime()
      const countTime = (endTime - startTime) / 1000
      const expiresIn = loginIno.expiresIn! / 1000
      // 防止长时间不点击导致临时token都失效了
      if (expiresIn - countTime > 0) {
        // 设置临时身份token
        mainStore.setLoginInfo(loginIno)
        //  打开MFA初始化弹窗
        showMFACodeDialog.value = true
        // 直接倒计时
        MFACodeDialogRef.value?.start(expiresIn - countTime)
        nextTick(() => {
          MFACodeDialogRef.value?.getSecret()
        })
      } else {
        ElMessage.warning(t('tempTokenExpired'))
      }
    })
    .catch(() => {
      mainStore.setLoginInfo({})
    })
}

// 存在多账户提示
const showMultipartUserSelectDialogTip = (loginIno: TokenResponse[]) => {
  ElMessageBox.confirm(t('multipartUserSelect'), t('tip'), {
    confirmButtonText: t('confirm'),
    cancelButtonText: t('cancel'),
    type: 'warning'
  }).then(() => {
    // 设置临时身份token
    showMultipartUserSelectDialog.value = true
    multipartUserInfo.value = loginIno
  })
}

// MFA强制校验后登录
const handleMFACodeForceLogin = (loginInfo: TokenResponse) => {
  showMFACodeForceDialog.value = false
  const timer = setTimeout(() => {
    clearTimeout(timer)
    mainStore.setLoginInfo(loginInfo)
    handleInfo()
  }, 500)
}

// 账户选择后，继续登录
const handleContinueLogin = (loginInfo: TokenResponse) => {
  showMultipartUserSelectDialog.value = false
  const timer = setTimeout(() => {
    clearTimeout(timer)
    // 选中当前的需要登录的用户ID
    // 进行登录
    loginForm.userId = loginInfo.userId
    // 调用登录
    clickLogin()
  }, 500)
}

// 登录结束-----------------------------------------------------------------

// 注册开始-----------------------------------------------------------------
// 注册表单
const registerForm = ref<newSaasRegistryParam>({})
const registerFormRef = ref<FormInstance>()
// 注册成功展示出来的登录名,可用于判断是否注册成功
const loginName = ref('')
// 注册表单校验
const registerFormRules = computed<FormRules>(() => {
  return {
    orgType: [
      { required: true, message: t('pleaseSelect') + t('login.registerType') }
    ],
    orgName: [
      {
        required: registerForm.value.orgType === 2,
        message: t('pleaseInput') + t('login.companyName')
      }
    ],
    contactName: [
      { required: true, message: t('pleaseInput') + t('login.concatRealName') }
    ],
    contactMobile: [
      { required: true, message: t('pleaseInput') + t('login.contactPhone') },
      {
        validator: (rule: any, value: any, callback: any) => {
          let reg = /^1[3456789]\d{9}$/
          if (reg.test(value)) {
            callback()
          } else {
            callback(new Error(t('validPhoneFormat')))
          }
        }
      }
    ],
    code: [{ required: true, message: t('pleaseInput') + t('validateCode') }],
    adminPasswd: [
      { required: true, message: t('pleaseInput') + t('login.passWord') },
      {
        validator: (rule: any, value: any, callback: any) => {
          if (
            /^(?=.*[A-Za-z])(?=.*\d)[\w!@#$%^&*\-+=(){}[\]|\\:;"'<>,.?/`~]{8,72}$/.test(
              value
            )
          ) {
            callback()
          } else {
            callback(new Error(t('passwordFormat')))
          }
        }
      }
    ],
    repeatPassword: [
      { required: true, message: t('confirmPasswordAgain') },
      {
        validator: (rule: any, value: any, callback: any) => {
          if (value === registerForm.value.adminPasswd) {
            callback()
          } else {
            callback(new Error(t('validSurePassword')))
          }
        }
      }
    ],
    isCheck: [
      {
        validator: (rule: any, value: any, callback: any) => {
          if (value) {
            callback()
          } else {
            callback(new Error(t('pleaseCheckLoginRule')))
          }
        }
      }
    ]
  }
})

// 点击注册
const handleSubmitRegister = () => {
  registerFormRef.value?.validate(valid => {
    if (valid) {
      loading.value = true
      const params: SaasRegistryParam = {
        orgType: registerForm.value.orgType,
        contactName: registerForm.value.contactName,
        contactMobile: registerForm.value.contactMobile,
        adminPasswd: rsaEncrypt(registerForm.value.adminPasswd) as string
      }
      if (registerForm.value.orgType === 2) {
        params.orgName = registerForm.value.orgName
      }
      openRegistrySave(params, {
        deviceCode: registerForm.value.code!
      })
        .then(res => {
          if (res.state === 'success' && res.data) {
            ElMessage.success(t('login.accountRegistration') + t('success'))
            // @ts-expect-error
            loginName.value = `admin@${res.data.id}`
          } else {
            ElMessage.error(res.msg)
          }
          loading.value = false
        })
        .catch(() => {
          loading.value = false
        })
    }
  })
}

// 是否显示注册图形验证码
// 生成Captcha
const getGenCaptchaForRegister = () => {
  loading.value = true
  openRegistryGenCaptcha({
    captchaId: validateParams.value.captchaId || ''
  })
    .then(res => {
      loading.value = false
      if (res.state === 'success') {
        // 成功
        validateParams.value = {}
        showCaptcha.value = false
        // 获取手机验证码
        queryCodeForMessageNoCaptcha()
      } else if (res.state === 'error' && res.msg) {
        // 失败
        showCaptcha.value = false
        ElMessage.error(res.msg)
      } else if (res.data && res.data.captchaId) {
        // 警告
        validateParams.value = { ...res.data }
        showCaptcha.value = true
      }
    })
    .catch(() => {
      loading.value = false
    })
}

// 点击立即去登录
const goToLogin = () => {
  activeName.value = 0
  // 登录名赋值
  loginForm.loginId = loginName.value
  // 密码清空
  loginForm.loginSecret = ''
}

// 获取验证码
const countdown = ref(60)
// 是否显示获取验证码按钮，用于判断倒计时以及获取验证码按钮
const showGetCode = ref(true)

// 获取验证码是否禁用
const disabledGetCodeBtn = computed(() => {
  if (registerForm.value.contactMobile) {
    let reg = /^1[3456789]\d{9}$/
    if (reg.test(registerForm.value.contactMobile)) {
      return false
    }
    return true
  }
  return true
})

// 获取验证码
const getRegisterCode = () => {
  // 点击之后验证码60s后才可点击
  registerForm.value.code = ''
  // 是否需要机器验证
  getGenCaptchaForRegister()
}

// 倒计时60s
const countdownTime = () => {
  setTimeout(() => {
    if (countdown.value > 0) {
      countdown.value--
      countdownTime()
    } else {
      showGetCode.value = true
    }
  }, 1000)
}

// 发送手机验证码--无需机器校验
const queryCodeForMessageNoCaptcha = () => {
  openRegistrySendDeviceCode({
    mobile: registerForm.value.contactMobile!,
    captchaId: validateParams.value.captchaId || '',
    captchaSign: validateParams.value.captchaId ? validateSign.value : ''
  })
    .then((res: any) => {
      if (res.state === 'success') {
        // 倒计时
        showGetCode.value = false
        if (countdown.value === 0) {
          countdown.value = 60
        }
        // 开始倒计时
        countdownTime()
      } else {
        ElMessage.error(res.msg)
      }
    })
    .catch(() => {
      //
      console.log('特殊处理')
    })
}

// 注册结束---------------------------------------------------------------------

// 跳转忘记密码
const handleForgetPassword = () => {
  router.push({
    path: '/password'
  })
}

// 打开跳转链接
const handleWindowOpen = (url: string) => {
  window.open(url)
}

const formDarkImg = toRaw(
  'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKoAAABBCAYAAABB9T/DAAAAAXNSR0IArs4c6QAAAARzQklUCAgICHwIZIgAAA3ZSURBVHic7V0vlOq+Ev7yzk8gkchKJBJZiVy5ErnyyiuffPLKn1y5ErkSiaxEViIr6+aJzNA0ZJIUyuXP8p3DAUo7SZMvk8nMNBj8ABDRBMDMeU35BecdABoALb83AA4AamNM8/dq+0II5tYVuBaYnAsAc1hyTi4Q1wCoYUlbXV67F4bi6YhKRAWAEkBxpSKEtNuXpv17eBqi/gWChlDhRdi/gocn6o0I6uNF2CvjYYnKNmgJYHnjqggaWLK+bNgr4CGJSkRTAO+wi6R7ww6WsO2tK/JMeDii8lT/jstW8dfGAcDXtUwBboPmGvKJaGqMaVgZgD9PLh14vgyW3+bKfSiiEtESwOrW9WCIv7VF3y8raAB8jkGmQCf/hh2oo5RBRDNYN96S5X7zewlrfxewno7vXGIR0QLAxBiz4+9r2Db6ZPK/c5mfxpg6Je+fITd0SxBRCdtwt4YQtKcxWUMUsJ0tQYU1EY1B1hV3/B6WOBOux8YpewrgDUBljNnmCCWiFayv2Z2d6sCpO1gFceDPOZhwvZcAvrjeKwALImph26oFMGESfxtjDpqwh9ComSRtcKrVroGdMebbPcAaqRFtw1PzElZjXKz1iOgNllC5+BZNlpBbwLbZBJZEjTHmD/9WgjWqMWbDhNsPuQ8i+gU7uOZcTsuvCb8O/B0sW63z3WtUx/0Uwwa2IzWiSuNcghZWm+zdg1y/hTFmI8d4KqtZ061hNeu/IyywamPMZ+gH1rhv/DXX8zBHRxrAajeRIQvVgo8VAEq+jyhZuS4F7KxzIKIdgF+wZNywvDk6E6OA164+7pqo3NFvidM2sNOVf94OthHmsI1QYLjGbdH5SE9IxvVbAphx4x9gNVAL2IUIgD/ccSuu6yWYyCIn9Jt8GDAgar5u5h0TzNBF4oD8vIcGVnEURLRHpzUnbG5MYPunRGffN4iYFXdNVFhtFCPXtzGmIqK5d7yFJVADS7TKORbCAWFX1wTOlK78XqNbUBX83jMNuI4HIlpc6GedwWqmUWCM2QM9U0Xs7yU6csoAEC2ZrL8xpiaimmWUsDYq+HqRt2FZa1hzKmqq3C1R2UaKkXTr3JxPsj0f+4Jt9DXCU/9WFh7cWetIGSdg4/+4AGBbdUJEcyGBey4RTYloFls0JJA79WeDAycFfxVTRQa4HCul/AGiv2BnkZrlAd3MBmNMy3bvNEfuXRKVp7cycsreW9nKalSM9gLdaNYWIb0FB2sBV7MOWeGKjCgBjTF71v7nEnXCAyqEwcEPIvoIXLeF1XAtr87Fhm34t1wUsG2/QackXC/JCt0AeSeirYl4K+6SqIj7ShucTq17nmoAq0FlhelP9RswSRRSfcFqpQK2A0vWOKPF8bmu0zPlxWz2cxaLNfpEbQIKoODPX7CupV2mDSxehIq1PeAQlcuecvlbJLTq3RGVNYZvc7oIkoYb79vJQw3Zo28IuJccGQ0TXmzPCh1hdxdM2T7aM6M9h5Gn/gqdjb0OyCucQxIAGOJH9U2LWn7kASuBhjrl9I8SlQuJkWYoclaNZeL6lDG/RZfJH5SRuL7mOtRigzraehTcUR5Ag9NVv0t66SuxXYfUXbTxkt9rCcei8wJkI6VRlxgvGtQA+Dd2Ao8wQCdT0r3DjbEB8AHbIHv07dQlIj47tlX/h767Z5RpfwQURPTfEeXN0bmIAPTC1Dt0g37t/F7khDxh+7BA5wmp2CaewA7+XxjgLlSJyswfK4WuhXX+RkcSa7DPEcpzfaduNATIWGFyPe9F67mooQ/WOSzBsuvNs1Pl5A5UsO12cMhY88BfwSaR1CFZAbhridoYs+WFpAROxNwQl1i8rtoPZ4TtYsgK6Y0F9hrM0C0WDmDD/RHzRXMyjVix3JNZkcSQRWWQqJ5P8eC8GnQaShpkgbh5oC5eXnghF9rUP4V1R9SJUSwhRA1DfW8vvBDE2dlTPNV8IJ4IkkxgeOGFHFziRy2RjsMPIqljW0o+pyQrAN1mEFm+TMd/N8cdPHjH5lQBu2iRdpOFRA27gEnal85mGnPYCF09cj1H64OI/ALdXgsiv2X5+1A7nEVUdmHEpvzdkEULrwbF35Y6t4YlXu3VR3I/p85LUCOQTMH+wlIpah+yrZkoa4QjQY3rkHdCwXPlfBctp8MdIz9Ou2j3BSheDHb1vStlNfC8MEOe5g31QcY1EoRJhnpZfi+RejBRuQHKyCkHZNqldN5DegVsfucxNmyM2XGnal6KoHwO70naWaic0DUtN2RooG7lwxlPJEjkZyFPBXD0plDKUuvI9TxwrD5071tnMEhYVpWllNvrAw1OTm62z5TlfxDR0Vv0nwEXizZ5h64dsvylLGsOewOhhqxhNeABul+wZDIItpHigkTl+9HuJdawod8qJv6E7PNAZeCcBtZPuYfuO5zCkkDK2EJvg5m4pRSEfqtktnP6oAicV3M9h/RBDzzTaeuYGuk+Xon8oRp1pRQq2OTYgpFpqYH32EZC65ZEVPH5csOhztE0dsx8mYT8fFyfUFh565gFmhbberJKhAktJsOGNbibHOKjQCDS5qTQuTh6YbgP3nDaXpf0gVv+AuHkIk3+OlBfwM4wVbZG5RuPBQB2fg6mIqcXknNwcgPAMXz5FThfUPJ5YoyHcJIZn5FKCITJEUr8kMXaCpkkBQA+ptnyC0dbxuz9kzpG3IZb0z0KvUYGSbmeWX3glF8g3E4HBDxB/P1TkT0FMM8iKpMrlnpXD3DqazahujLn41pnFc7n2EApvO9l5FxBKFnDl9NweLBAeCAfEnZc7DcpK3ZfIe1e4lQ7Had8hDUpYJXNRX3AgytEUiDyuDXL1+5zkSSqY5dqaJH5LBDbRIUiI6WNNW05zTgHcEjHGiUnPOx3dhk4Z8vvWudEQ8cJU2nG57TQcxSmrp2q3FuLbsqP9UHKU5NTh5DJAWSk8iHSxzka9V0pWDBkRxDNJqy0keZAJaFM69wQ6sLD+RybHVwUThmhDpAFVBH4DbDx+Rw3XU771ZHfXK0aUirubHVJH8TqKUQtNPkJ2YDed5MoUblztIKBAb40x1EdQo4DWR0s3kDR6jPjesyRn2M74VW8avPxuybv0gQR9/o6cp7c2wKnbdx4CUGX9IHqYXBs30I55ZK2aFSispZI2aXbAYXFXEE5N6Fd64/yWrueGzJ0TzH7ukDY5nO1lDaIciM42vXHdknMFnPqdjf08Skf+P4v6QOtnql2AC5TRm2QqI4TWEOD4c+ox24iZ+rTrq8T312E3GsV0qtq3+bzny06u/N9b4QH327X6ikejNhgAuLRsTH6IHfWGyp/r2nUt1ihyPSXDkAqvAjo02uv8zjspmoe73uDLkqj3U80ApVATjRGW9SFMtdiC06/nv5gAuLtfEkfSL1imXbR6KP3bJWP+oSo7ITWLgCsi6GOFeoWTkQLtp2Sq9uInALhTj8odcmqH/rumNxrqsACKWcBp0Ej6jZwLDYIfXwGjl2jDxrHfx6rW2rQLhEeLLUxpk9USu/zVKcy9YloRkRzfkLgF8uTzbW0G1lqoUA+rtnKmm1Zx+rI8BcZufbkNiRLOXdC3aPCJ1A8CYDiykkENXp1DM14GX0QJFOiD1wTMDYQ1PVOIq95AzghVCdMFgV1m2i5kBssAr+5sf89whpkCuCNiDZeRo8sfrRoT61UUzveu977vkfabaUFJSroDb0iosavK+l7vabs/z3iM15oyvevj/WBn1WV3Qeme9w8VL8pJwBtA/K1/JFjqqhxLlgrBVyC3hY0XKlfkfPF8d+gv5eTj5ysnd/Q7a69MeYkJEjxJyOPWzIq5b0hHkSo0WnDAuGOb5DYopK12+9IOdGNca/dB2yLfmTKn0G3e3vyDQtf4Tp/2vBHSVaIeRRSyN37s4RuxpzUK+OaTcx5T+knHlKokZ/Us0ZYqVTG2f4ycv1V++CMFEcXssDttfU/TnLu2NDspIqIGqQ9Cz4qTaaCHbp/7evJicjYIbzPamgB1QNnOf2L4f/UEuyYBELTf4NMb8S1+4BzHw7QcwoGyzdM1CHCchF8pEBAeX8BWfMrRi4VjhNciJMztYpN5k5JQQ0ckVHw9XMoK2VwvmdOxllAfkgjRjW+Imfi1LPAyH0woI/3SOxmfTdbo3srzux/yxgguwCOmy7kXFOAH2/JMTUicnoRuTH8zwFbOmvKz5B7tT64VP7dEPWFPAS8BclZ4hkw6FGUF24LJdn75k/Y/g28iPogUPyNyUXes+Du9kcFkpGQlEP74eEkBe3R/b+AH8XKXuU/A+6SqOzqaaD44oiovWSBc89wnimLJWm0uOJfWN4j7nbqZ62pxbXLRHrcQ4K6zeli7sIWdvGUm5vwFLjrVT+T8QPKriR4otVuZrSoxvgplg+BuyYqcLIFpo8DLFlH9ffdAtTtTeU7xht4f7T2E3H3RAWimUbAE5H1BR0PQVQgmejwVGbAC6d4GKICWWT9+mmLjJ+ChyIqcHzcOZaVk8xVvTbY3sza7/SFPDwcUYGsrQxvYgpwvWbnZES9EMdDEhU4Rq+WiCfoDs1hvaQukmlVX7Osn4qHJaogQ7sC/Oz+2CRyNkZr4OwU/cL4eHiiCqjb5jxGWElYrnCmDeklRdf4IdlLt8bTEFXAhM3dX+qAzqEuZJN3SXieovsXZBkEFSJbNL4wPp6OqAInq38B/TGIXMiTk6ObDy/k4WmJ6oOnbNGKQlzRmIIG3V/qiKbN+UfsF66M/wOQQUxMRlNvEgAAAABJRU5ErkJggg=='
)

//  判断是否是暗黑
const isDark = useCustomDark()

// 服务条款
const showTermOfService = ref(false)

const loginRef = ref()
const { tilt, roll } = useParallax(loginRef)

const logoAnimation = computed(() => ({
  transform: `translateX(${tilt.value * 20}px) translateY(${
    roll.value * 30
  }px) scale(1)`
}))

// 刷新验证
const handleRefreshCode = () => {
  authGenCaptcha({
    captchaId: validateParams.value.captchaId || ''
  }).then(res => {
    if (res.state === 'success') {
      validateParams.value = {}
      showCaptcha.value = false
    } else if (res.state === 'error' && res.msg) {
      // 失败
      showFailuresText.value = res.msg
      showCaptcha.value = false
      const matchData = extractContentFromBrackets(res.msg)
      ElMessage.error({
        message: showFailuresText.value,
        duration: matchData[matchData.length - 1]
          ? Number(matchData[matchData.length - 1]) * 1000
          : 60 * 1000,
        showClose: true
      })
    } else if (res.data && res.data.captchaId) {
      validateParams.value = { ...res.data }
      showCaptcha.value = true
    }
  })
}

// 验证成功
const handleValidate = (val: string) => {
  if (activeName.value === 0) {
    //  登录
    if (
      activeLoginType.value === 0 ||
      (activeLoginType.value === 1 && loginForm.loginPass)
    ) {
      // 密码登录
      loading.value = true
      validateSign.value = val
      const data: LoginRequest = {
        loginId: loginForm.loginId,
        loginSecret: rsaEncrypt(loginForm.loginSecret) as string,
        loginType: getLoginTypeForPasswordLogin(),
        userType: loginForm.userType,
        captchaId: validateParams.value.captchaId,
        captchaSign: validateParams.value.captchaId ? validateSign.value : '',
        loginAgent: mainStore.loginAgent,
        forceLogin: loginForm.forceLogin,
        userId: loginForm.userId || undefined
      }
      if (activeLoginType.value === 1 && loginForm.loginPass) {
        // 短信验证码登录方式
        data.loginType = 23
        data.loginPass = loginForm.loginPass
        delete data.loginSecret
      }
      authLogin(data)
        .then(res => {
          if (res.state === 'success' && res.data?.length) {
            // 校验成功就直接登录进去
            captchaRef.value?.validateSuccess()
            setTimeout(() => {
              // 主账号
              const currentAccount = res.data!.find(item => item.token)
              // 其余账号
              const otherAccount = res.data!.filter(item => !item.token)
              if (currentAccount) {
                mainStore.setLoginInfo(currentAccount)
                mainStore.setOtherAccountsLoginInfo(otherAccount)
              } else {
                mainStore.setLoginInfo(res.data![0])
                mainStore.setOtherAccountsLoginInfo(res.data!.slice(1))
              }
              handleInfo()
            }, 1500)
          } else {
            if (String(res.code).includes('auth.center.captcha.verify')) {
              // 验证码错误重新刷新
              captchaRef.value?.validateError()
              const timer = setTimeout(() => {
                handleRefreshCode()
                clearTimeout(timer)
              }, 1500)
            } else if (res.code === 'auth.center.passwd.verify.error') {
              // 用户密码错误，关闭弹窗
              showCaptcha.value = false
              ElMessage.error(res.msg)
            } else if (res.code === 'auth.center.passwd.expire.warn') {
              // 密码过期
              passwordExpiredTip(res.data![0])
              showCaptcha.value = false
            } else if (res.code === 'auth.center.passwd.init.warn') {
              // 密码初始化，需要修改密码
              defaultPasswordTip(res.data![0])
              showCaptcha.value = false
            } else if (res.code === 'auth.center.login.double.warn') {
              // 双登
              const msgArray = extractContentFromBrackets(res.msg!)
              const msg = `IP:${msgArray[0]}${
                t('in') + t('someoneIsLogin')
              },${t('loginNoticeByForce')}`
              // 双登
              unForceLoginTip(msg)
              showCaptcha.value = false
            } else if (res.code === 'auth.center.mfa.init.warn') {
              // MFA未初始化
              mfaNotInitTip(res.data![0])
              showCaptcha.value = false
            } else if (res.code === 'auth.center.mfa.force.warn') {
              // MFA强制校验
              mainStore.setLoginInfo(res.data![0])
              showMFACodeForceDialog.value = true
              showCaptcha.value = false
            } else if (res.code === 'auth.center.user.multi.warn') {
              // 存在多个用户，选择需要登录的用户
              showMultipartUserSelectDialogTip(res.data!)
              showCaptcha.value = false
            } else {
              ElMessage.error(res.msg)
              showCaptcha.value = false
            }
            loading.value = false
          }
        })
        .catch(err => {
          ElMessageBox.alert(err.response.data.msg, t('login.loginFail'), {
            type: 'error',
            showClose: false,
            confirmButtonText: t('confirm'),
            callback: () => {
              loading.value = false
            }
          })
        })
    } else {
      // 短信验证码登录，调用手机号
      validateSign.value = val
      queryCodeForMessageNoCaptchaForLogin()
    }
  } else {
    // 发送手机验证码--需机器校验
    openRegistrySendDeviceCode({
      mobile: registerForm.value.contactMobile!,
      captchaId: validateParams.value.captchaId!,
      captchaSign: validateParams.value.captchaId ? validateSign.value : ''
    })
      .then((res: any) => {
        if (res.state === 'success') {
          captchaRef.value?.validateSuccess()
          // 倒计时
          showGetCode.value = false
          if (countdown.value === 0) {
            countdown.value = 60
          }
          // 开始倒计时
          countdownTime()
        } else {
          if (String(res.code).includes('auth.center.captcha.verify')) {
            // 验证码错误重新刷新
            captchaRef.value?.validateError()
            setTimeout(() => {
              handleRefreshCode()
            }, 1500)
          } else {
            ElMessage.error(res.msg)
            showCaptcha.value = false
          }
        }
      })
      .catch(() => {
        //
        console.log('特殊处理')
      })
  }
}

onMounted(() => {
  // 注册成功后的名称重置
  loginName.value = ''
  // 清除临时token之类的信息，防止异常
  mainStore.setLoginInfo({})
})

onUnmounted(() => {
  timer.value && clearInterval(timer.value)
})
</script>

<template>
  <div
    class="login"
    ref="loginRef"
  >
    <div class="login-box">
      <!-- 头部logo -->
      <div class="logo-header">
        <div class="login_top space-between padding-top-10">
          <el-image
            class="login-top__image"
            fit="cover"
            :src="
              isDark
                ? formDarkImg
                : 'https://qnimg.zowoyoo.com/img/84826/1704851011338.png'
            "
            :style="logoAnimation"
          />
          <div class="login-top__right flex-row flex-align">
            <p class="padding-left-15 flex-align">
              <LangSelect />
              <!-- 黑夜模式切换 -->
              <el-switch
                v-model="isDark"
                active-color="black"
                active-action-icon="Moon"
                inactive-action-icon="Sunny"
                class="margin-left-20"
              ></el-switch>
            </p>
          </div>
        </div>
      </div>
      <!-- 中间内容 -->
      <div class="login-content">
        <div class="opt-box">
          <!-- 登录、注册 -->
          <div
            class="opt-content"
            :style="{
              height: activeName === 0 ? '420px' : '88%',
              backgroundColor: isDark ? '#18222C' : 'var(--el-color-white)'
            }"
          >
            <template v-if="!showCaptcha">
              <!-- 切换的tab -->
              <div class="tab-wrapper margin-bottom-20">
                <div
                  class="tab-item-wrapper"
                  @click="handleClickTabForLogin"
                >
                  <div
                    class="common active"
                    :style="{
                      color: isDark ? 'var(--el-text-color-regular)' : '#000'
                    }"
                  >
                    {{
                      activeName === 0 ? t('login.signIn') : t('login.register')
                    }}
                  </div>
                </div>
                <!-- <div
                  class="tab-item-wrapper register-tab"
                  @click="handleClickToRegister"
                  v-show="activeName === 0"
                >
                  <div class="common">
                    <span class="margin-right-5">
                      {{ t('login.noAccount') }}
                    </span>
                    <el-text
                      type="primary"
                      size="small"
                    >
                      {{ t('login.clickHereToRegister') }}
                    </el-text>
                  </div>
                </div> -->
                <div
                  class="tab-item-wrapper register-tab"
                  @click="handleClickToLogin"
                  v-show="activeName === 1"
                >
                  <div class="common">
                    <span class="margin-right-5">
                      {{ t('login.hasAccount') }}
                    </span>
                    <el-text
                      type="primary"
                      size="small"
                    >
                      {{ t('login.clickHereToLogin') }}
                    </el-text>
                  </div>
                </div>
              </div>
              <!-- 登录 -->
              <div
                class="content-login"
                v-show="activeName === 0"
              >
                <el-form
                  ref="formEl"
                  label-position="right"
                  :model="loginForm"
                  :rules="rules"
                  label-width="0"
                  class="margin-top-15"
                  size="large"
                  :validate-on-rule-change="false"
                >
                  <el-form-item prop="loginId">
                    <el-input
                      v-model.trim="loginForm.loginId"
                      :placeholder="
                        activeLoginType === 0
                          ? t('idOrPhoneOrEmail')
                          : t('linkPhone')
                      "
                      clearable
                      :style="{ width: '100%' }"
                    />
                  </el-form-item>
                  <!-- 短信验证码登录时不需要密码输入框 -->
                  <el-form-item
                    prop="loginSecret"
                    v-show="activeLoginType === 0"
                  >
                    <el-input
                      v-model.trim="loginForm.loginSecret"
                      type="password"
                      show-password
                      :placeholder="t('login.pleaseInputPassWord')"
                      clearable
                      :style="{ width: '100%' }"
                    />
                  </el-form-item>
                  <!-- 短信验证码登录，输入验证码 -->
                  <el-form-item
                    prop="loginPass"
                    v-show="activeLoginType === 1"
                  >
                    <el-row :gutter="10">
                      <el-col :span="showGetCodeForLogin ? 20 : 14">
                        <el-input
                          v-model.trim="loginForm.loginPass"
                          :placeholder="t('pleaseInputValidateCode')"
                          clearable
                          :style="{ width: '100%' }"
                          :disabled="disabledGetCodeBtnForLogin"
                        />
                      </el-col>
                      <el-col :span="showGetCodeForLogin ? 4 : 10">
                        <el-button
                          type="primary"
                          round
                          :disabled="disabledGetCodeBtnForLogin"
                          @click="getLoginCode"
                          v-if="showGetCodeForLogin"
                        >
                          {{ t('getValidateCode') }}
                        </el-button>
                        <el-button
                          type="primary"
                          round
                          :disabled="true"
                          v-else
                        >
                          {{ `${t('getValidateCode')}(${countdownForLogin}s)` }}
                        </el-button>
                      </el-col>
                    </el-row>
                  </el-form-item>
                  <el-row
                    :gutter="10"
                    type="flex"
                    align="middle"
                  >
                    <el-col :span="18">
                      <el-form-item prop="isCheck">
                        <el-checkbox v-model="loginForm.isCheck">
                          <span
                            :style="{
                              color: isDark
                                ? 'var(--el-text-color-regular)'
                                : '#000'
                            }"
                          >
                            {{ t('login.consentAgreement') }}
                          </span>
                          <span @click.stop="showTermOfService = true">
                            {{ t('login.serviceTermsAndPrivacyPolicy') }}
                          </span>
                        </el-checkbox>
                      </el-form-item>
                    </el-col>
                    <el-col :span="6">
                      <!-- <div
                        class="text-message"
                        @click="handleTextMessageLogin"
                        v-show="activeLoginType === 0"
                      >
                        <el-text type="primary">
                          {{ t('validateCodeLogin') }}
                        </el-text>
                      </div>
                      <div
                        class="text-message"
                        @click="handleUserPasswordLogin"
                        v-show="activeLoginType === 1"
                      >
                        <el-text type="primary">
                          {{ t('passwordLogin') }}
                        </el-text>
                      </div> -->
                      <div class="flex-end text-message-force-login">
                        <el-checkbox
                          v-model="loginForm.forceLogin"
                          :label="t('forceLogin')"
                          size="small"
                        />
                      </div>
                    </el-col>
                  </el-row>
                </el-form>
                <!-- 短信验证码登录 -->
                <el-button
                  type="primary"
                  class="login-box__btn"
                  @click="clickLogin"
                  :loading="loading"
                  :style="{
                    background: isDark ? '#153D73' : '#0163f0',
                    borderColor: isDark ? '#153D73' : '#0163f0'
                  }"
                >
                  {{ t('login.signIn') }}
                </el-button>
                <div
                  class="margin-top-10 flex-center cursor-p"
                  @click="handleForgetPassword"
                >
                  <el-text type="primary">{{ t('forgetPassword') }}</el-text>
                </div>
              </div>
              <!-- 注册 -->
              <div
                class="content-register padding-top-15"
                v-show="activeName === 1"
              >
                <el-form
                  :model="registerForm"
                  size="large"
                  :rules="registerFormRules"
                  ref="registerFormRef"
                  v-if="!loginName"
                  :validate-on-rule-change="false"
                >
                  <el-row>
                    <el-col>
                      <el-form-item
                        :label="t('login.registerType')"
                        prop="orgType"
                      >
                        <el-radio-group v-model="registerForm.orgType">
                          <el-radio :value="2">
                            {{ t('login.enterprise') }}
                          </el-radio>
                          <el-radio :value="1">
                            {{ t('login.personal') }}
                          </el-radio>
                        </el-radio-group>
                      </el-form-item>
                    </el-col>
                  </el-row>
                  <el-row v-show="registerForm.orgType === 2">
                    <el-col>
                      <el-form-item prop="orgName">
                        <el-input
                          v-model.trim="registerForm.orgName"
                          :placeholder="
                            t('pleaseInput') + t('login.companyName')
                          "
                          clearable
                          :style="{ width: '100%' }"
                          autocomplete="off"
                        />
                      </el-form-item>
                    </el-col>
                  </el-row>
                  <el-row>
                    <el-col>
                      <el-form-item prop="contactName">
                        <el-input
                          v-model.trim="registerForm.contactName"
                          :placeholder="
                            t('pleaseInput') + t('login.concatRealName')
                          "
                          clearable
                          :style="{ width: '100%' }"
                          autocomplete="off"
                        />
                      </el-form-item>
                    </el-col>
                  </el-row>
                  <el-row>
                    <el-col>
                      <el-form-item prop="contactMobile">
                        <el-input
                          v-model.trim="registerForm.contactMobile"
                          :placeholder="
                            t('pleaseInput') + t('login.contactPhone')
                          "
                          clearable
                          :style="{ width: '100%' }"
                          autocomplete="off"
                        />
                      </el-form-item>
                    </el-col>
                  </el-row>
                  <el-row :gutter="10">
                    <el-col :span="showGetCode ? 16 : 14">
                      <el-form-item prop="code">
                        <el-input
                          v-model.trim="registerForm.code"
                          :placeholder="t('pleaseInputValidateCode')"
                          clearable
                          :style="{ width: '100%' }"
                          :disabled="disabledGetCodeBtn"
                        />
                      </el-form-item>
                    </el-col>
                    <el-col :span="showGetCode ? 8 : 10">
                      <el-button
                        type="primary"
                        round
                        :disabled="disabledGetCodeBtn"
                        @click="getRegisterCode"
                        v-if="showGetCode"
                      >
                        {{ t('getValidateCode') }}
                      </el-button>
                      <el-button
                        type="primary"
                        round
                        :disabled="true"
                        v-else
                      >
                        {{ `${t('getValidateCode')}(${countdown})s` }}
                      </el-button>
                    </el-col>
                  </el-row>
                  <el-row>
                    <el-col>
                      <el-form-item prop="adminPasswd">
                        <el-input
                          v-model.trim="registerForm.adminPasswd"
                          :placeholder="t('pleaseInput') + t('login.passWord')"
                          clearable
                          :style="{ width: '100%' }"
                          type="password"
                          show-password
                          autocomplete="new-password"
                        />
                      </el-form-item>
                    </el-col>
                  </el-row>
                  <el-row>
                    <el-col>
                      <el-form-item prop="repeatPassword">
                        <el-input
                          v-model.trim="registerForm.repeatPassword"
                          :placeholder="t('login.pleaseInputPasswordAgain')"
                          clearable
                          :style="{ width: '100%' }"
                          type="password"
                          show-password
                          autocomplete="new-password"
                        />
                      </el-form-item>
                    </el-col>
                  </el-row>
                  <el-row>
                    <el-col>
                      <el-form-item prop="isCheck">
                        <el-checkbox v-model="registerForm.isCheck">
                          <span
                            :style="{
                              color: isDark
                                ? 'var(--el-text-color-regular)'
                                : '#000'
                            }"
                          >
                            {{ t('login.consentAgreement') }}
                          </span>
                          <span @click.stop="showTermOfService = true">
                            {{ t('login.serviceTermsAndPrivacyPolicy') }}
                          </span>
                        </el-checkbox>
                      </el-form-item>
                    </el-col>
                  </el-row>
                  <el-row>
                    <el-col>
                      <el-button
                        type="primary"
                        :loading="loading"
                        class="login-box__btn"
                        :style="{
                          background: isDark ? '#153D73' : '#0163f0',
                          borderColor: isDark ? '#153D73' : '#0163f0'
                        }"
                        @click="handleSubmitRegister"
                      >
                        {{ t('login.submitRegister') }}
                      </el-button>
                    </el-col>
                  </el-row>
                </el-form>
                <!-- 注册成功 -->
                <div
                  class="registerSuccess"
                  v-else
                >
                  <p class="flex-align flex-center">
                    <el-icon
                      color="var(--el-color-success)"
                      size="28"
                    >
                      <Check />
                    </el-icon>
                    <span class="padding-left-5">
                      {{ t('login.accountRegistration') + t('success') + '!' }}
                    </span>
                  </p>
                  <div class="success-desc padding-top-20">
                    {{ t('login.registerSuccessDesc') }}
                  </div>
                  <div class="login-name">
                    <span>{{ t('login.userName') + '：' }}</span>
                    <span>{{ loginName }}</span>
                  </div>
                  <div class="login-box__btn_box">
                    <el-button
                      type="primary"
                      :loading="loading"
                      class="login-box__btn"
                      :style="{
                        background: isDark ? '#153D73' : '#0163f0',
                        borderColor: isDark ? '#153D73' : '#0163f0'
                      }"
                      @click="goToLogin"
                    >
                      {{ t('login.logInNow') }}
                    </el-button>
                  </div>
                </div>
              </div>
              <div
                :class="{
                  'light-animation': loading && !isDark,
                  'dark-animation': loading && isDark
                }"
              ></div>
            </template>
            <template v-else>
              <!-- 验证组件 -->
              <Captcha
                ref="captchaRef"
                v-model:show="showCaptcha"
                :data="validateParams"
                mode="fixed"
                @refresh="handleRefreshCode"
                @validate="handleValidate"
              ></Captcha>
            </template>
          </div>
        </div>
      </div>
    </div>
    <!-- 底部 -->
    <div class="login-bottom">
      <div class="footer">
        <div class="footer-desc">
          <div class="link-wrapper">
            <div class="link-one">
              <div class="title">{{ t('ZiWoYou') }}</div>
              <a
                class="sub-link"
                @click="handleWindowOpen('https://www.zowoyoo.cn/rookie.html')"
              >
                {{ t('gettingStarted') }}
              </a>
              <a
                class="sub-link"
                @click="handleWindowOpen('http://www.zowoyoo.cn/about.html')"
              >
                {{ t('aboutUs') }}
              </a>

              <a
                class="sub-link"
                @click="
                  handleWindowOpen('https://www.zowoyoo.cn/school/home.html')
                "
              >
                {{ t('ZiWoYouBusinessSchool') }}
              </a>
            </div>
            <div class="link-two padding-left-5">
              <div class="title">{{ t('franchiseCooperation') }}</div>
              <a
                class="sub-link"
                @click="handleWindowOpen('https://www.zowoyoo.cn/contect.html')"
              >
                {{ t('concatUs') }}
              </a>
              <a
                class="sub-link"
                @click="handleWindowOpen('https://www.zowoyoo.cn/join.html')"
              >
                {{ t('joiningPeers') }}
              </a>
              <a
                class="sub-link"
                @click="handleWindowOpen('https://www.zowoyoo.cn/job.html')"
              >
                {{ t('joinUs') }}
              </a>
            </div>
          </div>
          <div
            class="code"
            style="
              display: flex;
              flex-direction: column;
              justify-content: center;
            "
          >
            <el-image :src="codeForShow" />
            <span
              style="
                font-size: 12px;
                color: rgba(255, 255, 255, 0.4);
                text-align: center;
                padding-top: 5px;
              "
            >
              {{ t('weChatOfficialAccount') }}
            </span>
          </div>
        </div>
        <div class="logo">
          <el-image
            :src="logo"
            style="width: 170px"
          />
        </div>
      </div>
      <div class="desc">
        <div>{{ t('companyProfile') }}</div>
        <div>{{ t('companyProfileDesc') }}</div>
      </div>
    </div>

    <!-- 服务条款 -->
    <TermOfService
      v-model:show="showTermOfService"
      ref="updatePasswordDialogRef"
    />
    <!-- 修改密码 -->
    <UpdatePasswordDialog v-model="showUpdatePassword" />
    <!-- MFA初始化 -->
    <MFACodeDialog
      v-model="showMFACodeDialog"
      ref="MFACodeDialogRef"
    />
    <!-- MFA强制校验 -->
    <ForceMFADialog
      v-model="showMFACodeForceDialog"
      @login="handleMFACodeForceLogin"
      :captchaId="validateParams.captchaId"
      :captchaSign="validateSign"
    />
    <!-- 多账户选择 -->
    <MultipartUserSelectDialog
      v-model="showMultipartUserSelectDialog"
      :user-info-list="multipartUserInfo"
      @continueLogin="handleContinueLogin"
    />
  </div>
</template>

<style lang="scss" scoped>
$primary-color: #0163f0;

.textAlign {
  text-align: center;
}

.login {
  position: relative;
  height: 100%;
  overflow: hidden auto;
  .login-box {
    width: 100vw;
    background: url('../../assets/login.png') no-repeat center;
    background-size: cover;
    background-repeat: no-repeat;
    background-position: center center;
    height: calc(100vh - 150px);

    .logo-header {
      width: 100vw;
      height: 65px;
      .login_top {
        max-width: 1200px;
        margin: 0 auto;

        .login-top__image {
          width: 137px;
          height: 52px;
        }

        .login-top__right {
          color: var(--el-color-white);
          p {
            :deep(.lang-select__icon) {
              background: var(--el-color-primary);
            }
          }
        }
      }
    }
    .login-content {
      max-width: 1200px;
      height: calc(100vh - 215px);
      min-height: 770px;
      margin: 0 auto;
      box-sizing: border-box;
      padding: 15px 0;
      display: flex;
      .image-content {
        width: 770px;
        height: 100%;
        :deep(.el-image) {
          width: 100%;
          height: 100%;
          img {
            width: 100%;
            height: 100%;
            border-radius: 4px 0 0 4px;
          }
        }
      }
      .opt-box {
        width: 100vw;
        height: 100%;
        position: relative;
        margin: 0 auto;
        margin-top: 60px;

        .opt-content {
          max-width: 1200px;
          min-width: 420px;
          padding: 30px 20px;
          position: absolute;
          right: 0;
          border-radius: 10px 10px 10px 10px;
          background: var(--el-bg-color);

          box-sizing: border-box;
          transition: all 0.15s;
          .tab-wrapper {
            display: flex;
            justify-content: space-between;
            .tab-item-wrapper {
              line-height: 18px;
              font-weight: 700;
              cursor: pointer;
              color: #7f8690;
            }
            .active {
              color: #000;
              font-size: 20px;
            }
            .register-tab {
              padding-left: 80px;
              font-size: 12px;
            }
            .active-item {
              width: 100%;
              height: 4px;
              border-radius: 8px;
              background: $primary-color;
            }
            .common {
              transition: all 0.15s;
            }
          }
          .code-header {
            height: 60px;
            line-height: 60px;
            font-size: 18px;
          }
          .code-image {
            height: 80px;
          }
          .light-animation {
            position: absolute;
            top: 0;
            left: 0;
            width: 0;
            height: 100%;
            background: linear-gradient(
              0deg,
              rgba(255, 255, 255, 0),
              rgba(135, 206, 235, 0.4),
              rgba(255, 255, 255, 0)
            );
            animation: skeleton-animation 1s ease;
            animation-iteration-count: 1;
            animation-fill-mode: forwards;
          }
          .dark-animation {
            position: absolute;
            top: 0;
            left: 0;
            width: 0;
            height: 100%;
            background: linear-gradient(
              0deg,
              rgba(255, 255, 255, 0),
              rgba(255, 255, 255, 0.4),
              rgba(255, 255, 255, 0)
            );
            animation: skeleton-animation 1s ease;
            animation-iteration-count: 1;
            animation-fill-mode: forwards;
          }
        }
        .login-box__btn_box {
          display: flex;
          justify-content: center;
          margin-top: 30px;
        }
        .login-box__btn {
          font-size: 16px;
          width: 400px;
          height: 45px;
          background: $primary-color;
        }
        .registerSuccess {
          padding-top: 15px;
          box-sizing: border-box;
          .success-desc {
            font-size: 12px;
            color: #7f8690;
            box-sizing: border-box;
          }
          .login-name {
            height: 60px;
            padding: 20px 0;
            font-size: 14px;
            box-sizing: border-box;
          }
        }
      }
      .content-login {
        .text-message-forceLogin {
          width: 80px;
          height: 30px;
          cursor: pointer;
          text-align: right;
        }
        .text-message {
          height: 30px;
          font-weight: 700;
          cursor: pointer;
          display: flex;
          align-items: end;
          justify-content: flex-end;

          :deep(.el-text) {
            font-size: 12px;
          }
        }
        .text-message-force-login {
          height: 40px;
          font-weight: 700;
          :deep(.el-checkbox__label) {
            font-weight: bold;
          }
        }
      }
    }
  }
  .login-bottom {
    width: 100vw;
    height: 150px;
    background: #3e454d;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: space-around;
    .footer {
      width: 60%;
      margin: 0 auto;
      height: 105px;
      display: flex;
      justify-content: space-between;
      padding-top: 10px;
      .footer-desc {
        display: flex;
        justify-content: space-between;
        width: 300px;
        .link-wrapper {
          width: 180px;
          display: flex;
          justify-content: space-between;
          .title {
            font-size: 16px;
            color: #fff;
            padding: 8px 0;
            font-weight: bold;
            line-height: 12px;
          }
          .sub-link {
            font-size: 12px;
            padding: 4px 0;
            color: rgba(255, 255, 255, 0.4);
            cursor: pointer;
            display: block;
          }
        }
        .code {
          :deep(.el-image__inner) {
            width: 80px;
            height: 80px;
          }
        }
      }
    }

    .desc {
      display: flex;
      flex-direction: column;
      align-items: center;
      color: rgba(255, 255, 255, 0.7);
      font-size: 12px;
    }
  }
}

:deep(.el-checkbox__input.is-checked .el-checkbox__inner) {
  background: $primary-color;
}
:deep(.el-checkbox__label) {
  color: var(--el-color-primary);
}
:deep(.el-checkbox__input.is-checked + .el-checkbox__label) {
  color: $primary-color;
}

a {
  text-decoration: none;
}

@keyframes skeleton-animation {
  0% {
    width: 0;
  }
  50% {
    width: 100%;
  }
  100% {
    width: 0;
  }
}
</style>
