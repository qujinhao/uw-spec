<template>
  <!-- 虚假组件-占位用 -->
  <view class="m-cms"></view>
</template>

<script lang="ts" setup>
interface ComponentItem {
  id: number
  component: string
  options: {
    catalogId: number
  }
  attrs?: any
}
interface ATTRS {
  cmsList: ComponentItem[]
  cmsMsg: Record<string, any>
}
withDefaults(
  defineProps<{
    attrs: ATTRS
  }>(),
  {}
)
</script>

<style lang="scss" scoped>
.m-cms {
  min-height: 30px;
}
</style>
