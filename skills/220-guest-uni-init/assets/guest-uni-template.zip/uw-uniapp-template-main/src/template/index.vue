<template>
  <TemplateView
    v-if="!show"
    :project="project"
  ></TemplateView>
  <GbLoading v-model="show" />
</template>

<script lang="ts" setup>
import { ref, computed, onMounted } from 'vue'
import TemplateView from './components/template.vue'
import { useMainStore } from '@/store/main'
import { useUserStore } from '@/store/user'
import { onPageScroll } from '@dcloudio/uni-app'
import { guestSiteInfoLoad } from '@/api/saasMallAppGuestApi'
import { cloneDeep } from 'lodash-es'
import GbLoading from '@/components/GbLoading/index.vue'
import { restoreConfig } from '@/utils/tool'
import { initProject } from '@/config/project'

const mainStore = useMainStore()
const userStore = useUserStore()
const show = ref(true)
const project = computed(() => {
  return mainStore.customProject || {}
})
// interface SiteInfo {
//   saasId: number
//   siteId: number
// }
const getSite = async () => {
  try {
    show.value = true

    // // 获取并解析站点信息
    // const launchOptions = uni.getLaunchOptionsSync()
    // let siteInfo: SiteInfo | null = null

    // if (launchOptions.query?.siteInfo) {
    //   siteInfo = JSON.parse(launchOptions.query.siteInfo) as SiteInfo
    // }

    // if (!siteInfo || !siteInfo.siteId) {
    //   throw new Error('站点信息缺失')
    // }

    // useUserStore().setSiteInfo(siteInfo)
    // if (!userStore.siteInfo || !userStore.siteInfo.siteId) return
    const res = await guestSiteInfoLoad({ id: userStore.siteInfo!.siteId })
    /*
    data:{
      id:20001
      saasId:655370
      siteName:"一号站点"
      siteIcon:"{}"
      templateId:0
      mchId:0
      areaCode:0
      rankOrder:0
      siteConfig:"{\"pages\": [{\"id\": \"000000\", \"home\": true, \"name\": \"首页\", \"target\": \"17575720168vVb\", \"componentList\": [{\"id\": \"1757903475dERhcM\", \"name\": \"m-grid-nav\", \"height\": 170, \"options\": {\"catalogId\": 10227}}, {\"id\": \"1757903483qPKk6C\", \"name\": \"m-notice-bar\", \"height\": 37, \"options\": {\"catalogId\": 10002}}, {\"id\": \"1757903500gpgfCf\", \"name\": \"m-product-list\"}]}, {\"id\": \"17575720168vVb\", \"name\": \"产品详情\", \"pagesType\": 2, \"basicsPage\": \"/product/productDetail/index\"}, {\"id\": \"1757572073ISe3\", \"name\": \"新增页面\", \"componentList\": [{\"id\": \"1757902800GurRPX\", \"name\": \"m-title\"}]}]}"
      createDate:1753155493169
      modifyDate:1757903511141
      state:1
    }
    */
    // debugger
    if (res.state === 'success' && res.data?.siteConfig) {
      let siteConfig = restoreConfig(
        initProject,
        JSON.parse(res.data.siteConfig)
      )

      const project = Object.assign(cloneDeep(res.data), {
        siteConfig: siteConfig
      })
      console.log('log输出的内容：页面信息project', project)
      mainStore.setCustomProject(project)
    } else {
      uni.showToast({ title: res.msg, icon: 'none', duration: 2000 })
    }

    show.value = false
  } catch (error) {
    uni.showToast({ title: '服务异常', icon: 'error', duration: 5000 })
    console.log('log输出的内容：error', error)
  }
}
onMounted(() => {
  getSite()
})

onPageScroll((e) => {
  // 发送滚动位置给子组件
  uni.$emit('onPageScroll', e.scrollTop)
})
</script>
