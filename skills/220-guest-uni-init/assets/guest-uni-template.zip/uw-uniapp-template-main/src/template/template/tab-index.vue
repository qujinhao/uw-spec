<template>
  <view class="page">
    <!-- <my-page v-if="location == 3"></my-page> -->
    <active-page v-if="location == 2"></active-page>
    <category-page v-if="location == 1"></category-page>
    <tab-bar
      v-if="isShow === 'custom'"
      :project="project"
      :active="tab && tab.jump && tab.jump.id"
    ></tab-bar>
    <!-- <ZTabbar
      v-if="isShow === 'default'"
      name="home"
    /> -->
  </view>
</template>

<script lang="ts" setup>
import { computed } from 'vue'
import { useMainStore } from '@/store/main'

import activePage from './tabbar-page/active-page.vue'
import categoryPage from './tabbar-page/category-page.vue'
import TabBar from '../components/TabBar/index.vue'
// import ZTabbar from '@/components/ZTabbar'

const mainStore = useMainStore()

const props = defineProps({
  location: {
    type: Number,
    default: 1
  }
})

const project = computed(() => mainStore.customProject)
const tab = computed(() => {
  return project.value?.siteConfig?.config?.navigation?.list[props.location]
})

const page = computed(() => {
  return project.value?.siteConfig?.pages?.find((p: any) => p.home)
})
const isShow = computed(() => {
  return page.value?.isShowTabbar
})
</script>

<style lang="scss" scoped>
.page {
  // max-height: 650px;
  // overflow: auto;
  // padding-bottom: 50px;
  // padding-bottom: calc(50px + env(safe-area-inset-bottom));
  // padding-bottom: calc(50px + constant(safe-area-inset-bottom));
}
</style>
