<template>
  <view class="z-title">
    <view
      class="z-title-main"
      v-if="title"
    >
      <view class="z-title-left">
        <text
          v-if="icon"
          class="i"
          :style="{ backgroundImage: `url(${iconImg})` }"
        ></text>
        <text :style="{ fontSize: titleSize }">{{ title }}</text>
      </view>
      <view
        class="z-title-right"
        @click="handlerTitleClick"
        v-if="more"
      >
        <text>{{ moreName }}</text>
        <text class="more"></text>
      </view>
    </view>
    <view
      class="z-title-minor"
      v-if="second.length > 0"
    >
      <view
        v-for="item in second"
        :key="item.name"
        :class="{
          'z-minor-title': true,
          active: activeItem === item.key
        }"
        @click="handlerClick(item)"
      >
        {{ item.name }}
      </view>
      <view
        v-if="secondMore"
        class="z-title-minor-more"
        @click="clickSecondMore"
      >
        <text>{{ secondMoreName }}</text>
        <text class="more"></text>
      </view>
    </view>
  </view>
</template>

<script lang="ts" setup>
import { ref, computed } from 'vue'

interface Props {
  title?: string
  titleSize?: string
  icon?: boolean
  more?: boolean
  moreName?: string
  second?: Array<{ name: string; key: string | number }>
  secondMore?: boolean
  secondMoreName?: string
  defaultActive?: string | number
  defaultColor?: number
  isFixed?: boolean
  offsetTop?: number
}

const props = withDefaults(defineProps<Props>(), {
  // title 标题
  title: '',
  titleSize: '',
  // 图标
  icon: true,
  // 更多 是否显示
  more: true,
  moreName: '更多',
  // 二级标题 [{ name: '推荐',key: 'key' },{name: '离我最近', key: 'key2'}]
  second: () => [],
  // 二级标题是否显示更多
  secondMore: false,
  // 二级标题 更多名
  secondMoreName: '更多',
  // 默认点击的 key 值
  defaultActive: '',
  // 0 彩色  1 灰色
  defaultColor: 0,
  // 二级标题是否可吸顶
  isFixed: false,
  offsetTop: 45
})

interface Emits {
  (e: 'moreClick'): void
  (e: 'secondMoreClick'): void
  (e: 'change', item: { name: string; key: string | number }): void
}

const emit = defineEmits<Emits>()

const active = ref<string | number>('')
// const isFixedValue = ref(false)
const iconImg = ref('http://qnimg.zowoyoo.com/img/84826/1757319569299.png')

const activeItem = computed(() => {
  if (active.value !== '') {
    return active.value
  }
  if (props.defaultActive === '' && props.second.length > 0) {
    return props.second[0].key
  }
  return props.defaultActive
})

const handlerTitleClick = () => {
  emit('moreClick')
}

const clickSecondMore = () => {
  emit('secondMoreClick')
}

const handlerClick = (item: { name: string; key: string | number }) => {
  if (active.value === item.key) return false
  active.value = item.key
  emit('change', item)
}
</script>

<style lang="scss" scoped>
.z-title {
  padding: 20rpx 32rpx 10rpx;
  background-image: linear-gradient(#fff, #f6f6f6);
  border-radius: 30rpx 30rpx 0 0;
  .more {
    width: 24rpx;
    height: 24rpx;
    // background: url('./images/more.png') no-repeat center;
    background-size: contain;
    margin-left: 12rpx;
  }
  .z-title-main {
    display: flex;
    justify-content: space-between;
    margin-bottom: 10rpx;
    .z-title-left {
      display: flex;
      align-items: center;
      .i {
        width: 34rpx;
        height: 40rpx;
        background-repeat: no-repeat;
        background-position: center;
        background-size: contain;
        margin-right: 14rpx;
      }
      text {
        font-size: 38rpx;
      }
    }
    .z-title-right {
      display: flex;
      align-items: center;
      text {
        color: #666;
        font-size: 32rpx;
      }
    }
  }
  .z-title-minor {
    display: flex;
    align-items: baseline;
    padding-bottom: 20rpx;
    .z-minor-title {
      position: relative;
      font-size: 32rpx;
      color: #999;
      text-align: center;
      margin-right: 40rpx;
      transition: font-size 150ms;
    }
    .z-title-minor-more {
      flex: 1;
      display: flex;
      align-items: center;
      justify-content: flex-end;
      color: #666;
      font-size: 24rpx;
    }
    .active {
      font-size: 44rpx;
      color: #222;
      padding-bottom: 20rpx;
      background: url('http://qnimg.zowoyoo.com/img/84826/1757319618607.png')
        no-repeat center bottom;
      background-size: 34rpx 16rpx;
    }
  }
}
</style>
