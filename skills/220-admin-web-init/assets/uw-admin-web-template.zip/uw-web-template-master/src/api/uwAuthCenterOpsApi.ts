import request from '@/utils/request'
import {
  ResponseData,
  DataList,
  ESDataList,
  EnumStruct
} from './uwAuthCenterAuthApi'

//修改MSC权限
export const opsMscMscPermUpdate = (
  data: MscPerm,
  params: {
    remark: string // 备注
  }
): Promise<ResponseData<MscPerm>> => {
  return request('/uw-auth-center/ops/msc/mscPerm/update', {
    method: 'PUT',
    data,
    params
  })
}
//重置单个权限排序
export const opsMscMscPermResetPermRank = (params: {
  id: number // 权限ID
}): Promise<ResponseData<string>> => {
  return request('/uw-auth-center/ops/msc/mscPerm/resetPermRank', {
    method: 'PUT',
    params
  })
}
//重置应用权限排序
export const opsMscMscPermResetAppPermRank = (params: {
  userType: number // 用户类型
  appId: number // 应用id
}): Promise<ResponseData<string>> => {
  return request('/uw-auth-center/ops/msc/mscPerm/resetAppPermRank', {
    method: 'PUT',
    params
  })
}
//强制应用权限排序
export const opsMscMscPermForceAppPermRank = (
  data: Array<MscAppPermVo>,
  params: {
    userType: number // 用户类型
    appId: number // 应用id
  }
): Promise<ResponseData<string>> => {
  return request('/uw-auth-center/ops/msc/mscPerm/forceAppPermRank', {
    method: 'PUT',
    data,
    params
  })
}
//启用MSC权限
export const opsMscMscPermEnable = (params: {
  id: number // 主键ID
  remark: string // 备注
}): Promise<ResponseData<void>> => {
  return request('/uw-auth-center/ops/msc/mscPerm/enable', {
    method: 'PUT',
    params
  })
}
//禁用MSC权限
export const opsMscMscPermDisable = (params: {
  id: number // 主键ID
  remark: string // 备注
}): Promise<ResponseData<void>> => {
  return request('/uw-auth-center/ops/msc/mscPerm/disable', {
    method: 'PUT',
    params
  })
}
//修改MSC应用
export const opsMscMscAppUpdate = (
  data: MscApp,
  params: {
    remark: string // 备注
  }
): Promise<ResponseData<MscApp>> => {
  return request('/uw-auth-center/ops/msc/mscApp/update', {
    method: 'PUT',
    data,
    params
  })
}
//MSC应用列表排序
export const opsMscMscAppForceRank = (
  data: Array<MscApp>
): Promise<ResponseData<void>> => {
  return request('/uw-auth-center/ops/msc/mscApp/forceRank', {
    method: 'PUT',
    data
  })
}
//启用MSC应用
export const opsMscMscAppEnable = (params: {
  id: number // 主键ID
  remark: string // 备注
}): Promise<ResponseData<void>> => {
  return request('/uw-auth-center/ops/msc/mscApp/enable', {
    method: 'PUT',
    params
  })
}
//禁用MSC应用
export const opsMscMscAppDisable = (params: {
  id: number // 主键ID
  remark: string // 备注
}): Promise<ResponseData<void>> => {
  return request('/uw-auth-center/ops/msc/mscApp/disable', {
    method: 'PUT',
    params
  })
}
//清除TOTP校验限制
export const opsMscLiveClearTotpVerifyLimit = (params: {
  userInfo: string //
  remark: string // 备注
}): Promise<ResponseData<void>> => {
  return request('/uw-auth-center/ops/msc/live/clearTotpVerifyLimit', {
    method: 'PUT',
    params
  })
}
//清除IP错误限制
export const opsMscLiveClearIpErrorLimit = (params: {
  ip: string //
  remark: string // 备注
}): Promise<ResponseData<void>> => {
  return request('/uw-auth-center/ops/msc/live/clearIpErrorLimit', {
    method: 'PUT',
    params
  })
}
//清除设备验证码校验限制
export const opsMscLiveClearDeviceVerifyLimit = (params: {
  deviceId: string //
  remark: string // 备注
}): Promise<ResponseData<void>> => {
  return request('/uw-auth-center/ops/msc/live/clearDeviceVerifyLimit', {
    method: 'PUT',
    params
  })
}
//清除设备验证码发送限制
export const opsMscLiveClearDeviceSendLimit = (params: {
  ip: string //
  remark: string // 备注
}): Promise<ResponseData<void>> => {
  return request('/uw-auth-center/ops/msc/live/clearDeviceSendLimit', {
    method: 'PUT',
    params
  })
}
//清除Captcha验证码发送限制
export const opsMscLiveClearCaptchaSendLimit = (params: {
  ip: string //
  remark: string // 备注
}): Promise<ResponseData<void>> => {
  return request('/uw-auth-center/ops/msc/live/clearCaptchaSendLimit', {
    method: 'PUT',
    params
  })
}
//新增MSC权限
export const opsMscMscPermSave = (
  data: MscPerm
): Promise<ResponseData<MscPerm>> => {
  return request('/uw-auth-center/ops/msc/mscPerm/save', {
    method: 'POST',
    data
  })
}
//新增MSC应用
export const opsMscMscAppSave = (
  data: MscApp
): Promise<ResponseData<MscApp>> => {
  return request('/uw-auth-center/ops/msc/mscApp/save', {
    method: 'POST',
    data
  })
}
//踢出在线用户
export const opsMscLiveKickout = (params: {
  loginAgent: string // 登录代理
  saasId: number // saasId
  userId: number // 用户ID
  remark: string // 备注
}): Promise<ResponseData<void>> => {
  return request('/uw-auth-center/ops/msc/live/kickout', {
    method: 'POST',
    params
  })
}
//MSC权限详情
export const opsMscMscPermLoad = (params: {
  id: number // 权限ID
}): Promise<ResponseData<MscPerm>> => {
  return request('/uw-auth-center/ops/msc/mscPerm/load', {
    method: 'GET',
    params
  })
}
//MSC权限列表
export const opsMscMscPermList = (params: {
  userType: number // 用户类型
}): Promise<ResponseData<Array<MscAppPermVo>>> => {
  return request('/uw-auth-center/ops/msc/mscPerm/list', {
    method: 'GET',
    params
  })
}
//列出后台菜单系统管理员类型
export const opsMscMscPermListMenuUserType = (): Promise<
  ResponseData<Array<EnumStruct>>
> => {
  return request('/uw-auth-center/ops/msc/mscPerm/listMenuUserType', {
    method: 'GET'
  })
}
//查询数据历史
export const opsMscMscPermListDataHistory = (
  params: SysDataHistoryQueryParam
): Promise<ResponseData<DataList<SysDataHistory>>> => {
  return request('/uw-auth-center/ops/msc/mscPerm/listDataHistory', {
    method: 'GET',
    params
  })
}
//查询操作日志
export const opsMscMscPermListCritLog = (
  params: SysCritLogQueryParam
): Promise<ResponseData<DataList<SysCritLog>>> => {
  return request('/uw-auth-center/ops/msc/mscPerm/listCritLog', {
    method: 'GET',
    params
  })
}
//加载MSC应用主机
export const opsMscMscAppHostLoad = (params: {
  id: number // 主键ID
}): Promise<ResponseData<MscAppHost>> => {
  return request('/uw-auth-center/ops/msc/mscAppHost/load', {
    method: 'GET',
    params
  })
}
//列表MSC应用主机
export const opsMscMscAppHostList = (
  params: MscAppHostQueryParam
): Promise<ResponseData<DataList<MscAppHost>>> => {
  return request('/uw-auth-center/ops/msc/mscAppHost/list', {
    method: 'GET',
    params
  })
}
//查看MSC应用
export const opsMscMscAppLoad = (params: {
  id: number // MSC应用ID
}): Promise<ResponseData<MscApp>> => {
  return request('/uw-auth-center/ops/msc/mscApp/load', {
    method: 'GET',
    params
  })
}
//轻量级列表MSC应用
export const opsMscMscAppLiteList = (
  params: MscAppQueryParam
): Promise<ResponseData<DataList<MscApp>>> => {
  return request('/uw-auth-center/ops/msc/mscApp/liteList', {
    method: 'GET',
    params
  })
}
//MSC应用列表
export const opsMscMscAppList = (
  params: MscAppQueryParam
): Promise<ResponseData<DataList<MscApp>>> => {
  return request('/uw-auth-center/ops/msc/mscApp/list', {
    method: 'GET',
    params
  })
}
//列表MSC应用主机
export const opsMscMscAppListHost = (
  params: MscAppHostQueryParam
): Promise<ResponseData<DataList<MscAppHost>>> => {
  return request('/uw-auth-center/ops/msc/mscApp/listHost', {
    method: 'GET',
    params
  })
}
//查询数据历史
export const opsMscMscAppListDataHistory = (
  params: SysDataHistoryQueryParam
): Promise<ResponseData<DataList<SysDataHistory>>> => {
  return request('/uw-auth-center/ops/msc/mscApp/listDataHistory', {
    method: 'GET',
    params
  })
}
//查询操作日志
export const opsMscMscAppListCritLog = (
  params: SysCritLogQueryParam
): Promise<ResponseData<DataList<SysCritLog>>> => {
  return request('/uw-auth-center/ops/msc/mscApp/listCritLog', {
    method: 'GET',
    params
  })
}
//实时信息
export const opsMscLiveList = (): Promise<ResponseData<MscLiveInfo>> => {
  return request('/uw-auth-center/ops/msc/live/list', {
    method: 'GET'
  })
}
//列表TOTP校验限制用户
export const opsMscLiveListTotpVerifyLimit = (): Promise<
  ResponseData<Array<string>>
> => {
  return request('/uw-auth-center/ops/msc/live/listTotpVerifyLimit', {
    method: 'GET'
  })
}
//列表在线用户
export const opsMscLiveListOnlineUser = (): Promise<
  ResponseData<Array<string>>
> => {
  return request('/uw-auth-center/ops/msc/live/listOnlineUser', {
    method: 'GET'
  })
}
//列表登录用户
export const opsMscLiveListLogonUser = (): Promise<
  ResponseData<Array<string>>
> => {
  return request('/uw-auth-center/ops/msc/live/listLogonUser', {
    method: 'GET'
  })
}
//列表错误限制IP
export const opsMscLiveListIpErrorLimit = (): Promise<
  ResponseData<Array<string>>
> => {
  return request('/uw-auth-center/ops/msc/live/listIpErrorLimit', {
    method: 'GET'
  })
}
//列表设备ID校验限制
export const opsMscLiveListDeviceVerifyLimit = (): Promise<
  ResponseData<Array<string>>
> => {
  return request('/uw-auth-center/ops/msc/live/listDeviceVerifyLimit', {
    method: 'GET'
  })
}
//列表设备发送限制IP
export const opsMscLiveListDeviceSendLimit = (): Promise<
  ResponseData<Array<string>>
> => {
  return request('/uw-auth-center/ops/msc/live/listDeviceSendLimit', {
    method: 'GET'
  })
}
//列表Captcha发送限制IP
export const opsMscLiveListCaptchaSendLimit = (): Promise<
  ResponseData<Array<string>>
> => {
  return request('/uw-auth-center/ops/msc/live/listCaptchaSendLimit', {
    method: 'GET'
  })
}
//检查用户是否登录
export const opsMscLiveCheckUserLogon = (params: {
  saasId: number // saasId
  userType: number // 用户类型
  userId: number // 用户ID
}): Promise<ResponseData<void>> => {
  return request('/uw-auth-center/ops/msc/live/checkUserLogon', {
    method: 'GET',
    params
  })
}
//检查用户是否在线
export const opsMscLiveCheckUserActive = (params: {
  saasId: number // saasId
  userType: number // 用户类型
  userId: number // 用户ID
}): Promise<ResponseData<void>> => {
  return request('/uw-auth-center/ops/msc/live/checkUserActive', {
    method: 'GET',
    params
  })
}
//登录日志查询
export const opsLogLoginLogList = (
  params: MscLoginLogEsQueryParam
): Promise<ResponseData<ESDataList<MscLoginEsLog>>> => {
  return request('/uw-auth-center/ops/log/loginLog/list', {
    method: 'GET',
    params
  })
}
//客户登录日志查询
export const opsLogGuestLoginLogList = (
  params: MscGuestLoginEsLogQueryParam
): Promise<ResponseData<ESDataList<MscGuestLoginEsLog>>> => {
  return request('/uw-auth-center/ops/log/guestLoginLog/list', {
    method: 'GET',
    params
  })
}
//数据历史查询
export const opsLogDataHistoryList = (
  params: SysDataHistoryQueryParam
): Promise<ResponseData<DataList<SysDataHistory>>> => {
  return request('/uw-auth-center/ops/log/dataHistory/list', {
    method: 'GET',
    params
  })
}
//关键日志查询
export const opsLogCritLogList = (
  params: SysCritLogQueryParam
): Promise<ResponseData<DataList<SysCritLog>>> => {
  return request('/uw-auth-center/ops/log/critLog/list', {
    method: 'GET',
    params
  })
}
//操作日志查询
export const opsLogActionLogList = (
  params: MscActionEsLogQueryParam
): Promise<ResponseData<ESDataList<MscActionEsLog>>> => {
  return request('/uw-auth-center/ops/log/actionLog/list', {
    method: 'GET',
    params
  })
}
//列表统计信息
export const opsHomeDashboardListStats = (
  params: MscStatsQueryParam
): Promise<ResponseData<DataList<MscStats>>> => {
  return request('/uw-auth-center/ops/home/dashboard/listStats', {
    method: 'GET',
    params
  })
}
//列表运行指标
export const opsHomeDashboardListMetrics = (
  params: MscMetricsQueryParam
): Promise<ResponseData<DataList<MscMetrics>>> => {
  return request('/uw-auth-center/ops/home/dashboard/listMetrics', {
    method: 'GET',
    params
  })
}
//最新统计信息
export const opsHomeDashboardLastStats = (): Promise<
  ResponseData<MscStats>
> => {
  return request('/uw-auth-center/ops/home/dashboard/lastStats', {
    method: 'GET'
  })
}
//最新运行指标
export const opsHomeDashboardLastMetrics = (): Promise<
  ResponseData<MscMetrics>
> => {
  return request('/uw-auth-center/ops/home/dashboard/lastMetrics', {
    method: 'GET'
  })
}
//删除MSC权限
export const opsMscMscPermDelete = (params: {
  id: number // 主键ID
  remark: string // 备注
}): Promise<ResponseData<void>> => {
  return request('/uw-auth-center/ops/msc/mscPerm/delete', {
    method: 'DELETE',
    params
  })
}
//删除MSC应用
export const opsMscMscAppDelete = (params: {
  id: number // 主键ID
  remark: string // 备注
}): Promise<ResponseData<void>> => {
  return request('/uw-auth-center/ops/msc/mscApp/delete', {
    method: 'DELETE',
    params
  })
}

//MSC权限
export interface MscPerm {
  id?: number //主键
  appId?: number //应用 app_id
  permName?: string //应用权限名称
  permDesc?: string //应用权限描述
  userType?: number //权限类型
  permLevel?: number //权限等级：1分类2分类菜单3菜单4权限
  permCode?: string //应用权限描述值: URI or 资源Id
  licenseCode?: string //授权Key
  permRank?: number //权限排序，管理显示用
  createDate?: string //创建日期
  modifyDate?: string //修改日期
  displayState?: number //是否显示0不显示 1显示 2 VIP
  state?: number //-1: 删除; 0: 冻结; 1: 启用
}
//MSC菜单权限Vo
export interface MscAppPermVo {
  id?: number //应用Id
  appName?: string //应用唯一名称
  appVersion?: string //应用版本
  appLabel?: string //应用名称
  appRank?: number //应用显示顺序[ASC]
  lastUpdate?: string //最后更新时间
  displayState?: number //显示状态
  permVoList?: Array<PermVo> //菜单树列表
}
//
export interface PermVo {
  id?: number //id
  permCode?: string //权限菜单URI
  permName?: string //权限菜单名称
  permRank?: number //菜单排序
  licenseCode?: string //许可代码
  displayState?: number //1:显示,0:隐藏
}
//MSC应用
export interface MscApp {
  id?: number //主键
  appName?: string //应用名称
  appLabel?: string //应用显示名称
  appVersion?: string //应用版本
  appRank?: number //应用显示顺序
  remark?: string //备注
  permNum?: number //权限数量
  runHost?: number //运行主机数量
  runThread?: number //运行线程数
  runMem?: number //运行内存数
  runUser?: number //运行用户数
  runAccess?: number //运行访问数
  createDate?: string //创建时间
  modifyDate?: string //修改时间
  lastUpdate?: string //最后更新时间
  displayState?: number //是否显示0不显示 1显示 2 VIP
  state?: number //应用状态1: 上线; 0: 下线 -1:删除
}
//系统数据历史列表查询参数
export interface SysDataHistoryQueryParam {
  mchId?: number //商户ID
  userId?: number //用户ID
  userType?: number //用户类型
  id?: number //ID
  ids?: Array<number> //数组ID
  groupId?: number //用户的组ID
  userName?: string //用户名称
  nickName?: string //用户昵称
  realName?: string //真实名称
  entityClass?: string //实体类
  entityId?: string //实体ID
  entityName?: string //实体名
  userIp?: string //用户IP
  createDateRange?: Array<string> //创建日期范围
  $pg?: number //当前页码
  $rn?: number //每页条数
  $si?: number //起始位置
  $rt?: number //请求类型
  $sn?: Array<string> //排序名称
  $st?: Array<number> //排序类型
}
//系统数据历史
export interface SysDataHistory {
  id?: number //ID
  saasId?: number //saasId
  mchId?: number //商户ID
  userId?: number //用户ID
  userType?: number //用户类型
  groupId?: number //用户的组ID
  userName?: string //用户名称
  nickName?: string //用户昵称
  realName?: string //真实名称
  entityClass?: string //实体类
  entityId?: string //实体ID
  entityName?: string //实体名
  entityData?: string //实体数据
  entityUpdateInfo?: string //实体修改信息
  remark?: string //备注信息
  userIp?: string //用户IP
  createDate?: string //创建日期
}
//系统关键日志列表查询参数
export interface SysCritLogQueryParam {
  mchId?: number //商户ID
  userId?: number //用户id
  userType?: number //用户类型
  id?: number //ID
  ids?: Array<number> //数组ID
  groupId?: number //用户组ID
  userName?: string //用户名
  nickName?: string //用户昵称
  realName?: string //真实名称
  userIp?: string //用户ip
  apiUri?: string //请求uri
  apiName?: string //API名称
  bizType?: string //业务类型
  bizId?: string //业务ID
  requestDateRange?: Array<string> //请求时间范围
  responseState?: string //响应状态
  responseCode?: string //响应代码
  responseMillis?: number //请求毫秒数
  responseMillisRange?: Array<number> //请求毫秒数范围
  statusCode?: number //响应状态码
  statusCodeRange?: Array<number> //响应状态码范围
  appInfo?: string //应用信息
  appHost?: string //应用主机
  $pg?: number //当前页码
  $rn?: number //每页条数
  $si?: number //起始位置
  $rt?: number //请求类型
  $sn?: Array<string> //排序名称
  $st?: Array<number> //排序类型
}
//系统关键日志
export interface SysCritLog {
  id?: number //ID
  saasId?: number //saasId
  mchId?: number //商户ID
  userId?: number //用户id
  userType?: number //用户类型
  groupId?: number //用户组ID
  userName?: string //用户名
  nickName?: string //用户昵称
  realName?: string //真实名称
  userIp?: string //用户ip
  apiUri?: string //请求uri
  apiName?: string //API名称
  bizType?: string //业务类型
  bizId?: string //业务ID
  bizLog?: string //业务日志
  requestDate?: string //请求时间
  requestBody?: string //请求参数
  responseState?: string //响应状态
  responseCode?: string //响应代码
  responseMsg?: string //响应消息
  responseBody?: string //响应日志
  responseMillis?: number //请求毫秒数
  statusCode?: number //响应状态码
  appInfo?: string //应用信息
  appHost?: string //应用主机
}
//MSC应用主机
export interface MscAppHost {
  id?: number //主键
  appId?: number //appId
  appName?: string //应用名称
  appVersion?: string //应用版本
  appHost?: string //app主机
  appPort?: number //app端口
  userRpcNum?: number //在线rpc户数
  userRootNum?: number //在线root数
  userOpsNum?: number //在线ops数
  userAdminNum?: number //在线admin数
  userSaasNum?: number //在线saas用户
  userGuestNum?: number //在线会员数
  accessCount?: number //访问计数
  jvmMemMax?: number //jvm内存总数
  jvmMemTotal?: number //jvm内存总数
  jvmMemFree?: number //jvm空闲内存
  threadActive?: number //活跃线程
  threadPeak?: number //峰值线程
  threadDaemon?: number //守护线程
  threadStarted?: number //累计启动线程
  createDate?: string //创建时间
  modifyDate?: string //修改时间
  lastUpdate?: string //最后更新时间
  state?: number //应用状态1: 上线; 0: 下线 -1:删除
}
//MSC应用主机列表查询参数
export interface MscAppHostQueryParam {
  id?: number //主键
  ids?: Array<number> //ID数组
  appId?: number //appId
  appName?: string //应用名称
  appVersion?: string //应用版本
  appHost?: string //app主机
  appPort?: number //app端口
  appPortRange?: Array<number> //app端口范围
  userRpcNum?: number //在线rpc户数
  userRpcNumRange?: Array<number> //在线rpc户数范围
  userRootNum?: number //在线root数
  userRootNumRange?: Array<number> //在线root数范围
  userOpsNum?: number //在线ops数
  userOpsNumRange?: Array<number> //在线ops数范围
  userAdminNum?: number //在线admin数
  userAdminNumRange?: Array<number> //在线admin数范围
  userSaasNum?: number //在线saas用户
  userSaasNumRange?: Array<number> //在线saas用户范围
  userGuestNum?: number //在线会员数
  userGuestNumRange?: Array<number> //在线会员数范围
  accessCount?: number //访问计数
  accessCountRange?: Array<number> //访问计数范围
  jvmMemMax?: number //jvm内存总数
  jvmMemMaxRange?: Array<number> //jvm内存总数范围
  jvmMemTotal?: number //jvm内存总数
  jvmMemTotalRange?: Array<number> //jvm内存总数范围
  jvmMemFree?: number //jvm空闲内存
  jvmMemFreeRange?: Array<number> //jvm空闲内存范围
  threadActive?: number //活跃线程
  threadActiveRange?: Array<number> //活跃线程范围
  threadPeak?: number //峰值线程
  threadPeakRange?: Array<number> //峰值线程范围
  threadDaemon?: number //守护线程
  threadDaemonRange?: Array<number> //守护线程范围
  threadStarted?: number //累计启动线程
  threadStartedRange?: Array<number> //累计启动线程范围
  createDateRange?: Array<string> //创建时间范围
  modifyDateRange?: Array<string> //修改时间范围
  lastUpdateRange?: Array<string> //最后更新时间范围
  state?: number //应用状态1: 上线; 0: 下线 -1:删除
  states?: Array<number> //应用状态1: 上线; 0: 下线 -1:删除数组
  stateGte?: number //大于等于应用状态1: 上线; 0: 下线 -1:删除
  stateLte?: number //小于等于应用状态1: 上线; 0: 下线 -1:删除
  $pg?: number //当前页码
  $rn?: number //每页条数
  $si?: number //起始位置
  $rt?: number //请求类型
  $sn?: Array<string> //排序名称
  $st?: Array<number> //排序类型
}
//MSC应用列表查询参数
export interface MscAppQueryParam {
  id?: number //主键
  ids?: Array<number> //ID数组
  appName?: string //应用名称
  appLabel?: string //应用显示名称
  appVersion?: string //应用版本
  appRank?: number //应用显示顺序
  appRankRange?: Array<number> //应用显示顺序范围
  remark?: string //备注
  permNum?: number //权限数量
  permNumRange?: Array<number> //权限数量范围
  runHost?: number //运行主机数量
  runHostRange?: Array<number> //运行主机数量范围
  runThread?: number //运行线程数
  runThreadRange?: Array<number> //运行线程数范围
  runMem?: number //运行内存数
  runMemRange?: Array<number> //运行内存数范围
  runUser?: number //运行用户数
  runUserRange?: Array<number> //运行用户数范围
  runAccess?: number //运行访问数
  runAccessRange?: Array<number> //运行访问数范围
  createDateRange?: Array<string> //创建时间范围
  modifyDateRange?: Array<string> //修改时间范围
  lastUpdateRange?: Array<string> //最后更新时间范围
  displayState?: number //是否显示0不显示 1显示 2 VIP
  state?: number //应用状态1: 上线; 0: 下线 -1:删除
  states?: Array<number> //应用状态1: 上线; 0: 下线 -1:删除数组
  stateGte?: number //大于等于应用状态1: 上线; 0: 下线 -1:删除
  stateLte?: number //小于等于应用状态1: 上线; 0: 下线 -1:删除
  $pg?: number //当前页码
  $rn?: number //每页条数
  $si?: number //起始位置
  $rt?: number //请求类型
  $sn?: Array<string> //排序名称
  $st?: Array<number> //排序类型
}
//MSC实时在线数据
export interface MscLiveInfo {
  onlineToken?: number //在线Token数
  logonToken?: number //登录Token数
  invalidateToken?: number //失效Token数
  mfaLimitNum?: number //MFA信息数
}
//用户登录日志查询参数
export interface MscLoginLogEsQueryParam {
  mchId?: number //商户ID
  userId?: number //用户id
  userType?: number //用户类型
  appInfo?: string //App信息
  appHost?: string //App主机
  loginAgent?: string //登录代理
  loginType?: number //登录类型
  loginId?: string //登录标识
  groupId?: number //用户组ID
  userName?: string //用户名
  nickName?: string //用户昵称
  realName?: string //真实名称
  userIp?: string //操作人ip
  responseState?: string //响应状态
  responseCode?: string //响应代码
  responseMillisRange?: Array<number> //请求毫秒数范围
  loginDateRange?: Array<string> //登录时间范围
  $pg?: number //当前页码
  $rn?: number //每页条数
  $si?: number //起始位置
  $rt?: number //请求类型
  $sn?: Array<string> //排序名称
  $st?: Array<number> //排序类型
}
//用户登录ES日志
export interface MscLoginEsLog {
  appInfo?: string //App信息
  appHost?: string //App主机
  loginAgent?: string //登录客户端
  loginType?: number //登录类型
  loginId?: string //登录标识
  userId?: number //用户Id
  userName?: string //用户信息
  nickName?: string //昵称信息
  realName?: string //真实姓名
  saasId?: number //运营商Id
  mchId?: number //商户Id
  groupId?: number //用户组Id
  userType?: number //用户类型
  userIp?: string //登录IP
  clientType?: number //登录设备
  clientAgent?: string //用户代理
  responseState?: string //响应状态
  responseCode?: string //响应代码
  responseMsg?: string //响应消息
  loginDate?: string //登录时间
  responseMillis?: number //响应毫秒数
}
//访客登录日志查询参数
export interface MscGuestLoginEsLogQueryParam {
  mchId?: number //商户ID
  userId?: number //用户id
  userType?: number //用户类型
  appInfo?: string //App信息
  appHost?: string //App主机
  loginAgent?: string //登录代理
  loginType?: number //登录类型
  loginId?: string //登录标识
  groupId?: number //用户组ID
  userName?: string //用户名
  nickName?: string //用户昵称
  realName?: string //真实名称
  userIp?: string //操作人ip
  responseState?: string //响应状态
  responseCode?: string //响应代码
  responseMillisRange?: Array<number> //请求毫秒数范围
  loginDateRange?: Array<string> //登录时间范围
  $pg?: number //当前页码
  $rn?: number //每页条数
  $si?: number //起始位置
  $rt?: number //请求类型
  $sn?: Array<string> //排序名称
  $st?: Array<number> //排序类型
}
//用户登录ES日志
export interface MscGuestLoginEsLog {
  appInfo?: string //App信息
  appHost?: string //App主机
  loginAgent?: string //登录客户端
  loginType?: number //登录类型
  loginId?: string //登录标识
  userId?: number //用户Id
  userName?: string //用户信息
  nickName?: string //昵称信息
  realName?: string //真实姓名
  saasId?: number //运营商Id
  mchId?: number //商户Id
  groupId?: number //用户组Id
  userType?: number //用户类型
  userIp?: string //登录IP
  clientType?: number //登录设备
  clientAgent?: string //用户代理
  responseState?: string //响应状态
  responseCode?: string //响应代码
  responseMsg?: string //响应消息
  loginDate?: string //登录时间
  responseMillis?: number //响应毫秒数
}
//用户操作日志查询参数
export interface MscActionEsLogQueryParam {
  mchId?: number //商户ID
  userId?: number //用户id
  userType?: number //用户类型
  appInfo?: string //应用信息
  appHost?: string //应用主机
  groupId?: number //用户组ID
  userName?: string //用户名
  nickName?: string //用户昵称
  realName?: string //真实名称
  userIp?: string //操作人ip
  bizType?: string //操作对象类型
  bizId?: string //操作对象id
  apiUri?: string //请求uri
  apiName?: string //API名称
  responseState?: string //响应状态
  responseCode?: string //响应代码
  responseMillisRange?: Array<number> //请求毫秒数范围
  statusCode?: number //响应状态码
  statusCodeRange?: Array<number> //响应状态码范围
  requestDateRange?: Array<string> //创建时间范围
  $pg?: number //当前页码
  $rn?: number //每页条数
  $si?: number //起始位置
  $rt?: number //请求类型
  $sn?: Array<string> //排序名称
  $st?: Array<number> //排序类型
}
//用户操作ES日志
export interface MscActionEsLog {
  appInfo?: string //App信息
  appHost?: string //App主机
  saasId?: number //运营商Id
  mchId?: number //商户Id
  userId?: number //用户Id
  userType?: number //用户类型
  groupId?: number //用户组Id
  userName?: string //用户信息
  nickName?: string //昵称信息
  realName?: string //真实姓名
  userIp?: string //用户IP
  apiUri?: string //API URI
  apiName?: string //API名称
  bizType?: string //业务类型
  bizId?: any //业务Id
  bizLog?: string //业务日志
  requestBody?: string //请求参数
  requestDate?: string //请求时间
  responseBody?: string //响应日志
  responseState?: string //响应状态
  responseCode?: string //响应代码
  responseMsg?: string //响应消息
  responseMillis?: number //执行返回毫秒数
  statusCode?: number //响应状态码
}
//MSC日统计信息列表查询参数
export interface MscStatsQueryParam {
  id?: number //id
  ids?: Array<number> //ID数组
  reporterInfo?: string //报告者信息
  statsDateRange?: Array<string> //创建日期范围
  mscApp?: number //msc_app数量
  mscAppRange?: Array<number> //msc_app数量范围
  mscPerm?: number //msc_perm数量
  mscPermRange?: Array<number> //msc_perm数量范围
  allSaas?: number //saas数量
  allSaasRange?: Array<number> //saas数量范围
  allGroup?: number //用户组数量
  allGroupRange?: Array<number> //用户组数量范围
  allUser?: number //用户数量
  allUserRange?: Array<number> //用户数量范围
  userRoot?: number //root用户数量
  userRootRange?: Array<number> //root用户数量范围
  userAdmin?: number //管理员用户数量
  userAdminRange?: Array<number> //管理员用户数量范围
  userRpc?: number //rpc用户数量
  userRpcRange?: Array<number> //rpc用户数量范围
  userOps?: number //ops用户数量
  userOpsRange?: Array<number> //ops用户数量范围
  userSaas?: number //saas用户数量
  userSaasRange?: Array<number> //saas用户数量范围
  userMch?: number //saas商户数量
  userMchRange?: Array<number> //saas商户数量范围
  userActiveMax?: number //活跃用户峰值
  userActiveMaxRange?: Array<number> //活跃用户峰值范围
  userLogonMax?: number //登录用户峰值
  userLogonMaxRange?: Array<number> //登录用户峰值范围
  invalidTokenMax?: number //非法token峰值
  loginLimitMax?: number //登录峰值指数
  loginLimitMaxRange?: Array<number> //登录峰值指数范围
  logActionSuccess?: number //用户操作错误计数
  logActionSuccessRange?: Array<number> //用户操作错误计数范围
  logActionFail?: number //用户操作错误计数
  logActionFailRange?: Array<number> //用户操作错误计数范围
  loginSuccess?: number //登录成功
  loginSuccessRange?: Array<number> //登录成功范围
  loginFail?: number //登录失败
  loginFailRange?: Array<number> //登录失败范围
  loginCaptcha?: number //captcha计数
  loginCaptchaRange?: Array<number> //captcha计数范围
  loginCaptchaSuccess?: number //captcha成功
  loginCaptchaSuccessRange?: Array<number> //captcha成功范围
  loginCaptchaFail?: number //captcha失败
  loginCaptchaFailRange?: Array<number> //captcha失败范围
  loginCode?: number //验证码
  loginCodeRange?: Array<number> //验证码范围
  loginCodeSuccess?: number //验证码成功
  loginCodeSuccessRange?: Array<number> //验证码成功范围
  loginCodeFail?: number //验证码失败
  loginCodeFailRange?: Array<number> //验证码失败范围
  tokenRefreshSuccess?: number //刷新成功
  tokenRefreshSuccessRange?: Array<number> //刷新成功范围
  tokenRefreshFail?: number //刷新失败
  tokenRefreshFailRange?: Array<number> //刷新失败范围
  tokenLogout?: number //登出
  tokenLogoutRange?: Array<number> //登出范围
  tokenDouble?: number //双登
  tokenDoubleRange?: Array<number> //双登范围
  tokenKickout?: number //踢出
  tokenKickoutRange?: Array<number> //踢出范围
  guestLoginSuccess?: number //客户登录成功
  guestLoginSuccessRange?: Array<number> //客户登录成功范围
  guestLoginFail?: number //客户登录错误数
  guestLoginFailRange?: Array<number> //客户登录错误数范围
  guestRefreshSuccess?: number //客户刷新成功
  guestRefreshSuccessRange?: Array<number> //客户刷新成功范围
  guestRefreshFail?: number //客户刷新失败
  guestRefreshFailRange?: Array<number> //客户刷新失败范围
  guestLogout?: number //客户登出
  guestLogoutRange?: Array<number> //客户登出范围
  guestDouble?: number //客户双登
  guestDoubleRange?: Array<number> //客户双登范围
  guestKickout?: number //客户踢出
  guestKickoutRange?: Array<number> //客户踢出范围
  newSaas?: number //新增saas
  newSaasRange?: Array<number> //新增saas范围
  newGroup?: number //新增组
  newGroupRange?: Array<number> //新增组范围
  newUser?: number //新增用户
  newUserRange?: Array<number> //新增用户范围
  runApp?: number //运行应用数
  runAppRange?: Array<number> //运行应用数范围
  runHost?: number //运行主机数
  runHostRange?: Array<number> //运行主机数范围
  runThread?: number //运行线程数
  runThreadRange?: Array<number> //运行线程数范围
  runMem?: number //运行内存数
  runMemRange?: Array<number> //运行内存数范围
  runUser?: number //运行用户数
  runUserRange?: Array<number> //运行用户数范围
  runAccess?: number //主机访问数
  runAccessRange?: Array<number> //主机访问数范围
  $pg?: number //当前页码
  $rn?: number //每页条数
  $si?: number //起始位置
  $rt?: number //请求类型
  $sn?: Array<string> //排序名称
  $st?: Array<number> //排序类型
}
//MSC日统计信息
export interface MscStats {
  id?: number //id
  reporterInfo?: string //报告者信息
  statsDate?: string //创建日期
  mscApp?: number //msc_app数量
  mscPerm?: number //msc_perm数量
  allSaas?: number //saas数量
  allGroup?: number //用户组数量
  allUser?: number //用户数量
  userRoot?: number //root用户数量
  userAdmin?: number //管理员用户数量
  userRpc?: number //rpc用户数量
  userOps?: number //ops用户数量
  userSaas?: number //saas用户数量
  userMch?: number //saas商户数量
  userActiveMax?: number //活跃用户峰值
  userLogonMax?: number //登录用户峰值
  invalidTokenMax?: number //非法token峰值
  loginLimitMax?: number //登录峰值指数
  logActionSuccess?: number //用户操作错误计数
  logActionFail?: number //用户操作错误计数
  loginSuccess?: number //登录成功
  loginFail?: number //登录失败
  loginCaptcha?: number //captcha计数
  loginCaptchaSuccess?: number //captcha成功
  loginCaptchaFail?: number //captcha失败
  loginCode?: number //验证码
  loginCodeSuccess?: number //验证码成功
  loginCodeFail?: number //验证码失败
  tokenRefreshSuccess?: number //刷新成功
  tokenRefreshFail?: number //刷新失败
  tokenLogout?: number //登出
  tokenDouble?: number //双登
  tokenKickout?: number //踢出
  guestLoginSuccess?: number //客户登录成功
  guestLoginFail?: number //客户登录错误数
  guestRefreshSuccess?: number //客户刷新成功
  guestRefreshFail?: number //客户刷新失败
  guestLogout?: number //客户登出
  guestDouble?: number //客户双登
  guestKickout?: number //客户踢出
  newSaas?: number //新增saas
  newGroup?: number //新增组
  newUser?: number //新增用户
  runApp?: number //运行应用数
  runHost?: number //运行主机数
  runThread?: number //运行线程数
  runMem?: number //运行内存数
  runUser?: number //运行用户数
  runAccess?: number //主机访问数
}
//MSC实时指标信息列表查询参数
export interface MscMetricsQueryParam {
  id?: number //id
  ids?: Array<number> //ID数组
  statsDateRange?: Array<string> //创建日期范围
  loginLimit?: number //登录峰值指数
  loginLimitRange?: Array<number> //登录峰值指数范围
  userActive?: number //在线用户峰值
  userActiveRange?: Array<number> //在线用户峰值范围
  userLogon?: number //登录用户峰值
  userLogonRange?: Array<number> //登录用户峰值范围
  invalidToken?: number //非法token峰值
  loginSuccess?: number //登录成功
  loginSuccessRange?: Array<number> //登录成功范围
  loginFail?: number //登录失败
  loginFailRange?: Array<number> //登录失败范围
  loginCaptcha?: number //captcha计数
  loginCaptchaRange?: Array<number> //captcha计数范围
  loginCaptchaSuccess?: number //captcha成功
  loginCaptchaSuccessRange?: Array<number> //captcha成功范围
  loginCaptchaFail?: number //captcha失败
  loginCaptchaFailRange?: Array<number> //captcha失败范围
  loginCode?: number //验证码
  loginCodeRange?: Array<number> //验证码范围
  loginCodeSuccess?: number //验证码成功
  loginCodeSuccessRange?: Array<number> //验证码成功范围
  loginCodeFail?: number //验证码失败
  loginCodeFailRange?: Array<number> //验证码失败范围
  tokenRefreshSuccess?: number //刷新成功
  tokenRefreshSuccessRange?: Array<number> //刷新成功范围
  tokenRefreshFail?: number //刷新失败
  tokenRefreshFailRange?: Array<number> //刷新失败范围
  tokenLogout?: number //登出
  tokenLogoutRange?: Array<number> //登出范围
  tokenDouble?: number //双登
  tokenDoubleRange?: Array<number> //双登范围
  tokenKickout?: number //踢出
  tokenKickoutRange?: Array<number> //踢出范围
  guestLoginSuccess?: number //客户登录成功
  guestLoginSuccessRange?: Array<number> //客户登录成功范围
  guestLoginFail?: number //客户登录错误
  guestLoginFailRange?: Array<number> //客户登录错误范围
  guestRefreshSuccess?: number //客户刷新成功
  guestRefreshSuccessRange?: Array<number> //客户刷新成功范围
  guestRefreshFail?: number //客户刷新失败
  guestRefreshFailRange?: Array<number> //客户刷新失败范围
  guestLogout?: number //客户登出
  guestLogoutRange?: Array<number> //客户登出范围
  guestDouble?: number //客户双登
  guestDoubleRange?: Array<number> //客户双登范围
  guestKickout?: number //客户踢出
  guestKickoutRange?: Array<number> //客户踢出范围
  newSaas?: number //新增saas
  newSaasRange?: Array<number> //新增saas范围
  newGroup?: number //新增组
  newGroupRange?: Array<number> //新增组范围
  newUser?: number //新增用户
  newUserRange?: Array<number> //新增用户范围
  runApp?: number //运行应用数
  runAppRange?: Array<number> //运行应用数范围
  runHost?: number //运行主机数
  runHostRange?: Array<number> //运行主机数范围
  runThread?: number //运行线程数
  runThreadRange?: Array<number> //运行线程数范围
  runMem?: number //运行内存数
  runMemRange?: Array<number> //运行内存数范围
  runUser?: number //运行用户数
  runUserRange?: Array<number> //运行用户数范围
  runAccess?: number //主机访问数
  runAccessRange?: Array<number> //主机访问数范围
  $pg?: number //当前页码
  $rn?: number //每页条数
  $si?: number //起始位置
  $rt?: number //请求类型
  $sn?: Array<string> //排序名称
  $st?: Array<number> //排序类型
}
//MSC实时指标信息
export interface MscMetrics {
  id?: number //id
  statsDate?: string //创建日期
  loginLimit?: number //登录峰值指数
  userActive?: number //在线用户峰值
  userLogon?: number //登录用户峰值
  invalidToken?: number //非法token峰值
  loginSuccess?: number //登录成功
  loginFail?: number //登录失败
  loginCaptcha?: number //captcha计数
  loginCaptchaSuccess?: number //captcha成功
  loginCaptchaFail?: number //captcha失败
  loginCode?: number //验证码
  loginCodeSuccess?: number //验证码成功
  loginCodeFail?: number //验证码失败
  tokenRefreshSuccess?: number //刷新成功
  tokenRefreshFail?: number //刷新失败
  tokenLogout?: number //登出
  tokenDouble?: number //双登
  tokenKickout?: number //踢出
  guestLoginSuccess?: number //客户登录成功
  guestLoginFail?: number //客户登录错误
  guestRefreshSuccess?: number //客户刷新成功
  guestRefreshFail?: number //客户刷新失败
  guestLogout?: number //客户登出
  guestDouble?: number //客户双登
  guestKickout?: number //客户踢出
  newSaas?: number //新增saas
  newGroup?: number //新增组
  newUser?: number //新增用户
  runApp?: number //运行应用数
  runHost?: number //运行主机数
  runThread?: number //运行线程数
  runMem?: number //运行内存数
  runUser?: number //运行用户数
  runAccess?: number //主机访问数
}
