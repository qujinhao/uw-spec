<script setup lang="ts">
import {
  guestOrderInfoChangeApply,
  type OrderChangeRequest,
  type OrderInfo
} from '@/api/saasMallAppGuestApi'
import dummy from '@/static/images/dummy.png'
import { useI18n } from 'vue-i18n'
import { formatPrice, isJSON, getProductSingleImg } from '@/utils/tool'
import { useCommonSelectTypes } from '@/utils/enumeration'
import dayjs from 'dayjs'
import { computed } from 'vue'
// import { TypeSku } from '@/config/EnumConst'

const props = defineProps<{
  item: OrderInfo // 订单信息
}>()

const emits = defineEmits<{
  (e: 'clickPay'): void
  (e: 'getOrderList'): void
}>()

const { t } = useI18n()
const { handleTypeForLabel, StateOrderOptions } = useCommonSelectTypes()

// 解析orderInfo的字段 前端DIY存储 list展示
const getInfo = (): any => {
  const orderInfo = props.item?.orderInfo || ''
  let obj = {} as any
  if (isJSON(orderInfo)) {
    obj = JSON.parse(orderInfo)
  }
  return obj
}

// 是否为产品类型
// const isProductType = computed(() => {
//   return getInfo().skuType === TypeSku.PRODUCT
// })
// // 是否为场次类型
// const isSessionType = computed(() => {
//   return getInfo().skuType === TypeSku.SESSION
// })
// // 是否为规格类型
// const isSpecType = computed(() => {
//   return getInfo().skuType === TypeSku.SPEC
// })

// 订单规格列表数据
const specInfoList = computed<any[]>(() => {
  if (!getInfo().specInfoList?.length) return []
  return getInfo().specInfoList
})

// 规格整合名称
const specInfoName = computed(() => {
  if (specInfoList.value?.length) {
    const specItems =
      specInfoList.value?.map(
        (item) => `${item.specName} * ${item.purchaseNum}`
      ) || []

    return specItems.join(' + ')
  }
  return ''
})

// 游玩日期
// const travelDate = computed(() => {
//   let date = ''
//   if (getInfo().travelDate) {
//     date = dayjs(getInfo().travelDate).format('YYYY-MM-DD')
//   }
//   return date
// })
// 游玩结束日期
const travelEndDate = computed(() => {
  let date = ''
  if (getInfo().travelEndDate) {
    date = dayjs(getInfo().travelEndDate).format('YYYY-MM-DD')
  }
  return date
})

// 取消订单
const handleOrderCancel = (item: OrderInfo) => {
  uni.showModal({
    title: '提示',
    content: '',
    placeholderText: '请输入取消订单原因',
    editable: true,
    success: async function (modalRes) {
      console.log('modalRes', modalRes)
      if (modalRes.confirm) {
        const data: OrderChangeRequest = {
          orderId: item.id, //订单ID
          cancelVoucherIds: '', //取消code(票码id:取消数量),多个用,分开
          applyType: 0, //申请类型1修改 0 取消
          // @ts-ignore
          applyInfo: modalRes.content //申请理由
        }
        console.log('用户点击确定', data)
        const res = await guestOrderInfoChangeApply(data)
        if (res.state === 'success') {
          uni.showToast({
            icon: 'none',
            title: '订单取消成功'
          })
          emits('getOrderList')
        } else {
          uni.showToast({
            icon: 'none',
            title: res.msg
          })
        }
      } else if (modalRes.cancel) {
        console.log('用户点击取消')
      }
    }
  })
}
</script>

<template>
  <div
    class="orderItem flex flex-col gap-[20rpx] rounded-[30rpx] bg-white shadow-[0_2px_10px_0_rgba(0,0,0,0.1)]"
  >
    <!-- {{ specInfoList }}  -->
    <!-- {{ props.item }} -->
    <div class="flex flex-col gap-[20rpx] p-[18rpx_30rpx]">
      <div class="flex items-center justify-between">
        <div class="text-[#01060C] text-[30rpx] truncate whitespace-nowrap">
          {{ '美豪麗致酒店（廣州東站天河體育中心店）-高级双床房' }}
        </div>
        <div
          class="text-gray-500 text-[28rpx] shrink-0"
          :class="{
            'FF6100 text-[#FF6100]': props.item.state === 1,
            '199FB3 text-[#199FB3]': props.item.state === 1,
            '0078F6 text-[#0078F6]': props.item.state === 1
          }"
        >
          {{ handleTypeForLabel(props.item?.orderState!, StateOrderOptions) }}
        </div>
      </div>

      <div class="flex justify-between gap-[20rpx]">
        <div
          class="flex shrink-0 w-[160rpx] h-[160rpx] border border-gray-300 rounded-2xl overflow-hidden"
        >
          <img
            class="w-full h-full"
            :src="getProductSingleImg(getInfo()?.productImg) || dummy"
          />
        </div>

        <div class="w-full flex justify-between">
          <div class="flex flex-col">
            <div>{{ '2025-10-10' }}</div>
            <div v-if="travelEndDate">-{{ travelEndDate }}</div>
            <div class="flex">{{ specInfoName }}</div>
            <!-- <div class="flex">张数：{{ getInfo()?.buyNum }}</div> -->
          </div>

          <div class="flex items-center">
            <div class="text-[#01060C] font-bold">
              {{ t('CNY') }}
              <span class="">
                {{ formatPrice(props.item?.orderMoney as number) }}
              </span>
            </div>
          </div>
        </div>
      </div>

      <template v-if="true">
        <div class="div-line"></div>
        <div class="flex gap-[30rpx] justify-end">
          <div
            class="order-btn-item"
            @click.stop="handleOrderCancel(props.item)"
          >
            取消
          </div>
          <div
            class="order-btn-item pay"
            @click.stop="emits('clickPay')"
          >
            支付
          </div>
        </div>
      </template>
    </div>
  </div>
</template>

<style lang="scss" scoped>
// .orderItem {
//   //
// }
</style>
