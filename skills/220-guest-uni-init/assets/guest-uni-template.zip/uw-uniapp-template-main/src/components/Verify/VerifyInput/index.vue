<script lang="ts" setup>
import { ref, onMounted, computed } from 'vue'
import defaultImg from '../default.jpg'
import { useI18n } from 'vue-i18n'
import type { CaptchaQuestion } from '@/api/authUwAuthCenterApiAuth'

const { t } = useI18n()

const props = withDefaults(
  defineProps<{
    imgSize?: Record<string, string>
    resPonCaptcha?: CaptchaQuestion
  }>(),
  {
    imgSize: () => {
      return {
        width: '360px',
        height: '140px'
      }
    }
  }
)

const emits = defineEmits<{
  (e: 'refresh'): void
  (e: 'getCaptchaSign', item: { answerData: string; opTime: number }): void
}>()

// 效验图形码值
const verifyVal = ref('')

const startVerifyTime = ref(0)
const endVerifyTime = ref(0)

const opTime = computed(() => {
  return endVerifyTime.value - startVerifyTime.value
})

// 效验验证码
const handleCheckCaptcha = () => {
  if (!verifyVal.value) {
    uni.showToast({
      icon: 'none',
      title: t('pleaseInputImgCode')
    })
    return
  }

  endVerifyTime.value = Date.now()
  emits('getCaptchaSign', {
    answerData: verifyVal.value,
    opTime: opTime.value
  })
}

/**
 * 成功回调
 */
const verifySuccessCb = () => {
  // debugger
  verifyVal.value = ''
}

/**
 * 失败回调
 */
const verifyErrorCb = () => {
  // debugger
  verifyVal.value = ''
}

/**
 * 恢复初始变量
 */
const initVerifyData = () => {
  verifyVal.value = ''
}

/**
 * 刷新人机验证码
 */
const handleRefresh = () => {
  verifyVal.value = ''
  emits('refresh')
}

/**
 * 输入框值改变
 */
const handleInputChange = () => {
  if (verifyVal.value.length === 1) {
    startVerifyTime.value = Date.now()
  }
}

onMounted(() => {
  // console.log('verifyInput Com ---')
})
defineExpose({
  verifySuccessCb,
  verifyErrorCb,
  initVerifyData
})
</script>

<template>
  <div class="flex flex-col items-center justify-center">
    <div class="verify-img-out">
      <div
        class="verify-img-panel"
        :style="{ width: imgSize.width, height: imgSize.height }"
      >
        <image
          :src="
            props.resPonCaptcha?.mainImageBase64
              ? 'data:image/png;base64,' + props.resPonCaptcha?.mainImageBase64
              : defaultImg
          "
          alt=""
          style="width: 100%; height: 100%; display: block"
        ></image>
        <div
          class="verify-refresh"
          @click="handleRefresh()"
        >
          <span class="iconfont icon-refresh"></span>
        </div>
      </div>
    </div>
    <div
      v-if="props.resPonCaptcha?.mainImageBase64"
      class="verify-input-panel flex"
      :style="{ width: imgSize.width, 'margin-top': '10rpx' }"
    >
      <input
        class="verify-input flex-1"
        type="text"
        v-model="verifyVal"
        :placeholder="t('ImgCode')"
        placeholderStyle="color: #c0c4cc"
        @input="handleInputChange"
      />
      <div
        class="verify-btn"
        :class="{ disabled: !verifyVal }"
        @click="handleCheckCaptcha()"
      >
        {{ t('submit') }}
      </div>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.verify-img-panel {
  margin: 0;
  box-sizing: content-box;
  border-radius: 3px;
  position: relative;
}
.verify-input-panel {
  display: flex;
  gap: 10rpx;
  .verify-input {
    height: 40px;
    line-height: 40px;
    border: 1px solid #f2f3f5;
    border-radius: 10px;
    padding: 0 16px;
    &::placeholder {
      color: #c0c4cc; // 你想换的颜色
      font-size: 28rpx;
    }
    /* 兼容小程序 */
    &::-webkit-input-placeholder {
      color: #c0c4cc;
    }
  }
  .verify-btn {
    color: #ffffff;
    // background-color: $uni-color-primary;
    // border: 1px solid $uni-color-primary;
    background-color: #f58c1c;
    border: 1px solid #f58c1c;
    height: 40px;
    line-height: 40px;
    border-radius: 10px;
    padding: 0 10px;
    text-align: center;
    &.disabled {
      pointer-events: none;
      border: 1px solid #f2f3f5;
      background-color: #f5f5f5;
      color: #999999;
    }
  }
}
</style>
