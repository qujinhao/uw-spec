export interface PropsType {
  attrs: {
    historyData: Array<string>
  }
  styles: {
    cmpRadius: number // 容器圆角
    imgRadius: number // 图片圆角
    pagePadding: number // 左右边距
    cmpUpperPadding: number //	上边距
    cmpLowerPadding: number //	下边距
    cmpBackground: string // 背景色
  }
  // 字段替换
  listField?: {
    viewId?: string // 显示的id字段
    viewName?: string // 显示名称
  }
  list: Record<string, string>[]
}

export interface RecommendItemType {
  viewId?: string
  viewName?: string
}
