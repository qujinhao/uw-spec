<template>
  <!-- 魔方组件 -->
  <view :style="[wrapStyle(styles)]">
    <view
      class="cap-cube-wrap"
      :style="[getWrapStyle()]"
    >
      <view
        v-for="(item, index) in mergedAttrs.list"
        :key="index"
        class="absolute cap-cube-item"
        :style="[getMainStyle(item)]"
      >
        <view
          class="cap-cube-item-wrap"
          :style="[getItemStyle()]"
        >
          <img
            class="cap-cube-img"
            mode="aspectFill"
            :src="item.image"
            lazy-load
            @click="jump(item.jump)"
          />
          <!-- <image
            class="cap-cube-img"
            mode="aspectFill"
            :src="item.image"
            @click="jump(item.jump)"
          /> -->
        </view>
      </view>
    </view>
  </view>
</template>

<script lang="ts" setup>
import { computed, type StyleValue } from 'vue'
import { wrapStyle, cmpStyle, unit } from '../utils/registerBaseStyle'
import type { Attrs, Styles, JumpType } from './type'
// import type { StyleValue } from 'vue'

const props = withDefaults(
  defineProps<{
    attrs: Partial<Attrs>
    styles: Partial<Styles>
  }>(),
  {
    attrs: () => ({}),
    styles: () => ({})
  }
)
const mergedAttrs = computed(() => ({
  model: 'custom', // 模板类型
  row: 3, // 行数
  list: [], // 方格数据
  ...props.attrs
}))

const mergedStyles = computed(() => ({
  pagePadding: 0,
  cmpRadius: 0,
  imgMargin: 0,
  imgRadius: 0,
  cmpBackground: '',
  ...props.styles
}))
const emit = defineEmits<{
  jump: [item: JumpType]
}>()
// 单元块尺度
const itemUnit = computed(() => {
  return (375 - mergedStyles.value.pagePadding * 2) / 6
})
// 容器宽度
const wrapHeight = computed(() => {
  return mergedAttrs.value.row * itemUnit.value
})
// 单项间距
const margin = computed(() => {
  return mergedStyles.value.imgMargin
})

// 容器样式
const getWrapStyle = () => {
  const result: StyleValue = {}

  if (mergedAttrs.value.list && mergedAttrs.value.list.length > 0) {
    result.height = unit(wrapHeight.value)
  } else {
    result.backgroundImage =
      "url('http://qnimg.zowoyoo.com/img/84826/1715237104041.png')"
    result.backgroundSize = '100% 100%'
    result.height = unit(190)
  }

  return {
    ...cmpStyle(mergedStyles.value),
    ...result
  }
}

// 主体样式
const getMainStyle = (styles: any) => {
  const result: StyleValue = {}

  Object.keys(styles).forEach((key) => {
    const tmep = styles[key] * itemUnit.value

    switch (key) {
      case 'top': {
        result.paddingTop = unit(tmep === 0 ? margin.value : margin.value / 2)
        break
      }

      case 'left': {
        result.paddingLeft = unit(tmep === 0 ? margin.value : margin.value / 2)
        break
      }

      case 'bottom': {
        result.paddingBottom = unit(
          tmep === wrapHeight.value ? margin.value : margin.value / 2
        )
        break
      }

      case 'right': {
        result.paddingRight = unit(
          tmep === 375 - mergedStyles.value.pagePadding * 2
            ? margin.value
            : margin.value / 2
        )
        break
      }
    }
    result[key as any] = unit(tmep)
  })

  return result
}

// 单项容器样式
const getItemStyle = () => {
  return {
    borderRadius: unit(mergedStyles.value.imgRadius)
  }
}
const jump = (item?: JumpType) => {
  if (!item) return
  emit('jump', item)
}
</script>

<style lang="scss" scoped>
.cap-cube-wrap {
  overflow: hidden;
  position: relative;

  .absolute {
    position: absolute !important;
  }

  .cap-cube-item {
    display: flex;

    .cap-cube-item-wrap {
      width: 100%;
      height: 100%;
      overflow: hidden;

      .cap-cube-img {
        width: 100%;
        height: 100%;
      }
    }
  }
}
</style>
