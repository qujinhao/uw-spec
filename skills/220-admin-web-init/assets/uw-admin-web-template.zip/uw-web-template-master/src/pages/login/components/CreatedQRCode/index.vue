<script lang="ts" setup>
const props = withDefaults(
  defineProps<{
    url: string
    width?: string | number
    height?: string | number
  }>(),
  {
    width: 100,
    height: 100
  }
)

const imgWidth = computed(() => {
  if (typeof props.width === 'number') {
    return props.width + 'px'
  }
  return props.width
})

const imgHeight = computed(() => {
  if (typeof props.height === 'number') {
    return props.height + 'px'
  }
  return props.height
})

const qrcode = ref('')
watch(
  () => props.url,
  val => {
    if (val) {
      qrcode.value = `data:image/png;base64,${val}`
    }
  },
  {
    immediate: true
  }
)
</script>

<template>
  <div>
    <img
      v-if="props.url"
      :src="qrcode"
      alt="QR Code"
      :style="{ width: imgWidth, height: imgHeight }"
    />
  </div>
</template>

<style scope lang="scss"></style>
