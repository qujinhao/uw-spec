<template>
  <!-- 数字步进器 - 未开发 -->
  <view class="number-controller">
    <button
      @click="decrease"
      :disabled="inputValue <= min"
    >
      <text>-</text>
    </button>
    <input
      type="number"
      v-model="inputValue"
      @input="onInput"
      @blur="onBlur"
    />
    <button
      @click="increase"
      :disabled="inputValue >= max"
    >
      +
    </button>
  </view>
</template>

<script setup>
import { ref, watch } from 'vue'

const props = defineProps({
  modelValue: {
    type: Number,
    required: true
  },
  min: {
    type: Number,
    default: -Infinity
  },
  max: {
    type: Number,
    default: Infinity
  },
  step: {
    type: Number,
    default: 1
  }
})

const emit = defineEmits(['update:modelValue'])

// 值
const inputValue = ref(props.modelValue)

// 监听
watch(
  () => props.modelValue,
  (newVal) => {
    inputValue.value = newVal
  }
)

// 减少事件
const decrease = () => {
  if (inputValue.value > props.min) {
    const newValue = inputValue.value - props.step
    emit('update:modelValue', newValue)
  }
}

// 增加事件
const increase = () => {
  if (inputValue.value < props.max) {
    const newValue = inputValue.value + props.step
    emit('update:modelValue', newValue)
  }
}

// 输入
const onInput = (e) => {
  let newValue = Number(e.target.value)

  if (newValue < props.min) {
    newValue = props.min
  } else if (newValue > props.max) {
    newValue = props.max
  }

  emit('update:modelValue', newValue)
}

// 失去焦点
const onBlur = () => {
  if (inputValue.value < props.min) {
    emit('update:modelValue', props.min)
  } else if (inputValue.value > props.max) {
    emit('update:modelValue', props.max)
  }
}
</script>

<style scoped>
.number-controller {
  display: flex;
  align-items: center;
}

button {
  width: 32px;
  height: 32px;
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: #f2f3f5;
  border: 1px solid #f2f3f5;
  border-radius: 4px;
  cursor: pointer;
}

button:disabled {
  cursor: not-allowed;
  color: #717272;
}

input {
  width: 60px;
  height: 32px;
  text-align: center;
  border: 1px solid #ccc;
  margin: 0 2px;
  border-radius: 4px;
}
</style>
