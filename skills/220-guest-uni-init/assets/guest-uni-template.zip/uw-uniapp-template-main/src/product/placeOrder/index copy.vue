<!-- 下单页 -->
<script lang="ts" setup>
import { reactive, ref, computed } from 'vue'
import { onLoad } from '@dcloudio/uni-app'

import ZBottomBtn from './components/ZBottomBtn/index.vue'
import {
  guestOrderInfoSave,
  type OrderRequest,
  type OrderGuestRequest
} from '@/api/saasMallAppGuestApi'
import { navToUrl, parseTime } from '@/utils/tool'

const state = reactive({
  num: 1,
  btnLoading: false
})
const orderData = ref()
const orderParams = ref<OrderRequest>({})
const orderGuestRequestsList = ref<OrderGuestRequest[]>([
  {
    guestName: '王小明',
    guestMobile: '13000000000'
  }
])

const priceTotal = computed(() => {
  return state.num * orderData.value?.priceSale
})

const numberChange = (data: any) => {
  state.num = data.value
}

// const handleGuestOrderInfoSave = async () => {
//   const res = await guestOrderInfoSave({
//     // saasId: 111, //运营商ID
//     // siteId: 13, //站点ID
//     guests: [],
//     products: [
//         productId: 58
//       }
//     ]
//   })

//   if (res.state === 'success') {
//     console.log(res)
//   }
// }
const validate = () => {
  // 电话号码正则表达式示例，可以根据实际需求调整
  const phoneRegex = /^1[3-9]\d{9}$/ // 假设是中国大陆的手机号码格式

  if (orderGuestRequestsList.value.length === 0) {
    uni.showToast({
      title: '请填写游客信息',
      icon: 'none'
    })
    return false
  }

  for (let i = 0; i < orderGuestRequestsList.value.length; i++) {
    const guest = orderGuestRequestsList.value[i]
    if (!guest.guestName) {
      uni.showToast({
        title: `游客${i + 1}姓名不能为空`,
        icon: 'none'
      })
      return false
    }
    if (!guest.guestMobile || !phoneRegex.test(guest.guestMobile)) {
      uni.showToast({
        title: `游客${i + 1}电话号码无效`,
        icon: 'none'
      })
      return false
    }
  }

  return true
}
const submit = async () => {
  if (!validate()) return
  const res = await guestOrderInfoSave({
    orderDate: parseTime(1733997320000, ''),
    productId: orderData.value.id,
    orderGuestRequests: orderGuestRequestsList.value,
    orderPrice: priceTotal.value
  })

  if (res.state === 'success') {
    navToUrl('/packages/order/orderPay/index')
  } else {
    uni.showToast({
      title: '下单失败',
      icon: 'none'
    })
  }
}

onLoad((options: any) => {
  if (options.productData) {
    orderData.value = JSON.parse(options.productData)
    console.log(orderData.value)
  }
})
</script>

<template>
  <view class="placeOrder-page">
    <view
      class="home-top-bg"
      :style="{ backgroundImage: `url(${orderData?.imgMain})` }"
    ></view>
    <view class="placeOrder-page__box m10 p10 fontBold">
      <view class="title fontBold border-bottom">产品标题</view>
      <view class="content">12月26日（周四）- 12月27日（周五）住1晚</view>
    </view>
    <!-- <view class="placeOrder-page__box m10 p10">
      <view class="title fontBold">选择数量</view>
      <view class="space-between flex-align">
        <view class="price">￥ {{ count }} / 件</view>
        <up-number-box
          v-model="state.num"
          :min="0"
          :max="100"
          @change="numberChange"
        ></up-number-box>
      </view>
    </view> -->
    <view class="placeOrder-page__box m10 p10">
      <view class="title fontBold">入住信息</view>
      <view class="space-between flex-align">
        <view class="price content">
          2024-12-26 (¥{{ orderData?.priceSale }}/间)
        </view>
        <up-number-box
          v-model="state.num"
          :min="1"
          :max="100"
          @change="numberChange"
        ></up-number-box>
      </view>
    </view>
    <!-- 联系人信息 -->
    <!-- <view class="placeOrder-page__box form__box m10 p10">
      <view class="title fontBold">联系人信息</view>
      <view class="placeOrder-page__box__form content">
        <view class="placeOrder-page__box__form__Item flex-align space-between">
          <text
            class="label"
            :class="{
              required: true
            }"
          >
            联系人
          </text>
          <input
            v-model="orderParams.contactName"
            type="text"
            class="input flex-1 ml30"
            placeholder="请输入联系人姓名"
          />
        </view>
        <view class="placeOrder-page__box__form__Item flex-align space-between">
          <text
            class="label"
            :class="{
              required: true
            }"
          >
            手机号
          </text>
          <input
            v-model="orderParams.contactPhone"
            type="text"
            class="input flex-1 ml30"
            placeholder="请输入手机号"
          />
        </view>
      </view>
    </view> -->

    <!-- 游客信息 -->
    <view class="placeOrder-page__box form__box m10 p10">
      <view class="title fontBold">游客信息填写</view>
      <view
        v-for="(item, index) in orderGuestRequestsList"
        :key="index"
        class="placeOrder-page__box__form content"
      >
        <view class="placeOrder-page__box__form__Item flex-align space-between">
          <text
            class="label"
            :class="{
              required: true
            }"
          >
            游客{{ index + 1 }}
          </text>
          <input
            v-model="item.guestName"
            type="text"
            class="input flex-1 ml30"
            placeholder="请输入游客姓名"
          />
        </view>
        <view class="placeOrder-page__box__form__Item flex-align space-between">
          <text
            class="label"
            :class="{
              required: true
            }"
          >
            手机号
          </text>
          <input
            v-model="item.guestMobile"
            type="text"
            class="input flex-1 ml30"
            placeholder="请输入手机号"
          />
        </view>
      </view>
    </view>

    <!-- 备注 -->
    <view class="placeOrder-page__box m10 p10">
      <view class="title fontBold">备注</view>
      <view class="placeOrder-page__box__form content">
        <view class="placeOrder-page__box__form__Item flex-align space-between">
          <text class="label">留言</text>
          <input
            v-model="orderParams.remark"
            type="text"
            class="input flex-1 ml30"
            placeholder="如有特殊需求请在这里留言"
          />
        </view>
      </view>
    </view>

    <!-- 底部 -->
    <ZBottomBtn
      :priceTotal="priceTotal"
      @click="submit"
    />
  </view>
</template>

<style lang="scss" scoped>
.placeOrder-page {
  position: relative;
  width: 100vw;
  min-height: calc(100vh - 50px);
  overflow: hidden;
  background-color: #f0f0f0;
  .home-top-bg {
    margin-top: 45px;
    position: absolute;
    width: 100%;
    height: 150px;
    filter: blur(20px);
  }
  &__box {
    position: relative;
    border-radius: 10rpx;
    background-color: #ffffff;
    .content {
      padding: 5px;
      color: #666;
      font-size: 14px;
    }
    &.form__box {
      padding-bottom: 0 !important;
    }
    &__form {
      padding: 0 30rpx;
      &__Item {
        line-height: 3em;
        border-bottom: 1px solid #f0f0f0;
        &:last-child {
          border: none;
        }
        .label {
          width: 150rpx;
          &.required {
            position: relative;
            &::before {
              position: absolute;
              top: 0rpx;
              left: -14rpx;
              display: block;
              content: '*';
              color: #ff0000;
            }
          }
        }
        .input {
          font-size: 12px;
        }
        .textarea {
          border-radius: 10rpx;
          border: 1px solid #d3d3d3;
          padding: 20rpx;
        }
      }
    }
  }
}
.border-bottom {
  padding: 10px 0;
  border-bottom: 1px solid #e5e5e5;
}
</style>
