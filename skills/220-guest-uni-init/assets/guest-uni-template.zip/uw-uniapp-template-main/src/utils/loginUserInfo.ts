import { useUserStore } from '@/store/user'
// import { ref } from 'vue'
import channelType from '@/utils/channelType'
// import { useMainStore } from '@/store/main'
import { login } from '@/api/text'
// import type { ResponseData } from '@/api/type/API_TYPE'

/**
 * - auth_base: 静默授权
 * - auth_user: 网站支付宝登录
 * - auth_zhima: 用户芝麻信息
 */
// type LoginScopes = 'auth_base' | 'auth_user' | 'auth_zhima'

export default function useUserInfoModule() {
  const userStore = useUserStore()
  // const mainStore = useMainStore()

  // 静默登录
  async function silentLogin({
    param
  }: {
    param?: any
  } = {}) {
    console.log('静默登录-进入', param)
    return new Promise((resolve, reject) => {
      uni.login({
        success: async (res) => {
          // 登录参数
          const params: any = {
            code: res.code,
            appId: 'wxc627db84bc3463e9',
            saleChannel: channelType(process.env.VUE_APP_PLATFORM),
            ...param
          }

          const loginData: any = await login(params)
          if (loginData.state === 1) {
            //
            resolve(true)
          } else {
            uni.showToast({
              icon: 'none',
              mask: true,
              title: loginData.msg
            })
            reject(res)
          }
        },
        fail: (err: any) => {
          uni.showToast({
            title: JSON.stringify(err),
            icon: 'none'
          })
        }
      })
    })
  }

  /**
   * h5调用登录
   */
  async function H5APIlogin(param?: any) {
    return new Promise((resolve, reject) => {
      const openId = userStore.openId
      const murmur = '3qyvXKXq8GxoToYt29E5TCT7tJvc9EEu8BCMbw4c6Q5Ca' // 浏览器端临时身份
      const params = {
        openId: openId || murmur,
        orderCustId: '6297191',
        parentCustId: '84826',
        saleChannel: 4,
        appId: 'wx459e5e2c8f2788d0',
        ...param // 会覆盖上面重名的键值
      }
      console.log('登录参数', params)
      login(params)
        .then((res: any) => {
          if (res.state === 1) {
            console.log('静默登录H5-成功', res.data)
            userStore.setOpenId(
              res.data.openId || res.data.maUserInfo.openId || ''
            )
            userStore.setUserInfo(res.data)

            resolve(true)
          } else {
            uni.showToast({
              title: res.msg || res.code,
              icon: 'none',
              mask: true,
              duration: 5000
            })
            uni.clearStorage() //  会清除所有通过 uni.setStorage 或 uni.setStorageSync 存储的数据
            reject(false)
          }
        })
        .catch(() => {
          uni.showToast({
            title: '登录失败，请稍后再试~',
            icon: 'none',
            mask: true,
            duration: 5000
          })
          uni.clearStorage()
          reject(false)
        })
    })
  }

  return {
    silentLogin,
    H5APIlogin
  }
}
