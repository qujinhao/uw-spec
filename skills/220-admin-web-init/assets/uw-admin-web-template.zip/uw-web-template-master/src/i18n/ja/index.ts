// import jaLocale from 'element-plus/lib/locale/lang/ja'
import jaLocale from 'element-plus/dist/locale/ja.mjs'

// 自动导入当前文件夹的所有文件下多语言包
const jaCN = import.meta.glob(['./*', '!./index', '!./type.d.ts'], {
  import: 'default',
  eager: true
})

let i18nJa = {
  ...jaLocale
}

for (const key in jaCN) {
  if (Object.hasOwn(jaCN, key)) {
    const item = jaCN[key]
    i18nJa = Object.assign(i18nJa, item)
  }
}

export default i18nJa
