<template>
  <view class="z-rich-text">
    <p class="z-rich-text-title">{{ title }}</p>
    <mp-html
      v-if="!$slots.default"
      class="z-rich-text-main"
      ref="rich"
      :content="letslazyload"
      :style="mainStype"
    ></mp-html>
    <view
      v-if="$slots.default"
      :style="mainStype"
      class="z-rich-text-main"
      ref="richRef"
    >
      <slot></slot>
    </view>
    <view
      class="z-rich-text-look"
      v-if="showHight && richHight > showHight"
    >
      <text @click="show = !show">
        {{ show ? t('zDetailCollapse.hide') : t('zDetailCollapse.more') }}
        <uni-icons type="right" />
      </text>
    </view>
  </view>
</template>

<script lang="ts" setup>
import { ref, computed, onMounted, watch } from 'vue'
import i18n from '@/i18n/index'
import mpHtml from 'mp-html/dist/uni-app/components/mp-html/mp-html'

const { t } = i18n().global

const props = withDefaults(
  defineProps<{
    title: string
    rich?: string
    showHight?: number
    panding?: number
  }>(),
  {
    rich: '',
    panding: 16
  }
)

const show = ref(false)
const richHight = ref(0)

const letslazyload = computed(() => {
  let contentp = props.rich
  const regexp1 = new RegExp(/(<img )([^>]*)(src=")([^"]*")([^>]*)(>)/, 'g')
  contentp = contentp.replace(regexp1, (match, p1, p2, p3, p4, p5, p6) => {
    return p1 + p2 + 'data-src="' + p4 + p5 + p6
  })
  return contentp
})

const mainStype = computed(() => {
  let style = 'height: auto;'
  if (!show.value) {
    if (props.showHight && props.showHight < richHight.value) {
      style += `height: ${props.showHight}px;`
    }
  }
  return style + `padding: 10px ${props.panding}px;`
})

const richRef = ref<HTMLElement | null>(null)

watch(richHight, (newData) => {
  if (props.showHight && newData > props.showHight) {
    show.value = false
  }
})

onMounted(() => {
  handleHeight()
})

const handleHeight = () => {
  if (richRef.value) {
    richHight.value = richRef.value.clientHeight
  }
}
</script>

<style lang="scss">
@import './style/index.scss';
</style>
