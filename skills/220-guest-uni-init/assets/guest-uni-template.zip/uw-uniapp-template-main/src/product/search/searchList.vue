<script lang="ts" setup>
import { reactive } from 'vue'
import { onLoad, onPullDownRefresh, onReachBottom } from '@dcloudio/uni-app'
// import RouterUtil from '@/utils/RouterUtil'

import ZScrollView from '@/components/ZScrollView/index.vue'
import ZProductList from '@/components/ZProductList/index.vue'
import ZLoadMore from '@/components/ZLoadMore/index.vue'

const state = reactive({
  page: 0,
  keyword: '',
  loading: true,
  loadingType: 'more',
  navList: [] as any[],
  productList: [] as any[]
})

// 获取商品列表
const getProductList = async (type = '') => {
  // api测试
  const ApiPromise = new Promise((resolve) => {
    resolve(1)
  })
  try {
    let res: any = {}
    res = await ApiPromise
    state.loading = false
    if (type === 'refresh') {
      uni.stopPullDownRefresh()
    }
    state.loadingType = res.data.length < 10 ? 'noMore' : 'more'
    state.productList = [...state.productList, ...res.data]
  } catch (e) {
    state.loading = false
    if (type === 'refresh') {
      uni.stopPullDownRefresh()
    }
    console.log('log输出的内容：e', e)
  }
}

// 返回/关闭抽屉
const back = () => {
  // RouterUtil.back()
}

// 搜索事件
const search = () => {
  state.page = 1
  state.loading = true
  state.productList.length = 0
  console.log('search')
  getProductList()
}

// 下拉刷新
onPullDownRefresh(() => {
  state.page = 1
  state.productList.length = 0
  getProductList('refresh')
})

onLoad((options) => {
  console.log('搜索列表页 ---', options)

  state.navList = [
    {
      title: '门票'
    },
    {
      title: '酒店'
    }
  ]
})

// 加载更多
onReachBottom(() => {
  if (state.loadingType === 'noMore') return
  state.page++
  getProductList()
})
</script>

<template>
  <view class="searchList-page">
    <view class="searchList-page__top">
      <view class="searchList-page__top__header flex-align">
        <i
          class="iconfont list_1"
          @tap="back"
        ></i>
        <view class="searchList-page__top__header__input-box flex-align flex-1">
          <input
            v-model="state.keyword"
            class="input"
            placeholder="请输入关键字"
            type="text"
            @confirm="search"
          />
          <i
            class="iconfont search"
            @tap.stop="search"
          ></i>
        </view>
      </view>
      <view class="searchList-page__top__filter">
        <ZScrollView
          :navList="state.navList"
          navPadding="0 30rpx"
        />
      </view>
    </view>
    <view class="searchList-page__content">
      <ZProductList />
      <ZLoadMore
        v-if="state.productList.length"
        :status="state.loadingType"
      />
    </view>
  </view>
</template>

<style lang="scss" scoped>
.searchList-page {
  background: #f8f8f8;
  min-height: 100vh;
  padding-bottom: calc(env(safe-area-inset-bottom) / 2);
  box-sizing: border-box;
  &__top {
    width: 100%;
    top: 0;
    z-index: 2;
    background-color: #fff;
    &__header {
      padding: 10rpx 0;
      padding-left: 20rpx;
      &__input-box {
        box-sizing: border-box;
        height: 60rpx;
        position: relative;
        margin: 0 10rpx;
        .search {
          z-index: 100;
          display: flex;
          align-items: center;
          position: absolute;
          top: 0;
          right: 0;
          width: 60rpx;
          height: 60rpx;
          font-size: 36rpx;
          color: #333;
        }
        .input {
          width: 100%;
          height: 60rpx;
          border-radius: 30rpx;
          font-size: 24rpx;
          padding-left: 28rpx;
          color: #333;
          background-color: #f1f1f1;
        }
      }
    }
  }
}
</style>
