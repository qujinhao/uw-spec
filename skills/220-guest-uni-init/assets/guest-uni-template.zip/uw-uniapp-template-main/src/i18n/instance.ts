// 独立的 i18n 实例，不依赖 store，用于避免循环依赖
import { createI18n } from 'vue-i18n'
import type { I18N } from './i18n.type'

export const messages = {}

// 引入i18n文件夹下所有集合index.ts文件
const modules: Record<string, any> = import.meta.glob(
  ['./*/index.ts', '!./*/type.ts', '!./type.d.ts'],
  {
    eager: true
  }
)

// https://vitejs.cn/vite3-cn/guide/features.html#glob-import
for (const path in modules) {
  const match = path.match(/\.\/([\w-]+)\//)
  const key = match ? match[1] : null //  取出文件夹名的 en、zh-cn、zh-tw ... 作为key
  // @ts-expect-error
  messages[key] = modules[path].default
}

// 获取浏览器默认语言
const getBrowserLang = (): I18N => {
  const sys = uni.getSystemInfoSync()
  if (!sys) return 'zh-CN'
  const lang = sys.language?.replace('_', '-') || sys.language || 'zh-CN'
  return lang as I18N
}

// 创建独立的 i18n 实例，用于 API 请求等场景
export const createI18nInstance = (locale?: I18N) => {
  return createI18n({
    legacy: false,
    locale: locale || getBrowserLang(),
    fallbackLocale: 'zh-CN',
    messages
  })
}

// 默认实例（使用浏览器语言）
let defaultI18nInstance = createI18nInstance()

// 更新默认实例的语言（由 store 调用）
export const setDefaultI18nLocale = (locale: I18N) => {
  defaultI18nInstance = createI18nInstance(locale)
}

// 获取默认实例
export const i18n = () => defaultI18nInstance

export default defaultI18nInstance
