import store from '@/store/index'
import { useMainStore } from '@/store/main'
import { ElMessage } from 'element-plus'

/**
 * 传入一个对应userType的接口枚举 返回对应值的requestApi
 * @param reqFn 请求方法
 * @example getUserTypeApi( {300: () => saasCommonOssGenUploadParam(params), 310: () => mchCommonOssGenUploadParam(params)})  --> 登录的saas运营商返回 () => mchCommonOssGenUploadParam(params)
 * @returns 根据登录的权限返回value
 */
export const getUserTypeApi = <R>(reqFn: Record<number, R>): R => {
  let request: R = reqFn[0]
  const mainStore = useMainStore(store)
  const loginUserType = mainStore.loginInfo.userType || 0
  const keys: string[] = Object.keys(reqFn)
  for (let index = 0; index < keys.length; index++) {
    const key = keys[index]
    if (Number(key) === loginUserType) {
      request = reqFn[loginUserType]
      break
    }
  }
  if (!request) {
    ElMessage.error('传入参数有误')
  }
  return request
}
