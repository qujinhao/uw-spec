export interface Attrs {
  model: string // 模板类型
  row: number // 行数
  list?: ListType[] // 方格数据
}
// 样式控制
export interface Styles {
  pagePadding: number //	页面边距
  cmpRadius: number //	组件圆角
  imgMargin: number //	单项间距
  imgRadius: number //	单项圆角
  cmpBackground?: string //	背景颜色
}
interface ListType {
  top?: number
  left?: number
  bottom?: number
  right?: number
  height?: number
  width?: number
  image?: string
  jump?: JumpType
}

export interface JumpType {
  id?: string
  type?: string
}
