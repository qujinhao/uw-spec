<template>
  <!-- 栅格导航组件 -->
  <view
    class="m-grid-nav"
    :style="boxStyle"
  >
    <view
      class="m-grid-nav-body"
      :style="getWrapStyle"
    >
      <view
        class="grids"
        :style="[getGridsStyle()]"
      >
        <view
          v-for="(item, i) in mergedAttrs.dataList"
          :key="'tab-nav' + i"
          class="grid-item"
          :style="[geItemStyle()]"
          @click="clickItem(item)"
        >
          <view
            :style="{ height: unit(mergedStyles.imgWidth) }"
            class="m-grif-nav-image"
          >
            <view
              v-if="['image', 'image-text'].includes(mergedAttrs.type)"
              :style="[geItemImgStyle(item.img)]"
            ></view>
          </view>
          <text
            v-if="['text', 'image-text'].includes(mergedAttrs.type)"
            class="ellipsis-1"
          >
            {{ item.name }}
          </text>
        </view>
      </view>
    </view>
  </view>
</template>

<script lang="ts" setup>
import { computed, type CSSProperties } from 'vue'
import { unit } from '../utils/registerBaseStyle'
import type { Attrs, JumpType, Styles } from './type'

const defaultIamge = 'http://qnimg.zowoyoo.com/img/84826/1715237104041.png'
const props = withDefaults(
  defineProps<{
    attrs?: Partial<Attrs>
    styles?: Partial<Styles>
  }>(),
  {
    attrs: () => ({}),
    styles: () => ({})
  }
)

// 合并后的属性
const mergedAttrs = computed(() => ({
  isCustomAdvert: false, // 是否自定义广告
  model: 'fixed', // 模式选择: fixed-固定布局 | scroll-横向滚动
  type: 'image-text', // 显示类型: image-仅图片 | text-仅文本 | image-text-图文
  max: '4', // 一行显示数量
  dataList: [
    {
      name: '拼团',
      img: 'http://qnimg.zowoyoo.com/img/84826/1620443545857.png',
      url: '/shoppingrush'
    },
    {
      name: '抢购',
      img: 'http://qnimg.zowoyoo.com/img/84826/1620443331592.png',
      url: '/shoppingrush'
    },
    {
      name: '门票',
      img: 'http://qnimg.zowoyoo.com/img/84826/1620443390426.png',
      url: '/tickets'
    },
    {
      name: '住宿',
      img: 'http://qnimg.zowoyoo.com/img/84826/1620443365165.png',
      url: '/hotel'
    },
    {
      name: '套餐',
      img: 'http://qnimg.zowoyoo.com/img/84826/1620443407068.png',
      url: '/setmeal'
    },
    {
      name: '线路',
      img: 'http://qnimg.zowoyoo.com/img/84826/1620443426452.png',
      url: '/linechannel'
    }
  ],
  ...props.attrs
}))

// 合并后的样式
const mergedStyles = computed(() => ({
  pageMargin: 0, // 左右外边距
  pagePadding: 0, // 左右内边距
  marginTop: 10, // 上外边距
  marginBottom: 10, // 下外边距
  paddingTop: 0, // 上内边距
  paddingBottom: 0, // 下内边距
  imgPadding: 10, // 单项间距
  radiusTop: 0, // 上圆角
  radiusBottom: 0, // 下圆角
  itemWidth: 100, // 单项宽度
  imgWidth: 50, // 图片宽度
  imgRadius: 0, // 图片圆角
  fontSize: 12, // 文本字体大小
  titleColor: '', // 文本颜色
  cmpBackground: '', // 组件背景色
  ...props.styles
}))

const emit = defineEmits<{
  jump: [item: JumpType]
}>()

const itemWidth = computed(() => {
  return (
    (375 - mergedStyles.value.pageMargin * 2 - mergedStyles.value.imgPadding) /
    Number(mergedAttrs.value.max)
  )
})

// 容器样式
const getWrapStyle = computed<CSSProperties>(() => {
  return {
    overflowX:
      mergedAttrs.value.model === 'fixed' ? 'hidden' : ('auto' as const)
  }
})

// 整体容器样式
const boxStyle = computed(() => {
  return {
    fontSize: mergedStyles.value.fontSize,
    color: mergedStyles.value.titleColor,
    background: mergedStyles.value.cmpBackground,
    borderTopLeftRadius: unit(mergedStyles.value.radiusTop),
    borderTopRightRadius: unit(mergedStyles.value.radiusTop),
    borderBottomRightRadius: unit(mergedStyles.value.radiusBottom),
    borderBottomLeftRadius: unit(mergedStyles.value.radiusBottom),
    marginTop: unit(mergedStyles.value.marginTop),
    marginBottom: unit(mergedStyles.value.marginBottom),
    marginLeft: unit(mergedStyles.value.pageMargin),
    marginRight: unit(mergedStyles.value.pageMargin),
    paddingTop: unit(mergedStyles.value.paddingTop),
    paddingBottom: unit(mergedStyles.value.paddingBottom),
    paddingLeft: unit(mergedStyles.value.pagePadding),
    paddingRight: unit(mergedStyles.value.pagePadding)
  }
})

// grids 样式
const getGridsStyle = () => {
  if (mergedAttrs.value.model === 'fixed') {
    const gap = mergedStyles.value.imgPadding || 0 // 间隔（gap）大小
    const columns = Number(mergedAttrs.value.max || '4') // 每行列数

    // 因为每两列之间有一个gap，所以需要除以(columns + 1)来平均分配gap
    const effectiveColumnWidth =
      (100 - (columns + 1) * (gap / columns)) / columns

    return {
      display: 'grid',
      gridTemplateColumns: `repeat(auto-fit, minmax(${effectiveColumnWidth}%, 1fr))`,
      gap: unit(gap)
    }
  }
  if (mergedAttrs.value.model === 'scroll') {
    return {
      width: unit(
        (itemWidth.value + mergedStyles.value.imgPadding * 2) *
          mergedAttrs.value.dataList.length
      )
    }
  }
}

// 单项样式
const geItemStyle = () => {
  return {
    placeSelf: 'center',
    color: mergedStyles.value.titleColor,
    width: unit(
      mergedAttrs.value.model === 'fixed'
        ? mergedStyles.value.itemWidth
        : itemWidth.value
    )
  }
}

// 单项图片样式
const geItemImgStyle = (imgUrl: string | undefined) => {
  return {
    width: unit(mergedStyles.value.imgWidth),
    height: unit(mergedStyles.value.imgWidth),
    borderRadius: unit(mergedStyles.value.imgRadius),
    // marginBottom: mergedAttrs.value.type === 'image-text' ? unit(5) : 0,
    backgroundImage: `url(${imgUrl || defaultIamge})`,
    backgroundSize: 'cover'
  }
}

// 跳转处理
const clickItem = (item: any) => {
  if (item.url) {
    const type = item.url.includes('/') ? 'link' : 'custom'
    emit('jump', { id: item.url, type })
  }
}
</script>

<style lang="scss" scoped>
.m-grid-nav {
  .m-grid-nav-body {
    &::-webkit-scrollbar {
      display: none;
    }

    .grids {
      .grid-item {
        display: inline-flex;
        flex-direction: column;
        align-items: center;
      }
    }
  }

  .ellipsis-1 {
    text-overflow: ellipsis;
    white-space: normal;
    word-break: break-all;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 1;
    overflow: hidden;
    line-height: normal;
  }
}

.m-grif-nav-image {
  display: flex;
  justify-content: center;
  align-items: center;
}
</style>
