import request from '@/utils/request'
import { ResponseData, DataList, ESDataList } from './uwAuthCenterAuthApi'

//修改当前运营商
export const saasSaasInfoUpdate = (
  data: SaasInfo,
  params: {
    remark: string // 备注
  }
): Promise<ResponseData<void>> => {
  return request('/saas-base-app/saas/saas/info/update', {
    method: 'PUT',
    data,
    params
  })
}
//修改商户信息
export const saasPartnerMchInfoUpdate = (
  data: SaasMchInfo,
  params: {
    remark: string // 备注
  }
): Promise<ResponseData<SaasMchInfo>> => {
  return request('/saas-base-app/saas/partner/mchInfo/update', {
    method: 'PUT',
    data,
    params
  })
}
//启用商户
export const saasPartnerMchInfoEnable = (params: {
  id: number // 主键ID
  remark: string // 备注
}): Promise<ResponseData<void>> => {
  return request('/saas-base-app/saas/partner/mchInfo/enable', {
    method: 'PUT',
    params
  })
}
//禁用商户
export const saasPartnerMchInfoDisable = (params: {
  id: number // 主键ID
  remark: string // 备注
}): Promise<ResponseData<void>> => {
  return request('/saas-base-app/saas/partner/mchInfo/disable', {
    method: 'PUT',
    params
  })
}
//修改商户等级信息
export const saasPartnerMchGradeUpdate = (
  data: SaasMchGrade,
  params: {
    remark: string // 备注
  }
): Promise<ResponseData<SaasMchGrade>> => {
  return request('/saas-base-app/saas/partner/mchGrade/update', {
    method: 'PUT',
    data,
    params
  })
}
//启用商户等级
export const saasPartnerMchGradeEnable = (params: {
  id: number // 主键ID
  remark: string // 备注
}): Promise<ResponseData<void>> => {
  return request('/saas-base-app/saas/partner/mchGrade/enable', {
    method: 'PUT',
    params
  })
}
//禁用商户等级
export const saasPartnerMchGradeDisable = (params: {
  id: number // 主键ID
  remark: string // 备注
}): Promise<ResponseData<void>> => {
  return request('/saas-base-app/saas/partner/mchGrade/disable', {
    method: 'PUT',
    params
  })
}
//启用商户资质信息
export const saasPartnerMchCertEnable = (params: {
  id: number // 主键ID
  remark: string // 备注
}): Promise<ResponseData<void>> => {
  return request('/saas-base-app/saas/partner/mchCert/enable', {
    method: 'PUT',
    params
  })
}
//禁用商户资质信息
export const saasPartnerMchCertDisable = (params: {
  id: number // 主键ID
  remark: string // 备注
}): Promise<ResponseData<void>> => {
  return request('/saas-base-app/saas/partner/mchCert/disable', {
    method: 'PUT',
    params
  })
}
//资质审核拒绝
export const saasPartnerMchCertAuditReject = (params: {
  id: number //
  remark: string //
}): Promise<ResponseData<SaasMchCert>> => {
  return request('/saas-base-app/saas/partner/mchCert/auditReject', {
    method: 'PUT',
    params
  })
}
//资质审核通过
export const saasPartnerMchCertAuditConfirm = (params: {
  id: number //
  remark: string //
}): Promise<ResponseData<SaasMchCert>> => {
  return request('/saas-base-app/saas/partner/mchCert/auditConfirm', {
    method: 'PUT',
    params
  })
}
//修改运营商公告
export const saasNoticeSaasUpdate = (
  data: SaasNoticeInfo,
  params: {
    remark: string // 备注
  }
): Promise<ResponseData<SaasNoticeInfo>> => {
  return request('/saas-base-app/saas/notice/saas/update', {
    method: 'PUT',
    data,
    params
  })
}
//启用运营商公告
export const saasNoticeSaasEnable = (params: {
  id: number // 主键ID
  remark: string // 备注
}): Promise<ResponseData<void>> => {
  return request('/saas-base-app/saas/notice/saas/enable', {
    method: 'PUT',
    params
  })
}
//禁用运营商公告
export const saasNoticeSaasDisable = (params: {
  id: number // 主键ID
  remark: string // 备注
}): Promise<ResponseData<void>> => {
  return request('/saas-base-app/saas/notice/saas/disable', {
    method: 'PUT',
    params
  })
}
//工单已解决
export const saasCommonSpsTicketSolve = (params: {
  id: number // 工单ID
}): Promise<ResponseData<SpsTicketInfo>> => {
  return request('/saas-base-app/saas/common/spsTicket/solve', {
    method: 'PUT',
    params
  })
}
//工单关闭
export const saasCommonSpsTicketClose = (params: {
  id: number // 工单ID
}): Promise<ResponseData<SpsTicketInfo>> => {
  return request('/saas-base-app/saas/common/spsTicket/close', {
    method: 'PUT',
    params
  })
}
//工单重新激活
export const saasCommonSpsTicketActivate = (params: {
  id: number // 工单ID
}): Promise<ResponseData<SpsTicketInfo>> => {
  return request('/saas-base-app/saas/common/spsTicket/activate', {
    method: 'PUT',
    params
  })
}
//通知上传成功
export const saasCommonOssUploadSuccess = (params: {
  configSid?: string // 配置id
  id: number // 文件id
  filePath: string // 文件名
}): Promise<ResponseData<SysOssFile>> => {
  return request('/saas-base-app/saas/common/oss/uploadSuccess', {
    method: 'PUT',
    params
  })
}
//更新refId
export const saasCommonOssUpdateRefId = (params: {
  id: number // 文件id
  filePath: string // 文件名
  refId: string // 文件refId
}): Promise<ResponseData<SysOssFile>> => {
  return request('/saas-base-app/saas/common/oss/updateRefId', {
    method: 'PUT',
    params
  })
}
//解除链接
export const saasCommonOssUnlink = (params: {
  id: number // 文件id
  filePath: string // 文件名
}): Promise<ResponseData<SysOssFile>> => {
  return request('/saas-base-app/saas/common/oss/unlink', {
    method: 'PUT',
    params
  })
}
//链接文件
export const saasCommonOssLink = (params: {
  id: number // 要链接的文件id
  filePath: string // 文件名
  refType: string // 关联的表名
  refId: string // 关联表的id
}): Promise<ResponseData<SysOssFile>> => {
  return request('/saas-base-app/saas/common/oss/link', {
    method: 'PUT',
    params
  })
}
//修改字典
export const saasBaseDictUpdate = (
  data: SysDictInfo,
  params: {
    remark: string // 备注
  }
): Promise<ResponseData<SysDictInfo>> => {
  return request('/saas-base-app/saas/base/dict/update', {
    method: 'PUT',
    data,
    params
  })
}
//修改字典多语言
export const saasBaseDictLangUpdate = (
  data: SysDictLang,
  params: {
    remark: string // 备注
  }
): Promise<ResponseData<SysDictLang>> => {
  return request('/saas-base-app/saas/base/dict/lang/update', {
    method: 'PUT',
    data,
    params
  })
}
//启用字典多语言
export const saasBaseDictLangEnable = (params: {
  id: number // 主键ID
  remark: string // 备注
}): Promise<ResponseData<void>> => {
  return request('/saas-base-app/saas/base/dict/lang/enable', {
    method: 'PUT',
    params
  })
}
//禁用字典多语言
export const saasBaseDictLangDisable = (params: {
  id: number // 主键ID
  remark: string // 备注
}): Promise<ResponseData<void>> => {
  return request('/saas-base-app/saas/base/dict/lang/disable', {
    method: 'PUT',
    params
  })
}
//启用字典
export const saasBaseDictEnable = (params: {
  id: number // 主键ID
  remark: string // 备注
}): Promise<ResponseData<void>> => {
  return request('/saas-base-app/saas/base/dict/enable', {
    method: 'PUT',
    params
  })
}
//禁用字典
export const saasBaseDictDisable = (params: {
  id: number // 主键ID
  remark: string // 备注
}): Promise<ResponseData<void>> => {
  return request('/saas-base-app/saas/base/dict/disable', {
    method: 'PUT',
    params
  })
}
//修改应用接口配置
export const saasAisLinkerConfigUpdate = (
  data: AisLinkerConfig,
  params: {
    remark: string // 备注
  }
): Promise<ResponseData<AisLinkerConfig>> => {
  return request('/saas-base-app/saas/ais/linkerConfig/update', {
    method: 'PUT',
    data,
    params
  })
}
//启用应用接口配置
export const saasAisLinkerConfigEnable = (params: {
  id: number // 主键ID
  remark: string // 备注
}): Promise<ResponseData<void>> => {
  return request('/saas-base-app/saas/ais/linkerConfig/enable', {
    method: 'PUT',
    params
  })
}
//禁用应用接口配置
export const saasAisLinkerConfigDisable = (params: {
  id: number // 主键ID
  remark: string // 备注
}): Promise<ResponseData<void>> => {
  return request('/saas-base-app/saas/ais/linkerConfig/disable', {
    method: 'PUT',
    params
  })
}
//设置授权报警限值
export const saasAipLicenseSetLicenseAlertLimit = (params: {
  id: number // 主键ID
  licenseAlertLimit: number // 授权报警限值
  remark: string // 备注
}): Promise<ResponseData<void>> => {
  return request('/saas-base-app/saas/aip/license/setLicenseAlertLimit', {
    method: 'PUT',
    params
  })
}
//刷新授权
export const saasAipLicenseRefreshLicense = (params: {
  id: number // 需要刷新的授权ID
}): Promise<ResponseData<void>> => {
  return request('/saas-base-app/saas/aip/license/refreshLicense', {
    method: 'PUT',
    params
  })
}
//撤销开票申请
export const saasAipInvoiceCancel = (params: {
  id: number // 申请记录编号
}): Promise<ResponseData<void>> => {
  return request('/saas-base-app/saas/aip/invoice/cancel', {
    method: 'PUT',
    params
  })
}
//新增资质
export const saasSaasCertSave = (
  data: SaasCertInfo
): Promise<ResponseData<SaasCertInfo>> => {
  return request('/saas-base-app/saas/saas/cert/save', {
    method: 'POST',
    data
  })
}
//保存商户信息
export const saasPartnerMchInfoSave = (
  data: SaasMchInfo
): Promise<ResponseData<SaasMchInfo>> => {
  return request('/saas-base-app/saas/partner/mchInfo/save', {
    method: 'POST',
    data
  })
}
//保存商户等级信息
export const saasPartnerMchGradeSave = (
  data: SaasMchGrade
): Promise<ResponseData<SaasMchGrade>> => {
  return request('/saas-base-app/saas/partner/mchGrade/save', {
    method: 'POST',
    data
  })
}
//新增商户资质信息
export const saasPartnerMchCertSave = (
  data: SaasMchCert
): Promise<ResponseData<SaasMchCert>> => {
  return request('/saas-base-app/saas/partner/mchCert/save', {
    method: 'POST',
    data
  })
}
//新增运营商公告
export const saasNoticeSaasSave = (
  data: SaasNoticeInfo
): Promise<ResponseData<SaasNoticeInfo>> => {
  return request('/saas-base-app/saas/notice/saas/save', {
    method: 'POST',
    data
  })
}
//短信发送
export const saasMsgSmsSend = (data: MsgSmsVo): Promise<ResponseData<void>> => {
  return request('/saas-base-app/saas/msg/sms/send', {
    method: 'POST',
    data
  })
}
//邮件发送
export const saasMsgMailSend = (params: {
  msgMail: MsgMailVo //
}): Promise<ResponseData<void>> => {
  return request('/saas-base-app/saas/msg/mail/send', {
    method: 'POST',
    params
  })
}
//发送登录授权
export const saasCommonSpsTicketSendAuth = (
  data: SpsTicketEvent
): Promise<ResponseData<SpsTicketEvent>> => {
  return request('/saas-base-app/saas/common/spsTicket/sendAuth', {
    method: 'POST',
    data
  })
}
//保存工单
export const saasCommonSpsTicketSave = (
  data: SpsTicketInfo
): Promise<ResponseData<SpsTicketInfo>> => {
  return request('/saas-base-app/saas/common/spsTicket/save', {
    method: 'POST',
    data
  })
}
//工单沟通
export const saasCommonSpsTicketEvent = (
  data: SpsTicketEvent
): Promise<ResponseData<SpsTicketEvent>> => {
  return request('/saas-base-app/saas/common/spsTicket/event', {
    method: 'POST',
    data
  })
}
//新增字典
export const saasBaseDictSave = (
  data: SysDictInfo
): Promise<ResponseData<SysDictInfo>> => {
  return request('/saas-base-app/saas/base/dict/save', {
    method: 'POST',
    data
  })
}
//新增字典多语言
export const saasBaseDictLangSave = (
  data: SysDictLang
): Promise<ResponseData<SysDictLang>> => {
  return request('/saas-base-app/saas/base/dict/lang/save', {
    method: 'POST',
    data
  })
}
//订单在线支付
export const saasAipOrderPayOrderOnline = (
  data: AipOrderPayParam
): Promise<ResponseData<FinPayOrderResponse>> => {
  return request('/saas-base-app/saas/aip/order/payOrderOnline', {
    method: 'POST',
    data
  })
}
//订单余额支付
export const saasAipOrderPayOrderByBalance = (params: {
  orderId: number // 订单ID
}): Promise<ResponseData<void>> => {
  return request('/saas-base-app/saas/aip/order/payOrderByBalance', {
    method: 'POST',
    params
  })
}
//购买服务
export const saasAipOrderOrderVendor = (
  data: Array<AipVendorOrderParam>,
  params: {
    remark: string // 备注
  }
): Promise<ResponseData<AipOrderInfo>> => {
  return request('/saas-base-app/saas/aip/order/orderVendor', {
    method: 'POST',
    data,
    params
  })
}
//购买产品
export const saasAipOrderOrderProduct = (params: {
  productId: number //
  productNum: number //
  remark?: string //
}): Promise<ResponseData<AipOrderInfo>> => {
  return request('/saas-base-app/saas/aip/order/orderProduct', {
    method: 'POST',
    params
  })
}
//费用计算
export const saasAipOrderCalcOrderPrice = (
  data: Array<AipVendorOrderParam>
): Promise<ResponseData<AipVendorOrderPriceData>> => {
  return request('/saas-base-app/saas/aip/order/calcOrderPrice', {
    method: 'POST',
    data
  })
}
//发票申请
export const saasAipInvoiceApply = (
  data: AipInvoiceInfo
): Promise<ResponseData<void>> => {
  return request('/saas-base-app/saas/aip/invoice/apply', {
    method: 'POST',
    data
  })
}
//Aip充值
export const saasAipBalanceInfoRecharge = (
  data: AipRechargeParam
): Promise<ResponseData<FinPayOrderResponse>> => {
  return request('/saas-base-app/saas/aip/balanceInfo/recharge', {
    method: 'POST',
    data
  })
}
//Aip充值退款
export const saasAipBalanceInfoRechargeRefund = (
  data: AipRechargeRefundParam
): Promise<ResponseData<void>> => {
  return request('/saas-base-app/saas/aip/balanceInfo/rechargeRefund', {
    method: 'POST',
    data
  })
}
//获取我的运营商信息
export const saasSaasInfoLoad = (): Promise<ResponseData<SaasInfo>> => {
  return request('/saas-base-app/saas/saas/info/load', {
    method: 'GET'
  })
}
//资质列表
export const saasSaasCertList = (
  params: SaasCertInfoQueryParam
): Promise<ResponseData<DataList<SaasCertInfo>>> => {
  return request('/saas-base-app/saas/saas/cert/list', {
    method: 'GET',
    params
  })
}
//加载商户信息
export const saasPartnerMchInfoLoad = (params: {
  id: number // 主键ID
}): Promise<ResponseData<SaasMchInfo>> => {
  return request('/saas-base-app/saas/partner/mchInfo/load', {
    method: 'GET',
    params
  })
}
//商户列表
export const saasPartnerMchInfoLiteList = (
  params: SaasMchInfoQueryParam
): Promise<ResponseData<DataList<SaasMchInfo>>> => {
  return request('/saas-base-app/saas/partner/mchInfo/liteList', {
    method: 'GET',
    params
  })
}
//商户列表
export const saasPartnerMchInfoList = (
  params: SaasMchInfoQueryParam
): Promise<ResponseData<DataList<SaasMchInfo>>> => {
  return request('/saas-base-app/saas/partner/mchInfo/list', {
    method: 'GET',
    params
  })
}
//查询数据历史
export const saasPartnerMchInfoListDataHistory = (
  params: SysDataHistoryQueryParam
): Promise<ResponseData<DataList<SysDataHistory>>> => {
  return request('/saas-base-app/saas/partner/mchInfo/listDataHistory', {
    method: 'GET',
    params
  })
}
//查询操作日志
export const saasPartnerMchInfoListCritLog = (
  params: SysCritLogQueryParam
): Promise<ResponseData<DataList<SysCritLog>>> => {
  return request('/saas-base-app/saas/partner/mchInfo/listCritLog', {
    method: 'GET',
    params
  })
}
//加载商户等级信息
export const saasPartnerMchGradeLoad = (params: {
  id: number // 主键ID
}): Promise<ResponseData<SaasMchGrade>> => {
  return request('/saas-base-app/saas/partner/mchGrade/load', {
    method: 'GET',
    params
  })
}
//商户等级列表
export const saasPartnerMchGradeLiteList = (
  params: SaasMchGradeQueryParam
): Promise<ResponseData<DataList<SaasMchGrade>>> => {
  return request('/saas-base-app/saas/partner/mchGrade/liteList', {
    method: 'GET',
    params
  })
}
//商户等级列表
export const saasPartnerMchGradeList = (
  params: SaasMchGradeQueryParam
): Promise<ResponseData<DataList<SaasMchGrade>>> => {
  return request('/saas-base-app/saas/partner/mchGrade/list', {
    method: 'GET',
    params
  })
}
//查询数据历史
export const saasPartnerMchGradeListDataHistory = (
  params: SysDataHistoryQueryParam
): Promise<ResponseData<DataList<SysDataHistory>>> => {
  return request('/saas-base-app/saas/partner/mchGrade/listDataHistory', {
    method: 'GET',
    params
  })
}
//查询操作日志
export const saasPartnerMchGradeListCritLog = (
  params: SysCritLogQueryParam
): Promise<ResponseData<DataList<SysCritLog>>> => {
  return request('/saas-base-app/saas/partner/mchGrade/listCritLog', {
    method: 'GET',
    params
  })
}
//加载商户资质信息
export const saasPartnerMchCertLoad = (params: {
  id: number // 主键ID
}): Promise<ResponseData<SaasMchCert>> => {
  return request('/saas-base-app/saas/partner/mchCert/load', {
    method: 'GET',
    params
  })
}
//轻量级列表商户资质信息
export const saasPartnerMchCertLiteList = (
  params: SaasMchCertQueryParam
): Promise<ResponseData<DataList<SaasMchCert>>> => {
  return request('/saas-base-app/saas/partner/mchCert/liteList', {
    method: 'GET',
    params
  })
}
//列表商户资质信息
export const saasPartnerMchCertList = (
  params: SaasMchCertQueryParam
): Promise<ResponseData<DataList<SaasMchCert>>> => {
  return request('/saas-base-app/saas/partner/mchCert/list', {
    method: 'GET',
    params
  })
}
//查询数据历史
export const saasPartnerMchCertListDataHistory = (
  params: SysDataHistoryQueryParam
): Promise<ResponseData<DataList<SysDataHistory>>> => {
  return request('/saas-base-app/saas/partner/mchCert/listDataHistory', {
    method: 'GET',
    params
  })
}
//查询操作日志
export const saasPartnerMchCertListCritLog = (
  params: SysCritLogQueryParam
): Promise<ResponseData<DataList<SysCritLog>>> => {
  return request('/saas-base-app/saas/partner/mchCert/listCritLog', {
    method: 'GET',
    params
  })
}
//类型文件统计
export const saasOssReportRefStats = (): Promise<
  ResponseData<DataList<FileStatsInfo>>
> => {
  return request('/saas-base-app/saas/oss/report/refStats', {
    method: 'GET'
  })
}
//文件列表
export const saasOssFileList = (
  params: SysOssFileQueryParam
): Promise<ResponseData<DataList<SysOssFile>>> => {
  return request('/saas-base-app/saas/oss/file/list', {
    method: 'GET',
    params
  })
}
//加载运营商公告
export const saasNoticeSaasLoad = (params: {
  id: number // 主键ID
}): Promise<ResponseData<SaasNoticeInfo>> => {
  return request('/saas-base-app/saas/notice/saas/load', {
    method: 'GET',
    params
  })
}
//公告列表
export const saasNoticeSaasList = (
  params: SaasNoticeInfoQueryParam
): Promise<ResponseData<DataList<SaasNoticeInfo>>> => {
  return request('/saas-base-app/saas/notice/saas/list', {
    method: 'GET',
    params
  })
}
//查询数据历史
export const saasNoticeSaasListDataHistory = (
  params: SysDataHistoryQueryParam
): Promise<ResponseData<DataList<SysDataHistory>>> => {
  return request('/saas-base-app/saas/notice/saas/listDataHistory', {
    method: 'GET',
    params
  })
}
//查询操作日志
export const saasNoticeSaasListCritLog = (
  params: SysCritLogQueryParam
): Promise<ResponseData<DataList<SysCritLog>>> => {
  return request('/saas-base-app/saas/notice/saas/listCritLog', {
    method: 'GET',
    params
  })
}
//已发送短信列表
export const saasMsgSmsList = (
  params: MsgSmsHistoryQueryParam
): Promise<ResponseData<DataList<MsgSmsHistory>>> => {
  return request('/saas-base-app/saas/msg/sms/list', {
    method: 'GET',
    params
  })
}
//发送队列
export const saasMsgSmsListQueue = (
  params: MsgSmsQueueQueryParam
): Promise<ResponseData<DataList<MsgSmsQueue>>> => {
  return request('/saas-base-app/saas/msg/sms/listQueue', {
    method: 'GET',
    params
  })
}
//已发送邮件列表
export const saasMsgMailList = (
  params: MsgMailHistoryQueryParam
): Promise<ResponseData<DataList<MsgMailHistory>>> => {
  return request('/saas-base-app/saas/msg/mail/list', {
    method: 'GET',
    params
  })
}
//发送队列
export const saasMsgMailListQueue = (
  params: MsgMailQueueQueryParam
): Promise<ResponseData<DataList<MsgMailQueue>>> => {
  return request('/saas-base-app/saas/msg/mail/listQueue', {
    method: 'GET',
    params
  })
}
//工单列表
export const saasCommonSpsTicketStats = (): Promise<
  ResponseData<Record<string, number>>
> => {
  return request('/saas-base-app/saas/common/spsTicket/stats', {
    method: 'GET'
  })
}
//工单详情
export const saasCommonSpsTicketLoad = (params: {
  id: number // 工单ID
}): Promise<ResponseData<SpsTicketInfoEx>> => {
  return request('/saas-base-app/saas/common/spsTicket/load', {
    method: 'GET',
    params
  })
}
//工单列表
export const saasCommonSpsTicketList = (
  params: SpsTicketInfoQueryParam
): Promise<ResponseData<DataList<SpsTicketInfo>>> => {
  return request('/saas-base-app/saas/common/spsTicket/list', {
    method: 'GET',
    params
  })
}
//工单处理记录查询
export const saasCommonSpsTicketListEvent = (
  params: SpsTicketEventQueryParam
): Promise<ResponseData<DataList<SpsTicketEvent>>> => {
  return request('/saas-base-app/saas/common/spsTicket/listEvent', {
    method: 'GET',
    params
  })
}
//文件列表
export const saasCommonOssList = (
  params: SysOssFileQueryParam
): Promise<ResponseData<DataList<SysOssFile>>> => {
  return request('/saas-base-app/saas/common/oss/list', {
    method: 'GET',
    params
  })
}
//生成上传参数
export const saasCommonOssGenUploadParam = (params: {
  configSid?: string // 配置id
  refType: string // 关联类型
  refId: string // 关联ID
  fileName: string // 文件名
  fileSize: number // 文件大小
  accessType?: number // 访问类型。0，公共文件；1.隐私文件
  expireDate?: string // 文件过期时间
}): Promise<ResponseData<OssUploadParam>> => {
  return request('/saas-base-app/saas/common/oss/genUploadParam', {
    method: 'GET',
    params
  })
}
//根据商户ID或名称模糊搜索
export const saasCommonInfoLiteListSaasMch = (params: {
  mchType?: number // 商户类型
  keyword: string // 关键字
}): Promise<ResponseData<DataList<SaasMchSimpleInfo>>> => {
  return request('/saas-base-app/saas/common/info/liteListSaasMch', {
    method: 'GET',
    params
  })
}
//加载字典
export const saasBaseDictLoad = (params: {
  id: number // 主键ID
}): Promise<ResponseData<SysDictInfo>> => {
  return request('/saas-base-app/saas/base/dict/load', {
    method: 'GET',
    params
  })
}
//轻量级列表字典
export const saasBaseDictLiteList = (
  params: SysDictInfoQueryParam
): Promise<ResponseData<DataList<SysDictInfo>>> => {
  return request('/saas-base-app/saas/base/dict/liteList', {
    method: 'GET',
    params
  })
}
//列表字典
export const saasBaseDictList = (
  params: SysDictInfoQueryParam
): Promise<ResponseData<DataList<SysDictInfo>>> => {
  return request('/saas-base-app/saas/base/dict/list', {
    method: 'GET',
    params
  })
}
//查询数据历史
export const saasBaseDictListDataHistory = (
  params: SysDataHistoryQueryParam
): Promise<ResponseData<DataList<SysDataHistory>>> => {
  return request('/saas-base-app/saas/base/dict/listDataHistory', {
    method: 'GET',
    params
  })
}
//查询操作日志
export const saasBaseDictListCritLog = (
  params: SysCritLogQueryParam
): Promise<ResponseData<DataList<SysCritLog>>> => {
  return request('/saas-base-app/saas/base/dict/listCritLog', {
    method: 'GET',
    params
  })
}
//加载字典多语言
export const saasBaseDictLangLoad = (params: {
  id: number // 主键ID
}): Promise<ResponseData<SysDictLang>> => {
  return request('/saas-base-app/saas/base/dict/lang/load', {
    method: 'GET',
    params
  })
}
//轻量级列表字典多语言
export const saasBaseDictLangLiteList = (
  params: SysDictLangQueryParam
): Promise<ResponseData<DataList<SysDictLang>>> => {
  return request('/saas-base-app/saas/base/dict/lang/liteList', {
    method: 'GET',
    params
  })
}
//列表字典多语言
export const saasBaseDictLangList = (
  params: SysDictLangQueryParam
): Promise<ResponseData<DataList<SysDictLang>>> => {
  return request('/saas-base-app/saas/base/dict/lang/list', {
    method: 'GET',
    params
  })
}
//应用接口列表
export const saasAisLinkerInfoList = (
  params: AisLinkerInfoQueryParam
): Promise<ResponseData<DataList<AisLinkerInfo>>> => {
  return request('/saas-base-app/saas/ais/linkerInfo/list', {
    method: 'GET',
    params
  })
}
//加载应用接口配置
export const saasAisLinkerConfigLoad = (params: {
  id: number // 主键ID
}): Promise<ResponseData<AisLinkerConfig>> => {
  return request('/saas-base-app/saas/ais/linkerConfig/load', {
    method: 'GET',
    params
  })
}
//加载应用接口
export const saasAisLinkerConfigLoadLinkerInfo = (params: {
  id: number // 主键ID
}): Promise<ResponseData<AisLinkerInfo>> => {
  return request('/saas-base-app/saas/ais/linkerConfig/loadLinkerInfo', {
    method: 'GET',
    params
  })
}
//应用接口配置列表(不分页)
export const saasAisLinkerConfigLiteList = (
  params: AisLinkerConfigQueryParam
): Promise<ResponseData<DataList<AisLinkerConfig>>> => {
  return request('/saas-base-app/saas/ais/linkerConfig/liteList', {
    method: 'GET',
    params
  })
}
//列表应用接口配置
export const saasAisLinkerConfigList = (
  params: AisLinkerConfigQueryParam
): Promise<ResponseData<DataList<AisLinkerConfig>>> => {
  return request('/saas-base-app/saas/ais/linkerConfig/list', {
    method: 'GET',
    params
  })
}
//查询数据历史
export const saasAisLinkerConfigListDataHistory = (
  params: SysDataHistoryQueryParam
): Promise<ResponseData<DataList<SysDataHistory>>> => {
  return request('/saas-base-app/saas/ais/linkerConfig/listDataHistory', {
    method: 'GET',
    params
  })
}
//查询操作日志
export const saasAisLinkerConfigListCritLog = (
  params: SysCritLogQueryParam
): Promise<ResponseData<DataList<SysCritLog>>> => {
  return request('/saas-base-app/saas/ais/linkerConfig/listCritLog', {
    method: 'GET',
    params
  })
}
//功能详情
export const saasAipVendorLoad = (params: {
  id: number // 主键ID
}): Promise<ResponseData<AipVendorInfoEx>> => {
  return request('/saas-base-app/saas/aip/vendor/load', {
    method: 'GET',
    params
  })
}
//功能列表
export const saasAipVendorList = (
  params: AipVendorInfoQueryParam
): Promise<ResponseData<DataList<AipVendorInfoEx>>> => {
  return request('/saas-base-app/saas/aip/vendor/list', {
    method: 'GET',
    params
  })
}
//应用套餐详情
export const saasAipProductLoad = (params: {
  id: number // 主键ID
}): Promise<ResponseData<AipProductInfoEx>> => {
  return request('/saas-base-app/saas/aip/product/load', {
    method: 'GET',
    params
  })
}
//应用套餐列表
export const saasAipProductList = (
  params: AipProductInfoQueryParam
): Promise<ResponseData<DataList<AipProductInfoEx>>> => {
  return request('/saas-base-app/saas/aip/product/list', {
    method: 'GET',
    params
  })
}
//加载Aip订单
export const saasAipOrderLoad = (params: {
  id: number // 主键ID
}): Promise<ResponseData<AipOrderInfoEx>> => {
  return request('/saas-base-app/saas/aip/order/load', {
    method: 'GET',
    params
  })
}
//列表Aip订单
export const saasAipOrderList = (
  params: AipOrderInfoQueryParam
): Promise<ResponseData<DataList<AipOrderInfoEx>>> => {
  return request('/saas-base-app/saas/aip/order/list', {
    method: 'GET',
    params
  })
}
//列表Aip订单明细
export const saasAipOrderListDetail = (
  params: AipOrderDetailQueryParam
): Promise<ResponseData<DataList<AipOrderDetail>>> => {
  return request('/saas-base-app/saas/aip/order/listDetail', {
    method: 'GET',
    params
  })
}
//加载Aip授权
export const saasAipLicenseLoad = (params: {
  id: number // 主键ID
}): Promise<ResponseData<AipLicenseInfo>> => {
  return request('/saas-base-app/saas/aip/license/load', {
    method: 'GET',
    params
  })
}
//列表Aip授权
export const saasAipLicenseList = (
  params: AipLicenseInfoQueryParam
): Promise<ResponseData<Array<AipLicenseInfoEx>>> => {
  return request('/saas-base-app/saas/aip/license/list', {
    method: 'GET',
    params
  })
}
//发票详情
export const saasAipInvoiceLoad = (params: {
  id: number // 申请记录编号
}): Promise<ResponseData<AipInvoiceInfoEx>> => {
  return request('/saas-base-app/saas/aip/invoice/load', {
    method: 'GET',
    params
  })
}
//发票申请列表
export const saasAipInvoiceList = (
  params: AipInvoiceInfoQueryParam
): Promise<ResponseData<DataList<AipInvoiceInfo>>> => {
  return request('/saas-base-app/saas/aip/invoice/list', {
    method: 'GET',
    params
  })
}
//列表交易记录
export const saasAipBalanceLogList = (
  params: AipBalanceLogQueryParam
): Promise<ResponseData<DataList<AipBalanceLog>>> => {
  return request('/saas-base-app/saas/aip/balanceLog/list', {
    method: 'GET',
    params
  })
}
//列表Aip余额信息
export const saasAipBalanceInfoListBalanceInfo = (): Promise<
  ResponseData<Array<AipBalanceInfo>>
> => {
  return request('/saas-base-app/saas/aip/balanceInfo/listBalanceInfo', {
    method: 'GET'
  })
}
//运营商充值消费折线图
export const saasAipBalanceInfoBalanceReport = (params: {
  statsDateBegin: string // 开始统计时间
  statsDateEnd: string // 结束统计时间
}): Promise<ResponseData<Array<AipBalanceReportStats>>> => {
  return request('/saas-base-app/saas/aip/balanceInfo/balanceReport', {
    method: 'GET',
    params
  })
}
//当前AIP余额信息
export const saasAipBalanceInfoBalanceInfo = (): Promise<
  ResponseData<AipBalanceInfo>
> => {
  return request('/saas-base-app/saas/aip/balanceInfo/balanceInfo', {
    method: 'GET'
  })
}
//列表广告内容表
export const saasAipAdList = (
  params: AipAdInfoQueryParam
): Promise<ResponseData<DataList<AipAdInfo>>> => {
  return request('/saas-base-app/saas/aip/ad/list', {
    method: 'GET',
    params
  })
}
//删除资质
export const saasSaasCertDelete = (params: {
  id: number // 主键ID
  remark: string // 备注
}): Promise<ResponseData<void>> => {
  return request('/saas-base-app/saas/saas/cert/delete', {
    method: 'DELETE',
    params
  })
}
//删除商户
export const saasPartnerMchInfoDelete = (params: {
  id: number // 主键ID
  remark: string // 备注
}): Promise<ResponseData<void>> => {
  return request('/saas-base-app/saas/partner/mchInfo/delete', {
    method: 'DELETE',
    params
  })
}
//删除商户等级信息
export const saasPartnerMchGradeDelete = (params: {
  id: number // 主键ID
  remark: string // 备注
}): Promise<ResponseData<void>> => {
  return request('/saas-base-app/saas/partner/mchGrade/delete', {
    method: 'DELETE',
    params
  })
}
//删除商户资质信息
export const saasPartnerMchCertDelete = (params: {
  id: number // 主键ID
  remark: string // 备注
}): Promise<ResponseData<void>> => {
  return request('/saas-base-app/saas/partner/mchCert/delete', {
    method: 'DELETE',
    params
  })
}
//删除文件
export const saasOssFileDelete = (params: {
  configSid?: string // 配置id
  id: number // 存储文件id
  forceDelete?: boolean // 强制删除
}): Promise<ResponseData<void>> => {
  return request('/saas-base-app/saas/oss/file/delete', {
    method: 'DELETE',
    params
  })
}
//删除运营商公告
export const saasNoticeSaasDelete = (params: {
  id: number // 主键ID
  remark: string // 备注
}): Promise<ResponseData<void>> => {
  return request('/saas-base-app/saas/notice/saas/delete', {
    method: 'DELETE',
    params
  })
}
//删除字典多语言
export const saasBaseDictLangDelete = (params: {
  id: number // 主键ID
  remark: string // 备注
}): Promise<ResponseData<void>> => {
  return request('/saas-base-app/saas/base/dict/lang/delete', {
    method: 'DELETE',
    params
  })
}
//删除字典
export const saasBaseDictDelete = (params: {
  id: number // 主键ID
  remark: string // 备注
}): Promise<ResponseData<void>> => {
  return request('/saas-base-app/saas/base/dict/delete', {
    method: 'DELETE',
    params
  })
}
//删除应用接口配置
export const saasAisLinkerConfigDelete = (params: {
  id: number // 主键ID
  remark: string // 备注
}): Promise<ResponseData<void>> => {
  return request('/saas-base-app/saas/ais/linkerConfig/delete', {
    method: 'DELETE',
    params
  })
}

//运营商信息
export interface SaasInfo {
  id?: number //主键ID
  saasName?: string //运营商名称
  saasLogo?: string //运营商logo
  orgType?: number //组织类型
  serviceType?: number //付费类型
  saasCurrency?: string //系统币种
  saasLang?: string //系统默认语言
  bdId?: number //招商负责人
  bdInfo?: string //招商负责人姓名
  opId?: number //运营负责人
  opInfo?: string //运营负责人姓名
  areaCode?: number //区域编码
  orgName?: string //机构名称
  orgDesc?: string //机构简介
  orgId?: string //机构号码
  orgAddress?: string //机构地址
  contactName?: string //公司联系人姓名
  contactPhone?: string //公司联系电话
  contactFax?: string //公司联系传真
  contactEmail?: string //公司联系邮箱
  contactMobile?: string //公司联系手机
  contactIm?: string //公司联系IM
  statsProductNum?: number //统计产品数
  statsOrderNum?: number //统计订单数
  statsOrderAmount?: number //统计订单额
  createDate?: string //创建时间
  modifyDate?: string //修改时间
  auditDate?: string //审核时间
  auditState?: number //审核状态
  lastLoginDate?: string //最后登录时间
  lastOrderDate?: string //最后下单时间
  state?: number //运营商状态
}
//商户信息
export interface SaasMchInfo {
  id?: number //主键ID
  saasId?: number //运营商编号
  mchType?: number //商户类型 1-供应商 2-分销商
  bdId?: number //关联业务员ID
  parentId?: number //上级ID
  agentId?: number //合伙人编号
  mchName?: string //商户名称
  mchLang?: string //语种类型
  mchCurrency?: string //货币类型
  gradeLevel?: number //商户等级Id
  contactName?: string //商户联系人
  contactPhone?: string //商户联系电话
  contactMobile?: string //商户联系手机
  contactEmail?: string //商户联系邮箱
  contactAddress?: string //公司地址
  mchDesc?: string //商户介绍
  mchConfig?: string //商户资源
  statsOrder?: number //总订单量
  statsMoney?: number //总订单金额
  statsProduct?: number //总销售量
  createDate?: string //创建时间
  modifyDate?: string //修改时间
  state?: number //状态
}
//商户等级
export interface SaasMchGrade {
  id?: number //主键ID
  saasId?: number //运营商编号
  mchType?: number //商户类型 1-供应商 2-分销商
  gradeName?: string //等级名称
  gradeLevel?: number //等级
  createDate?: string //创建时间
  modifyDate?: string //修改时间
  state?: number //状态
}
//商户证件信息
export interface SaasMchCert {
  id?: number //主键ID
  saasId?: number //运营商编号
  mchId?: number //商户编号
  certType?: string //证书类型
  certId?: string //证书编码
  certInfo?: string //证书信息
  certImg?: string //证书照片
  accessType?: number //访问类型
  startDate?: string //有效期开始时间
  endDate?: string //有效期结束时间
  createDate?: string //创建时间
  modifyDate?: string //修改日期
  auditState?: number //审批状态
  auditUserId?: number //审批人ID
  auditUserInfo?: string //审批人信息
  auditRemark?: string //审批信息
  auditDate?: string //审核时间
  state?: number //状态
}
//运营商公告
export interface SaasNoticeInfo {
  id?: number //主键ID
  saasId?: number //运营商编号
  accessType?: number //访问类型
  releaseType?: number //发布类型
  stick?: number //是否置顶 0 不置顶 1 置顶
  tags?: string //标签 用 , 分割
  title?: string //标题
  content?: string //公告内容
  viewNum?: number //点击数
  userId?: number //发布人
  userName?: string //发布人名称
  createDate?: string //创建时间
  releaseDate?: string //发布时间
  stickDate?: string //截止置顶时间
  modifyDate?: string //最后修改时间
  state?: number //状态
}
//支持工单信息
export interface SpsTicketInfo {
  id?: number //工单id
  saasId?: number //用户saasId
  userId?: number //用户id
  userType?: number //用户类型
  userAccount?: string //用户账号
  userInfo?: string //用户名
  userPhone?: string //手机号
  userEmail?: string //邮箱
  opId?: number //指定处理者id
  opInfo?: string //op信息
  appName?: string //应用名
  ticketTitle?: string //问题标题
  ticketContent?: string //问题内容
  ticketImg?: string //图片路径
  ticketTag?: string //问题描述标签
  ticketLevel?: number //紧急程度
  ticketRefType?: string //关联业务类型
  ticketRefId?: string //关联业务ID
  createDate?: string //创建时间
  lastUpdate?: string //最后更新时间
  state?: number //问题处理进度
}
//系统存储文件
export interface SysOssFile {
  id?: number //主键
  parentId?: number //父级ID
  saasId?: number //saas id
  mchId?: number //商户id
  configId?: number //配置id
  accessType?: number //访问类型
  fileInfo?: string //文件信息
  filePath?: string //文件路径
  fileType?: string //文件后缀
  fileSize?: number //文件大小
  fileHash?: string //文件hash
  refType?: string //关联表名
  refId?: string //关联表的id
  linkNum?: number //链接计数
  userId?: number //userId
  userInfo?: string //用户名
  userIp?: string //用户IP
  userType?: number //用户类型
  requestDate?: string //请求日期
  uploadDate?: string //上传日期
  expireDate?: string //过期日期
  lastUpdate?: string //更新时间
  state?: number //状态
}
//系统字典
export interface SysDictInfo {
  id?: number //主键
  saasId?: number //saasId
  parentId?: number //父级id
  dictCode?: string //字典项数值
  dictName?: string //字典项名称
  dictDesc?: string //字典项描述
  dictRank?: number //同一层级的排序
  createDate?: string //创建时间
  modifyDate?: string //修改日期
  state?: number //状态
}
//字典多语言
export interface SysDictLang {
  id?: number //主键
  saasId?: number //saasId
  dictId?: number //字典id
  dictName?: string //字典项名称
  dictDesc?: string //字典项描述
  langType?: string //多语言类型
  createDate?: string //创建时间
  modifyDate?: string //修改日期
  state?: number //状态
}
//AIS链接器配置
export interface AisLinkerConfig {
  id?: number //主键ID
  saasId?: number //SAAS ID
  mchId?: number //商户ID
  appName?: string //应用名
  linkerId?: number //链接器ID
  typeId?: number //类型ID
  configSid?: string //配置标识
  configName?: string //配置名称
  configDesc?: string //配置描述
  pubData?: string //公开配置
  apiData?: string //API配置
  sysData?: string //系统配置
  logData?: string //日志配置
  createDate?: string //创建时间
  modifyDate?: string //修改时间
  state?: number //状态
}
//运营商证件信息
export interface SaasCertInfo {
  id?: number //主键ID
  saasId?: number //运营商编号
  certType?: string //证书类型
  certId?: string //证书编码
  certInfo?: string //证书信息
  certImg?: string //证书照片
  accessType?: number //访问类型
  startDate?: string //有效期开始时间
  endDate?: string //有效期结束时间
  createDate?: string //创建时间
  modifyDate?: string //修改日期
  auditState?: number //审批状态
  auditRemark?: string //审批信息
  auditUserId?: number //审批人ID
  auditUserInfo?: string //审批人信息
  auditDate?: string //审核时间
  state?: number //状态
}
//
export interface MsgSmsVo {
  saasId?: number //运营商ID
  refType?: string //业务关联类
  refId?: string //业务关联id
  sentLimit?: number //发送限制
  scheduleDate?: string //计划发送时间
  mobile?: string //收信人手机号码
  content?: string //短信内容
  paramMap?: Record<string, string> //短信内容参数
}
//
export interface MsgMailVo {
  saasId?: number //运营商ID
  refType?: string //业务关联类
  refId?: string //业务关联id
  sentLimit?: number //发送限制
  scheduleDate?: string //计划发送时间
  fromAddress?: string //发信人地址
  toAddress?: string //收信人地址
  subject?: string //邮件标题
  content?: string //邮件内容(若为模板发送，该内容为模板替换json数据）
  isHtml?: number //邮件内容格式是否为html（0-否  1-是）
  attachment?: Record<string, string> //邮件附件
}
//支持工单事件
export interface SpsTicketEvent {
  id?: number //事件id
  saasId?: number //回复者saasId
  userId?: number //回复者id
  userType?: number //回复者用户类型
  userInfo?: string //回复者用户名
  ticketId?: number //问题id
  eventType?: number //事件类型
  eventBody?: string //回复内容
  eventImg?: string //图片
  createDate?: string //创建时间
  state?: number //状态
}
//Aip订单付款入参
export interface AipOrderPayParam {
  payConfigId?: number //支付渠道ID
  payChannel?: string //支付渠道类型
  payTradeType?: string //支付交易类型
  payCurrency?: string //货币类型 人民币:CNY;
  payAmount?: number //支付金额，单位分
  bizOrderExt?: string //应用订单扩展信息
  payRemark?: string //支付备注
  orderId?: number //订单id
}
//支付宝App支付信息
export interface AlipayAppPayInfo {
  tradeNo?: string //支付宝交易订单号
}
//支付操作响应体
export interface FinPayOrderResponse {
  payOrderId?: number //payOrderId
  saasId?: number //运营商id
  userId?: number //用户id
  userType?: number //用户类型
  userInfo?: string //用户信息
  userIp?: string //用户ip
  payConfigId?: number //支付配置id
  payChannel?: string //支付渠道
  payTradeType?: string //支付交易类型
  payDeviceId?: string //支付设备号
  payStoreInfo?: string //支付门店信息
  orderInfo?: string //业务订单信息
  orderCurrency?: string //订单货币类型
  orderAmount?: number //订单金额，单位分
  bizAppInfo?: string //业务应用信息
  bizOrderType?: string //应用订单类型
  bizOrderId?: string //业务订单id
  bizOrderExt?: string //业务扩展信息
  wxAppPayInfo?: WxAppPayInfo //
  alipayAppPayInfo?: AlipayAppPayInfo //
  scanPayInfo?: string //扫码支付信息
  mobileWebUrl?: string //移动端浏览器支付跳转链接
}
//微信App支付信息
export interface WxAppPayInfo {
  appId?: string //公众号或小程序appId
  timeStamp?: string //时间戳
  nonceStr?: string //随机串
  packageData?: string //数据包
  signType?: string //签名方式
  paySign?: string //支付签名
}
//AipVendor下单参数
export interface AipVendorOrderParam {
  vendorId?: number //服务id
  orderLicenseValue?: number //购买的授权数值
  orderLicensePeriod?: number //购买的授权期限(秒)
}
//AIP订单
export interface AipOrderInfo {
  id?: number //主键ID
  saasId?: number //运营商编号
  orderInfo?: string //产品名
  productId?: number //产品ID
  productNum?: number //产品数量
  productPrice?: number //产品价格
  orderCurrency?: string //币种类型
  orderAmount?: number //订单总价
  payAmount?: number //支付金额
  payInfoId?: string //支付id
  refundAmount?: number //退款金额
  remark?: string //备注
  userId?: number //支付用户
  userInfo?: string //用户信息
  userIp?: string //支付IP
  orderDate?: string //问题创建时间
  payDate?: string //支付时间
  executeDate?: string //执行时间
  finishDate?: string //执行完成时间
  refundDate?: string //退款时间
  state?: number //状态
}
//AIP授权
export interface AipLicenseInfo {
  id?: number //主键ID
  saasId?: number //运营商编号
  appName?: string //应用名
  vendorId?: number //功能id
  renewId?: number //续期ID
  vendorType?: number //功能类型
  vendorName?: string //服务名称
  vendorClass?: string //服务类
  licenseCode?: string //授权标识（授权名称）
  licenseAlertLimit?: number //授权报警限值
  licenseValue?: number //授权数值
  lastOrderDetailId?: number //最近订单明细ID
  lastOrderId?: number //最近订单ID
  effectDate?: string //生效时间
  expireDate?: string //过期时间
  createDate?: string //创建时间
  lastOrderDate?: string //最近重购时间
  lastConsumeDate?: string //最近扣费时间
  state?: number //状态
}
//AIP服务
export interface AipVendorInfo {
  id?: number //主键ID
  appName?: string //应用名称
  vendorName?: string //服务名称
  vendorIntro?: string //服务简介
  vendorDesc?: string //服务描述
  vendorRank?: number //服务排序
  vendorType?: number //服务类型
  vendorTag?: string //业务标签
  vendorImg?: string //服务图片
  vendorClass?: string //功能对应的类
  licenseCode?: string //授权代码
  licenseData?: string //授权data
  licenseAlertLimit?: number //授权报警限值
  licenseValue?: number //授权值
  licensePeriod?: number //限制时间，0不限制
  licenseUnit?: string //单位
  licenseCurrency?: string //授权币种
  licenseFee?: number //授权费用
  orderNum?: number //下单数量
  orderNumVirtual?: number //虚拟已售数量
  orderAmount?: number //下单金额
  createDate?: string //创建时间
  modifyDate?: string //更新时间
  state?: number //状态
}
//AipVendor下单参数
export interface AipVendorOrderPriceData {
  orderDate?: string //
  orderAmount?: number //订单价格
  vendorPriceList?: Array<VendorPriceData> //服务价格明细
}
//订单价格明细
export interface VendorPriceData {
  vendorInfo?: AipVendorInfo //
  licenseInfo?: AipLicenseInfo //
  licenseValue?: number //购买授权数值
  licensePeriod?: number //购买授权时间，0不限制
  periodDiscount?: number //时间折扣
  licenseFee?: number //服务价格
  effectDate?: string //生效时间
  expireDate?: string //失效时间
}
//AIP发票
export interface AipInvoiceInfo {
  id?: number //主键ID
  saasId?: number //运营商编号
  invoiceType?: number //发票类型（1-增值税普通发票 2-增值税专用发票）
  invoiceTitle?: string //发票抬头
  invoiceItem?: string //发票项目
  invoiceAmount?: number //发票金额
  invoiceTaxNum?: string //纳税人识别号
  invoiceCode?: string //发票号码
  invoiceUrl?: string //发票链接
  invoiceAddress?: string //地址
  invoicePhone?: string //电话
  bankName?: string //开户行
  bankNumber?: string //账号
  applyUserId?: number //申请人ID
  applyUserInfo?: string //申请人用户名
  applyRemark?: string //申请备注
  auditUserId?: number //审批人ID
  auditUserInfo?: string //审批人用户名
  auditRemark?: string //审批备注
  drawerId?: number //登记人ID
  drawerName?: string //登记人用户名
  drawerRemark?: string //登记备注
  consumeLogIds?: string //消费记录ID
  createDate?: string //创建时间
  makeDate?: string //开票时间
  lastUpdate?: string //最后更新时间
  state?: number //发票状态
}
//充值参数
export interface AipRechargeParam {
  payConfigId?: number //支付渠道ID
  payChannel?: string //支付渠道类型
  payTradeType?: string //支付交易类型
  payCurrency?: string //货币类型 人民币:CNY;
  payAmount?: number //支付金额，单位分
  bizOrderExt?: string //应用订单扩展信息
  payRemark?: string //支付备注
}
//充值退款参数
export interface AipRechargeRefundParam {
  rechargeLogId?: number //充值日志ID
  refundAmount?: number //退款金额，单位分
  refundRemark?: string //退款备注
}
//运营商证件信息列表查询参数
export interface SaasCertInfoQueryParam {
  id?: number //主键ID
  ids?: Array<number> //ID数组
  certType?: string //证书类型
  certId?: string //证书编码
  certInfo?: string //证书信息
  certImg?: string //证书照片
  accessType?: number //访问类型
  startDateRange?: Array<string> //有效期开始时间范围
  endDateRange?: Array<string> //有效期结束时间范围
  createDateRange?: Array<string> //创建时间范围
  modifyDateRange?: Array<string> //修改日期范围
  auditState?: number //审批状态
  auditRemark?: string //审批信息
  auditUserId?: number //审批人ID
  auditUserInfo?: string //审批人信息
  auditDateRange?: Array<string> //审核时间范围
  state?: number //状态
  states?: Array<number> //状态数组
  stateGte?: number //大于等于状态
  stateLte?: number //小于等于状态
  $pg?: number //当前页码
  $rn?: number //每页条数
  $si?: number //起始位置
  $rt?: number //请求类型
  $sn?: Array<string> //排序名称
  $st?: Array<number> //排序名称
}
//商户信息列表查询参数
export interface SaasMchInfoQueryParam {
  id?: number //主键ID
  ids?: Array<number> //ID数组
  mchType?: number //商户类型 1-供应商 2-分销商
  bdId?: number //关联业务员ID
  parentId?: number //上级ID
  agentId?: number //合伙人编号
  mchName?: string //商户名称
  mchLang?: string //语种类型
  mchCurrency?: string //货币类型
  gradeLevel?: number //商户等级Id
  gradeLevelRange?: Array<number> //商户等级Id范围
  contactName?: string //商户联系人
  contactPhone?: string //商户联系电话
  contactMobile?: string //商户联系手机
  contactEmail?: string //商户联系邮箱
  contactAddress?: string //公司地址
  statsOrder?: number //总订单量
  statsOrderRange?: Array<number> //总订单量范围
  statsMoney?: number //总订单金额
  statsMoneyRange?: Array<number> //总订单金额范围
  statsProduct?: number //总销售量
  statsProductRange?: Array<number> //总销售量范围
  createDateRange?: Array<string> //创建时间范围
  modifyDateRange?: Array<string> //修改时间范围
  state?: number //状态
  states?: Array<number> //状态数组
  stateGte?: number //大于等于状态
  stateLte?: number //小于等于状态
  $pg?: number //当前页码
  $rn?: number //每页条数
  $si?: number //起始位置
  $rt?: number //请求类型
  $sn?: Array<string> //排序名称
  $st?: Array<number> //排序名称
}
//系统数据历史列表查询参数
export interface SysDataHistoryQueryParam {
  mchId?: number //商户ID
  userId?: number //用户ID
  userType?: number //用户类型
  id?: number //ID
  ids?: Array<number> //数组ID
  groupId?: number //用户的组ID
  userName?: string //用户名称
  nickName?: string //用户昵称
  realName?: string //真实名称
  entityClass?: string //实体类
  entityId?: string //实体ID
  entityName?: string //实体名
  userIp?: string //用户IP
  createDateRange?: Array<string> //创建日期范围
  $pg?: number //当前页码
  $rn?: number //每页条数
  $si?: number //起始位置
  $rt?: number //请求类型
  $sn?: Array<string> //排序名称
  $st?: Array<number> //排序名称
}
//系统数据历史
export interface SysDataHistory {
  id?: number //ID
  saasId?: number //saasId
  mchId?: number //商户ID
  userId?: number //用户ID
  userType?: number //用户类型
  groupId?: number //用户的组ID
  userName?: string //用户名称
  nickName?: string //用户昵称
  realName?: string //真实名称
  entityClass?: string //实体类
  entityId?: string //实体ID
  entityName?: string //实体名
  entityData?: string //实体数据
  entityUpdateInfo?: string //实体修改信息
  remark?: string //备注信息
  userIp?: string //用户IP
  createDate?: string //创建日期
}
//系统关键日志列表查询参数
export interface SysCritLogQueryParam {
  mchId?: number //商户ID
  userId?: number //用户id
  userType?: number //用户类型
  id?: number //ID
  ids?: Array<number> //数组ID
  groupId?: number //用户组ID
  userName?: string //用户名
  nickName?: string //用户昵称
  realName?: string //真实名称
  userIp?: string //用户ip
  apiUri?: string //请求uri
  apiName?: string //API名称
  bizType?: string //业务类型
  bizId?: string //业务ID
  requestDateRange?: Array<string> //请求时间范围
  responseState?: string //响应状态
  responseCode?: string //响应代码
  responseMillis?: number //请求毫秒数
  responseMillisRange?: Array<number> //请求毫秒数范围
  statusCode?: number //响应状态码
  statusCodeRange?: Array<number> //响应状态码范围
  appInfo?: string //应用信息
  appHost?: string //应用主机
  $pg?: number //当前页码
  $rn?: number //每页条数
  $si?: number //起始位置
  $rt?: number //请求类型
  $sn?: Array<string> //排序名称
  $st?: Array<number> //排序名称
}
//系统关键日志
export interface SysCritLog {
  id?: number //ID
  saasId?: number //saasId
  mchId?: number //商户ID
  userId?: number //用户id
  userType?: number //用户类型
  groupId?: number //用户组ID
  userName?: string //用户名
  nickName?: string //用户昵称
  realName?: string //真实名称
  userIp?: string //用户ip
  apiUri?: string //请求uri
  apiName?: string //API名称
  bizType?: string //业务类型
  bizId?: string //业务ID
  bizLog?: string //业务日志
  requestDate?: string //请求时间
  requestBody?: string //请求参数
  responseState?: string //响应状态
  responseCode?: string //响应代码
  responseMsg?: string //响应消息
  responseBody?: string //响应日志
  responseMillis?: number //请求毫秒数
  statusCode?: number //响应状态码
  appInfo?: string //应用信息
  appHost?: string //应用主机
}
//商户等级列表查询参数
export interface SaasMchGradeQueryParam {
  id?: number //主键ID
  ids?: Array<number> //ID数组
  mchType?: number //商户类型 1-供应商 2-分销商
  gradeName?: string //等级名称
  gradeLevel?: number //等级
  gradeLevelRange?: Array<number> //等级范围
  createDateRange?: Array<string> //创建时间范围
  modifyDateRange?: Array<string> //修改时间范围
  state?: number //状态
  states?: Array<number> //状态数组
  stateGte?: number //大于等于状态
  stateLte?: number //小于等于状态
  $pg?: number //当前页码
  $rn?: number //每页条数
  $si?: number //起始位置
  $rt?: number //请求类型
  $sn?: Array<string> //排序名称
  $st?: Array<number> //排序名称
}
//商户证件信息列表查询参数
export interface SaasMchCertQueryParam {
  mchId?: number //商户编号
  id?: number //主键ID
  ids?: Array<number> //ID数组
  certType?: string //证书类型
  certId?: string //证书编码
  certInfo?: string //证书信息
  certImg?: string //证书照片
  accessType?: number //访问类型
  startDateRange?: Array<string> //有效期开始时间范围
  endDateRange?: Array<string> //有效期结束时间范围
  createDateRange?: Array<string> //创建时间范围
  modifyDateRange?: Array<string> //修改日期范围
  auditState?: number //审批状态
  auditUserId?: number //审批人ID
  auditUserInfo?: string //审批人信息
  auditRemark?: string //审批信息
  auditDateRange?: Array<string> //审核时间范围
  state?: number //状态
  states?: Array<number> //状态数组
  stateGte?: number //大于等于状态
  stateLte?: number //小于等于状态
  $pg?: number //当前页码
  $rn?: number //每页条数
  $si?: number //起始位置
  $rt?: number //请求类型
  $sn?: Array<string> //排序名称
  $st?: Array<number> //排序名称
}
//文件信息统计信息
export interface FileStatsInfo {
  statsKey?: string //分组Key
  fileNum?: number //文件个数
  fileSize?: number //文件大小
}
//系统存储文件列表查询参数
export interface SysOssFileQueryParam {
  mchId?: number //商户id
  userId?: number //userId
  userType?: number //用户类型
  id?: number //主键
  ids?: Array<number> //ID数组
  parentId?: number //父级ID
  configId?: number //配置id
  accessType?: number //访问类型
  fileInfo?: string //文件信息
  filePath?: string //文件路径
  fileType?: string //文件后缀
  fileSize?: number //文件大小
  fileSizeRange?: Array<number> //文件大小范围
  fileHash?: string //文件hash
  refType?: string //关联表名
  refId?: string //关联表的id
  linkNum?: number //链接计数
  linkNumRange?: Array<number> //链接计数范围
  userInfo?: string //用户名
  userIp?: string //用户IP
  requestDateRange?: Array<string> //请求日期范围
  uploadDateRange?: Array<string> //上传日期范围
  expireDateRange?: Array<string> //过期日期范围
  lastUpdateRange?: Array<string> //更新时间范围
  state?: number //状态
  states?: Array<number> //状态数组
  stateGte?: number //大于等于状态
  stateLte?: number //小于等于状态
  $pg?: number //当前页码
  $rn?: number //每页条数
  $si?: number //起始位置
  $rt?: number //请求类型
  $sn?: Array<string> //排序名称
  $st?: Array<number> //排序名称
}
//运营商公告列表查询参数
export interface SaasNoticeInfoQueryParam {
  userId?: number //发布人
  id?: number //主键ID
  ids?: Array<number> //ID数组
  accessType?: number //访问类型
  releaseType?: number //发布类型
  stick?: number //是否置顶 0 不置顶 1 置顶
  stickRange?: Array<number> //是否置顶 0 不置顶 1 置顶范围
  tags?: string //标签 用 , 分割
  title?: string //标题
  viewNum?: number //点击数
  viewNumRange?: Array<number> //点击数范围
  userName?: string //发布人名称
  createDateRange?: Array<string> //创建时间范围
  releaseDateRange?: Array<string> //发布时间范围
  stickDateRange?: Array<string> //截止置顶时间范围
  modifyDateRange?: Array<string> //最后修改时间范围
  state?: number //状态
  states?: Array<number> //状态数组
  stateGte?: number //大于等于状态
  stateLte?: number //小于等于状态
  $pg?: number //当前页码
  $rn?: number //每页条数
  $si?: number //起始位置
  $rt?: number //请求类型
  $sn?: Array<string> //排序名称
  $st?: Array<number> //排序名称
}
//短信通知记录列表查询参数
export interface MsgSmsHistoryQueryParam {
  id?: number //主键ID
  ids?: Array<number> //ID数组
  configId?: number //发送短信使用的配置
  sendTag?: string //接口发送id
  refType?: string //业务关联类
  refId?: string //业务关联ID
  mobile?: string //收信人手机号码
  content?: string //短信内容
  createDateRange?: Array<string> //创建时间范围
  scheduleDateRange?: Array<string> //计划发送时间范围
  sentDateRange?: Array<string> //发送时间范围
  sentTimes?: number //发送次数
  sentTimesRange?: Array<number> //发送次数范围
  sentLimit?: number //发送限制
  sentLimitRange?: Array<number> //发送限制范围
  state?: number //短信发送状态
  states?: Array<number> //短信发送状态数组
  stateGte?: number //大于等于短信发送状态
  stateLte?: number //小于等于短信发送状态
  $pg?: number //当前页码
  $rn?: number //每页条数
  $si?: number //起始位置
  $rt?: number //请求类型
  $sn?: Array<string> //排序名称
  $st?: Array<number> //排序名称
}
//短信通知记录
export interface MsgSmsHistory {
  id?: number //主键ID
  saasId?: number //运营商ID
  configId?: number //发送短信使用的配置
  sendTag?: string //接口发送id
  refType?: string //业务关联类
  refId?: string //业务关联ID
  mobile?: string //收信人手机号码
  content?: string //短信内容
  createDate?: string //创建时间
  scheduleDate?: string //计划发送时间
  sentDate?: string //发送时间
  sentTimes?: number //发送次数
  sentLimit?: number //发送限制
  errorMsg?: string //错误消息
  state?: number //短信发送状态
}
//短信通知记录列表查询参数
export interface MsgSmsQueueQueryParam {
  id?: number //主键ID
  ids?: Array<number> //ID数组
  configId?: number //发送短信使用的配置
  sendTag?: string //接口发送id
  refType?: string //业务关联类
  refId?: string //业务关联ID
  mobile?: string //收信人手机号码
  content?: string //短信内容
  createDateRange?: Array<string> //创建时间范围
  scheduleDateRange?: Array<string> //计划发送时间范围
  sentDateRange?: Array<string> //发送时间范围
  sentTimes?: number //发送次数
  sentTimesRange?: Array<number> //发送次数范围
  sentLimit?: number //发送限制
  sentLimitRange?: Array<number> //发送限制范围
  state?: number //短信发送状态
  states?: Array<number> //短信发送状态数组
  stateGte?: number //大于等于短信发送状态
  stateLte?: number //小于等于短信发送状态
  $pg?: number //当前页码
  $rn?: number //每页条数
  $si?: number //起始位置
  $rt?: number //请求类型
  $sn?: Array<string> //排序名称
  $st?: Array<number> //排序名称
}
//短信通知记录
export interface MsgSmsQueue {
  id?: number //主键ID
  saasId?: number //运营商ID
  configId?: number //发送短信使用的配置
  sendTag?: string //接口发送id
  refType?: string //业务关联类
  refId?: string //业务关联ID
  mobile?: string //收信人手机号码
  content?: string //短信内容
  createDate?: string //创建时间
  scheduleDate?: string //计划发送时间
  sentDate?: string //发送时间
  sentTimes?: number //发送次数
  sentLimit?: number //发送限制
  errorMsg?: string //错误消息
  state?: number //短信发送状态
}
//邮件通知记录列表查询参数
export interface MsgMailHistoryQueryParam {
  id?: number //
  ids?: Array<number> //ID数组
  configId?: number //发送mail使用的配置
  sendTag?: string //邮件发送ID
  refType?: string //业务关联类
  refId?: string //业务关联id
  fromAddress?: string //发信人地址
  toAddress?: string //收信人地址
  subject?: string //邮件标题
  isHtml?: number //邮件内容格式是否为html（0-否  1-是）
  isHtmlRange?: Array<number> //邮件内容格式是否为html（0-否  1-是）范围
  createDateRange?: Array<string> //创建时间范围
  scheduleDateRange?: Array<string> //计划发送时间范围
  sentDateRange?: Array<string> //发送时间范围
  sentTimes?: number //发送次数
  sentTimesRange?: Array<number> //发送次数范围
  sentLimit?: number //发送限制
  sentLimitRange?: Array<number> //发送限制范围
  state?: number //邮件发送状态
  states?: Array<number> //邮件发送状态数组
  stateGte?: number //大于等于邮件发送状态
  stateLte?: number //小于等于邮件发送状态
  $pg?: number //当前页码
  $rn?: number //每页条数
  $si?: number //起始位置
  $rt?: number //请求类型
  $sn?: Array<string> //排序名称
  $st?: Array<number> //排序名称
}
//邮件通知记录
export interface MsgMailHistory {
  id?: number //
  saasId?: number //运营商ID
  configId?: number //发送mail使用的配置
  sendTag?: string //邮件发送ID
  refType?: string //业务关联类
  refId?: string //业务关联id
  fromAddress?: string //发信人地址
  toAddress?: string //收信人地址
  subject?: string //邮件标题
  content?: string //邮件内容(若为模板发送，该内容为模板替换json数据）
  isHtml?: number //邮件内容格式是否为html（0-否  1-是）
  attachment?: string //邮件附件地址
  createDate?: string //创建时间
  scheduleDate?: string //计划发送时间
  sentDate?: string //发送时间
  sentTimes?: number //发送次数
  sentLimit?: number //发送限制
  errorMsg?: string //错误信息
  state?: number //邮件发送状态
}
//邮件通知记录列表查询参数
export interface MsgMailQueueQueryParam {
  id?: number //
  ids?: Array<number> //ID数组
  configId?: number //发送mail使用的配置
  sendTag?: string //邮件发送ID
  refType?: string //业务关联类
  refId?: string //业务关联id
  fromAddress?: string //发信人地址
  toAddress?: string //收信人地址
  subject?: string //邮件标题
  isHtml?: number //邮件内容格式是否为html（0-否  1-是）
  isHtmlRange?: Array<number> //邮件内容格式是否为html（0-否  1-是）范围
  createDateRange?: Array<string> //创建时间范围
  scheduleDateRange?: Array<string> //计划发送时间范围
  sentDateRange?: Array<string> //发送时间范围
  sentTimes?: number //发送次数
  sentTimesRange?: Array<number> //发送次数范围
  sentLimit?: number //发送限制
  sentLimitRange?: Array<number> //发送限制范围
  state?: number //邮件发送状态
  states?: Array<number> //邮件发送状态数组
  stateGte?: number //大于等于邮件发送状态
  stateLte?: number //小于等于邮件发送状态
  $pg?: number //当前页码
  $rn?: number //每页条数
  $si?: number //起始位置
  $rt?: number //请求类型
  $sn?: Array<string> //排序名称
  $st?: Array<number> //排序名称
}
//邮件通知记录
export interface MsgMailQueue {
  id?: number //
  saasId?: number //运营商ID
  configId?: number //发送mail使用的配置
  sendTag?: string //邮件发送ID
  refType?: string //业务关联类
  refId?: string //业务关联id
  fromAddress?: string //发信人地址
  toAddress?: string //收信人地址
  subject?: string //邮件标题
  content?: string //邮件内容(若为模板发送，该内容为模板替换json数据）
  isHtml?: number //邮件内容格式是否为html（0-否  1-是）
  attachment?: string //邮件附件地址
  createDate?: string //创建时间
  scheduleDate?: string //计划发送时间
  sentDate?: string //发送时间
  sentTimes?: number //发送次数
  sentLimit?: number //发送限制
  errorMsg?: string //错误信息
  state?: number //邮件发送状态
}
//数据
export interface SpsTicketInfoEx {
  id?: number //工单id
  saasId?: number //用户saasId
  userId?: number //用户id
  userType?: number //用户类型
  userAccount?: string //用户账号
  userInfo?: string //用户名
  userPhone?: string //手机号
  userEmail?: string //邮箱
  opId?: number //指定处理者id
  opInfo?: string //op信息
  appName?: string //应用名
  ticketTitle?: string //问题标题
  ticketContent?: string //问题内容
  ticketImg?: string //图片路径
  ticketTag?: string //问题描述标签
  ticketLevel?: number //紧急程度
  ticketRefType?: string //关联业务类型
  ticketRefId?: string //关联业务ID
  createDate?: string //创建时间
  lastUpdate?: string //最后更新时间
  state?: number //问题处理进度
  saasName?: string //
}
//支持工单信息列表查询参数
export interface SpsTicketInfoQueryParam {
  userId?: number //用户id
  userType?: number //用户类型
  id?: number //工单id
  ids?: Array<number> //ID数组
  userAccount?: string //用户账号
  userInfo?: string //用户名
  userPhone?: string //手机号
  userEmail?: string //邮箱
  opId?: number //指定处理者id
  opInfo?: string //op信息
  appName?: string //应用名
  ticketTitle?: string //问题标题
  ticketTag?: string //问题描述标签
  ticketLevel?: number //紧急程度
  ticketLevelRange?: Array<number> //紧急程度范围
  ticketRefType?: string //关联业务类型
  ticketRefId?: string //关联业务ID
  createDateRange?: Array<string> //创建时间范围
  lastUpdateRange?: Array<string> //最后更新时间范围
  state?: number //问题处理进度
  states?: Array<number> //问题处理进度数组
  stateGte?: number //大于等于问题处理进度
  stateLte?: number //小于等于问题处理进度
  $pg?: number //当前页码
  $rn?: number //每页条数
  $si?: number //起始位置
  $rt?: number //请求类型
  $sn?: Array<string> //排序名称
  $st?: Array<number> //排序名称
}
//支持工单事件列表查询参数
export interface SpsTicketEventQueryParam {
  userId?: number //回复者id
  userType?: number //回复者用户类型
  id?: number //事件id
  ids?: Array<number> //ID数组
  userInfo?: string //回复者用户名
  ticketId?: number //问题id
  eventType?: number //事件类型
  createDateRange?: Array<string> //创建时间范围
  state?: number //状态
  states?: Array<number> //状态数组
  stateGte?: number //大于等于状态
  stateLte?: number //小于等于状态
  $pg?: number //当前页码
  $rn?: number //每页条数
  $si?: number //起始位置
  $rt?: number //请求类型
  $sn?: Array<string> //排序名称
  $st?: Array<number> //排序名称
}
//预签名返回参数
export interface OssUploadParam {
  id?: number //文件ID
  key?: string //文件名
  ossHost?: string //上传主机
  uploadParam?: Record<string, string> //上传参数
}
//运营商商户简单信息
export interface SaasMchSimpleInfo {
  id?: number //主键ID
  saasId?: number //运营商编号
  mchType?: number //商户类型 1-供应商 2-分销商
  mchName?: string //商户名称
  gradeLevel?: number //商户等级Id
}
//系统字典列表查询参数
export interface SysDictInfoQueryParam {
  id?: number //主键
  ids?: Array<number> //ID数组
  parentId?: number //父级id
  dictCode?: string //字典项数值
  dictName?: string //字典项名称
  dictDesc?: string //字典项描述
  dictRank?: number //同一层级的排序
  dictRankRange?: Array<number> //同一层级的排序范围
  createDateRange?: Array<string> //创建时间范围
  modifyDateRange?: Array<string> //修改日期范围
  state?: number //状态
  states?: Array<number> //状态数组
  stateGte?: number //大于等于状态
  stateLte?: number //小于等于状态
  $pg?: number //当前页码
  $rn?: number //每页条数
  $si?: number //起始位置
  $rt?: number //请求类型
  $sn?: Array<string> //排序名称
  $st?: Array<number> //排序名称
}
//字典多语言列表查询参数
export interface SysDictLangQueryParam {
  id?: number //主键
  ids?: Array<number> //ID数组
  dictId?: number //字典id
  dictName?: string //字典项名称
  dictDesc?: string //字典项描述
  langType?: string //多语言类型
  createDateRange?: Array<string> //创建时间范围
  modifyDateRange?: Array<string> //修改日期范围
  state?: number //状态
  states?: Array<number> //状态数组
  stateGte?: number //大于等于状态
  stateLte?: number //小于等于状态
  $pg?: number //当前页码
  $rn?: number //每页条数
  $si?: number //起始位置
  $rt?: number //请求类型
  $sn?: Array<string> //排序名称
  $st?: Array<number> //排序名称
}
//AIS链接器信息列表查询参数
export interface AisLinkerInfoQueryParam {
  id?: number //主键ID
  ids?: Array<number> //ID数组
  appName?: string //应用名
  typeId?: number //类型ID
  typeClass?: string //类型类
  linkerClass?: string //链接器类
  linkerName?: string //链接器名
  linkerVersion?: string //链接器版本
  linkerIcon?: string //AIS图标
  devInfo?: string //开发者信息
  createDateRange?: Array<string> //创建时间范围
  modifyDateRange?: Array<string> //修改时间范围
  state?: number //状态
  states?: Array<number> //状态数组
  stateGte?: number //大于等于状态
  stateLte?: number //小于等于状态
  $pg?: number //当前页码
  $rn?: number //每页条数
  $si?: number //起始位置
  $rt?: number //请求类型
  $sn?: Array<string> //排序名称
  $st?: Array<number> //排序名称
}
//AIS链接器信息
export interface AisLinkerInfo {
  id?: number //主键ID
  appName?: string //应用名
  typeId?: number //类型ID
  typeClass?: string //类型类
  linkerClass?: string //链接器类
  linkerName?: string //链接器名
  linkerVersion?: string //链接器版本
  linkerFunction?: string //链接器功能
  linkerDesc?: string //链接器描述
  linkerIcon?: string //AIS图标
  pubParam?: string //公开配置
  apiParam?: string //API配置
  sysParam?: string //系统配置
  logParam?: string //日志配置
  devInfo?: string //开发者信息
  createDate?: string //创建时间
  modifyDate?: string //修改时间
  state?: number //状态
}
//AIS链接器配置列表查询参数
export interface AisLinkerConfigQueryParam {
  mchId?: number //商户ID
  id?: number //主键ID
  ids?: Array<number> //ID数组
  appName?: string //应用名
  linkerId?: number //链接器ID
  linkerClass?: string //链接器类
  typeId?: number //类型ID
  typeClass?: string //类型类
  configSid?: string //配置标识
  configName?: string //配置名称
  createDateRange?: Array<string> //创建时间范围
  modifyDateRange?: Array<string> //修改时间范围
  state?: number //状态
  states?: Array<number> //状态数组
  stateGte?: number //大于等于状态
  stateLte?: number //小于等于状态
  $pg?: number //当前页码
  $rn?: number //每页条数
  $si?: number //起始位置
  $rt?: number //请求类型
  $sn?: Array<string> //排序名称
  $st?: Array<number> //排序名称
}
//数据
export interface AipVendorInfoEx {
  id?: number //主键ID
  appName?: string //应用名称
  vendorName?: string //服务名称
  vendorIntro?: string //服务简介
  vendorDesc?: string //服务描述
  vendorRank?: number //服务排序
  vendorType?: number //服务类型
  vendorTag?: string //业务标签
  vendorImg?: string //服务图片
  vendorClass?: string //功能对应的类
  licenseCode?: string //授权代码
  licenseData?: string //授权data
  licenseAlertLimit?: number //授权报警限值
  licenseValue?: number //授权值
  licensePeriod?: number //限制时间，0不限制
  licenseUnit?: string //单位
  licenseCurrency?: string //授权币种
  licenseFee?: number //授权费用
  orderNum?: number //下单数量
  orderNumVirtual?: number //虚拟已售数量
  orderAmount?: number //下单金额
  createDate?: string //创建时间
  modifyDate?: string //更新时间
  state?: number //状态
  subList?: Array<AipVendorInfoEx> //下级服务
}
//AIP服务列表查询参数
export interface AipVendorInfoQueryParam {
  id?: number //主键ID
  ids?: Array<number> //ID数组
  appName?: string //应用名称
  vendorName?: string //服务名称
  vendorRank?: number //服务排序
  vendorRankRange?: Array<number> //服务排序范围
  vendorType?: number //服务类型
  vendorTag?: string //业务标签
  vendorImg?: string //服务图片
  vendorClass?: string //功能对应的类
  licenseCode?: string //授权代码
  licenseAlertLimit?: number //授权报警限值
  licenseAlertLimitRange?: Array<number> //授权报警限值范围
  licenseValue?: number //授权值
  licenseValueRange?: Array<number> //授权值范围
  licensePeriod?: number //限制时间，0不限制
  licensePeriodRange?: Array<number> //限制时间，0不限制范围
  licenseUnit?: string //单位
  licenseCurrency?: string //授权币种
  licenseFee?: number //授权费用
  licenseFeeRange?: Array<number> //授权费用范围
  orderNum?: number //下单数量
  orderNumRange?: Array<number> //下单数量范围
  orderNumVirtual?: number //虚拟已售数量
  orderNumVirtualRange?: Array<number> //虚拟已售数量范围
  orderAmount?: number //下单金额
  orderAmountRange?: Array<number> //下单金额范围
  createDateRange?: Array<string> //创建时间范围
  modifyDateRange?: Array<string> //更新时间范围
  state?: number //状态
  states?: Array<number> //状态数组
  stateGte?: number //大于等于状态
  stateLte?: number //小于等于状态
  $pg?: number //当前页码
  $rn?: number //每页条数
  $si?: number //起始位置
  $rt?: number //请求类型
  $sn?: Array<string> //排序名称
  $st?: Array<number> //排序名称
}
//AIP产品明细
export interface AipProductDetail {
  id?: number //主键ID
  productId?: number //产品ID
  vendorRank?: number //排序
  appName?: string //功能对应的应用
  vendorId?: number //功能对应的类
  vendorType?: number //服务类型
  vendorName?: string //服务名
  vendorClass?: string //服务类
  licenseCode?: string //授权代码
  licenseValue?: number //授权值
  licensePeriod?: number //授权时间段
  licenseUnit?: string //单位
  licenseCurrency?: string //授权币种
  licenseFee?: number //服务费
  createDate?: string //创建时间
  modifyDate?: string //更新时间
  state?: number //状态：-1（删除）、0（未生效）、1（已生效）
}
//数据
export interface AipProductInfoEx {
  id?: number //主键ID
  productName?: string //功能对应的应用
  productIntro?: string //功能简介
  productDesc?: string //功能简介
  productRank?: number //排序
  productTag?: string //业务标签
  productUnit?: string //单位
  productCurrency?: string //货币类型
  productPrice?: number //功能价格(分)
  productImg?: string //主图地址
  startSaleDate?: string //开始销售时间
  endSaleDate?: string //结束销售时间
  stockNum?: number //总库存量
  bookLimitNum?: number //预定限制数量
  orderAmount?: number //已售金额
  orderNum?: number //已售数量
  orderNumVirtual?: number //虚拟已售数量
  createDate?: string //创建时间
  modifyDate?: string //更新时间
  state?: number //状态
  productDetailList?: Array<AipProductDetail> //产品详情列表
}
//AIP产品列表查询参数
export interface AipProductInfoQueryParam {
  id?: number //主键ID
  ids?: Array<number> //ID数组
  productName?: string //功能对应的应用
  productIntro?: string //功能简介
  productRank?: number //排序
  productRankRange?: Array<number> //排序范围
  productTag?: string //业务标签
  productUnit?: string //单位
  productCurrency?: string //货币类型
  productPrice?: number //功能价格(分)
  productPriceRange?: Array<number> //功能价格(分)范围
  productImg?: string //主图地址
  startSaleDateRange?: Array<string> //开始销售时间范围
  endSaleDateRange?: Array<string> //结束销售时间范围
  stockNum?: number //总库存量
  stockNumRange?: Array<number> //总库存量范围
  bookLimitNum?: number //预定限制数量
  bookLimitNumRange?: Array<number> //预定限制数量范围
  orderAmount?: number //已售金额
  orderAmountRange?: Array<number> //已售金额范围
  orderNum?: number //已售数量
  orderNumRange?: Array<number> //已售数量范围
  orderNumVirtual?: number //虚拟已售数量
  orderNumVirtualRange?: Array<number> //虚拟已售数量范围
  createDateRange?: Array<string> //创建时间范围
  modifyDateRange?: Array<string> //更新时间范围
  state?: number //状态
  states?: Array<number> //状态数组
  stateGte?: number //大于等于状态
  stateLte?: number //小于等于状态
  $pg?: number //当前页码
  $rn?: number //每页条数
  $si?: number //起始位置
  $rt?: number //请求类型
  $sn?: Array<string> //排序名称
  $st?: Array<number> //排序名称
}
//AIP订单明细
export interface AipOrderDetail {
  id?: number //主键ID
  saasId?: number //运营商编号
  orderId?: number //订单ID
  appName?: string //功能对应的应用
  vendorId?: number //服务ID
  vendorType?: number //服务类型
  vendorName?: string //服务名
  vendorClass?: string //服务类
  executeParam?: string //运行参数
  licenseId?: number //boss授权Id
  licenseCode?: string //授权代码
  licenseValue?: number //授权值
  licensePeriod?: number //限制时间
  licenseUnit?: string //单位
  licenseCurrency?: string //授权币种
  licenseFee?: number //服务费
  licenseEffectDate?: string //生效时间
  licenseExpireDate?: string //过期时间
  executeLog?: string //授权日志
  createDate?: string //创建时间
  executeDate?: string //更新时间
  finishDate?: string //完成时间
  state?: number //状态
}
//数据
export interface AipOrderInfoEx {
  id?: number //主键ID
  saasId?: number //运营商编号
  orderInfo?: string //产品名
  productId?: number //产品ID
  productNum?: number //产品数量
  productPrice?: number //产品价格
  orderCurrency?: string //币种类型
  orderAmount?: number //订单总价
  payAmount?: number //支付金额
  payInfoId?: string //支付id
  refundAmount?: number //退款金额
  remark?: string //备注
  userId?: number //支付用户
  userInfo?: string //用户信息
  userIp?: string //支付IP
  orderDate?: string //问题创建时间
  payDate?: string //支付时间
  executeDate?: string //执行时间
  finishDate?: string //执行完成时间
  refundDate?: string //退款时间
  state?: number //状态
  orderDetailList?: Array<AipOrderDetail> //订单详情列表
  saasName?: string //运营商名称
}
//AIP订单列表查询参数
export interface AipOrderInfoQueryParam {
  userId?: number //支付用户
  id?: number //主键ID
  ids?: Array<number> //ID数组
  orderInfo?: string //产品名
  productId?: number //产品ID
  productNum?: number //产品数量
  productNumRange?: Array<number> //产品数量范围
  productPrice?: number //产品价格
  productPriceRange?: Array<number> //产品价格范围
  orderCurrency?: string //币种类型
  orderAmount?: number //订单总价
  orderAmountRange?: Array<number> //订单总价范围
  payAmount?: number //支付金额
  payAmountRange?: Array<number> //支付金额范围
  payInfoId?: string //支付id
  refundAmount?: number //退款金额
  refundAmountRange?: Array<number> //退款金额范围
  userInfo?: string //用户信息
  userIp?: string //支付IP
  orderDateRange?: Array<string> //问题创建时间范围
  payDateRange?: Array<string> //支付时间范围
  executeDateRange?: Array<string> //执行时间范围
  finishDateRange?: Array<string> //执行完成时间范围
  refundDateRange?: Array<string> //退款时间范围
  state?: number //状态
  states?: Array<number> //状态数组
  stateGte?: number //大于等于状态
  stateLte?: number //小于等于状态
  $pg?: number //当前页码
  $rn?: number //每页条数
  $si?: number //起始位置
  $rt?: number //请求类型
  $sn?: Array<string> //排序名称
  $st?: Array<number> //排序名称
}
//AIP订单明细列表查询参数
export interface AipOrderDetailQueryParam {
  id?: number //主键ID
  ids?: Array<number> //ID数组
  orderId?: number //订单ID
  appName?: string //功能对应的应用
  vendorId?: number //服务ID
  vendorType?: number //服务类型
  vendorName?: string //服务名
  vendorClass?: string //服务类
  licenseId?: number //boss授权Id
  licenseCode?: string //授权代码
  licenseValue?: number //授权值
  licenseValueRange?: Array<number> //授权值范围
  licensePeriod?: number //限制时间
  licensePeriodRange?: Array<number> //限制时间范围
  licenseUnit?: string //单位
  licenseCurrency?: string //授权币种
  licenseFee?: number //服务费
  licenseFeeRange?: Array<number> //服务费范围
  licenseEffectDateRange?: Array<string> //生效时间范围
  licenseExpireDateRange?: Array<string> //过期时间范围
  createDateRange?: Array<string> //创建时间范围
  executeDateRange?: Array<string> //更新时间范围
  finishDateRange?: Array<string> //完成时间范围
  state?: number //状态
  states?: Array<number> //状态数组
  stateGte?: number //大于等于状态
  stateLte?: number //小于等于状态
  $pg?: number //当前页码
  $rn?: number //每页条数
  $si?: number //起始位置
  $rt?: number //请求类型
  $sn?: Array<string> //排序名称
  $st?: Array<number> //排序名称
}
//AIP授权列表查询参数
export interface AipLicenseInfoQueryParam {
  id?: number //主键ID
  ids?: Array<number> //ID数组
  appName?: string //应用名
  vendorId?: number //功能id
  renewId?: number //续期ID
  vendorType?: number //功能类型
  vendorName?: string //服务名称
  vendorClass?: string //服务类
  licenseCode?: string //授权标识（授权名称）
  licenseAlertLimit?: number //授权报警限值
  licenseAlertLimitRange?: Array<number> //授权报警限值范围
  licenseValue?: number //授权数值
  licenseValueRange?: Array<number> //授权数值范围
  lastOrderDetailId?: number //最近订单明细ID
  lastOrderId?: number //最近订单ID
  effectDateRange?: Array<string> //生效时间范围
  expireDateRange?: Array<string> //过期时间范围
  createDateRange?: Array<string> //创建时间范围
  lastOrderDateRange?: Array<string> //最近重购时间范围
  lastConsumeDateRange?: Array<string> //最近扣费时间范围
  state?: number //状态
  states?: Array<number> //状态数组
  stateGte?: number //大于等于状态
  stateLte?: number //小于等于状态
  $pg?: number //当前页码
  $rn?: number //每页条数
  $si?: number //起始位置
  $rt?: number //请求类型
  $sn?: Array<string> //排序名称
  $st?: Array<number> //排序名称
}
//
export interface AipLicenseInfoEx {
  id?: number //主键ID
  saasId?: number //运营商编号
  appName?: string //应用名
  vendorId?: number //功能id
  renewId?: number //续期ID
  vendorType?: number //功能类型
  vendorName?: string //服务名称
  vendorClass?: string //服务类
  licenseCode?: string //授权标识（授权名称）
  licenseAlertLimit?: number //授权报警限值
  licenseValue?: number //授权数值
  lastOrderDetailId?: number //最近订单明细ID
  lastOrderId?: number //最近订单ID
  effectDate?: string //生效时间
  expireDate?: string //过期时间
  createDate?: string //创建时间
  lastOrderDate?: string //最近重购时间
  lastConsumeDate?: string //最近扣费时间
  state?: number //状态
  subList?: Array<AipLicenseInfoEx> //子授权列表
  saasName?: string //运营商名称
}
//AIP余额日志
export interface AipBalanceLog {
  id?: number //ID
  parentId?: number //父ID
  saasId?: number //SaasId
  currency?: string //币种类型
  bizOrderType?: string //应用订单类型
  bizOrderId?: string //应用订单号
  bizOrderExt?: string //应用订单扩展信息
  bizRemark?: string //业务备注
  payInfoId?: string //支付id
  balanceType?: number //余额类型
  dealType?: number //交易类型
  dealAmount?: number //交易金额
  dealRefund?: number //交易退款
  dealRemark?: string //交易备注
  userId?: number //用户ID
  userIp?: string //用户IP
  userInfo?: string //用户名
  auditUserId?: number //审批人ID
  auditUserIp?: string //审批人IP
  auditUserInfo?: string //操作人名
  auditRemark?: string //审批备注
  createDate?: string //创建时间
  auditDate?: string //审批时间
  dealDate?: string //完成时间
  state?: number //状态
  billState?: number //对账状态
}
//数据
export interface AipInvoiceInfoEx {
  id?: number //主键ID
  saasId?: number //运营商编号
  invoiceType?: number //发票类型（1-增值税普通发票 2-增值税专用发票）
  invoiceTitle?: string //发票抬头
  invoiceItem?: string //发票项目
  invoiceAmount?: number //发票金额
  invoiceTaxNum?: string //纳税人识别号
  invoiceCode?: string //发票号码
  invoiceUrl?: string //发票链接
  invoiceAddress?: string //地址
  invoicePhone?: string //电话
  bankName?: string //开户行
  bankNumber?: string //账号
  applyUserId?: number //申请人ID
  applyUserInfo?: string //申请人用户名
  applyRemark?: string //申请备注
  auditUserId?: number //审批人ID
  auditUserInfo?: string //审批人用户名
  auditRemark?: string //审批备注
  drawerId?: number //登记人ID
  drawerName?: string //登记人用户名
  drawerRemark?: string //登记备注
  consumeLogIds?: string //消费记录ID
  createDate?: string //创建时间
  makeDate?: string //开票时间
  lastUpdate?: string //最后更新时间
  state?: number //发票状态
  aipConsumeLogList?: Array<AipBalanceLog> //交易记录列表
  saasName?: string //运营商名称
}
//AIP发票列表查询参数
export interface AipInvoiceInfoQueryParam {
  id?: number //主键ID
  ids?: Array<number> //ID数组
  invoiceType?: number //发票类型（1-增值税普通发票 2-增值税专用发票）
  invoiceTitle?: string //发票抬头
  invoiceItem?: string //发票项目
  invoiceAmount?: number //发票金额
  invoiceAmountRange?: Array<number> //发票金额范围
  invoiceTaxNum?: string //纳税人识别号
  invoiceCode?: string //发票号码
  invoiceUrl?: string //发票链接
  invoiceAddress?: string //地址
  invoicePhone?: string //电话
  bankName?: string //开户行
  bankNumber?: string //账号
  applyUserId?: number //申请人ID
  applyUserInfo?: string //申请人用户名
  applyRemark?: string //申请备注
  auditUserId?: number //审批人ID
  auditUserInfo?: string //审批人用户名
  auditRemark?: string //审批备注
  drawerId?: number //登记人ID
  drawerName?: string //登记人用户名
  drawerRemark?: string //登记备注
  createDateRange?: Array<string> //创建时间范围
  makeDateRange?: Array<string> //开票时间范围
  lastUpdateRange?: Array<string> //最后更新时间范围
  state?: number //发票状态
  states?: Array<number> //发票状态数组
  stateGte?: number //大于等于发票状态
  stateLte?: number //小于等于发票状态
  $pg?: number //当前页码
  $rn?: number //每页条数
  $si?: number //起始位置
  $rt?: number //请求类型
  $sn?: Array<string> //排序名称
  $st?: Array<number> //排序名称
}
//AIP余额日志列表查询参数
export interface AipBalanceLogQueryParam {
  userId?: number //用户ID
  id?: number //ID
  ids?: Array<number> //ID数组
  parentId?: number //父ID
  currency?: string //币种类型
  bizOrderType?: string //应用订单类型
  bizOrderId?: string //应用订单号
  bizOrderExt?: string //应用订单扩展信息
  bizRemark?: string //业务备注
  payInfoId?: string //支付id
  balanceType?: number //余额类型
  dealType?: number //交易类型
  dealAmount?: number //交易金额
  dealAmountRange?: Array<number> //交易金额范围
  dealRefund?: number //交易退款
  dealRefundRange?: Array<number> //交易退款范围
  dealRemark?: string //交易备注
  userIp?: string //用户IP
  userInfo?: string //用户名
  auditUserId?: number //审批人ID
  auditUserIp?: string //审批人IP
  auditUserInfo?: string //操作人名
  auditRemark?: string //审批备注
  createDateRange?: Array<string> //创建时间范围
  auditDateRange?: Array<string> //审批时间范围
  dealDateRange?: Array<string> //完成时间范围
  state?: number //状态
  states?: Array<number> //状态数组
  stateGte?: number //大于等于状态
  stateLte?: number //小于等于状态
  billState?: number //对账状态
  $pg?: number //当前页码
  $rn?: number //每页条数
  $si?: number //起始位置
  $rt?: number //请求类型
  $sn?: Array<string> //排序名称
  $st?: Array<number> //排序名称
}
//AIP余额
export interface AipBalanceInfo {
  id?: number //id
  saasId?: number //saasId
  currency?: string //币种类型
  depositBalance?: number //预存余额
  depositSumRecharge?: number //存款总充值金额
  depositSumRechargeRefund?: number //存款总充值退款
  depositSumConsume?: number //存款总消费金额
  depositSumConsumeRefund?: number //存款总消费退款
  orderNum?: number //已售数量
  createDate?: string //创建时间
  lastRechargeDate?: string //最近充值时间
  lastConsumeDate?: string //最近消费时间
  modifyDate?: string //修改时间
  state?: number //状态
}
//余额交易报表统计
export interface AipBalanceReportStats {
  statsDate?: string //统计日期
  dealType?: number //交易类型
  saasNum?: string //系统数量
  dealNum?: string //交易次数
  dealAmount?: string //交易金额
}
//AIP广告列表查询参数
export interface AipAdInfoQueryParam {
  id?: number //主键
  ids?: Array<number> //ID数组
  spaceId?: number //广告位id
  spaceCode?: string //分类代码
  adTitle?: string //主标题
  subTitle?: string //副标题（可以不输入）
  adLink?: string //对应链接
  adImg?: string //对应图片
  rankOrder?: number //推荐值
  rankOrderRange?: Array<number> //推荐值范围
  clickNum?: number //点击数
  clickNumRange?: Array<number> //点击数范围
  expireDateRange?: Array<string> //到期时间范围
  createDateRange?: Array<string> //创建时间范围
  modifyDateRange?: Array<string> //修改时间范围
  state?: number //状态
  states?: Array<number> //状态数组
  stateGte?: number //大于等于状态
  stateLte?: number //小于等于状态
  $pg?: number //当前页码
  $rn?: number //每页条数
  $si?: number //起始位置
  $rt?: number //请求类型
  $sn?: Array<string> //排序名称
  $st?: Array<number> //排序名称
}
//AIP广告
export interface AipAdInfo {
  id?: number //主键
  saasId?: number //运营商id
  spaceId?: number //广告位id
  spaceCode?: string //分类代码
  adTitle?: string //主标题
  subTitle?: string //副标题（可以不输入）
  adLink?: string //对应链接
  adImg?: string //对应图片
  rankOrder?: number //推荐值
  clickNum?: number //点击数
  expireDate?: string //到期时间
  createDate?: string //创建时间
  modifyDate?: string //修改时间
  state?: number //状态
}
