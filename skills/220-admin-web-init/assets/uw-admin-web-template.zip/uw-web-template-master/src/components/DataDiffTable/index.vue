<template>
  <el-dialog
    v-model="isShow"
    :title="props.id ? `数据详情#${props.id}` : '数据详情'"
    @close="resetForm"
    width="1400px"
    draggable
  >
    <el-table
      border
      :style="{ width: '100%' }"
      :header-cell-style="{
        backgroundColor: 'var(--el-color-info-light-9)'
      }"
      :data="showData"
      stripe
    >
      <el-table-column
        prop="key"
        label="字段名"
        align="center"
        width="120"
        fixed="left"
      ></el-table-column>
      <el-table-column
        label="旧值"
        align="center"
      >
        <template v-slot="{ row }">
          <div
            class="ellipsis"
            :title="row.oldValue"
          >
            <el-text
              tag="del"
              v-if="row.oldValue !== row.newValue"
            >
              {{ row.oldValue }}
            </el-text>
            <el-text v-else>{{ row.oldValue }}</el-text>
          </div>
        </template>
      </el-table-column>
      <el-table-column
        label="新值"
        align="center"
      >
        <template v-slot="{ row }">
          <div
            class="ellipsis"
            :title="row.newValue"
          >
            <el-text>{{ row.newValue }}</el-text>
          </div>
        </template>
      </el-table-column>
    </el-table>
  </el-dialog>
</template>

<script setup lang="ts">
import { isJSON } from '@/utils/tool'

const props = defineProps<{
  show: boolean
  data: string
  id?: number
}>()

const showData = computed(() => {
  if (isJSON(props.data)) {
    const data = JSON.parse(props.data) as Record<string, any>
    const keys = Reflect.ownKeys(data)
    const isRightDataType = keys.every(
      key =>
        Object.prototype.toString.call(data[key as string]) ===
        '[object Object]'
    )
    if (isRightDataType) {
      const result = keys.map(key => {
        const target = data[key as string]
        return {
          key: key,
          oldValue: target?.oldValue || '',
          newValue: target?.newValue || ''
        }
      })
      console.log(result)
      return result
    }
    return []
  }
  return []
})

const emits = defineEmits<{
  (e: 'update:show', val: boolean): void
}>()

// 是否显示
const isShow = computed({
  get() {
    return props.show
  },
  set(val) {
    emits('update:show', val)
  }
})

const resetForm = () => {
  isShow.value = false
}
</script>

<style scoped lang="scss">
:deep(.el-dialog__body) {
  max-height: 650px;
  overflow: hidden auto;
  .ellipsis {
    width: 620px; // 设置元素宽度为父元素宽度的100%
    white-space: nowrap; // 防止文本换行
    overflow: hidden; // 隐藏溢出的文本
    text-overflow: ellipsis; // 显示省略号
  }
}
</style>
