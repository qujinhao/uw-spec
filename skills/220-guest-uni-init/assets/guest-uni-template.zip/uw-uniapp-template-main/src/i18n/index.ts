// 定义语言国际化内容
import pinia from '../store'
import { useMainStore } from '@/store/main'
import type { I18N } from './i18n.type'
import { messages, createI18nInstance, setDefaultI18nLocale } from './instance'

const useI18n = () => {
  const mainStore = useMainStore(pinia)
  // 更新默认实例的语言设置
  setDefaultI18nLocale(
    mainStore.i18n || (mainStore.curBrownerLang as I18N).toLocaleLowerCase()
  )
  return createI18nInstance(
    mainStore.i18n || (mainStore.curBrownerLang as I18N).toLocaleLowerCase()
  )
}

export default useI18n
export { messages }
