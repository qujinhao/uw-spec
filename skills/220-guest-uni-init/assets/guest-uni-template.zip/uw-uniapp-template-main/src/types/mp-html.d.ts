declare module 'mp-html/dist/uni-app/components/mp-html/mp-html' {
  import { DefineComponent } from 'vue'
  // eslint-disable-next-line
  const component: DefineComponent
  export default component
}
