<script lang="ts" setup>
import { useI18n } from 'vue-i18n'
const router = useRouter()
const { t } = useI18n()
</script>

<template>
  <el-empty
    :image-size="300"
    description="404"
    :style="{
      '--el-font-size-base': '32px'
    }"
  ></el-empty>
  <div class="flex-center">
    <el-button
      type="primary"
      @click="router.back()"
    >
      {{ t('returnToPreviousPage') }}
    </el-button>
  </div>
</template>

<style lang="scss" scoped></style>
