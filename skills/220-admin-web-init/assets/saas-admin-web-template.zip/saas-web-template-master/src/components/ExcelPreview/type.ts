export interface excelProps {
  modelValue: boolean // 是否展示
  src: string // 文档地址，文件在CDN或服务器上的地址，或者是通过FileReader读取的文件ArrayBuffer或者Blob格式。
  title?: string // 文档标题
  width?: number // 弹窗宽度
  height?: number //  弹窗高度
  dialogExpand?: Record<string, any> // 弹窗其余扩展属性
  renderedHandler?: () => void // 渲染完成执行回调
  errorHandler?: () => void // 渲染错误执行回调
}
