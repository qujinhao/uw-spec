/**
 * 基础 接口返回数据结构
 */
export interface DataList<T> {
  startIndex?: number //
  resultNum?: number //
  size?: number //
  sizeAll?: number //
  page?: number //
  pageCount?: number //
  results?: Array<T> //
}

/**
 * 基础 接口返回数据结构
 */
export interface ESDataList<T> {
  startIndex?: number //
  resultNum?: number //
  size?: number //
  sizeAll?: number //
  page?: number //
  pageCount?: number //
  results?: Array<T> //
}

export interface ResponseData<T> {
  data?: T
  state: 'success' | 'error'
  msg?: string
  code?: string
  timestamp?: number
}

//  通用字典表类型，通用只读
export interface commonType {
  readonly label: string
  readonly value: number | string
}

//Enum结构
export interface EnumStruct {
  value?: number //数值
  label?: string //名称
}
