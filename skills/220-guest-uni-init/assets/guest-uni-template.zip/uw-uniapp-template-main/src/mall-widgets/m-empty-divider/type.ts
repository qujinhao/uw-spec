/*
 * @Description:
 * @Date: 2024-06-21 09:42:59
 * @LastEditors: niezihao
 * @LastEditTime: 2024-06-21 10:01:35
 * @Author: niezihao
 */
export interface PropsType {
  // 样式控制
  styles: {
    height: number //高度
    lineColor: string //分割线颜色
    model: string //分割模式
    pagePadding: number //页面边距
    type: string //分割线类型
    cmpBackground: string //背景色
  }
}
