<script lang="ts" setup>
import {
  authSendDeviceCode,
  authGenCaptcha,
  authResetPassword,
  type CaptchaQuestion
} from '@/api/uwAuthCenterAuthApi'
import {
  userUserTypeConfig,
  type UserTypeConfig
} from '@/api/uwAuthCenterUserApi'
import { ElMessage, type FormInstance } from 'element-plus'
import { rsaEncrypt } from '@/utils/encryptionAndDecryption'
import { useCustomDark } from '@/hooks/useCustomDark'
import { useMainStore } from '@/store/main'
import { useI18n } from 'vue-i18n'

const formDarkImg = toRaw(
  'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKoAAABBCAYAAABB9T/DAAAAAXNSR0IArs4c6QAAAARzQklUCAgICHwIZIgAAA3ZSURBVHic7V0vlOq+Ev7yzk8gkchKJBJZiVy5ErnyyiuffPLKn1y5ErkSiaxEViIr6+aJzNA0ZJIUyuXP8p3DAUo7SZMvk8nMNBj8ABDRBMDMeU35BecdABoALb83AA4AamNM8/dq+0II5tYVuBaYnAsAc1hyTi4Q1wCoYUlbXV67F4bi6YhKRAWAEkBxpSKEtNuXpv17eBqi/gWChlDhRdi/gocn6o0I6uNF2CvjYYnKNmgJYHnjqggaWLK+bNgr4CGJSkRTAO+wi6R7ww6WsO2tK/JMeDii8lT/jstW8dfGAcDXtUwBboPmGvKJaGqMaVgZgD9PLh14vgyW3+bKfSiiEtESwOrW9WCIv7VF3y8raAB8jkGmQCf/hh2oo5RBRDNYN96S5X7zewlrfxewno7vXGIR0QLAxBiz4+9r2Db6ZPK/c5mfxpg6Je+fITd0SxBRCdtwt4YQtKcxWUMUsJ0tQYU1EY1B1hV3/B6WOBOux8YpewrgDUBljNnmCCWiFayv2Z2d6sCpO1gFceDPOZhwvZcAvrjeKwALImph26oFMGESfxtjDpqwh9ComSRtcKrVroGdMebbPcAaqRFtw1PzElZjXKz1iOgNllC5+BZNlpBbwLbZBJZEjTHmD/9WgjWqMWbDhNsPuQ8i+gU7uOZcTsuvCb8O/B0sW63z3WtUx/0Uwwa2IzWiSuNcghZWm+zdg1y/hTFmI8d4KqtZ061hNeu/IyywamPMZ+gH1rhv/DXX8zBHRxrAajeRIQvVgo8VAEq+jyhZuS4F7KxzIKIdgF+wZNywvDk6E6OA164+7pqo3NFvidM2sNOVf94OthHmsI1QYLjGbdH5SE9IxvVbAphx4x9gNVAL2IUIgD/ccSuu6yWYyCIn9Jt8GDAgar5u5h0TzNBF4oD8vIcGVnEURLRHpzUnbG5MYPunRGffN4iYFXdNVFhtFCPXtzGmIqK5d7yFJVADS7TKORbCAWFX1wTOlK78XqNbUBX83jMNuI4HIlpc6GedwWqmUWCM2QM9U0Xs7yU6csoAEC2ZrL8xpiaimmWUsDYq+HqRt2FZa1hzKmqq3C1R2UaKkXTr3JxPsj0f+4Jt9DXCU/9WFh7cWetIGSdg4/+4AGBbdUJEcyGBey4RTYloFls0JJA79WeDAycFfxVTRQa4HCul/AGiv2BnkZrlAd3MBmNMy3bvNEfuXRKVp7cycsreW9nKalSM9gLdaNYWIb0FB2sBV7MOWeGKjCgBjTF71v7nEnXCAyqEwcEPIvoIXLeF1XAtr87Fhm34t1wUsG2/QackXC/JCt0AeSeirYl4K+6SqIj7ShucTq17nmoAq0FlhelP9RswSRRSfcFqpQK2A0vWOKPF8bmu0zPlxWz2cxaLNfpEbQIKoODPX7CupV2mDSxehIq1PeAQlcuecvlbJLTq3RGVNYZvc7oIkoYb79vJQw3Zo28IuJccGQ0TXmzPCh1hdxdM2T7aM6M9h5Gn/gqdjb0OyCucQxIAGOJH9U2LWn7kASuBhjrl9I8SlQuJkWYoclaNZeL6lDG/RZfJH5SRuL7mOtRigzraehTcUR5Ag9NVv0t66SuxXYfUXbTxkt9rCcei8wJkI6VRlxgvGtQA+Dd2Ao8wQCdT0r3DjbEB8AHbIHv07dQlIj47tlX/h767Z5RpfwQURPTfEeXN0bmIAPTC1Dt0g37t/F7khDxh+7BA5wmp2CaewA7+XxjgLlSJyswfK4WuhXX+RkcSa7DPEcpzfaduNATIWGFyPe9F67mooQ/WOSzBsuvNs1Pl5A5UsO12cMhY88BfwSaR1CFZAbhridoYs+WFpAROxNwQl1i8rtoPZ4TtYsgK6Y0F9hrM0C0WDmDD/RHzRXMyjVix3JNZkcSQRWWQqJ5P8eC8GnQaShpkgbh5oC5eXnghF9rUP4V1R9SJUSwhRA1DfW8vvBDE2dlTPNV8IJ4IkkxgeOGFHFziRy2RjsMPIqljW0o+pyQrAN1mEFm+TMd/N8cdPHjH5lQBu2iRdpOFRA27gEnal85mGnPYCF09cj1H64OI/ALdXgsiv2X5+1A7nEVUdmHEpvzdkEULrwbF35Y6t4YlXu3VR3I/p85LUCOQTMH+wlIpah+yrZkoa4QjQY3rkHdCwXPlfBctp8MdIz9Ou2j3BSheDHb1vStlNfC8MEOe5g31QcY1EoRJhnpZfi+RejBRuQHKyCkHZNqldN5DegVsfucxNmyM2XGnal6KoHwO70naWaic0DUtN2RooG7lwxlPJEjkZyFPBXD0plDKUuvI9TxwrD5071tnMEhYVpWllNvrAw1OTm62z5TlfxDR0Vv0nwEXizZ5h64dsvylLGsOewOhhqxhNeABul+wZDIItpHigkTl+9HuJdawod8qJv6E7PNAZeCcBtZPuYfuO5zCkkDK2EJvg5m4pRSEfqtktnP6oAicV3M9h/RBDzzTaeuYGuk+Xon8oRp1pRQq2OTYgpFpqYH32EZC65ZEVPH5csOhztE0dsx8mYT8fFyfUFh565gFmhbberJKhAktJsOGNbibHOKjQCDS5qTQuTh6YbgP3nDaXpf0gVv+AuHkIk3+OlBfwM4wVbZG5RuPBQB2fg6mIqcXknNwcgPAMXz5FThfUPJ5YoyHcJIZn5FKCITJEUr8kMXaCpkkBQA+ptnyC0dbxuz9kzpG3IZb0z0KvUYGSbmeWX3glF8g3E4HBDxB/P1TkT0FMM8iKpMrlnpXD3DqazahujLn41pnFc7n2EApvO9l5FxBKFnDl9NweLBAeCAfEnZc7DcpK3ZfIe1e4lQ7Had8hDUpYJXNRX3AgytEUiDyuDXL1+5zkSSqY5dqaJH5LBDbRIUiI6WNNW05zTgHcEjHGiUnPOx3dhk4Z8vvWudEQ8cJU2nG57TQcxSmrp2q3FuLbsqP9UHKU5NTh5DJAWSk8iHSxzka9V0pWDBkRxDNJqy0keZAJaFM69wQ6sLD+RybHVwUThmhDpAFVBH4DbDx+Rw3XU771ZHfXK0aUirubHVJH8TqKUQtNPkJ2YDed5MoUblztIKBAb40x1EdQo4DWR0s3kDR6jPjesyRn2M74VW8avPxuybv0gQR9/o6cp7c2wKnbdx4CUGX9IHqYXBs30I55ZK2aFSispZI2aXbAYXFXEE5N6Fd64/yWrueGzJ0TzH7ukDY5nO1lDaIciM42vXHdknMFnPqdjf08Skf+P4v6QOtnql2AC5TRm2QqI4TWEOD4c+ox24iZ+rTrq8T312E3GsV0qtq3+bzny06u/N9b4QH327X6ikejNhgAuLRsTH6IHfWGyp/r2nUt1ihyPSXDkAqvAjo02uv8zjspmoe73uDLkqj3U80ApVATjRGW9SFMtdiC06/nv5gAuLtfEkfSL1imXbR6KP3bJWP+oSo7ITWLgCsi6GOFeoWTkQLtp2Sq9uInALhTj8odcmqH/rumNxrqsACKWcBp0Ej6jZwLDYIfXwGjl2jDxrHfx6rW2rQLhEeLLUxpk9USu/zVKcy9YloRkRzfkLgF8uTzbW0G1lqoUA+rtnKmm1Zx+rI8BcZufbkNiRLOXdC3aPCJ1A8CYDiykkENXp1DM14GX0QJFOiD1wTMDYQ1PVOIq95AzghVCdMFgV1m2i5kBssAr+5sf89whpkCuCNiDZeRo8sfrRoT61UUzveu977vkfabaUFJSroDb0iosavK+l7vabs/z3iM15oyvevj/WBn1WV3Qeme9w8VL8pJwBtA/K1/JFjqqhxLlgrBVyC3hY0XKlfkfPF8d+gv5eTj5ysnd/Q7a69MeYkJEjxJyOPWzIq5b0hHkSo0WnDAuGOb5DYopK12+9IOdGNca/dB2yLfmTKn0G3e3vyDQtf4Tp/2vBHSVaIeRRSyN37s4RuxpzUK+OaTcx5T+knHlKokZ/Us0ZYqVTG2f4ycv1V++CMFEcXssDttfU/TnLu2NDspIqIGqQ9Cz4qTaaCHbp/7evJicjYIbzPamgB1QNnOf2L4f/UEuyYBELTf4NMb8S1+4BzHw7QcwoGyzdM1CHCchF8pEBAeX8BWfMrRi4VjhNciJMztYpN5k5JQQ0ckVHw9XMoK2VwvmdOxllAfkgjRjW+Imfi1LPAyH0woI/3SOxmfTdbo3srzux/yxgguwCOmy7kXFOAH2/JMTUicnoRuTH8zwFbOmvKz5B7tT64VP7dEPWFPAS8BclZ4hkw6FGUF24LJdn75k/Y/g28iPogUPyNyUXes+Du9kcFkpGQlEP74eEkBe3R/b+AH8XKXuU/A+6SqOzqaaD44oiovWSBc89wnimLJWm0uOJfWN4j7nbqZ62pxbXLRHrcQ4K6zeli7sIWdvGUm5vwFLjrVT+T8QPKriR4otVuZrSoxvgplg+BuyYqcLIFpo8DLFlH9ffdAtTtTeU7xht4f7T2E3H3RAWimUbAE5H1BR0PQVQgmejwVGbAC6d4GKICWWT9+mmLjJ+ChyIqcHzcOZaVk8xVvTbY3sza7/SFPDwcUYGsrQxvYgpwvWbnZES9EMdDEhU4Rq+WiCfoDs1hvaQukmlVX7Osn4qHJaogQ7sC/Oz+2CRyNkZr4OwU/cL4eHiiCqjb5jxGWElYrnCmDeklRdf4IdlLt8bTEFXAhM3dX+qAzqEuZJN3SXieovsXZBkEFSJbNL4wPp6OqAInq38B/TGIXMiTk6ObDy/k4WmJ6oOnbNGKQlzRmIIG3V/qiKbN+UfsF66M/wOQQUxMRlNvEgAAAABJRU5ErkJggg=='
)

//  判断是否是暗黑
const isDark = useCustomDark()
const { t } = useI18n()
const router = useRouter()
const mainStore = useMainStore()
// 身份认证
const formRef = ref<FormInstance>()
const form = ref({
  loginId: '',
  verifyCode: '',
  newPassword: '',
  repeatPassword: ''
})
// 多次登录失败提示文字
const showFailuresText = ref('')
// 校验参数
const validateParams = ref<CaptchaQuestion>({})
// 加密的签名
const validateSign = ref('')
// 是否显示校验
const showCaptcha = ref(false)
// 操作类型
const optType = ref(0) // 0 获取短信验证码  1 重置密码
const captchaRef = ref()

// 密码配置要求
const passwordConfig = computed(() => {
  return userTypeConfig.value.passwordConfig?.name || ''
})

const userTypeConfig = ref<UserTypeConfig>({})
// 获取用户类型配置
const handleLoadUserConfig = () => {
  userUserTypeConfig()
    .then(res => {
      userTypeConfig.value = res.data || {}
    })
    .catch(() => {
      userTypeConfig.value = {}
    })
}

// 点击认证
const handleValidate = () => {
  optType.value = 0
  showFailuresText.value = ''
  // 判断是否需要机器验证
  authGenCaptcha({
    captchaId: validateParams.value.captchaId || ''
  }).then(res => {
    if (res.state === 'success') {
      validateParams.value = {}
      // 直接发送请求，获取验证码
      queryCodeForMessageNoCaptchaForLogin()
    } else if (res.state === 'error' && res.msg) {
      validateParams.value = {}
      showFailuresText.value = res.msg
      showCaptcha.value = false
    } else if (res.data && res.data.captchaId) {
      // 需要校验
      validateParams.value = { ...res.data }
      showCaptcha.value = true
    }
  })
}

// 刷新图形验证码
const handleRefreshCode = () => {
  authGenCaptcha({
    captchaId: validateParams.value.captchaId || ''
  }).then(res => {
    if (res.state === 'success') {
      validateParams.value = {}
      showCaptcha.value = false
    } else if (res.state === 'error' && res.msg) {
      showFailuresText.value = res.msg
      showCaptcha.value = false
    } else if (res.data && res.data.captchaId) {
      validateParams.value = { ...res.data }
      showCaptcha.value = true
    }
  })
}

// 获取验证码
const countdownForLogin = ref(60)
// 是否显示获取验证码按钮，用于判断倒计时以及获取验证码按钮
const showGetCodeForLogin = ref(true)

const timer = ref()
// 倒计时60s
const countdownTimeForLogin = () => {
  timer.value = setInterval(() => {
    if (countdownForLogin.value > 0) {
      countdownForLogin.value--
    } else {
      showGetCodeForLogin.value = true
      clearInterval(timer.value)
    }
  }, 1000)
}

// 发送手机验证码--无需机器校验
const queryCodeForMessageNoCaptchaForLogin = () => {
  authSendDeviceCode({
    loginType: getLoginTypeForPasswordLogin(),
    loginId: form.value.loginId,
    captchaId: validateParams.value.captchaId || '',
    captchaSign: validateParams.value.captchaId ? validateSign.value : '',
    userType: 300,
    loginAgent: mainStore.loginAgent,
    forceLogin: true
  }).then((res: any) => {
    if (res.state === 'success') {
      ElMessage.success(
        getLoginTypeForPasswordLogin() === 23
          ? t('phoneCodeHasSent')
          : t('emailCodeHasSent')
      )
      // 倒计时
      showGetCodeForLogin.value = false
      if (countdownForLogin.value === 0) {
        countdownForLogin.value = 60
      }
      // 开始倒计时
      countdownTimeForLogin()
    } else {
      if (String(res.code).includes('auth.center.captcha.verify')) {
        // 验证码错误重新刷新
        captchaRef.value?.validateError()
        const timer = setTimeout(() => {
          handleRefreshCode()
          clearTimeout(timer)
        }, 1500)
      } else {
        ElMessage.error(res.msg)
        showCaptcha.value = false
      }
    }
  })
}

// 密码登录时获取登录的类型
const getLoginTypeForPasswordLogin = (): number => {
  // 手机号正则
  const phoneReg =
    /^(13[0-9]|14[01456879]|15[0-35-9]|16[2567]|17[0-8]|18[0-9]|19[0-35-9])\d{8}$/
  // 邮箱正则
  const emailReg = /^\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/
  if (phoneReg.test(form.value.loginId)) {
    return 23
  } else if (emailReg.test(form.value.loginId)) {
    return 22
  }
  // 普通账户密码登录
  return 1
}

// 检验手机号/邮箱
const validateLoginId = (rule: any, value: any, callback: any) => {
  if (value) {
    const res = getLoginTypeForPasswordLogin()
    if (res === 23 || res === 22) {
      callback()
    } else {
      callback(new Error(t('phoneOrEmailFormatError')))
    }
  } else {
    callback(new Error(t('pleaseInputPhoneOrEmail')))
  }
}

// 禁用获取验证码
const disabledGetCode = computed(() => {
  if (!form.value.loginId) {
    return true
  }
  const res = getLoginTypeForPasswordLogin()
  if (res === 23 || res === 22) {
    return false
  }
  return true
})

// 校验密码
const validatePassword = (rule: any, value: any, callback: any) => {
  if (value) {
    if (
      /^(?=.*[A-Za-z])(?=.*\d)[\w!@#$%^&*\-+=(){}[\]|\\:;"'<>,.?/`~]{8,72}$/.test(
        value
      )
    ) {
      callback()
    } else {
      callback(new Error(t('passwordFormat')))
    }
  } else {
    callback(new Error(t('pleaseInput')))
  }
}

// 校验确认密码
const validateRepeatPassword = (rule: any, value: any, callback: any) => {
  if (value) {
    if (value === form.value.newPassword) {
      callback()
    } else {
      callback(new Error(t('user.passwordError')))
    }
  } else {
    callback(new Error(t('pleaseInput')))
  }
}

const showSuccessResult = ref(false)
// 点击重置密码
const handleRepeatPassword = () => {
  formRef.value?.validate(valid => {
    if (valid) {
      optType.value = 1
      authResetPassword({
        deviceType: getLoginTypeForPasswordLogin(),
        deviceId: form.value.loginId,
        deviceCode: form.value.verifyCode,
        newPassword: rsaEncrypt(form.value.newPassword) as string,
        captchaId: validateParams.value.captchaId || '',
        captchaSign: validateParams.value.captchaId ? validateSign.value : '',
        saasId: 0
      }).then(res => {
        if (res.state === 'success') {
          ElMessage.success(t('passwordResetSuccess'))
          showSuccessResult.value = true
        } else {
          if (res.code === 'auth.center.passwd.complexity.error') {
            if (passwordConfig.value) {
              const msg = handlePasswordTip()
              ElMessage.error(msg || res.msg)
            } else {
              ElMessage.error(res.msg || t('passwordEdit') + t('error'))
            }
          } else {
            ElMessage.error(res.msg || t('passwordEdit') + t('error'))
          }
        }
      })
    }
  })
}

// 处理密码提示
const handlePasswordTip = () => {
  if (passwordConfig.value === 'ULTIMATE') {
    return t('ULTIMATEPasswordRule')
  } else if (passwordConfig.value === 'EXTREME') {
    return t('EXTREMEPasswordRule')
  } else if (passwordConfig.value === 'STRICT') {
    return t('STRICTPasswordRule')
  } else if (passwordConfig.value === 'STANDARD') {
    return t('STANDARDPasswordRule')
  } else if (passwordConfig.value === 'NORMAL') {
    return t('passwordFormat')
  }
}
// 前往登录
const toLogin = () => {
  router.push({
    path: '/login'
  })
  showSuccessResult.value = false
}

// 校验自定义事件
const handleValidateForImg = (val: string) => {
  // 获取短信验证码
  validateSign.value = val
  authSendDeviceCode({
    loginType: getLoginTypeForPasswordLogin(),
    loginId: form.value.loginId,
    captchaId: validateParams.value.captchaId || '',
    captchaSign: validateParams.value.captchaId ? validateSign.value : '',
    userType: 300,
    loginAgent: mainStore.loginAgent
  }).then((res: any) => {
    if (res.state === 'success') {
      captchaRef.value?.validateSuccess()
      setTimeout(() => {
        ElMessage.success(
          getLoginTypeForPasswordLogin() === 23
            ? t('phoneCodeHasSent')
            : t('emailCodeHasSent')
        )
        // 倒计时
        showGetCodeForLogin.value = false
        if (countdownForLogin.value === 0) {
          countdownForLogin.value = 60
        }
        // 开始倒计时
        countdownTimeForLogin()
      }, 1500)
    } else {
      if (String(res.code).includes('auth.center.captcha.verify')) {
        // 验证码错误重新刷新
        captchaRef.value?.validateError()
        setTimeout(() => {
          handleRefreshCode()
        }, 1500)
      } else {
        ElMessage.error(res.msg)
        showCaptcha.value = false
      }
    }
  })
}

onMounted(() => {
  handleLoadUserConfig()
})

onUnmounted(() => {
  timer.value && clearInterval(timer.value)
})
</script>

<template>
  <div class="password-wrapper">
    <div
      class="logo-header"
      :style="{ background: isDark ? '#10233e' : '#1f6cee' }"
    >
      <div class="login_top padding-top-10">
        <el-image
          class="login-top__image"
          fit="cover"
          :src="
            isDark
              ? formDarkImg
              : 'https://qnimg.zowoyoo.com/img/84826/1704851011338.png'
          "
        ></el-image>
      </div>
    </div>
    <div
      class="content-wrapper flex-center"
      :style="{ background: isDark ? '#10233e' : '#f5f7fa' }"
    >
      <div class="content">
        <el-row
          type="flex"
          justify="center"
          class="margin-top-30 margin-bottom-30"
          v-show="!showSuccessResult"
        >
          <el-col :span="16">
            <el-text class="desc">
              {{ t('resetPasswordTitle') }}
            </el-text>
          </el-col>
        </el-row>
        <el-form
          ref="formRef"
          :model="form"
          label-width="120px"
          status-icon
          v-show="!showSuccessResult"
        >
          <el-row
            type="flex"
            justify="center"
            class="margin-top-30"
          >
            <el-col :span="16">
              <el-form-item
                label=""
                prop="loginId"
                label-width="0"
                :rules="[{ validator: validateLoginId }]"
              >
                <el-input
                  v-model="form.loginId"
                  :placeholder="t('phoneOrEmail')"
                  size="large"
                />
              </el-form-item>
            </el-col>
          </el-row>
          <el-row
            type="flex"
            justify="center"
            class="margin-top-30"
            :gutter="10"
          >
            <el-col :span="10">
              <el-form-item
                label=""
                prop="verifyCode"
                label-width="0"
                :rules="[
                  { required: true, message: t('pleaseInputValidateCode') }
                ]"
              >
                <el-input
                  v-model="form.verifyCode"
                  :placeholder="t('pleaseInputValidateCode')"
                  clearable
                  :style="{ width: '100%' }"
                  size="large"
                  :disabled="!form.loginId"
                />
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-button
                type="primary"
                v-if="showGetCodeForLogin"
                size="large"
                :style="{ width: '100%' }"
                @click="handleValidate"
                :disabled="disabledGetCode"
              >
                {{ t('getValidateCode') }}
              </el-button>
              <el-button
                type="primary"
                :disabled="true"
                size="large"
                :style="{ width: '100%' }"
                v-else
              >
                {{ `${t('getValidateCode')}(${countdownForLogin}s)` }}
              </el-button>
            </el-col>
          </el-row>
          <el-row
            type="flex"
            justify="center"
            class="margin-top-30"
          >
            <el-col :span="16">
              <el-form-item
                label=""
                prop="newPassword"
                label-width="0"
                :rules="[{ validator: validatePassword }]"
              >
                <el-input
                  v-model="form.newPassword"
                  :placeholder="t('newPassword')"
                  size="large"
                  type="password"
                  show-password
                  autocomplete="new-password"
                />
              </el-form-item>
            </el-col>
          </el-row>
          <el-row
            type="flex"
            justify="center"
            class="margin-top-30"
          >
            <el-col :span="16">
              <el-form-item
                label=""
                prop="repeatPassword"
                label-width="0"
                :rules="[{ validator: validateRepeatPassword }]"
              >
                <el-input
                  v-model="form.repeatPassword"
                  :placeholder="t('confirmPasswordAgain')"
                  size="large"
                  type="password"
                  show-password
                  autocomplete="new-password"
                />
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
        <el-row
          type="flex"
          justify="center"
          class="margin-top-30"
          v-show="!showSuccessResult"
        >
          <el-col :span="4">
            <el-button
              type="primary"
              size="large"
              :style="{ width: '100%' }"
              icon="Check"
              @click="handleRepeatPassword"
            >
              {{ t('resetPassword') }}
            </el-button>
          </el-col>
        </el-row>
        <el-row
          type="flex"
          justify="center"
          class="margin-top-30"
          v-if="showSuccessResult"
        >
          <el-col :span="16">
            <el-result
              icon="success"
              :title="t('passwordResetSuccess')"
              :sub-title="t('goToLoginPage')"
            >
              <template #extra>
                <el-button
                  type="primary"
                  icon="Promotion"
                  size="large"
                  @click="toLogin"
                >
                  {{ t('toLogin') }}
                </el-button>
              </template>
            </el-result>
          </el-col>
        </el-row>
      </div>
    </div>
  </div>
  <!-- 验证组件 -->
  <Captcha
    ref="captchaRef"
    v-model:show="showCaptcha"
    :data="validateParams"
    mode="pop"
    @refresh="handleRefreshCode"
    @validate="handleValidateForImg"
  ></Captcha>
</template>

<style lang="scss" scoped>
.password-wrapper {
  width: 100vw;
  height: 100vh;
  overflow: hidden;
  box-sizing: border-box;
  .logo-header {
    width: 100vw;
    height: 65px;
    background: #1f6cee;
    .login_top {
      max-width: 1200px;
      margin: 0 auto;

      .login-top__image {
        width: 137px;
        height: 52px;
      }

      .login-top__right {
        color: var(--el-color-white);
        p {
          :deep(.lang-select__icon) {
            background: var(--el-color-primary);
          }
        }
      }
    }
  }
  .content-wrapper {
    width: 100%;
    height: calc(100vh - 65px);
    box-sizing: border-box;
    padding-top: 20px;
    .content {
      width: 35%;
      height: 500px;
      background: var(--el-bg-color);
      border-radius: 20px;
      box-shadow: 0px 8px 21px 0px rgba(5, 76, 138, 0.45);

      .desc {
        font-size: 18px;
        font-weight: bold;
        line-height: 12px;
        letter-spacing: 0em;
        color: var(--el-text-color-primary);
      }
    }
  }
}
</style>
