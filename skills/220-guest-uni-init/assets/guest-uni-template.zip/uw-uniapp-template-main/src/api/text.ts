// 测试接口
import request from '@/api/request'
import { formatParam } from '@/utils/tool'
const baseURL = 'https://task-api-stag.zowoyoo.com'
const header = {
  channel: 19
}

// 产品详情
export async function prodDetail(infoId: any, params: any) {
  return request({
    url: `/api/product/common/prodDetail/${infoId}`,
    method: 'GET',
    params,
    baseURL,
    header
  })
}

// 产品描述
export async function content(infoId: any) {
  return request({
    url: `/api/product/common/product/content/${infoId}`,
    method: 'GET',
    baseURL,
    header
  })
}

// 产品描述
export async function priceCalendar(params: any) {
  return request({
    url: '/api/product/common/priceCalendar',
    method: 'GET',
    data: params,
    baseURL,
    header
  })
}

// 产品的规格信息
export async function prodSpecs(params: any) {
  return request({
    url: `/api/product/common/prod/specs?${formatParam(params)}`,
    method: 'GET',
    baseURL,
    header
  })
}

// 产品的规格信息
export async function viewsDetail(params: any) {
  return request({
    url: `/api/product/common/view/${params.viewId}`,
    method: 'GET',
    data: params,
    baseURL,
    header
  })
}
// 产品的规格信息
export async function getProductDescUrl(infoId: any, params?: any) {
  return request({
    url: `/api/product/common/product/desc/${infoId}?${formatParam(params)}`,
    method: 'GET',
    baseURL,
    header
  })
}
// 产品的规格信息
export async function listSubMsgTpl(params: any) {
  return request({
    url: '/api/ma/common/listSubMsgTpl',
    method: 'GET',
    data: params,
    baseURL,
    header
  })
}
// 产品的规格信息
export async function couponList(params: any) {
  return request({
    url: '/api/coupon/couponList',
    method: 'GET',
    data: params,
    baseURL,
    header
  })
}
// 产品的规格信息
export async function subMsg(params: any) {
  return request({
    url: '/api/ma/common/subMsg',
    method: 'GET',
    data: params,
    baseURL,
    header
  })
}
// 产品的规格信息
export async function getTicketTypeInfo(params: any) {
  return request({
    url: '/api/custom/getTicketTypeInfo',
    method: 'GET',
    data: params,
    baseURL,
    header
  })
}
// 产品的规格信息
export async function getShoppingCartList(params: any) {
  return request({
    url: `/api/custom/mingshop/shoppingcart/shoppingCartList?${formatParam(params)}`,
    method: 'GET',
    baseURL,
    header
  })
}
// 产品的规格信息
export async function addShoppingCart(params: any) {
  return request({
    url: '/api/custom/mingshop/shoppingcart/addShoppingCart',
    method: 'POST',
    data: params,
    baseURL,
    header
  })
}
// 产品的规格信息
export async function prodMaterial(params: any) {
  return request({
    url: '/api/product/material/prodMaterial',
    method: 'GET',
    data: params,
    baseURL,
    header
  })
}
// 产品的规格信息
export async function materialHandle(params: any) {
  return request({
    url: '/api/product/material/materialHandle',
    method: 'POST',
    data: params,
    baseURL,
    header
  })
}
// 产品的规格信息
export async function receivedList(params: any) {
  return request({
    url: '/api/coupon/receivedList',
    method: 'GET',
    data: params,
    baseURL,
    header
  })
}
// 产品的规格信息
export async function couponMoney(receiveId: any, params: any) {
  return request({
    url: `/api/coupon/couponMoney/${receiveId}`,
    method: 'GET',
    data: params,
    baseURL,
    header
  })
}
// 产品的规格信息
export async function getCalQueryByYYLink(params: any) {
  return request({
    url: `/api/subscribe/getCal/queryByYYLink?${formatParam(params)}`,
    method: 'GET',
    baseURL,
    header
  })
}
// 产品的规格信息
export async function detailQueryByYYLink(params: any) {
  return request({
    url: `/api/subscribe/product/detail/queryByYYLink?${formatParam(params)}`,
    method: 'GET',
    baseURL,
    header
  })
}
// 产品的规格信息
export async function couponReceive(couponId: any) {
  return request({
    url: `/api/coupon/couponReceive/${couponId}`,
    method: 'POST',
    baseURL,
    header
  })
}
// 产品的规格信息
export async function login(params: any) {
  return request({
    url: '/api/user/login',
    method: 'POST',
    baseURL,
    header,
    data: params
  })
}
