<script lang="ts" setup>
import MenuItem from './menuItem.vue'
import type { MENU_ITEM } from './type'

const route = useRoute()

type EMITS = (e: 'change', item: number | string) => void

const props = withDefaults(
  defineProps<{
    list: MENU_ITEM[]
  }>(),
  {}
)

const emits = defineEmits<EMITS>()

const active = ref<number | string>()

watch(
  () => route.path,
  newData => {
    active.value = newData
  }
)

const clickMenu = (item: MENU_ITEM) => {
  if (item.route !== active.value) {
    active.value = item.route
    emits('change', item.route)
  }
}

onMounted(() => {
  active.value = route.path
})
</script>

<template>
  <div class="menu">
    <el-scrollbar>
      <MenuItem
        v-for="(item, index) in props.list"
        :key="index"
        :active-id="active"
        :list="item.list"
        :icon="item.icon"
        :route="item.route"
        @click="clickMenu"
      >
        <ToolTipText :text="$t(item.route)" />
      </MenuItem>
    </el-scrollbar>
  </div>
</template>

<style lang="scss" scoped>
.menu {
  width: 100%;
  height: calc(100vh - $asideItemHeight);
  background-color: $asideBackgroundColor;
  .menu-item {
    :deep(.el-text) {
      color: $asidecolor;
    }
  }
}
</style>
