<script setup lang="ts">
import { type ComponentInternalInstance } from 'vue'
import Sortable from 'sortablejs'
import { ElMessage, FormRules, ElMessageBox } from 'element-plus'
import { SearchFormType } from '@/components/SearchForm/type'
import {
  opsMscMscAppUpdate,
  opsMscMscAppEnable,
  opsMscMscAppDisable,
  opsMscMscAppSave,
  opsMscMscAppForceRank,
  opsMscMscAppList,
  opsMscMscAppDelete,
  type MscApp,
  type MscAppQueryParam,
  MscAppHost,
  MscAppHostQueryParam,
  opsMscMscAppHostList
} from '@/api/uwAuthCenterOpsApi'
import { usePermissionCode } from '@/hooks/usePermissionCode'
import { useCommonSelectTypes } from '@/utils/selectOptions'
import { useI18n } from 'vue-i18n'
import { commonType } from '@/types'
import { useCrud } from '@/hooks/useCrud'
import { ResponseData, DataList } from '@/api/uwAuthCenterAuthApi'
import { convertBytes } from '@/utils/tool'

// 获取全局挂载的方法
const { proxy } = getCurrentInstance() as ComponentInternalInstance
const { dayjs, useActivated } = proxy as any
const { handleTypeForLabel, appStates } = useCommonSelectTypes()
const { t } = useI18n()

// 删除接口参数类型
interface deleteParamsType {
  id: number
  remark: string // 备注
}

const {
  tableConfig, // 表格相关配置属性
  handleList, // 列表请求函数
  dialogConfig, // 弹窗相关配置属性
  dialogFormRef, // 弹窗表单ref
  handleDelete, // 删除函数
  handleOpenSaveDialog, // 打开保存弹窗
  handleOpenUpdateDialog, // 打开编辑弹窗
  handleSubmitDialog, // 提交弹窗表单
  handleResetDialog //重置弹窗
} = useCrud<MscApp, MscAppQueryParam>(
  {
    // 列表请求接口
    listFn: (): Promise<ResponseData<DataList<MscApp>>> => {
      tableConfig.queryParams.$sn = ['id']
      return opsMscMscAppList(tableConfig.queryParams)
    },
    updateFn: (remark?: string): Promise<ResponseData<MscApp>> => {
      return opsMscMscAppUpdate(dialogConfig.dialogFormData, {
        remark: remark || ''
      })
    },
    saveFn: async (): Promise<ResponseData<MscApp>> => {
      return opsMscMscAppSave(dialogConfig.dialogFormData)
    },
    deleteFn: (params: deleteParamsType) => opsMscMscAppDelete(params)
  },
  {
    openDeleteRemark: true,
    dialogSubTitleField: 'appLabel'
  }
)

const stateEnum = computed(() => {
  return {
    0: t('offline'),
    1: t('online'),
    '-1': t('delete')
  }
})

const handleStateEnum = (state: '-1' | 0 | 1) => {
  return stateEnum.value[state]
}

// 搜索表单 结构组成数据
const searchList = computed<SearchFormType[]>(() => {
  return [
    {
      field: 'appName',
      formItem: {
        label: '应用名称',
        labelWidth: '90'
      },
      formItemWidth: 280,
      clearable: true,
      componentType: 'input',
      placeholder: '请输入应用名称'
    },
    {
      field: 'appVersion',
      formItem: {
        label: '应用版本',
        labelWidth: '90'
      },
      formItemWidth: 280,
      clearable: true,
      componentType: 'input',
      placeholder: '请输入应用版本'
    },
    {
      field: 'state',
      formItem: {
        label: '状态',
        labelWidth: '90'
      },
      options: appStates.value,
      formItemWidth: 280,
      clearable: true,
      componentType: 'select',
      placeholder: t('pleaseSelect') + '状态',
      value: ''
    }
  ]
})

// 表单表头组成数据
const TableColumn = computed(() => {
  return [
    {
      prop: 'id',
      label: 'ID',
      align: 'center',
      minWidth: 60,
      fixed: 'left'
    },
    {
      prop: 'appName',
      label: '应用名称',
      align: 'center',
      minWidth: 150
    },
    {
      prop: 'appLabel',
      label: '应用显示名称',
      align: 'center',
      minWidth: 170
    },
    {
      prop: 'appVersion',
      label: '应用版本',
      align: 'center',
      minWidth: 100
    },
    {
      prop: 'permNum',
      label: '权限数量',
      align: 'center',
      minWidth: 100
    },
    {
      prop: 'runHost',
      label: '运行主机',
      align: 'center',
      minWidth: 100
    },
    {
      prop: 'runThread',
      label: '运行线程数',
      align: 'center',
      minWidth: 100
    },
    {
      prop: 'runMem',
      label: '运行内存',
      align: 'center',
      minWidth: 100
    },
    {
      prop: 'runUser',
      label: '运行用户数',
      align: 'center',
      minWidth: 100
    },
    {
      prop: 'runAccess',
      label: '运行访问数',
      align: 'center',
      minWidth: 100
    },
    {
      prop: 'remark',
      label: t('remark'),
      align: 'center',
      minWidth: 100
    },
    {
      prop: 'createDate',
      label: '创建/修改时间',
      align: 'center',
      minWidth: 170
    },
    {
      prop: 'lastUpdate',
      label: '最后更新时间',
      align: 'center',
      minWidth: 170
    },
    {
      prop: 'state',
      label: '状态',
      align: 'center',
      minWidth: 100,
      fixed: 'right'
    }
  ]
})

// 新增/修改 表单校验
const dialogListRules: FormRules = {
  appName: [
    {
      required: true,
      message: t('pleaseInput') + '应用名称'
    }
  ],
  appLabel: [
    {
      required: true,
      message: t('pleaseInput') + '应用显示名称'
    }
  ],
  appVersion: [
    {
      required: true,
      message: t('pleaseInput') + '应用版本'
    }
  ]
}

// 上线  开启MSC应用
const handleRootMscMscAppEnable = (id: number) => {
  ElMessageBox.prompt(t('pleaseInput') + '上线说明', t('tip'), {
    type: 'warning',
    confirmButtonText: t('confirm'),
    cancelButtonText: t('cancel'),
    inputValidator: (value: string) => {
      if (value) {
        return true
      }
      return false
    },
    inputErrorMessage: t('pleaseInput') + '上线说明',
    inputType: 'textarea'
  })
    .then(({ value }) => {
      opsMscMscAppEnable({ id, remark: value }).then(res => {
        if (res.state === 'success') {
          handleList()
          ElMessage.success('上线成功')
        } else {
          ElMessage({
            message: res.msg,
            type: 'error'
          })
        }
      })
    })
    .catch(() => {
      ElMessage({
        type: 'info',
        message: '操作取消'
      })
    })
}
// 下线 关闭MSC应用
const handleRootMscMscAppDisable = (id: number) => {
  ElMessageBox.prompt(t('pleaseInput') + '下线说明', t('tip'), {
    type: 'warning',
    confirmButtonText: t('confirm'),
    cancelButtonText: t('cancel'),
    inputValidator: (value: string) => {
      if (value) {
        return true
      }
      return false
    },
    inputErrorMessage: t('pleaseInput') + '下线说明',
    inputType: 'textarea'
  })
    .then(({ value }) => {
      opsMscMscAppDisable({ id, remark: value }).then(res => {
        if (res.state === 'success') {
          handleList()
          ElMessage.success('下线成功')
        } else {
          ElMessage({
            message: res.msg,
            type: 'error'
          })
        }
      })
    })
    .catch(() => {
      ElMessage({
        type: 'info',
        message: '操作取消'
      })
    })
}

const handleRootMscMscAppRank = () => {
  const arr = (tableConfig.dataList || []).map(item => {
    return {
      id: item.id,
      appName: item.appName,
      appLabel: item.appLabel,
      appVersion: item.appVersion
    }
  })
  opsMscMscAppForceRank(arr).then(res => {
    if (res.state === 'success') {
      handleList()
      ElMessage({
        message: '排序成功',
        type: 'success'
      })
    } else {
      ElMessage({
        message: res.msg,
        type: 'error'
      })
    }
  })
}

// 行拖拽
const handleRowDrop = () => {
  let tbody = document.querySelector(
    '.el-table__body-wrapper tbody'
  ) as HTMLElement
  // let _this = this
  Sortable.create(tbody, {
    handle: '.msc-app-sort', // handle's class
    // or { name: "...", pull: [true, false, 'clone', array], put: [true, false, array] }
    group: {
      name: 'words',
      pull: true,
      put: true
    },
    animation: 150, // ms, number 单位：ms，定义排序动画的时间
    // onAdd: function (evt) { // 拖拽时候添加有新的节点的时候发生该事件
    //   console.log('onAdd.foo:', [evt.item, evt.from])
    // },
    // onUpdate: function (evt) { // 拖拽更新节点位置发生该事件
    //   console.log('onUpdate.foo:', [evt.item, evt.from])
    // },
    // onRemove: function (evt) { // 删除拖拽节点的时候促发该事件
    //   console.log('onRemove.foo:', [evt.item, evt.from])
    // },
    // onStart: function (evt) { // 开始拖拽出发该函数
    //   console.log('onStart', evt.oldIndex)
    //   console.log('onStart.foo:', evt, [evt.item, evt.from])
    // },
    // onSort: function (evt) { // 发生排序发生该事件
    //   console.log('onUpdate.foo:', [evt.item, evt.from])
    // },
    onEnd({ newIndex, oldIndex }) {
      // 结束拖拽
      if (
        tableConfig.dataList &&
        typeof newIndex === 'number' &&
        typeof oldIndex === 'number'
      ) {
        let currRow = tableConfig.dataList.splice(oldIndex, 1)[0]
        tableConfig.dataList.splice(newIndex, 0, currRow)
      }
    }
  })
}

const handleTableType = (
  data: string | number,
  findList: commonType[]
): string => {
  const target = findList.find(item => item.value === data)
  if (target) {
    return target.label
  }
  return ''
}

//  新增、编辑
const statusList = computed<commonType[]>(() => {
  return [
    {
      label: t('state') + '：',
      value: handleTableType(
        dialogConfig.dialogFormData.state as number,
        appStates.value
      )
    },
    {
      label: t('createDate') + '：',
      value: dialogConfig.dialogFormData.createDate
        ? dayjs(dialogConfig.dialogFormData.createDate).format(
            'YYYY-MM-DD HH:mm:ss'
          )
        : '--'
    },
    {
      label: t('modifyDate') + '：',
      value: dialogConfig.dialogFormData.modifyDate
        ? dayjs(dialogConfig.dialogFormData.modifyDate).format(
            'YYYY-MM-DD HH:mm:ss'
          )
        : '--'
    }
  ]
})

const {
  tableConfig: tableConfigDetail, // 表格相关配置属性
  handleList: handleDetailList // 列表请求函数
} = useCrud<MscAppHost, MscAppHostQueryParam>({
  // 列表请求接口
  listFn: (): Promise<ResponseData<DataList<MscAppHost>>> => {
    return opsMscMscAppHostList(tableConfigDetail.queryParams)
  }
})

// 统计弹窗
const statisticsDialog = ref(false)
// 统计详情
const handleStatisticsDetail = (row: MscApp) => {
  tableConfigDetail.queryParams.appId = row.id
  statisticsDialog.value = true
  handleDetailList()
}

// 统计弹窗关闭
const handleCloseForStatistics = () => {
  tableConfigDetail.queryParams.$rn = 10
  tableConfigDetail.queryParams.$pg = 1
}

// 显示各项用户数
const handleShowUserInfo = (item: MscAppHost) => {
  return `<div><span>rpc：</span><span>${item.userRpcNum}</span><div>
<div><span>root：</span><span>${item.userRootNum}</span><div>
<div><span>ops：</span><span>${item.userOpsNum}</span><div>
<div><span>admin：</span><span>${item.userAdminNum}</span><div>
<div><span>saas：</span><span>${item.userSaasNum}</span><div>
<div><span>会员：</span><span>${item.userGuestNum}</span><div>
    `
}

useActivated(() => {
  handleList()
  nextTick(() => {
    handleRowDrop()
  })
})
</script>

<template>
  <div class="flex_col">
    <div class="flex_col_header">
      <SearchForm
        v-model="tableConfig.queryParams"
        :bnt-loading="tableConfig.tableLoading"
        :list="searchList"
        @change="handleList()"
        @search="handleList"
      >
        <template #right>
          <el-button
            size="small"
            type="primary"
            @click="handleRootMscMscAppRank"
            round
            icon="Sort"
          >
            {{ $t('saveSort') }}
          </el-button>
          <el-button
            class="margin-left-10"
            type="primary"
            size="small"
            @click="handleOpenSaveDialog"
            icon="Plus"
            v-permission="usePermissionCode('save')"
            round
          >
            {{ $t('add') }}
          </el-button>
        </template>
      </SearchForm>
    </div>

    <el-table
      border
      style="width: 100%"
      :header-cell-style="{
        backgroundColor: 'var(--el-color-info-light-9)'
      }"
      row-key="id"
      :data="tableConfig.dataList"
      v-loading="tableConfig.tableLoading"
      class="flex_col_body"
      stripe
      show-overflow-tooltip
    >
      <el-table-column
        :label="$t('sort')"
        width="60px"
        align="center"
        fixed="left"
      >
        <div class="msc-app-sort">
          <el-icon color="var(--el-color-primary)">
            <Sort />
          </el-icon>
        </div>
      </el-table-column>
      <el-table-column
        v-for="item in TableColumn"
        :key="item.prop"
        v-bind="item"
      >
        <template #default="scope">
          <span v-if="item.prop === 'lastUpdate'">
            {{ dayjs(scope.row[item.prop]).format('YYYY-MM-DD HH:mm:ss') }}
          </span>
          <div v-else-if="item.prop === 'createDate'">
            <div>
              <span>
                {{
                  scope.row.createDate
                    ? dayjs(scope.row.createDate).format('YYYY-MM-DD HH:mm:ss')
                    : ''
                }}
              </span>
            </div>
            <div>
              <span>
                {{
                  scope.row.modifyDate
                    ? dayjs(scope.row.modifyDate).format('YYYY-MM-DD HH:mm:ss')
                    : ''
                }}
              </span>
            </div>
          </div>
          <div v-else-if="item.prop === 'runMem'">
            <span>{{ convertBytes(scope.row.runMem) }}</span>
          </div>
          <el-text
            v-else-if="item.prop === 'state'"
            :type="scope.row.state === 1 ? 'success' : 'danger'"
            underline="never"
          >
            {{ handleStateEnum(scope.row.state) }}
          </el-text>
          <span v-else>{{ scope.row[item.prop] }}</span>
        </template>
      </el-table-column>
      <el-table-column
        :label="$t('control')"
        align="center"
        width="200"
        fixed="right"
      >
        <template #default="scope">
          <el-button-group v-if="scope.row.state !== -1">
            <el-tooltip
              content="应用主机列表"
              placement="top"
            >
              <el-button
                icon="Tickets"
                size="small"
                @click.stop="handleStatisticsDetail(scope.row)"
              ></el-button>
            </el-tooltip>
            <el-tooltip
              :content="t('edit')"
              placement="top"
            >
              <el-button
                type="primary"
                icon="Edit"
                size="small"
                v-permission="usePermissionCode('update')"
                @click.stop="handleOpenUpdateDialog(scope.row)"
              ></el-button>
            </el-tooltip>
            <template v-if="scope.row.state === 1">
              <el-tooltip
                :content="$t('offline')"
                placement="top"
              >
                <el-button
                  type="warning"
                  icon="BottomLeft"
                  size="small"
                  v-permission="usePermissionCode('disable')"
                  @click.stop="handleRootMscMscAppDisable(scope.row.id)"
                ></el-button>
              </el-tooltip>
            </template>
            <template v-if="scope.row.state === 0">
              <el-tooltip
                :content="t('online')"
                placement="top"
              >
                <el-button
                  type="success"
                  icon="TopRight"
                  size="small"
                  v-permission="usePermissionCode('enable')"
                  @click.stop="handleRootMscMscAppEnable(scope.row.id)"
                ></el-button>
              </el-tooltip>
            </template>
            <template v-if="scope.row.state === 0">
              <el-tooltip
                :content="t('delete')"
                placement="top"
              >
                <el-button
                  type="danger"
                  icon="Delete"
                  size="small"
                  v-permission="usePermissionCode('delete')"
                  @click.stop="handleDelete({ id: scope.row.id, remark: '' })"
                ></el-button>
              </el-tooltip>
            </template>
          </el-button-group>
        </template>
      </el-table-column>
    </el-table>
    <Pagination
      v-model:page-size="tableConfig.queryParams.$rn"
      @page-size-change="handleList(false)"
      :total="tableConfig.sizeAll"
      v-model:current-page="tableConfig.queryParams.$pg"
      @current-change="handleList(false)"
      class="flex_col_bottom"
    />
  </div>

  <!-- 新增、修改 -->
  <el-dialog
    v-model="dialogConfig.dialogShow"
    :title="dialogConfig.dialogTitle"
    destroy-on-close
    width="800px"
    @close="handleResetDialog"
    draggable
    :close-on-click-modal="false"
  >
    <div v-loading="dialogConfig.dialogLoading">
      <el-form
        ref="dialogFormRef"
        :model="dialogConfig.dialogFormData"
        :rules="dialogListRules"
        label-width="130px"
        label-position="right"
      >
        <template v-if="dialogConfig.dialogType === 1">
          <div class="form-item-wrapper">
            <titleHeader
              :title="t('showInfo')"
              type="status"
              :status-list="statusList"
              status-list-padding-left="60px"
            />
          </div>
        </template>
        <div class="form-item-wrapper">
          <titleHeader
            title="应用信息"
            class="margin-top-15"
          />
          <el-form-item
            label="应用名称"
            prop="appName"
          >
            <el-input
              v-model="dialogConfig.dialogFormData.appName"
              style="width: 85%"
            ></el-input>
          </el-form-item>
          <el-form-item
            label="应用显示名称"
            prop="appLabel"
          >
            <el-input
              v-model="dialogConfig.dialogFormData.appLabel"
              style="width: 85%"
            ></el-input>
          </el-form-item>
          <el-form-item
            label="应用版本"
            prop="appVersion"
          >
            <el-input
              v-model="dialogConfig.dialogFormData.appVersion"
              style="width: 85%"
            ></el-input>
          </el-form-item>
          <el-form-item
            label="应用名称"
            prop="remark"
          >
            <el-input
              v-model="dialogConfig.dialogFormData.remark"
              type="textarea"
              min-row="4"
              style="width: 85%"
            ></el-input>
          </el-form-item>
        </div>
      </el-form>
    </div>
    <template #footer>
      <el-button
        @click="dialogConfig.dialogShow = false"
        icon="Close"
      >
        {{ $t('cancel') }}
      </el-button>
      <el-button
        type="primary"
        @click="handleSubmitDialog"
        :loading="dialogConfig.dialogLoading"
        icon="Check"
      >
        {{ dialogConfig.dialogType === 0 ? $t('add') : $t('edit') }}
      </el-button>
    </template>
  </el-dialog>

  <!-- 统计弹窗 -->
  <div class="static-dialog">
    <el-dialog
      v-model="statisticsDialog"
      title="应用主机列表"
      @close="handleCloseForStatistics"
      width="1500px"
      draggable
    >
      <el-table
        border
        style="width: 100%"
        :header-cell-style="{
          backgroundColor: 'var(--el-color-info-light-9)'
        }"
        :data="tableConfigDetail.dataList"
        v-loading="tableConfigDetail.tableLoading"
      >
        <el-table-column
          prop="id"
          label="ID"
          align="center"
          width="90"
          fixed="left"
        ></el-table-column>
        <el-table-column
          prop="appId"
          label="appId"
          align="center"
        ></el-table-column>
        <el-table-column
          label="应用名称"
          align="center"
          width="180px"
        >
          <template v-slot="{ row }">
            <div>
              <span>{{ row.appName }}</span>
              <span class="margin-left-5">{{ row.appVersion }}</span>
            </div>
          </template>
        </el-table-column>
        <el-table-column
          label="app主机"
          align="center"
          min-width="180"
        >
          <template v-slot="{ row }">
            <div>
              <span>{{ row.appHost }}</span>
              <span>{{ ':' + row.appPort }}</span>
            </div>
          </template>
        </el-table-column>
        <!-- 在线rpc/root/ops/admin/saas/会员用户数 -->
        <el-table-column
          label="在线用户数"
          align="center"
          min-width="180"
        >
          <template v-slot="{ row }">
            <el-tooltip
              :content="handleShowUserInfo(row)"
              raw-content
              placement="top-start"
            >
              <el-text type="primary">
                <span>{{ row.userRpcNum }}</span>
                <span>/</span>
                <span>{{ row.userRootNum }}</span>
                <span>/</span>
                <span>{{ row.userOpsNum }}</span>
                <span>/</span>
                <span>{{ row.userAdminNum }}</span>
                <span>/</span>
                <span>{{ row.userSaasNum }}</span>
                <span>/</span>
                <span>{{ row.userGuestNum }}</span>
              </el-text>
            </el-tooltip>
          </template>
        </el-table-column>
        <el-table-column
          prop="accessCount"
          label="访问数"
          align="center"
          min-width="100"
        ></el-table-column>
        <el-table-column
          prop="jvmMemMax"
          label="jvm内存信息"
          align="center"
          min-width="180"
        >
          <template v-slot="{ row }">
            <div>
              <span>最大：</span>
              <span>{{ convertBytes(row.jvmMemMax) }}</span>
            </div>
            <div>
              <span>总数：</span>
              <span>{{ convertBytes(row.jvmMemTotal) }}</span>
            </div>
            <div>
              <span>空闲：</span>
              <span>{{ convertBytes(row.jvmMemFree) }}</span>
            </div>
          </template>
        </el-table-column>
        <el-table-column
          label="线程信息"
          align="center"
          min-width="150"
        >
          <template v-slot="{ row }">
            <div>
              <span>活跃：</span>
              <span>{{ row.threadActive }}</span>
            </div>
            <div>
              <span>峰值：</span>
              <span>{{ row.threadPeak }}</span>
            </div>
            <div>
              <span>守护：</span>
              <span>{{ row.threadDaemon }}</span>
            </div>
            <div>
              <span>累计：</span>
              <span>{{ row.threadStarted }}</span>
            </div>
          </template>
        </el-table-column>
        <el-table-column
          prop="createDate"
          label="创建/修改时间"
          align="center"
          width="180px"
        >
          <template v-slot="{ row }">
            <div>
              {{ dayjs(row['createDate']).format('YYYY-MM-DD HH:mm:ss') }}
            </div>
            <div>
              {{
                row.modifyDate
                  ? dayjs(row['modifyDate']).format('YYYY-MM-DD HH:mm:ss')
                  : ''
              }}
            </div>
          </template>
        </el-table-column>
        <el-table-column
          prop="lastUpdate"
          label="最后更新时间"
          align="center"
          width="170"
        >
          <template v-slot="{ row }">
            <span>
              {{
                row.lastUpdate
                  ? dayjs(row['lastUpdate']).format('YYYY-MM-DD HH:mm:ss')
                  : ''
              }}
            </span>
          </template>
        </el-table-column>
        <el-table-column
          prop="state"
          :label="t('state')"
          align="center"
          width="90"
          fixed="right"
        >
          <template v-slot="{ row }">
            <el-link
              :type="row.state === 1 ? 'success' : 'danger'"
              underline="never"
            >
              {{ handleTypeForLabel(row.state, appStates) }}
            </el-link>
          </template>
        </el-table-column>
      </el-table>
      <!-- 分页 -->
      <Pagination
        v-model:page-size="tableConfigDetail.queryParams.$rn"
        @page-size-change="handleDetailList(false)"
        :total="tableConfigDetail.sizeAll"
        v-model:current-page="tableConfigDetail.queryParams.$pg"
        @current-change="handleDetailList(false)"
      />
    </el-dialog>
  </div>
</template>

<style lang="scss" scoped>
.alignLeft {
  text-align: left;
}

.msc-app-sort {
  cursor: move;
}

.static-dialog {
  :deep(.el-dialog__body) {
    height: 600px;
    overflow: hidden auto;
  }
}
</style>
