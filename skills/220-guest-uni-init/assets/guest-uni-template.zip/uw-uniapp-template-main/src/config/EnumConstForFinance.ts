export enum TypeWithdraw {
  /**
   * 银行
   */
  BANK = 0,
  /**
   * 支付宝
   */
  ALIPAY = 1,
  /**
   * 微信
   */
  WECHAT = 2
}

export enum CurrencyType {
  /**
   * CNY
   */
  CNY = 'CNY'
}

export enum StateFinBalanceBill {
  /**
   * 未确认
   */
  INIT = 0,
  /**
   * 对账中
   */
  CHECKING = 1,
  /**
   * 对账完成
   */
  CHECK_SUCCESS = 2,
  /**
   * 对账失败
   */
  CHECK_FAIL = -2,
  /**
   * 开票申请
   */
  INVOICE_APPLY = 3,
  /**
   * 已开票
   */
  INVOICE_CONFIRM = 4,
  /**
   * 已开票
   */
  INVOICE_REJECT = -4
}

export enum TypeFinBillDate {
  /**
   * 不使用
   */
  NOT_USER = 0,
  /**
   * 入住时间/游玩日期
   */
  CHECKIN_DATE = 1,
  /**
   * 离店时间
   */
  CHECKOUT_DATE = 2,
  /**
   * 确认时间
   */
  CONFIRM_DATE = 3,
  /**
   * 支付时间
   */
  PAYMENT_DATE = 4,
  /**
   * 完成时间
   */
  FINISH_DATE = 5,
  /**
   * 下单时间
   */
  ORDER_DATE = 6,
  /**
   * 对账时间
   */
  VERIFY_DATE = 7
}

export enum TypeFinPayChannel {
  /**
   * WECHAT
   */
  WECHAT = 'WECHAT',
  /**
   * ALIPAY
   */
  ALIPAY = 'ALIPAY',
  /**
   * UNIONPAY
   */
  UNIONPAY = 'UNIONPAY'
}

export enum StateFinBalanceDeal {
  /**
   * 未确认
   */
  INIT = 0,
  /**
   * 审核确认
   */
  AUDIT_CONFIRM = 1,
  /**
   * 审核拒绝
   */
  AUDIT_REJECT = -1,
  /**
   * 审核完成
   */
  AUDIT_SUCCESS = 2,
  /**
   * 审核失败
   */
  AUDIT_FAIL = -2,
  /**
   * 已成功
   */
  NOTIFY_SUCCESS = 3,
  /**
   * 已失败
   */
  NOTIFY_FAIL = -3
}

export enum StateFinBill {
  /**
   * 对账异常
   */
  EXCEPTION = -1,
  /**
   * 未对账
   */
  NO_VERIFY = 0,
  /**
   * 已对账 未付/收款
   */
  VERIFY_AND_NO_PAY = 1,
  /**
   * 已对账 部分付/收款
   */
  VERIFY_AND_PART_PAY = 2,
  /**
   * 已对账 已付/收全款
   */
  VERIFY_AND_ALL_PAY = 3
}

export enum TypeFinPayTrade {
  /**
   * APP
   */
  APP = 'APP',
  /**
   * JSAPI_MP
   */
  JSAPI_MP = 'JSAPI_MP',
  /**
   * JSAPI_MA
   */
  JSAPI_MA = 'JSAPI_MA',
  /**
   * NATIVE
   */
  NATIVE = 'NATIVE',
  /**
   * H5
   */
  H5 = 'H5'
}

export enum TypeFinBillResult {
  /**
   * none
   */
  NORMAL = 1,
  /**
   * problem
   */
  PROBLEM = 2,
  /**
   * our_miss
   */
  OUR_MISS = 3
}

export enum StateFinPayRefund {
  /**
   * 初始状态
   */
  INIT = 0,
  /**
   * 退款申请成功
   */
  PRE_REFUND_SUCCESS = 50,
  /**
   * 退款申请失败
   */
  PRE_REFUND_ERROR = -50,
  /**
   * 退款处理中
   */
  REFUND_PROCESSING = 60,
  /**
   * 退款关闭
   */
  REFUND_CLOSED = 61,
  /**
   * 退款异常
   */
  REFUND_ABNORMAL = -60,
  /**
   * 退款通知异常
   */
  REFUND_NOTIFY_ERROR = -61,
  /**
   * 退款成功
   */
  REFUND_SUCCESS = 70
}

export enum TypeFinBizOrderList {
  /**
   * 订单ID列表
   */
  BY_ORDER_IDS = 1,
  /**
   * 供应/分销订单列表
   */
  BY_MCH_ORDER_IDS = 2,
  /**
   * 酒店确认号列表
   */
  BY_CONFIRM_IDS = 3
}

export enum TypeFinPay {
  /**
   * 线下支付
   */
  PAYMENT_OFFLINE = 0,
  /**
   * 在线支付
   */
  PAYMENT_ONLINE = 1,
  /**
   * 预存
   */
  BALANCE_DEPOSIT = 10,
  /**
   * 授信
   */
  BALANCE_CREDIT = 11,
  /**
   * 货仓预存
   */
  STORE_DEPOSIT = 20
}

export enum TypeFinBalance {
  /**
   * 预存
   */
  DEPOSIT = 1,
  /**
   * 授信
   */
  CREDIT = 2,
  /**
   * 返佣
   */
  REBATE = 3
}

export enum TypeFinBalanceDeal {
  /**
   * 存款充值
   */
  DEPOSIT_RECHARGE = 10,
  /**
   * 充值退款
   */
  DEPOSIT_RECHARGE_REFUND = -10,
  /**
   * 存款消费
   */
  DEPOSIT_CONSUME = -11,
  /**
   * 存款消费退还
   */
  DEPOSIT_CONSUME_REFUND = 11,
  /**
   * 存款收入
   */
  DEPOSIT_INCOME = 12,
  /**
   * 存款收入退款
   */
  DEPOSIT_INCOME_REFUND = -12,
  /**
   * 存款收入提现
   */
  DEPOSIT_INCOME_WITHDRAW = -13,
  /**
   * 返点提现
   */
  REBATE_WITHDRAW = -33,
  /**
   * 返点收入
   */
  REBATE_INCOME = 30,
  /**
   * 返点取消
   */
  REBATE_INCOME_REFUND = -30,
  /**
   * 信用还款
   */
  CREDIT_REPAY = 20,
  /**
   * 信用消费
   */
  CREDIT_CONSUME = -21,
  /**
   * 信用消费退款
   */
  CREDIT_CONSUME_REFUND = 21
}

export enum StateFinPayOrder {
  /**
   * 初始状态
   */
  INIT = 0,
  /**
   * 预下单成功
   */
  PRE_PAY_SUCCESS = 10,
  /**
   * 预下单失败
   */
  PRE_PAY_ERROR = -10,
  /**
   * 用户支付中
   */
  PAY_ING = 20,
  /**
   * 未支付
   */
  PAY_NONE = 21,
  /**
   * 转入退款
   */
  PAY_REFUND = 22,
  /**
   * 支付已关闭
   */
  PAY_CLOSED = 23,
  /**
   * 支付已撤销(付款码)
   */
  PAY_REVOKED = 24,
  /**
   * 支付失败
   */
  PAY_ERROR = -20,
  /**
   * 支付通知失败
   */
  PAY_NOTIFY_ERROR = -21,
  /**
   * 支付成功
   */
  PAY_SUCCESS = 30
}
