<script lang="ts" setup>
import { useMainStore } from "@/store/main";
import Menu from "./menu/index.vue";
import type { MENU_ITEM } from "./menu/type";
import icon from "../../config/icon";
import { routes } from "@/router";

const mainStore = useMainStore();

// 路由配置
const routeList = computed<MENU_ITEM[]>(() => {
  if (mainStore.appMenu.length === 0) {
    return [];
  }
  const list = mainStore.appMenu[mainStore.navIndex].children;
  const data: MENU_ITEM[] = list.map((item) => {
    const target = routes.find((routeItem) => routeItem.path === item.permCode);
    return {
      name: item.permName,
      icon: icon(item.permCode!),
      route: item.permCode!,
      list: item.children?.map((childrenItem) => {
        return {
          name: childrenItem.permName,
          icon: icon(childrenItem.permCode!),
          route: childrenItem.permCode!,
        };
      }),
    };
  });
  return data;
});
</script>

<template>
  <div
    :class="{
      'layout-aside': true,
      'aside-collapse': mainStore.collapse,
    }"
  >
    <Menu :list="routeList" />
  </div>
</template>

<style lang="scss" scoped>
.layout-aside {
  flex-shrink: 0;
  width: $asideWidth;
  transition: 0.3s;

  .aside-logo {
    width: 100%;
    height: var(--header-height);
    padding: 5px 10px;
    box-sizing: border-box;
    background-color: #fff;
    transition: 0.3s;
  }

  &.aside-collapse {
    width: $asideCollapseWidth;

    .aside-logo {
      width: 100%;
      padding: 0;
      border-radius: 50%;
      overflow: hidden;
    }
  }
}
</style>
