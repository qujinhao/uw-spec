/**
 * Request 事件处理模块
 * 用于处理 request 层和 store 层之间的通信
 * 解决循环依赖问题
 */

import pinia from '@/store/index'
import { useUserStore } from '@/store/user'
import { setTokenInfo } from '@/utils/tokenManager'
import { authRefreshToken } from '@/api/authUwAuthCenterApiAuth'

/**
 * 初始化 request 相关事件监听
 * 在应用启动时调用
 */
export function initRequestEventHandlers() {
  // 监听 token 刷新事件
  uni.$on(
    'refreshToken',
    (data: { createAt: number; expiresIn: number; token: string }) => {
      try {
        const userStore = useUserStore(pinia)
        userStore.setRefreshTokenInfo(data)
        // 同时更新 tokenManager
        setTokenInfo({ token: data.token })
      } catch (error) {
        console.error('处理 refreshToken 事件失败:', error)
      }
    }
  )

  // 监听清除登录缓存事件
  uni.$on('clearLoginCache', () => {
    try {
      const userStore = useUserStore(pinia)
      userStore.clearLoginCache()
    } catch (error) {
      console.error('处理 clearLoginCache 事件失败:', error)
    }
  })

  // 监听执行 token 刷新事件（由 request 层触发，store 层处理）
  uni.$on(
    'doRefreshToken',
    (data: {
      loginAgent: string
      refreshToken: string
      onSuccess: () => void
      onError: () => void
    }) => {
      try {
        const userStore = useUserStore(pinia)
        authRefreshToken({
          loginAgent: data.loginAgent,
          refreshToken: data.refreshToken
        })
          .then((authRefreshRes) => {
            const authRefreshData = {
              createAt: authRefreshRes.data?.createAt || 0,
              expiresIn: authRefreshRes.data?.expiresIn || 0,
              token: authRefreshRes.data?.token || ''
            }
            userStore.setRefreshTokenInfo(authRefreshData)
            // 同时更新 tokenManager
            setTokenInfo({ token: authRefreshData.token })
            // 调用成功回调
            data.onSuccess()
          })
          .catch((error) => {
            console.log('authRefreshToken error:', error)
            // 调用失败回调
            data.onError()
          })
      } catch (error) {
        console.error('处理 doRefreshToken 事件失败:', error)
        data.onError()
      }
    }
  )
}

/**
 * 移除 request 相关事件监听
 * 在应用卸载时调用（如果需要）
 */
export function removeRequestEventHandlers() {
  uni.$off('refreshToken')
  uni.$off('clearLoginCache')
  uni.$off('doRefreshToken')
}
