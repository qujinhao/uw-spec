<template>
  <transition name="el-fade-in">
    <div
      :class="{ relative: mode === 'fixed', fixed: mode === 'pop' }"
      v-show="isShow"
      ref="captChaRef"
    >
      <div class="header-tip margin-bottom-5">
        {{ `${t('pleaseClick')}【${pointTextListForComputed.join(',')}】` }}
      </div>
      <div class="verify-img-out">
        <div
          class="verify-img-panel"
          :style="{
            width: setSize.imgWidth + 'px',
            height: setSize.imgHeight + 'px',
            backgroundSize: `${setSize.imgWidth}px ${setSize.imgHeight}px`,
            marginBottom: vSpace + 'px'
          }"
        >
          <div
            class="verify-refresh"
            style="z-index: 3"
            @click="refresh"
            v-show="showRefresh"
          >
            <el-icon
              size="22px"
              color="var(--el-slide-menu-background)"
            >
              <Refresh />
            </el-icon>
          </div>
          <img
            :src="'data:image/png;base64,' + pointBackImgBase"
            ref="imgRef"
            alt=""
            @click="bindingClick ? imageClick($event) : undefined"
          />

          <div
            v-for="(tempPoint, index) in tempPoints"
            :key="index"
            class="point-area"
            :style="{
              backgroundColor: '#1abd6c',
              color: '#fff',
              zIndex: 9999,
              width: '20px',
              height: '20px',
              textAlign: 'center',
              lineHeight: '20px',
              borderRadius: '50%',
              position: 'absolute',
              top: parseInt(String(tempPoint.y - 10)) + 'px',
              left: parseInt(String(tempPoint.x - 10)) + 'px'
            }"
          >
            {{ index + 1 }}
          </div>
        </div>
      </div>
      <div
        class="verify-bar-area"
        :style="{
          width: setSize.imgWidth + 'px',
          height: setSize.barHeight + 'px',
          color: barAreaColor,
          lineHeight: setSize.barHeight + 'px'
        }"
      >
        <span class="verify-msg">{{ text }}</span>
      </div>
    </div>
  </transition>
</template>
<script lang="ts" setup name="TextClickCaptcha">
import { resetSize } from './utils'
import { type ComponentInternalInstance } from 'vue'
import { useI18n } from 'vue-i18n'

interface sizeType {
  width: string
  height: string
}

interface pointType {
  x: number
  y: number
}

const { t } = useI18n()
const props = withDefaults(
  defineProps<{
    show?: boolean
    mode?: 'fixed' | 'pop' // fixed 正常展示  pop弹窗展示
    imgCodeForValidate: string // 图片url
    pointTextList: string[] // 图片上的文字
    vSpace?: number
    imgSize?: sizeType
    barSize?: sizeType
  }>(),
  {
    show: false,
    mode: 'pop',
    vSpace: 5,
    imgSize: () => ({
      width: '360px',
      height: '140px'
    }),
    barSize: () => ({
      width: '360px',
      height: '40px'
    })
  }
)

const emits = defineEmits<{
  (e: 'update:show', val: boolean): void
  (e: 'validate', val: string): void
  (e: 'refresh'): void
}>()

const isShow = computed({
  get() {
    return props.show
  },
  set(val) {
    emits('update:show', val)
  }
})

const { proxy } = getCurrentInstance() as ComponentInternalInstance
const checkNum = ref(4) //默认需要点击的字数
const fontPos = reactive([]) //选中的坐标信息
const checkPosArr = reactive<pointType[]>([]) //用户点击的坐标
const num = ref(1) //点击的记数
const pointBackImgBase = computed(() => props.imgCodeForValidate)
const pointTextListForComputed = computed(() => props.pointTextList)
const setSize = reactive<{
  imgHeight: number
  imgWidth: number
  barHeight: number
  barWidth: number
}>({
  imgHeight: 140,
  imgWidth: 360,
  barHeight: 40,
  barWidth: 360
})
const tempPoints = reactive<pointType[]>([])
const text = ref('')
const barAreaColor = ref<string>('')
const showRefresh = ref(true)
const bindingClick = ref(true)
const startTime = ref(0)

//加载页面
const init = () => {
  tempPoints.splice(0, tempPoints.length)
  fontPos.splice(0, fontPos.length)
  checkPosArr.splice(0, checkPosArr.length)
  num.value = 1
  changeWord()
  nextTick(() => {
    let { imgHeight, imgWidth, barHeight, barWidth } = resetSize(proxy)
    setSize.imgHeight = imgHeight
    setSize.imgWidth = imgWidth
    setSize.barHeight = barHeight
    setSize.barWidth = barWidth
  })
}

const changeWord = () => {
  text.value = `${t('pleaseClick')}【${pointTextListForComputed.value.join(
    ','
  )}】`
}

const imgRef = ref(null)
const imageClick = (e: MouseEvent) => {
  checkPosArr.push(getMousePos(e))
  if (num.value === 1) {
    startTime.value = +new Date()
  }
  if (num.value === checkNum.value) {
    num.value = createPoint(getMousePos(e))
    //按比例转换坐标值
    let arr = pointTransform(checkPosArr, setSize)
    checkPosArr.length = 0
    checkPosArr.push(...arr)
    //等创建坐标执行完
    setTimeout(() => {
      const data = {
        answerData: JSON.stringify(checkPosArr),
        opTime: +new Date() - startTime.value
      }
      emits('validate', JSON.stringify(data))
    }, 400)
  }
  if (num.value < checkNum.value) {
    num.value = createPoint(getMousePos(e))
  }
}

// 校验成功
const validateSuccess = () => {
  barAreaColor.value = 'var(--el-color-success)'
  text.value = t('validateSuccess')
  bindingClick.value = false
  startTime.value = 0
  if (props.mode === 'pop') {
    setTimeout(() => {
      isShow.value = false
    }, 1500)
  } else {
    isShow.value = false
  }
}

// 校验失败
const validateError = () => {
  barAreaColor.value = 'var(--el-color-danger)'
  text.value = t('validateError')
  startTime.value = 0
}

//获取坐标
const getMousePos = (e: MouseEvent) => {
  let x = e.offsetX
  let y = e.offsetY
  return { x, y }
}

//创建坐标点
const createPoint = (pos: pointType) => {
  tempPoints.push({ ...pos })
  return num.value + 1
}

// 刷新
const refresh = () => {
  tempPoints.splice(0, tempPoints.length)
  barAreaColor.value = 'var(--el-text-color-primary)'
  bindingClick.value = true
  fontPos.splice(0, fontPos.length)
  checkPosArr.splice(0, checkPosArr.length)
  startTime.value = 0
  num.value = 1
  emits('refresh')
  text.value = ''
  showRefresh.value = true
}

// 重置
const reset = () => {
  tempPoints.splice(0, tempPoints.length)
  barAreaColor.value = 'var(--el-text-color-primary)'
  bindingClick.value = true
  fontPos.splice(0, fontPos.length)
  checkPosArr.splice(0, checkPosArr.length)
  num.value = 1
  text.value = ''
  showRefresh.value = true
  startTime.value = 0
}

//坐标转换函数
const pointTransform = function (
  pointArr: pointType[],
  imgSize: {
    imgHeight: number
    imgWidth: number
    barHeight: number
    barWidth: number
  }
) {
  let newPointArr = pointArr.map(p => {
    let x = Math.round((360 * p.x) / parseInt(String(imgSize.imgWidth)))
    let y = Math.round((140 * p.y) / parseInt(String(imgSize.imgHeight)))
    return { x, y }
  })
  return newPointArr
}

const dialogWidth = computed(() => {
  return Number(props.imgSize.width.replace(/px/, '')) + 20 + 'px'
})

const dialogHeight = computed(() => {
  return Number(props.imgSize.height.replace(/px/, '')) + 90 + 'px'
})

// 元素
const captChaRef = ref()
// 点击外部关闭
onClickOutside(captChaRef, () => {
  if (props.mode === 'pop') {
    isShow.value = false
    reset()
  }
})

defineExpose({
  validateSuccess,
  validateError,
  changeWord
})

watch(
  () => props.imgCodeForValidate,
  val => {
    if (props.show) {
      if (val) {
        reset()
        init()
      } else {
        reset()
      }
    }
  },
  {
    immediate: true
  }
)
</script>

<style lang="scss" scoped>
.relative {
  position: relative;
  :deep(.menu-icon__box) {
    width: 100%;
  }
}
.fixed {
  position: fixed;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: v-bind(dialogWidth);
  height: v-bind(dialogHeight);
  z-index: 10;
  box-shadow: 0 0 11px 0 #999;
  background-color: var(--el-bg-color);
  box-sizing: border-box;
  border-radius: 6px;
  padding: 10px;
  :deep(.menu-icon__box) {
    width: 100%;
  }
}

.verify-tips {
  position: absolute;
  left: 0px;
  bottom: 0px;
  width: 100%;
  height: 30px;
  line-height: 30px;
  color: #fff;
}

.verify-code {
  font-size: 20px;
  text-align: center;
  cursor: pointer;
  margin-bottom: 5px;
  border: 1px solid #ddd;
}

.cerify-code-panel {
  height: 100%;
  overflow: hidden;
}

.verify-code-area {
  float: left;
}

.verify-input-area {
  float: left;
  width: 60%;
  padding-right: 10px;
}

.verify-change-area {
  line-height: 30px;
  float: left;
}

.varify-input-code {
  display: inline-block;
  width: 100%;
  height: 25px;
}

.verify-change-code {
  color: #337ab7;
  cursor: pointer;
}

.verify-btn {
  width: 200px;
  height: 30px;
  background-color: #337ab7;
  color: #ffffff;
  border: none;
  margin-top: 10px;
}

/*滑动验证码*/
.verify-bar-area {
  position: relative;
  background: var(--el-main-container-background);
  text-align: center;
  box-sizing: content-box;
  -moz-box-sizing: content-box;
  box-sizing: content-box;
  border-radius: 4px;
}

.verify-img-panel {
  margin: 0;
  -webkit-box-sizing: content-box;
  -moz-box-sizing: content-box;
  box-sizing: content-box;
  border: 1px solid #ddd;
  border-radius: 3px;
  position: relative;
  img {
    width: 100%;
    height: 100%;
    display: block;
    border-radius: 4px;
  }
}

.verify-img-panel .verify-refresh {
  width: 25px;
  height: 25px;
  text-align: center;
  padding: 5px;
  cursor: pointer;
  position: absolute;
  top: 0;
  right: 0;
  z-index: 2;
}

.verify-img-panel .icon-refresh {
  font-size: 20px;
  color: #fff;
}

.verify-bar-area .verify-move-block .verify-icon {
  font-size: 18px;
}

.verify-bar-area .verify-msg {
  z-index: 3;
  font-size: 12px;
  color: var(--el-text-color-secondary);
}

.header-tip {
  color: var(--el-text-color-primary);
  font-size: 16px;
}
</style>
