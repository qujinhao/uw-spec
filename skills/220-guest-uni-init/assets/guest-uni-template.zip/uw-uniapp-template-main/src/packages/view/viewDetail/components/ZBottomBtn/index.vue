<script lang="ts" setup>
import { onMounted } from 'vue'
import { useMainStore } from '@/store/main'
import { navToUrl } from '@/utils/tool'

const mainStore = useMainStore()

const menus = [
  {
    icon: mainStore.customProject.siteConfig?.config?.navigation.list[0].icon,
    text: mainStore.customProject.siteConfig?.config?.navigation.list[0].text,
    url: '/pages/home/index',
    query: {}
  },

  {
    icon: mainStore.customProject.siteConfig?.config?.navigation.list[2].icon,
    text: mainStore.customProject.siteConfig?.config?.navigation.list[2].text,
    url: '/template/template/tab-second',
    query: {}
  }
]

withDefaults(
  defineProps<{
    btnLoading?: boolean // 按钮loading
  }>(),
  {
    btnLoading: false
  }
)
const emits = defineEmits<{
  (e: 'click'): void
}>()
const submit = () => {
  emits('click')
}

onMounted(() => {
  console.log('product-footer ---')
})
</script>

<template>
  <view class="product-footer flex-align space-between">
    <view class="product-footer__left color-black space-between">
      <view
        class="product-footer__left__item flex-col flex-align mr5"
        v-for="(item, index) in menus"
        :key="index"
        @click="navToUrl(item.url)"
      >
        <view
          class="iconfont icon_text"
          :class="item.icon"
        ></view>
        <view class="label">{{ item.text }}</view>
      </view>
      <!-- <view class="product-footer__left__item flex-col flex-align mr30">
        <view class="iconfont x"></view>
        <view class="label">客服</view>
      </view> -->
      <!-- <view class="product-footer__left__item flex-col flex-align m-r-30">
        <view class="iconfont x"></view>
        <view class="label">分享</view>
      </view>
      <view class="product-footer__left__item flex-col flex-align m-r-30">
        <view class="iconfont x"></view>
        <view class="label">购物车</view>
      </view> -->
    </view>
    <view class="product-footer__btns flex-align flex-end flex-1">
      <!-- <view
        class="product-footer__btns__item flex-center add-cart__btn"
        @tap="submit"
      >
        加入购物车
      </view> -->
      <view
        class="product-footer__btns__item flex-center submit__btn primary-color-bg"
        @tap="submit"
      >
        立即下单
      </view>
    </view>
  </view>
</template>

<style lang="scss" scoped>
.product-footer {
  position: fixed;
  left: 0;
  bottom: 0;
  z-index: 98;
  width: 100%;
  font-size: 30rpx;
  background-color: #fff;
  box-shadow: 0 -1px 5px rgba(0, 0, 0, 0.05);
  padding: 16rpx 20rpx calc(env(safe-area-inset-bottom) / 2 + 16rpx);
  box-sizing: border-box;
  &__left {
    &__item {
      width: 50px;
      color: #666666;
      .iconfont {
        font-size: 30rpx;
      }
      .label {
        font-size: 24rpx;
      }
    }
  }
  &__btns {
    $radius: 50rpx;
    &__item {
      width: 100%;
      font-size: 26rpx;
      color: #ffffff;
      padding: 16rpx 20rpx;
    }
    .add-cart__btn {
      border-radius: $radius $radius $radius $radius;
    }
    .submit__btn {
      border-radius: $radius $radius $radius $radius;
    }
  }

  .icon_text {
    font-weight: 700;
  }
}
</style>
