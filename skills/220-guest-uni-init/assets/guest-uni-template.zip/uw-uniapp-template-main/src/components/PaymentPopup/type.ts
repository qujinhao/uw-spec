import type { AisLinkerConfigInfo } from '@/api/saasFinanceAppGuestApi'

// 扩展支付配置信息
export interface Extend_AisLinkerConfigInfo extends AisLinkerConfigInfo {
  payRemark?: string
  payChannel?: string // 从"pubParamMap": {"pay.channel": "WECHAT"}, 中抽离出来
}
