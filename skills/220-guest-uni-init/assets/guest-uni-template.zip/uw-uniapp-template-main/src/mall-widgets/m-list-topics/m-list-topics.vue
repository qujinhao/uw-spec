<template>
  <!-- 主题列表 - 未开发 -->
  <view
    class="m-list-topics"
    :style="[wrapStyle(styles), changeBgColor()]"
  >
    <view
      class="m-list-topics-body"
      :style="[getWrapStyle()]"
    >
      <view
        class="grids"
        :style="[getGridsStyle()]"
      >
        <view
          v-for="(item, i) in list"
          :key="'tab-nav' + i"
          class="grid-item"
          :style="[geItemStyle()]"
          @click="clickItem(item)"
        >
          <view v-if="attrs.overHide && list.length > attrs.max * 2">
            <!-- 超出部分隐藏 -->
            <view v-if="isHide">
              <!-- 隐藏状态 -->
              <view v-if="i < attrs.max * 2 - 1">
                <view
                  :style="{ height: unit(props.styles.imgWidth) }"
                  class="m-grid-nav-image"
                >
                  <view
                    v-if="['image', 'image-text'].includes(attrs.type)"
                    :style="
                      listField.imgKey && [
                        geItemImgStyle(item[listField.imgKey])
                      ]
                    "
                  ></view>
                  <!-- <image
                    v-if="['image', 'image-text'].includes(attrs.type)"
                    ref="image"
                    mode="scaleToFill"
                    :style="[geItemImgStyle()]"
                    :src="item[listField.imgKey] || defaultIamge"
                  /> -->
                </view>
                <text
                  v-if="['text', 'image-text'].includes(attrs.type)"
                  class="ellipsis-1"
                >
                  {{ listField.nameKey && item[listField.nameKey] }}
                </text>
              </view>
              <view
                v-else-if="i === attrs.max * 2 - 1"
                @click="toChangeHideState(false)"
              >
                <view
                  :style="{ height: unit(props.styles.imgWidth) }"
                  class="m-grid-nav-image"
                >
                  <view v-if="['image', 'image-text'].includes(attrs.type)">
                    <text>...</text>
                  </view>
                  <!-- <image
                    v-if="['image', 'image-text'].includes(attrs.type)"
                    ref="image"
                    mode="scaleToFill"
                    :style="[geItemImgStyle()]"
                    :src="item[listField.imgKey] || defaultIamge"
                  /> -->
                </view>
                <text
                  v-if="['text', 'image-text'].includes(attrs.type)"
                  class="ellipsis-1"
                >
                  展开
                </text>
              </view>
            </view>
            <view v-else-if="!isHide">
              <!-- 展开状态 -->
              <view>
                <view
                  :style="{ height: unit(props.styles.imgWidth) }"
                  class="m-grid-nav-image"
                >
                  <view
                    v-if="['image', 'image-text'].includes(attrs.type)"
                    :style="
                      listField.imgKey && [
                        geItemImgStyle(item[listField.imgKey])
                      ]
                    "
                  ></view>
                  <!-- <image
                    v-if="['image', 'image-text'].includes(attrs.type)"
                    ref="image"
                    mode="scaleToFill"
                    :style="[geItemImgStyle()]"
                    :src="item[listField.imgKey] || defaultIamge"
                  /> -->
                </view>
                <text
                  v-if="['text', 'image-text'].includes(attrs.type)"
                  class="ellipsis-1"
                >
                  {{ listField.nameKey && item[listField.nameKey] }}
                </text>
              </view>
            </view>
          </view>
          <view v-else>
            <view
              :style="{ height: unit(props.styles.imgWidth) }"
              class="m-grid-nav-image"
            >
              <view
                v-if="['image', 'image-text'].includes(attrs.type)"
                :style="
                  listField.imgKey && [geItemImgStyle(item[listField.imgKey])]
                "
              ></view>
              <!-- <image
                  v-if="['image', 'image-text'].includes(attrs.type)"
                  ref="image"
                  mode="scaleToFill"
                  :style="[geItemImgStyle()]"
                  :src="item[listField.imgKey] || defaultIamge"
                /> -->
            </view>
            <text
              v-if="['text', 'image-text'].includes(attrs.type)"
              class="ellipsis-1"
            >
              {{ listField.nameKey && item[listField.nameKey] }}
            </text>
          </view>
        </view>
        <li
          class="grid-item"
          :style="[geItemStyle()]"
          v-if="!isHide && list.length > attrs.max * 2"
        >
          <view @click="toChangeHideState(true)">
            <view
              :style="{ height: unit(props.styles.imgWidth) }"
              class="m-grid-nav-image"
            >
              <view v-if="['image', 'image-text'].includes(attrs.type)">
                <text>...</text>
              </view>
              <!-- <image
                  v-if="['image', 'image-text'].includes(attrs.type)"
                  ref="image"
                  mode="scaleToFill"
                  :style="[geItemImgStyle()]"
                  :src="item[listField.imgKey] || defaultIamge"
                /> -->
            </view>
            <text
              v-if="['text', 'image-text'].includes(attrs.type)"
              class="ellipsis-1"
            >
              隐藏
            </text>
          </view>
        </li>
      </view>
    </view>
  </view>
</template>

<script lang="ts" setup>
import { computed, ref, type StyleValue, onMounted } from 'vue'
import { wrapStyle, cmpStyle, unit } from '../utils/registerBaseStyle'
import type { PropsType, JumpType } from './type'

const defaultIamge = 'http://qnimg.zowoyoo.com/img/84826/1715237104041.png'
const props = withDefaults(defineProps<PropsType>(), {
  attrs: () => ({
    model: 'fixed', // 模式选择
    type: 'image-text', // 显示类型
    max: 4, // 一行显示数量
    overHide: false //超出是否隐藏
  }),
  styles: () => ({
    pagePadding: 0, //	页面边距
    cmpUpperPadding: 10, //	上边距
    cmpLowerPadding: 10, //	下边距
    imgPadding: 0, //	单项间距
    cmpUpperRadius: 0, //	上圆角
    cmpLowerRadius: 0, //	下圆角
    itemWidth: 100, //	单项宽度
    imgWidth: 50, //	图片宽度
    imgRadius: 0, // 图片圆角
    fontSize: 12, //	文本字体
    titleColor: '', //	文本颜色
    cmpBackground: '' //	组件背景
  }),
  listField: () => ({
    imgKey: 'menuLogo', // 显示的key字段 用来定义list中要显示的那个字段的值
    pathKey: 'menuLink', // 路径跳转链接
    nameKey: 'menuName'
  })
})

const emit = defineEmits<{
  jump: [item: JumpType]
}>()

const isHide = ref(false)

const itemWidth = computed(() => {
  return (
    (375 - props.styles.pagePadding * 2 - props.styles.imgPadding) /
    Number(props.attrs.max)
  )
})

// 容器样式
const getWrapStyle = (): StyleValue => {
  return {
    overflowX: props.attrs.model === 'fixed' ? 'hidden' : 'auto',
    ...cmpStyle(props.styles)
  }
}
const changeBgColor = () => {
  return {
    background: props.styles.cmpBackground
  }
}
// grids 样式
const getGridsStyle = () => {
  if (props.attrs.model === 'fixed') {
    const gap = props.styles.imgPadding || 0 // 间隔（gap）大小
    const columns = Number(props.attrs.max || '4') // 每行列数

    // 因为每两列之间有一个gap，所以需要除以(columns + 1)来平均分配gap
    const effectiveColumnWidth =
      (100 - (columns + 1) * (gap / columns)) / columns

    return {
      display: 'grid',
      gridTemplateColumns: `repeat(auto-fit, minmax(${effectiveColumnWidth}%, 1fr))`,
      gap: unit(gap)
    }
  }
  if (props.attrs.model === 'scroll') {
    return {
      width: unit(
        (itemWidth.value + props.styles.imgPadding * 2) * props.list.length
      )
    }
  }
}

// 单项样式
const geItemStyle = () => {
  return {
    placeSelf: 'center',
    color: props.styles.titleColor,
    width: unit(
      props.attrs.model === 'fixed' ? props.styles.itemWidth : itemWidth.value
    )
  }
}

// 单项图片样式
const geItemImgStyle = (imgUrl?: string) => {
  return {
    width: unit(props.styles.imgWidth),
    height: unit(props.styles.imgWidth),
    borderRadius: unit(props.styles.imgRadius),
    marginBottom: props.attrs.type === 'image-text' ? unit(5) : 0,
    backgroundImage: `url(${imgUrl || defaultIamge})`,
    backgroundSize: 'cover'
  }
}
// 跳转
const clickItem = (item: any) => {
  let url = ''
  if (props.listField && props.listField.pathKey) {
    url = item[props.listField.pathKey]
  }
  if (!url) return
  emit('jump', { id: url, type: 'link' })
}

// 改变隐藏状态
const toChangeHideState = (val: boolean) => {
  isHide.value = val
}

onMounted(() => {
  if (
    props.list.length > props.attrs.max * 2 &&
    props.attrs.overHide === true
  ) {
    isHide.value = true
  }
})
</script>

<style lang="scss" scoped>
.m-list-topics {
  .m-list-topics-body {
    &::-webkit-scrollbar {
      display: none;

      /* Chrome Safari */
    }

    .grids {
      .grid-item {
        display: inline-flex;
        flex-direction: column;
        align-items: center;
      }
    }
  }

  .ellipsis-1 {
    text-overflow: ellipsis;
    white-space: normal;
    word-break: break-all;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 1;
    overflow: hidden;
    line-height: normal;
    text-align: center;
  }
}

.m-grid-nav-image {
  display: flex;
  justify-content: center;
  align-items: center;
}
</style>
