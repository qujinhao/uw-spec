import { getT } from '@/i18n'
import { ElMessage, ElMessageBox, ElMessageBoxOptions } from 'element-plus'

// usePrompt入参类型配置，剔除callback,详情配置查看element-plus文档
interface usePromptConfig extends Omit<ElMessageBoxOptions, 'callback'> {
  confirmCallBack?: (remark?: string) => void // 点击确认执行方法
  cancelCallBack?: () => void // 点击取消执行方法
}

/**
 * 消息弹窗prompt hooks  主要用于启用、禁用
 * @param config  配置项信息详情查看element-plus文档，配置项去除callback配置项，
 * 增加confirmCallback(点击确认执行回调)
 * cancelCallback(点击取消执行回调)
 *
 */
export const usePrompt = (config: usePromptConfig) => {
  const t = getT()
  const options: usePromptConfig = {
    ...config
  }
  const unOptionsKeys = [
    'confirmCallBack',
    'cancelCallBack',
    'message',
    'title'
  ]
  unOptionsKeys.forEach(key => {
    if (key in config) {
      delete config[key as keyof usePromptConfig]
    }
  })
  return ElMessageBox.prompt(options.message, options.title || t('tip'), {
    ...config
  })
    .then(({ value }) => {
      options.confirmCallBack && options.confirmCallBack(value)
    })
    .catch(() => {
      if (options.cancelCallBack) {
        options.cancelCallBack && options.cancelCallBack()
      } else {
        ElMessage({
          type: 'info',
          message: t('operation') + t('cancel')
        })
      }
    })
}
