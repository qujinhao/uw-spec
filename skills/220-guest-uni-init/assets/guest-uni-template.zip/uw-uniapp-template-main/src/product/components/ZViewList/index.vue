<template>
  <view class="z-view-list">
    <view class="z-view-list-title">
      <p>
        <text>{{ title }}</text>
        <i v-if="titleType === 'colours'"></i>
      </p>
    </view>
    <template
      v-for="(prod, index) in dataArr"
      :key="index"
    >
      <view
        class="z-view-products"
        @click="goProductDetail(prod)"
      >
        <view class="z-view-products-top">
          <view class="z-view-products-title">{{ prod.infoTitle }}</view>
          <view class="z-view-products-tag">
            <text>
              {{
                prod.startDay === 0
                  ? '当天可预订'
                  : `需提前${prod.startDay}天预定`
              }}
            </text>
          </view>
        </view>
        <view class="z-view-products-bottom">
          <view class="z-view-products-price">
            <text class="marketPrice">
              <i>￥</i>
              {{ prod.salePrice }}
              <i v-if="postfix">{{ postfix }}</i>
            </text>
            <view class="price-box">
              <text
                class="price"
                v-if="prod.price && showPrice"
              >
                <i class="currency">
                  <b>￥</b>
                </i>
                <i class="p">{{ prod.price }}</i>
              </text>
            </view>
          </view>
          <text class="z-view-products-book">
            {{ '预订' }}
          </text>
        </view>
      </view>
    </template>
    <view
      class="z-detail-collapse-look"
      v-if="dataList.length > num"
    >
      <text @click="show = !show">
        {{ show ? '隐藏' : '查看全部' }}
        <uni-icons :name="show ? 'up' : 'down'" />
      </text>
    </view>
  </view>
</template>

<script lang="ts" setup>
import { ref, computed } from 'vue'

const props = defineProps<{
  showPrice: boolean
  num: number
  title: string
  titleType: string
  dataList: any[]
  postfix: string
}>()

const emit = defineEmits<{
  (e: 'click', item: any): void
}>()

const show = ref(false)

const dataArr = computed(() => {
  let arr = [...props.dataList]
  if (show.value) {
    arr = [...props.dataList]
  } else {
    arr = arr.slice(0, props.num)
  }
  return arr
})

const goProductDetail = (item: any) => {
  emit('click', item)
}
</script>

<style lang="scss" scoped>
@import './style/index.scss';
</style>
