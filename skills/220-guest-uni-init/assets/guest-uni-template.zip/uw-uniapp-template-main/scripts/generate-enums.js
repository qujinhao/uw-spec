import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'

// 获取当前文件路径
const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

// 读取EnumLabelMap.json文件
const enumLabelMapPath = path.join(__dirname, '../src/config/EnumLabelMap.json')
const enumLabelMapContent = fs.readFileSync(enumLabelMapPath, 'utf8')
const enumLabelMap = JSON.parse(enumLabelMapContent)

// 提取data对象
const enumData = enumLabelMap.data

// 处理不同格式的枚举数据
const processedEnumData = {}

for (const [enumName, enumValues] of Object.entries(enumData)) {
  // 检查是否为简单键值对格式（如  TypeTagParent ）
  const isSimpleStringEnum = Object.values(enumValues).every(
    (value) => typeof value === 'string' && value === enumValues[value]
  )

  if (['ResponseCode'].includes(enumName)) {
    // 特殊处理 ResponseCode 格式
    processedEnumData[enumName] = {}
    for (const [key, value] of Object.entries(enumValues)) {
      if (value.code) {
        processedEnumData[enumName][key] = value.code
      }
    }
  } else if (['TypeData'].includes(enumName)) {
    // 不做任何处理
    processedEnumData[enumName] = {}
  } else if (isSimpleStringEnum) {
    // 保持原有逻辑不变，直接复制
    // processedEnumData[enumName] = enumValues
    processedEnumData[enumName] = {}
    for (const [key, value] of Object.entries(enumValues)) {
      processedEnumData[enumName][key] = value
      // console.log('key:', key, value)
    }
  } else {
    // 保持原有逻辑不变
    processedEnumData[enumName] = enumValues
  }
}

// 获取每项的输出label
function getItemLabel(item) {
  return (
    item.label ||
    item.message ||
    item.langName ||
    item.labelKey ||
    item.value ||
    item.code ||
    item
  )
}
// 获取每项的输出值
function getItemValue(item) {
  if (item.code === 0 || item.code === '') return item.code
  if (item.value === 0 || item.value === '') return item.value
  if (item.fullCode === 0 || item.fullCode === '') return item.fullCode
  if (item.langKey === 0 || item.langKey === '') return item.langKey
  return item.value || item.code || item.fullCode || item.langKey || item
}

/**
 * 构建枚举定义文件 把后端返回的 hashMap 结构转成 enum 字符串
 * @param hashMap  后端 data 字段
 * @param keyPath  需要转换的 key，如 'TypeApply'；不传则全部转换
 */
function buildEnum(hashMap, keyPath) {
  const target = keyPath ? { [keyPath]: hashMap[keyPath] } : hashMap

  const lines = []
  Object.entries(target).forEach(([parentKey, group]) => {
    lines.push(`export enum ${parentKey} {`)
    const entries = Object.entries(group)
    entries.forEach(([key, item], index) => {
      // 用 label 里的中文做注释，采用JSDoc格式并将注释放在枚举值上方
      const label = getItemLabel(item)
      let value = getItemValue(item)
      // console.log('value:', value)
      /*
      value: BOOK_SMS
      value: { value: 0, label: '大于等于' }
      value: 3
      value: { value: 0, label: '申请' }
      value: 1
      value: SESSION_STOCK
      */

      if (typeof value === 'object') {
        value = getItemValue(value)
      } else if (typeof value !== 'number') {
        value = `'${value}'` // 处理特殊值 转为string
      }
      lines.push(`  /**`)
      lines.push(`   * ${label}`)
      lines.push(`   */`)
      if (index === entries.length - 1) {
        lines.push(`  ${key} = ${value}`)
      } else {
        lines.push(`  ${key} = ${value},`)
      }
    })
    lines.push('}\n')
  })

  return lines.join('\n')
}
// 生成枚举定义
const enumCode = buildEnum(processedEnumData)
// 写入到EnumConst.ts文件
const outputPath = path.join(__dirname, '../src/config/EnumConst.ts')
fs.writeFileSync(outputPath, enumCode, 'utf8')
console.log('枚举定义文件已生成:', outputPath)

/**
 * 构建枚举定义文件 把后端返回的 hashMap 结构转成 options 选项列表
 * @param hashMap  后端 data 字段
 */
function buildOptions(hashMap) {
  const lines = []
  Object.entries(hashMap).forEach(([parentKey, group]) => {
    // , 'SaasMallResponseCode', 'AuthErrorType'
    if (!['TypeData'].includes(parentKey)) {
      lines.push(`export const ${parentKey}Options = [`)
      const entries = Object.entries(group)
      // eslint-disable-next-line @typescript-eslint/no-unused-vars
      entries.forEach(([key, item]) => {
        // 用 label 里的中文做注释，采用JSDoc格式并将注释放在枚举值上方
        const label = getItemLabel(item)
        let value = getItemValue(item)
        if (typeof value !== 'number') {
          value = `'${value}'` // 处理特殊值 转为string
        }
        lines.push(`{label: '${label}', value: ${value}},`)
      })
      lines.push(']\n')
    }
  })

  return lines.join('\n')
}

// 处理不同格式的Options数据
const processedOptionsData = {}
for (const [enumName, enumValues] of Object.entries(enumData)) {
  // 检查是否为简单键值对格式（如  TypeTagParent ）
  const isSimpleStringEnum = Object.values(enumValues).every(
    (value) => typeof value === 'string' && value === enumValues[value]
  )
  if (!isSimpleStringEnum) {
    processedOptionsData[enumName] = enumValues
  }
}

// 生成Options定义
const options = buildOptions(processedOptionsData)
// 写入到EnumConst.ts文件
const outputOptionsPath = path.join(__dirname, '../src/config/optionsConst.ts')
fs.writeFileSync(outputOptionsPath, options, 'utf8')
console.log('Options定义文件已生成:', outputOptionsPath)
