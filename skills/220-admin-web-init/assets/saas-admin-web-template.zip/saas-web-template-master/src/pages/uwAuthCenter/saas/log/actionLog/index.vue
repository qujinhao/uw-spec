<script setup lang="ts">
import { type ComponentInternalInstance } from "vue";
import { SearchFormType } from "@/components/SearchForm/type";
import {
  saasLogActionLogList,
  type MscActionEsLog,
  type MscActionEsLogQueryParam,
  saasAccountUserLoad,
} from "@/api/uwAuthCenterSaasApi";
import { ResponseData, DataList } from "@/api/uwAuthCenterAuthApi";
import { useI18n } from "vue-i18n";
import { useCrud } from "@/hooks/useCrud";
import { useCommonSelectTypes } from "@/utils/selectOptions";
import { useMainStore } from "@/store/main";

const { userTypes, handleTypeForLabel, getAllUserTypes } =
  useCommonSelectTypes();

// 获取全局挂载的方法
const { proxy } = getCurrentInstance() as ComponentInternalInstance;
const { dayjs, useActivated } = proxy as any;
const { t } = useI18n();
const mainStore = useMainStore();

interface formParamsType extends MscActionEsLogQueryParam {
  dateTimeRange?: Array<string>;
}

const {
  tableConfig, // 表格相关配置属性
  handleList, // 列表请求函数
} = useCrud<MscActionEsLog, formParamsType>(
  {
    // 列表请求接口
    listFn: (): Promise<ResponseData<DataList<MscActionEsLog>>> => {
      return saasLogActionLogList(tableConfig.queryParams);
    },
  },
  {
    isCombinedFetch: true,
  }
);

// 搜索表单 结构组成数据
const searchList = computed<SearchFormType[]>(() => {
  return [
    {
      field: "userId",
      componentType: "input",
      formItem: {
        label: t("uwAuthCenter.MscLoginLogQueryParam.userId"),
        labelWidth: "70",
      },
      formItemWidth: 280,
      placeholder: t("pleaseInput"),
      clearable: true,
    },
    {
      field: "userName",
      componentType: "input",
      formItem: {
        label: "用户名称",
        labelWidth: "70",
      },
      formItemWidth: 280,
      placeholder: t("pleaseInput"),
      clearable: true,
    },
    {
      field: "realName",
      componentType: "input",
      formItem: {
        label: "真实姓名",
        labelWidth: "70",
      },
      formItemWidth: 280,
      placeholder: t("pleaseInput"),
      clearable: true,
    },
    {
      field: "userType",
      componentType: "select",
      formItem: {
        label: "用户类型",
        labelWidth: "70",
      },
      formItemWidth: 280,
      placeholder: t("pleaseSelect"),
      clearable: true,
      options: getAllUserTypes.value,
    },
    {
      field: "userIp",
      componentType: "input",
      formItem: {
        label: t("userIp"),
        labelWidth: "70",
      },
      formItemWidth: 280,
      placeholder: t("pleaseInput"),
      clearable: true,
    },
    {
      field: "mchId",
      componentType: "input",
      formItem: {
        label: "商户ID",
        labelWidth: "70",
      },
      formItemWidth: 280,
      placeholder: t("pleaseInput"),
      clearable: true,
    },
    {
      field: "appInfo",
      componentType: "input",
      formItem: {
        label: t("appInfo"),
        labelWidth: "70",
      },
      formItemWidth: 280,
      placeholder: t("pleaseInput"),
      clearable: true,
    },
    {
      field: "appHost",
      componentType: "input",
      formItem: {
        label: t("host"),
        labelWidth: "70",
      },
      formItemWidth: 280,
      placeholder: t("pleaseInput"),
      clearable: true,
    },
    {
      field: "uri",
      componentType: "input",
      formItem: {
        label: t("uwAuthCenter.MscActionESLog.uri"),
        labelWidth: "70",
      },
      formItemWidth: 280,
      placeholder: t("pleaseInput"),
      clearable: true,
    },
    {
      field: "info",
      componentType: "input",
      formItem: {
        label: "操作描述",
        labelWidth: "70",
      },
      formItemWidth: 280,
      placeholder: t("pleaseInput"),
      clearable: true,
    },
    {
      field: "bizType",
      componentType: "input",
      formItem: {
        label: "业务类型",
        labelWidth: "70",
      },
      formItemWidth: 280,
      placeholder: t("pleaseInput"),
      clearable: true,
    },
    {
      field: "bizId",
      componentType: "input",
      formItem: {
        label: t("uwAuthCenter.MscActionESLog.objectId"),
        labelWidth: "70",
      },
      formItemWidth: 280,
      placeholder: t("pleaseInput"),
      clearable: true,
    },
    {
      field: "requestDateRange",
      componentType: "datePicker",
      formItem: {
        label: t("uwAuthCenter.MscActionESLog.requestDate"),
        labelWidth: "70",
      },
      formItemWidth: 450,
      clearable: true,
      type: "datetimerange",
      startPlaceholder: t("startDate"),
      endPlaceholder: t("endDate"),
      defaultTime: [
        new Date(2000, 1, 1, 0, 0, 0),
        new Date(2000, 2, 1, 23, 59, 59),
      ],
      valueFormat: "YYYY-MM-DD HH:mm:ss",
    },
  ];
});

// 用户资料
const popoverData = ref({});
// popover 显示
const handlePopoverShow = (item: MscActionEsLog) => {
  const info = mainStore.saasUserInfo[item.userId as number];
  if (info && Object.keys(info).length) {
    popoverData.value = info;
  } else {
    saasAccountUserLoad({
      id: item.userId as number,
    })
      .then((res) => {
        if (res.state === "success") {
          popoverData.value = res.data || {};
        } else {
          popoverData.value = {};
        }
        mainStore.setSaasUserInfo(item.userId as number, popoverData.value);
      })
      .catch(() => {
        popoverData.value = {};
      });
  }
};

useActivated(() => {
  handleList();
});
</script>

<template>
  <div class="flex_col">
    <div class="flex_col_header">
      <SearchForm
        v-model="tableConfig.queryParams"
        :bnt-loading="tableConfig.tableLoading"
        :list="searchList"
        @change="handleList"
        @search="handleList"
      />
    </div>
    <el-table
      border
      :style="{ width: '100%' }"
      :header-cell-style="{
        backgroundColor: 'var(--el-color-info-light-9)',
      }"
      :data="tableConfig.dataList"
      v-loading="tableConfig.tableLoading"
      show-overflow-tooltip
      class="flex_col_body"
      stripe
    >
      <el-table-column
        prop="userInfo"
        label="用户信息"
        width="200"
        align="center"
      >
        <template #default="{ row }">
          <p>
            {{ row.userName }}({{
              handleTypeForLabel(row.userType, userTypes)
            }})
          </p>
          <p>{{ row.userIp }}</p>
        </template>
      </el-table-column>
      <el-table-column
        prop="appInfo"
        label="应用主机"
        width="210"
        align="center"
      >
        <template #default="scope">
          <div>{{ scope.row.appInfo }}</div>
          <div>{{ scope.row.appHost }}</div>
        </template>
      </el-table-column>
      <el-table-column
        prop="apiName"
        label="业务信息"
        width="350"
        align="center"
      >
        <template #default="scope">
          <div
            style="display: flex; flex-direction: column; align-items: center"
          >
            <el-tooltip
              effect="dark"
              placement="top"
              :disabled="!scope.row.bizType"
            >
              <template #content>
                <p>
                  {{ scope.row.bizType }}
                  <span v-if="scope.row.bizId || scope.row.bizId === 0">
                    :{{ scope.row.bizId }}
                  </span>
                </p>
              </template>
              <el-text :type="scope.row.bizType ? 'primary' : ''">
                <div>{{ scope.row.apiName }}</div>
              </el-text>
            </el-tooltip>
            <p>{{ scope.row.apiUri }}</p>
          </div>
        </template>
      </el-table-column>
      <el-table-column
        prop="requestInfo"
        label="请求/响应信息"
        align="center"
        width="230"
      >
        <template #default="scope">
          <div style="display: flex">
            <el-tooltip
              effect="dark"
              placement="top"
              :disabled="!scope.row.requestBody"
            >
              <template #content>
                <div style="width: 500px">
                  {{ scope.row.requestBody ? scope.row.requestBody : "" }}
                </div>
              </template>
              <el-text type="success">
                <div class="textAlignLeft">请求信息</div>
              </el-text>
            </el-tooltip>
            &nbsp;&nbsp;
            <span>
              {{ dayjs(scope.row.requestDate).format("YYYY-MM-DD HH:mm:ss") }}
            </span>
          </div>
          <div style="display: flex">
            <el-tooltip
              effect="dark"
              placement="top"
              :disabled="!scope.row.responseBody"
            >
              <template #content>
                <div style="width: 500px">
                  {{ scope.row.responseBody ? scope.row.responseBody : "" }}
                </div>
              </template>

              <el-text :type="scope.row.responseBody ? 'success' : ''">
                <div class="textAlignLeft">
                  <span>返回内容</span>
                </div>
              </el-text>
            </el-tooltip>
            &nbsp;&nbsp;
            <span>耗时({{ scope.row.responseMillis }}ms)</span>
          </div>
          <div class="textAlignLeft" v-if="scope.row.exception">
            <el-tooltip
              effect="dark"
              :content="scope.row.exception ? scope.row.exception : ''"
              :disabled="!scope.row.exception"
              teleported
              :offset="20"
            >
              <el-text type="danger">
                <span>异常信息</span>
              </el-text>
            </el-tooltip>
          </div>
        </template>
      </el-table-column>
      <el-table-column
        prop="bizLog"
        label="日志内容"
        minWidth="180"
        align="center"
      ></el-table-column>
      <el-table-column
        prop="statusCode"
        label="状态"
        width="100"
        align="center"
        fixed="right"
      >
        <template #default="scope">
          <el-text :type="scope.row.statusCode === 200 ? 'success' : 'danger'">
            {{ scope.row.statusCode === 200 ? t("success") : t("error") }}
          </el-text>
        </template>
      </el-table-column>
    </el-table>
    <Pagination
      v-model:page-size="tableConfig.queryParams.$rn"
      @pageSizeChange="handleList"
      :total="tableConfig.sizeAll"
      v-model:current-page="tableConfig.queryParams.$pg"
      @current-change="handleList"
      class="flex_col_bottom"
    />
  </div>
</template>

<style lang="scss" scoped>
.textAlignLeft {
  text-align: left;
}
</style>
