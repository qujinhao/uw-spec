###### 组件属性

```typescript
model: Record<string, any>                                                      // 数据对象，使用v-model="{xxx}", 在对应的属性上可传默认值,必传
list: []                                                                        // 表单生成，传入list属性的格式的数组,必传
formAttributes: {  size: '' | 'large' | 'default' | 'small', inline: boolean }  // size: 表单组件的大小   inline: 是否行内表单模式
type: 'search' | 'form'                                                         // search: 搜索组件模式   form：普通新增、修改表单模式, 默认search模式
bntLoading: boolean                                                             // 按钮加载状态
```

###### 组件事件

```typescript
change: () => void                                                              // 组件搜索项发生改变时触发
search: () => void                                                              // 点击搜索按钮触发事件
```

##### 组件插槽

```typescript
default       // 默认插槽
left          // 搜索栏左侧插槽
right         // 搜索栏右侧插槽
```

###### list 属性格式

```typescript
formItem?: {
    prop?: string | string[]                                        // 属性名
    label?: string                                                  // label名称
    labelWidth?: string | number                                    // label名称的宽度
    labelPosition?: 'left' | 'right' | 'top'                        // label名称的位置
    required?: boolean                                              // 校验是否必填
    rules?: import('element-plus').FormItemRule[]                   // 检验规则
  }
  formItemWidth?: number | string                                   // formTtem 的整体宽度
  componentWidth?: number | string                                  // 组件宽度
  componentType: 'radio' | 'select' | 'datePicker' | 'input'| 'select-v2'       // 组件的类型
  br?: boolean                                                      // 是否换行
  type?: string                                                     // UI组件的原生类型, 具体查看Element-plus官网文档
  field: string                                                     // 唯一字符串(必填) 若label不传，数据回传的时候会使用这个字段的值作为 label 的值
  disabled?: boolean                                                // 是否禁用
  readonly?: boolean                                                // 是否只读
  placeholder?: string                                              // 默认占位文字内容
  startPlaceholder?: string                                         // 范围选择时开始日期的占位内容
  endPlaceholder?: string                                           // 范围选择时开始日期的占位内容
  clearable?: boolean                                               // 是否可清空
  format?: string                                                   // 显示在输入框中的格式
  valueFormat?: string                                              // 可选，绑定值的格式。 不指定则绑定值为 Date 对象
  defaultTime?: [Date, Date] | Date                                 // 选择日期后的默认时间值。 如未指定则默认时间值为 00:00:00
  showPassword?: boolean                                            // 是否显示切换密码图标
  enterable?: boolean                                               // 当为输入框时，是否启用回车触发提交功能
  loading?: boolean                                                 // 按钮加载状态
  options?: Array<{ value?: string | number; label?: string }>      // select组件的option选项，格式[{label: '', value: xxx}]
  expand?: Record<string, any>                                      // 拓展字段，将会绑定到每一个 UI 组件上 优先级低于列出来的字段，具体查看Element-plus官网文档
  change?: (val: any) => void                                       // chang事件
  click?: () => void // 组件的点击事件 componentType 为 button 有效   // click事件
```
