<script lang="ts" setup>
import { onShow } from '@dcloudio/uni-app'
import { ref, computed, reactive } from 'vue'

import NavBar from '@/components/NavBar/index.vue'
import ZScrollView from '@/components/ZScrollView/index.vue'
import { guestOrderInfoList, type OrderInfo } from '@/api/saasMallAppGuestApi'
import { useUserStore } from '@/store/user'
import { isEmpty, navToUrl } from '@/utils/tool'

const userStore = useUserStore()

const state = reactive({
  $pg: 1,
  loading: false,
  isFixed: true // ZScrollView是否吸顶
})
const navTop = [
  {
    id: 1,
    title: '全部'
  },
  {
    id: 2,
    title: '待确定'
  },
  {
    id: 3,
    title: '待支付'
  },
  {
    id: 4,
    title: '退款/售后'
  },
  {
    id: 5,
    title: '已取消'
  },
  {
    id: 6,
    title: '已完成'
  }
]

// nav导航栏配置
const navStatusBar = computed(() => {
  let flag = true
  // #ifdef MP-TOUTIAO
  flag = false
  // #endif
  return flag
})

// 订单列表
const orderList = ref<OrderInfo[]>([])

const statusBar = computed(() => {
  const e = uni.getSystemInfoSync()
  return Number(e.statusBarHeight)
})
// 顶部间距判断
const topHeight = computed(() => {
  // 44为navBar默认高度
  let height = 44 + statusBar.value
  // #ifdef MP-TOUTIAO
  console.log('statusBar.value', statusBar.value)
  height = 44
  if (!state.isFixed) {
    height = 0
  }
  // #endif
  return height
})

const goToLogin = () => {
  navToUrl('/pages/login/index')
}

//搜索
const searchByKeyWords = (e: any) => {
  uni.showToast({
    title: String(e.detail.value),
    icon: 'none'
  })
  // state.keyword = e.value
  // initData()
}

const getOrderList = () => {
  state.loading = true

  guestOrderInfoList({
    $pg: state.$pg,
    $rn: 10
  }).then((res) => {
    if (res.state === 'success' && res.data && res.data.results) {
      orderList.value = [...orderList.value, ...res.data.results]
      state.$pg++
    }

    state.loading = false
  })
}

const scrolltolower = () => {
  getOrderList()
}

const handleChange = (e: any) => {
  console.log(e)
}

onShow(() => {
  if (!isEmpty(userStore.userInfo)) {
    getOrderList()
  }
})
</script>

<template>
  <view class="order-page">
    <!-- 未登录 -->
    <template v-if="isEmpty(userStore.userInfo)">
      <view class="order-empty flex-col flex-center flex-align">
        <text class="icon-order"></text>
        <view class="order-empty__text">
          未登录，
          <text
            class="link primary-color"
            @click="goToLogin"
          >
            登录/注册 >
          </text>
        </view>
      </view>
    </template>
    <!-- 已登录 -->
    <template v-else>
      <NavBar
        :border="true"
        fixed
        :status-bar="navStatusBar"
        nav-type="search"
        search-type="current"
        search-placeholder="请输入订单号"
        @to-search="searchByKeyWords"
      />
      <view :style="{ paddingTop: topHeight + 'px' }">
        <ZScrollView
          :navList="navTop"
          type="type-1"
          :isFixed="state.isFixed"
          :top="state.isFixed ? topHeight + 'px' : ''"
          navPadding="0 20rpx"
          itemMargin="0 20rpx"
          @change="handleChange"
        ></ZScrollView>
      </view>

      <template v-if="orderList.length > 0">
        <view :style="{ paddingTop: state.isFixed ? '40px' : '0px' }">
          <view
            class="order-list"
            :style="{
              height: `calc(100vh - ${state.isFixed ? topHeight + 40 : 0}px)`,
              overflow: 'hidden'
            }"
          >
            <up-list
              :style="{
                height: `calc(100vh - ${state.isFixed ? topHeight + 40 + 70 : 0}px)`
              }"
              @scrolltolower="scrolltolower"
            >
              <up-list-item
                v-for="(item, index) in orderList"
                :key="index"
                class="order-item"
              >
                <view
                  class="order-item__top space-between"
                  @click="
                    navToUrl(`/packages/order/orderDetail/index?id=${item.id}`)
                  "
                >
                  <view class="order-id fontBold">订单号: {{ item.id }}</view>
                  <view class="order-status primary-color">待支付</view>
                </view>
                <view class="order-item__center space-between mt10">
                  <view class="center-image">
                    <img
                      class="image"
                      :src="item.orderCurrency"
                      lazy-load
                    />
                  </view>
                  <view class="center-details flex-col">
                    <text class="order-title ellipsis2">
                      <!-- {{ item.currencyDistributor }} -->
                      {{ item.distributorMchId }}
                    </text>
                    <text class="order-grayCss">
                      下单日期： {{ item.guestId }}
                    </text>
                    <text class="order-grayCss">
                      用户姓名： {{ item.guestId }}
                    </text>
                    <text class="order-grayCss">
                      手机号码： {{ item.guestId }}
                    </text>
                    <!-- <text class="order-date">{{ item.date }}</text>
          <text class="order-status">{{ item.status }}</text> -->
                  </view>
                </view>
                <view class="order-item__bottom flex-align flex-end mt10">
                  <text class="order-count">
                    共{{ item.guestId || 0 }}件商品
                  </text>
                  <text class="order-price ml20">
                    合计
                    <text class="active fontBold">
                      ￥{{ item.guestId || 0 }}
                    </text>
                  </text>
                </view>
                <view class="order-item__btns flex-end mt10">
                  <view class="flex-end">
                    <button class="order-btn primary-color-bg">继续支付</button>
                    <button class="order-btn primary-color-bg ml20">
                      取消
                    </button>
                  </view>
                </view>
              </up-list-item>
              <up-loadmore :status="state.loading ? 'loading' : 'nomore'" />
            </up-list>
          </view>
        </view>
      </template>
      <template v-else>
        <view class="empty-orderData flex-col flex-align">
          <img
            class="img"
            mode="aspectFit"
            src="http://qnimg.zowoyoo.com/img/84826/1693472656871.png"
            lazy-load
          />
          <text class="null-order">暂无订单</text>
        </view>
      </template>
    </template>
  </view>
</template>

<style lang="scss" scoped>
.order-page {
  width: 100vw;
  height: calc(100vh - 50px);
  background-color: #f8f8f8;
  .order-empty {
    position: fixed;
    width: 100%;
    height: 100%;
    .icon-order {
      display: block;
      width: 60rpx;
      height: 60rpx;
      background: url('http://qnimg.zowoyoo.com/img/84826/1692784562969.jpg')
        no-repeat;
      background-size: contain;
    }
    .order-empty__text {
      font-size: 24rpx;
      margin-top: 20rpx;
    }
  }
  .empty-orderData {
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    .null-order {
      font-weight: 700;
      font-size: 32rpx;
    }
  }
}
.order-list {
  padding: 20rpx 30rpx;
  .order-item {
    // border: 1px solid #000;
    box-sizing: border-box;
    background-color: #ffffff;
    border-radius: 20rpx;
    padding: 20rpx;
    margin-bottom: 20rpx;

    &__top {
      .order-id {
        color: #111111;
      }
      // .order-status {}
    }
    &__center {
      .center-image {
        width: 190rpx;
        height: 190rpx;
        border-radius: 20rpx;
        overflow: hidden;
        margin-right: 20rpx;
        .image {
          width: 100%;
          height: 100%;
        }
      }
      .center-details {
        flex: 1;
        .order-grayCss {
          font-size: 24rpx;
          color: #999999;
        }
        .order-title {
          font-size: 16px;
          font-weight: bold;
          margin-bottom: 5px;
        }
      }
    }
    &__bottom {
      // border: 1px solid #000;
      .order-count {
        font-size: 24rpx;
      }
      .order-price {
        font-size: 24rpx;
      }
    }
    &__btns {
      .order-btn {
        color: #ffffff;
        border-radius: 50rpx;
        font-size: 24rpx;
        line-height: 2em;
      }
      // 按钮点击样式
      .button-hover {
        background-color: #f58c1c;
      }
    }
  }
}
</style>
