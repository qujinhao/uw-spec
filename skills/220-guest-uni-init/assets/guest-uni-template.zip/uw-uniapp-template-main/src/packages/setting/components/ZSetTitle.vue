<!-- 设置中心的Title拓展组件 -->
<script lang="ts" setup>
import { onMounted } from 'vue'

const props = withDefaults(
  defineProps<{
    list?: any[] // 数据
    title?: string // 单个标题
    rightTxt?: string // 右边插值
  }>(),
  {
    list: () => [],
    title: '',
    rightTxt: ''
  }
)
const emits = defineEmits<{
  (e: 'click', item: any): void
  (e: 'clickItem'): void
}>()

const handleClick = (item: any) => {
  emits('click', item)
}

const handleClickItem = () => {
  emits('clickItem')
}

onMounted(() => {
  // console.log('z-title Com ---')
})
</script>

<template>
  <!-- 传入数组形式 -->
  <template v-if="props.list.length">
    <view class="z-title">
      <view
        class="title-item space-between"
        v-for="(item, index) in props.list"
        :key="index"
        @click="handleClick(item)"
      >
        <text class="label">{{ item.label }}</text>
        <text class="icon-right flex-align flex-center">
          <text class="slot-txt">{{ item.slotTxt }}</text>
          <uni-icons
            type="right"
            size="20"
          ></uni-icons>
        </text>
      </view>
    </view>
  </template>
  <!-- 单个传title -->
  <template v-else>
    <view class="z-item-title">
      <view
        class="title-item space-between"
        @click="handleClickItem"
      >
        <text class="label">{{ props.title }}</text>
        <text class="icon-right flex-align flex-center">
          <text class="slot-txt">{{ props.rightTxt }}</text>
          <uni-icons
            type="right"
            size="20"
          ></uni-icons>
        </text>
      </view>
    </view>
  </template>
</template>

<style lang="scss" scoped>
.z-title {
  background-color: #f8f8f8;
  padding-top: 20rpx;
  .title-item {
    padding: 20rpx 30rpx;
    border-bottom: 1px solid #eeeeee;
    background-color: #ffffff;
    // .label {}
    .icon-right {
      .slot-txt {
        margin-right: 10rpx;
      }
    }
  }
}
.z-item-title {
  .title-item {
    padding: 20rpx 30rpx;
    border-bottom: 1px solid #eeeeee;
    background-color: #ffffff;
    // .label {}
    .icon-right {
      .slot-txt {
        margin-right: 10rpx;
      }
    }
  }
}
</style>
