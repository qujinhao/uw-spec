// Worker 线程：只做图片的解码与重编码（CPU 密集），不涉及 UI 与 DOM
import * as Comlink from 'comlink'
import * as jpeg from '@jsquash/jpeg'
import * as png from '@jsquash/png'
import * as webp from '@jsquash/webp'
// 大概700多kb

// 输入解码器：根据读到的原始格式来解码为 ImageData
const decoder = {
  jpeg: jpeg.decode,
  png: png.decode,
  webp: webp.decode
} as const

// 输出编码器：将 ImageData 重新编码为目标格式；jpeg/webp 支持质量参数
const encoder = {
  jpeg: (img: ImageData, q: number) => jpeg.encode(img, { quality: q }),
  png: png.encode,
  webp: (img: ImageData, q: number) => webp.encode(img, { quality: q })
} as const

// 简单魔数识别输入格式
function detectFormat(buf: ArrayBuffer): keyof typeof decoder {
  const v = new Uint8Array(buf)
  if (v[0] === 0xff && v[1] === 0xd8) return 'jpeg'
  if (v[0] === 0x89 && v[1] === 0x50) return 'png'
  if (v[0] === 0x52 && v[1] === 0x49 && v[8] === 0x57 && v[9] === 0x45)
    return 'webp'
  throw new Error('无法识别的图片格式')
}

export const api = {
  // 核心方法：输入 ArrayBuffer（由主线程 transfer 过来），返回 ArrayBuffer（transfer 回去）
  async convert(buf: ArrayBuffer, outType: keyof typeof encoder, quality = 75) {
    const inType = detectFormat(buf) // ← 自动识别
    const image = await decoder[inType](buf)
    if (!image) throw new Error('解码返回 null')
    const outBuf = await encoder[outType](image, quality)
    // 将结果以 Transferable 形式返回，避免拷贝
    return Comlink.transfer({ ok: true, data: outBuf }, [
      outBuf as unknown as ArrayBuffer
    ])
  }
}

Comlink.expose(api)

// 主线程：const api = Comlink.wrap(worker)
// Worker 内：Comlink.expose(object)

// 只是将postMessage的数据传递包装成一个异步的操作，并且暴露出一个proxy对象供主线程便利的操作Worker线程的数据
