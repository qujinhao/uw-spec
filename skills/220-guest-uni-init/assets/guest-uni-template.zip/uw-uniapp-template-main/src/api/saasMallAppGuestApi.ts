import request from '@/api/request'
import type { ResponseData, DataList } from '@/api/type/API_TYPE'

/**
 * 修改用户信息
 */
export const guestUserInfoUpdate = (data: GuestUpdateRequest) => {
  return request({
    url: '/saas-mall-app/guest/user/info/update',
    method: 'PUT',
    data
  }) as Promise<ResponseData<GuestInfoExt>>
}
/**
 * 解除绑定登录标识
 */
export const guestUserInfoUnbindLoginId = (params: {
  loginType: number //
  password: string //
}) => {
  return request({
    url: '/saas-mall-app/guest/user/info/unbindLoginId',
    method: 'PUT',
    params
  }) as Promise<ResponseData<void>>
}
/**
 * 绑定登录标识
 */
export const guestUserInfoBindLoginId = (params: {
  loginType: number //
  loginId: string //
  password: string //
  deviceCode: string //
}) => {
  return request({
    url: '/saas-mall-app/guest/user/info/bindLoginId',
    method: 'PUT',
    params
  }) as Promise<ResponseData<void>>
}
/**
 * 修改用户地址簿
 */
export const guestAddressInfoUpdate = (data: GuestAddress) => {
  return request({
    url: '/saas-mall-app/guest/address/info/update',
    method: 'PUT',
    data
  }) as Promise<ResponseData<GuestAddress>>
}
/**
 * 注销账号
 */
export const guestUserInfoLogoff = (data: GuestLogOffRequest) => {
  return request({
    url: '/saas-mall-app/guest/user/info/logoff',
    method: 'POST',
    data
  }) as Promise<ResponseData<void>>
}
/**
 * 新增订单信息
 */
export const guestOrderInfoSave = (data: OrderRequest) => {
  return request({
    url: '/saas-mall-app/guest/order/info/save',
    method: 'POST',
    data
  }) as Promise<ResponseData<OrderInfo>>
}
/**
 * 支付订单
 */
export const guestOrderInfoPay = (data: MallOrderPayParam) => {
  return request({
    url: '/saas-mall-app/guest/order/info/pay',
    method: 'POST',
    data
  }) as Promise<ResponseData<FinPayOrderResponse>>
}
/**
 * 订单规则校验
 */
export const guestOrderInfoOrderLimitCheck = (data: OrderRequest) => {
  return request({
    url: '/saas-mall-app/guest/order/info/orderLimitCheck',
    method: 'POST',
    data
  }) as Promise<ResponseData<void>>
}
/**
 * 订单变更申请
 */
export const guestOrderInfoChangeApply = (data: OrderChangeRequest) => {
  return request({
    url: '/saas-mall-app/guest/order/info/change/apply',
    method: 'POST',
    data
  }) as Promise<ResponseData<OrderChange>>
}
/**
 * 领取优惠券
 */
export const guestCouponInfoPickup = (data: CouponPickUpRequest) => {
  return request({
    url: '/saas-mall-app/guest/coupon/info/pickup',
    method: 'POST',
    data
  }) as Promise<ResponseData<void>>
}
/**
 * 新增用户地址簿
 */
export const guestAddressInfoSave = (data: GuestAddress) => {
  return request({
    url: '/saas-mall-app/guest/address/info/save',
    method: 'POST',
    data
  }) as Promise<ResponseData<GuestAddress>>
}
/**
 * 加载用户信息
 */
export const guestUserInfoLoad = () => {
  return request({
    url: '/saas-mall-app/guest/user/info/load',
    method: 'GET'
  }) as Promise<ResponseData<GuestInfoExt>>
}
/**
 * 列表站点搜索词
 */
export const guestSiteKeywordList = (params: GuestSiteKeywordQueryParam) => {
  return request({
    url: '/saas-mall-app/guest/site/keyword/list',
    method: 'GET',
    params
  }) as Promise<ResponseData<DataList<SiteKeyword>>>
}
/**
 * 加载站点信息
 */
export const guestSiteInfoLoad = (params: {
  id: number // 主键ID
}) => {
  return request({
    url: '/saas-mall-app/guest/site/info/load',
    method: 'GET',
    params
  }) as Promise<ResponseData<SiteInfo>>
}
/**
 * 获取poi列表
 */
export const guestSiteCmsListPoi = () => {
  return request({
    url: '/saas-mall-app/guest/site/cms/listPoi',
    method: 'GET'
  }) as Promise<ResponseData<Array<PoiInfo>>>
}
/**
 * 获取内容列表
 */
export const guestSiteCmsListInfo = (params: {
  catalogIds: Array<number> //
  componentCode?: string //
}) => {
  return request({
    url: '/saas-mall-app/guest/site/cms/listInfo',
    method: 'GET',
    params
  }) as Promise<ResponseData<SiteCmsInfo[]>>
}
/**
 * 获取CMS目录树列表
 */
export const guestSiteCmsListCatalog = (params: {
  catalogType: number //
}) => {
  return request({
    url: '/saas-mall-app/guest/site/cms/listCatalog',
    method: 'GET',
    params
  }) as Promise<ResponseData<Array<SiteCmsCatalogTreeVo>>>
}
/**
 * 获取广告位信息列表
 */
export const guestSiteAdList = (params: GuestSiteAdInfoQueryParam) => {
  return request({
    url: '/saas-mall-app/guest/site/ad/list',
    method: 'GET',
    params
  }) as Promise<ResponseData<DataList<SiteAdInfo>>>
}
/**
 * 列表产品规格
 */
export const guestProductInfoSpecList = (params: {
  productId: number //
  sessionId?: number //
  stockType: number //
  currency: string //
  date: string //
}) => {
  return request({
    url: '/saas-mall-app/guest/product/info/spec/list',
    method: 'GET',
    params
  }) as Promise<ResponseData<Array<ProductSpecVo>>>
}
/**
 * 列表产品场次
 */
export const guestProductInfoSessionList = (
  params: GuestProductSessionQueryParam
) => {
  return request({
    url: '/saas-mall-app/guest/product/info/session/list',
    method: 'GET',
    params
  }) as Promise<ResponseData<DataList<ProductSession>>>
}
/**
 * 获取产品价格列表
 */
export const guestProductInfoPriceList = (
  params: GuestProductPriceQueryParam
) => {
  return request({
    url: '/saas-mall-app/guest/product/info/price/list',
    method: 'GET',
    params
  }) as Promise<ResponseData<DataList<ProductPrice>>>
}
/**
 * 产品明细页
 */
export const guestProductInfoLoad = (params: {
  id: number // 产品id
}) => {
  return request({
    url: '/saas-mall-app/guest/product/info/load',
    method: 'GET',
    params
  }) as Promise<ResponseData<ProductInfo>>
}
/**
 * 产品列表页
 */
export const guestProductInfoList = (params: GuestProductInfoQueryParam) => {
  return request({
    url: '/saas-mall-app/guest/product/info/list',
    method: 'GET',
    params
  }) as Promise<ResponseData<DataList<ProductInfoEx>>>
}
/**
 * 加载产品限定表
 */
export const guestProductInfoLimitLoad = (params: {
  id: number // 主键ID
}) => {
  return request({
    url: '/saas-mall-app/guest/product/info/limit/load',
    method: 'GET',
    params
  }) as Promise<ResponseData<ProductLimit>>
}
/**
 * 轻量级列表产品限定表
 */
export const guestProductInfoLimitLiteList = (
  params: ProductLimitQueryParam
) => {
  return request({
    url: '/saas-mall-app/guest/product/info/limit/liteList',
    method: 'GET',
    params
  }) as Promise<ResponseData<DataList<ProductLimit>>>
}
/**
 * 列表产品限定表
 */
export const guestProductInfoLimitList = (params: ProductLimitQueryParam) => {
  return request({
    url: '/saas-mall-app/guest/product/info/limit/list',
    method: 'GET',
    params
  }) as Promise<ResponseData<DataList<ProductLimit>>>
}
/**
 * 加载酒店房床信息表
 */
export const guestProductHotelRoomLoad = (params: {
  id: number // 主键ID
}) => {
  return request({
    url: '/saas-mall-app/guest/product/hotel/room/load',
    method: 'GET',
    params
  }) as Promise<ResponseData<PoiHotelRoom>>
}
/**
 * 列表酒店房床信息表
 */
export const guestProductHotelRoomList = (
  params: GuestPoiHotelRoomQueryParam
) => {
  return request({
    url: '/saas-mall-app/guest/product/hotel/room/list',
    method: 'GET',
    params
  }) as Promise<ResponseData<DataList<PoiHotelRoom>>>
}
/**
 * poi信息详情
 */
export const guestPoiInfoLoad = (params: {
  poiId: number // poiId
}) => {
  return request({
    url: '/saas-mall-app/guest/poi/info/load',
    method: 'GET',
    params
  }) as Promise<ResponseData<PoiInfo>>
}
/**
 * poi列表页
 */
export const guestPoiInfoList = (params: GuestPoiInfoQueryParam) => {
  return request({
    url: '/saas-mall-app/guest/poi/info/list',
    method: 'GET',
    params
  }) as Promise<ResponseData<DataList<PoiInfoEx>>>
}
/**
 * 加载订单信息
 */
export const guestOrderInfoLoad = (params: {
  id: number // 主键ID
}) => {
  return request({
    url: '/saas-mall-app/guest/order/info/load',
    method: 'GET',
    params
  }) as Promise<ResponseData<OrderInfoEx>>
}
/**
 * 列表订单信息
 */
export const guestOrderInfoList = (params: GuestOrderInfoQueryParam) => {
  return request({
    url: '/saas-mall-app/guest/order/info/list',
    method: 'GET',
    params
  }) as Promise<ResponseData<DataList<OrderInfo>>>
}
/**
 * 加载用户优惠劵
 */
export const guestCouponInfoLoad = (params: {
  id: number // 主键ID
}) => {
  return request({
    url: '/saas-mall-app/guest/coupon/info/load',
    method: 'GET',
    params
  }) as Promise<ResponseData<GuestCoupon>>
}
/**
 * 加载用户历史优惠劵
 */
export const guestCouponInfoLoadHistory = (params: {
  id: number // 主键ID
}) => {
  return request({
    url: '/saas-mall-app/guest/coupon/info/loadHistory',
    method: 'GET',
    params
  }) as Promise<ResponseData<GuestCouponHistory>>
}
/**
 * 列表用户优惠劵
 */
export const guestCouponInfoList = (params: GuestGuestCouponQueryParam) => {
  return request({
    url: '/saas-mall-app/guest/coupon/info/list',
    method: 'GET',
    params
  }) as Promise<ResponseData<DataList<GuestCouponEx>>>
}
/**
 * 列表用户历史优惠劵
 */
export const guestCouponInfoListHistory = (
  params: GuestGuestCouponHistoryQueryParam
) => {
  return request({
    url: '/saas-mall-app/guest/coupon/info/listHistory',
    method: 'GET',
    params
  }) as Promise<ResponseData<DataList<GuestCouponHistory>>>
}
/**
 * 列表优惠劵信息表
 */
export const guestCouponInfoListCoupon = (params: CouponInfoQueryParam) => {
  return request({
    url: '/saas-mall-app/guest/coupon/info/listCoupon',
    method: 'GET',
    params
  }) as Promise<ResponseData<DataList<CouponInfo>>>
}
/**
 * 加载用户地址簿
 */
export const guestAddressInfoLoad = (params: {
  id: number // 主键ID
}) => {
  return request({
    url: '/saas-mall-app/guest/address/info/load',
    method: 'GET',
    params
  }) as Promise<ResponseData<GuestAddress>>
}
/**
 * 列表用户地址簿
 */
export const guestAddressInfoList = (params: GuestGuestAddressQueryParam) => {
  return request({
    url: '/saas-mall-app/guest/address/info/list',
    method: 'GET',
    params
  }) as Promise<ResponseData<DataList<GuestAddress>>>
}
/**
 * 删除用户地址簿
 */
export const guestAddressInfoDelete = (params: {
  id: number // 主键ID
  remark: string // 备注
}) => {
  return request({
    url: '/saas-mall-app/guest/address/info/delete',
    method: 'DELETE',
    params
  }) as Promise<ResponseData<void>>
}

/**
 * 更新用户DTO
 */
export interface GuestUpdateRequest {
  id?: number //主键
  mobile?: string //手机
  email?: string //邮箱
  username?: string //登录名称
  gender?: number //性别1男0女 -1未知
  birthday?: string //用户生日
  userIcon?: string //用户头像
  idInfo?: number //身份证号码
  idType?: number //证件类型
  realName?: string //真实名称
  wxId?: string //微信ID
  areaCode?: number //所在地区的area_code
}
/**
 *
 */
export interface GuestInfoExt {
  id?: number //主键
  saasId?: number //saasId
  mchId?: number //商户id
  mobile?: string //手机
  mobileArea?: string //联系电话区号
  email?: string //邮箱
  username?: string //登录名称
  password?: string //密码
  gender?: number //性别1男0女 -1未知
  birthday?: string //用户生日
  userIcon?: string //用户头像
  idType?: number //证件类型
  idInfo?: string //身份证号码
  realName?: string //真实名称
  wxId?: string //微信ID
  areaCode?: number //所在地区的area_code
  orderAmount?: number //下单总金额
  regIp?: string //创建ip
  lastPasswdDate?: string //最后更新密码时间
  lastLogonDate?: string //最后登录时间
  lastLogonIp?: string //最后登录ip
  logonCount?: number //登录次数
  createDate?: string //创建日期
  modifyDate?: string //修改日期
  state?: number //状态：-1: 删除 0: 冻结 1: 正常
}
/**
 * 用户地址簿
 */
export interface GuestAddress {
  id?: number //主键ID
  saasId?: number //运营商ID
  guestId?: number //用户ID
  areaCode?: number //所在地区的area_code
  guestName?: string //收货人
  guestPhone?: string //手机号码
  guestAddress?: string //详细地址
  addressTag?: string //地址标签,多个用逗号隔开,每个最多五个字
  isDefault?: number //是否默认地址 0:不是 1:是  不设置的话选第一条作为默认地址
  createDate?: string //创建时间
  modifyDate?: string //修改时间
  state?: number //地址状态 -1:删除 1:正常
}
/**
 * 用户注销账号
 */
export interface GuestLogOffRequest {
  password?: string //用户密码
  captchaId?: string //验证码Id
  captchaSign?: string //验证码用户答案
}
/**
 * 下单请求用户类
 */
export interface OrderGuestRequest {
  specId?: number //规格ID
  guestName?: string //客户姓名
  guestNamePinyin?: string //客户姓名拼音
  guestMobile?: string //客户电话
  guestMobileArea?: string //客户电话区号
  guestEmail?: string //客户email
  guestBirthday?: string //出生年月
  guestAge?: number //客户年龄
  guestNational?: string //客户国籍
  guestGender?: number //客户性别
  guestAddress?: string //游客地址
  idType?: number //证件类型
  idInfo?: string //证件号码
  remark?: string //备注
}
/**
 * 下单请求类
 */
export interface OrderRequest {
  saasId?: number //运营商ID
  distributorMchId?: number //分销商商户编号
  siteId?: number //站点ID
  agentId?: number //合伙人ID
  currencyType?: string //货币类型
  orderLang?: string //订单语言
  remark?: string //客人备注
  orderPrice?: number //订单总价格,含税费/服务费/配送费
  orderDate?: string //订单时间
  orderGuestRequests?: Array<OrderGuestRequest> //客人信息
  productId?: number //产品ID
  travelDate?: string //游玩日期
  travelEndDate?: string //游玩结束日期
  specInfos?: Array<SpecInfo> //产品规格集合
}
/**
 *
 */
export interface SpecInfo {
  specId?: number //
  sessionId?: number //
  purchaseNum?: number //
}
/**
 * 订单信息
 */
export interface OrderInfo {
  id?: number //商城订单ID
  saasId?: number //运营商ID
  poiId?: number //商家ID
  siteId?: number //站点ID
  agentId?: number //合伙人ID
  guestId?: number //会员编号|客人ID
  orderInfo?: string //订单信息
  orderLang?: string //订单语言类型
  unpayCancelMinutes?: number //订单不支付,自动取消时间
  areaCode?: number //产品的区域编码
  saleType?: number //销售类型，0：普通销售，1：预约销售
  payType?: number //支付类型,参考paymentType
  payMoney?: number //实际支付金额
  payDate?: string //订单支付时间
  useDateType?: number //预约(使用)日期类型(1:抢购后x天内克预约,2:抢购后指定到日期x内可预约,3:抢购后在日期x到y内可预约)
  useDateInfo?: string //有效期信息，根据有效期类型决定
  useDate?: string //预约/配送时间 如果为需要配送,就是配送时间,反之则是预约时间
  contactName?: string //联系人姓名（first_name@last_name）
  contactPhone?: string //联系人电话
  contactEmail?: string //联系人电子邮箱
  deliveryType?: number //配送类型 -1:供应商配送 0:需要配送 1:自动发码 >1的时候为码库发码,这时候前端传码库ID来处理
  deliveryAddress?: string //配送地址
  deliveryState?: number //配送状态 0:未发货 1:已发货
  deliveryDate?: string //生成通知单时间
  confirmType?: number //0-不需要确认 1-需要确认
  confirmDate?: string //订单确认时间
  finishNum?: number //订单验证完成数量
  finishMoney?: number //订单验证完成金额
  finishDate?: string //订单验证完成时间
  remark?: string //客人备注
  channelId?: number //渠道接口编号
  distributorMchId?: number //分销商商户编号
  distributorParentId?: number //分销商直属上级ID
  distributorMoney?: number //渠道结算价
  distributorOrderId?: string //渠道订单号
  distributorOrderState?: number //渠道订单状态
  distributorMoneyReceipted?: number //已经收取分销商的金额
  distributorMoneyRefund?: number //分销商取消金额
  distributorVerifyDate?: string //分销商对账时间
  distributorVerifyState?: number //分销商对账状态 -1 应收款有问题 0未对账 1已对账 未收款 2已收部分 3已收全款
  distributorRebate?: number //分销商佣金
  issueType?: number //issue类型
  issueInfo?: string //issue信息
  issueState?: number //issue处理信息
  refundNum?: number //取消数量
  refundMoney?: number //退款金额
  refundState?: number //取消申请状态
  refundDate?: string //订单取消时间
  orderCurrency?: string //订单货币类型
  orderMoney?: number //订单总价格,含税费/服务费/配送费
  orderState?: number //订单状态
  orderDate?: string //订单时间
  state?: number //状态 0:锁定订单,1:解锁订单
}
/**
 * Aip订单付款入参
 */
export interface MallOrderPayParam {
  payConfigId?: number //支付渠道ID
  payChannel?: string //支付渠道类型
  payTradeType?: string //支付交易类型
  payCurrency?: string //货币类型 人民币:CNY;
  payAmount?: number //支付金额，单位分
  bizOrderExt?: string //应用订单扩展信息
  payRemark?: string //支付备注
  orderId?: number //订单id
}
/**
 * 支付宝App支付信息
 */
export interface AlipayAppPayInfo {
  tradeNo?: string //支付宝交易订单号
}
/**
 * 支付操作响应体
 */
export interface FinPayOrderResponse {
  payOrderId?: number //payOrderId
  saasId?: number //运营商id
  userId?: number //用户id
  userType?: number //用户类型
  userInfo?: string //用户信息
  userIp?: string //用户ip
  payConfigId?: number //支付配置id
  payChannel?: string //支付渠道
  payTradeType?: string //支付交易类型
  payDeviceId?: string //支付设备号
  payStoreInfo?: string //支付门店信息
  orderInfo?: string //业务订单信息
  orderCurrency?: string //订单货币类型
  orderAmount?: number //订单金额，单位分
  bizAppInfo?: string //业务应用信息
  bizOrderType?: string //应用订单类型
  bizOrderId?: string //业务订单id
  bizOrderExt?: string //业务扩展信息
  wxAppPayInfo?: WxAppPayInfo //微信浏览器/小程序支付信息
  alipayAppPayInfo?: AlipayAppPayInfo //支付宝生活号/小程序支付信息
  scanPayInfo?: string //扫码支付信息
  mobileWebUrl?: string //移动端浏览器支付跳转链接
}
/**
 * 微信App支付信息
 */
export interface WxAppPayInfo {
  appId?: string //公众号或小程序appId
  timeStamp?: string //时间戳
  nonceStr?: string //随机串
  packageData?: string //数据包
  signType?: string //签名方式
  paySign?: string //支付签名
}
/**
 * 取消订单请求类
 */
export interface OrderChangeRequest {
  orderId?: number //订单ID
  cancelVoucherIds?: string //取消code(票码id:取消数量),多个用,分开
  applyType?: number //申请类型1修改 0 取消
  applyInfo?: string //申请理由
}
/**
 * 订单变更信息
 */
export interface OrderChange {
  id?: number //主键
  saasId?: number //运营商ID
  orderId?: number //订单号
  channelRefundId?: string //渠道退款流水号
  supplierRefundId?: string //供应商退款流水号
  refundVoucherIds?: string //取消票码id,多个用,分开
  applyType?: number //申请类型1修改 0 取消
  applyUserId?: number //申请人ID
  applyUserIp?: string //申请人IP
  applyUserInfo?: string //申请取消人
  applyDate?: string //申请时间
  applyRemark?: string //申请备注
  auditUserId?: number //审批人ID
  auditUserIp?: string //审批用户IP
  auditUserInfo?: string //审核人
  auditRemark?: string //审批备注
  auditDate?: string //审核时间
  auditState?: number //审核状态结果 0待审核，1审核通过，如何操作，退款多少在audi_memo里面说明,2拒绝通过申请
  orderDate?: string //订单创建时间
  modifyDate?: string //更新时间
  createDate?: string //创建日期
  state?: number //状态 1-正常 -1删除
}
/**
 * 优惠券领取入参
 */
export interface CouponPickUpRequest {
  couponId?: number //优惠劵ID
}
/**
 * 站点搜索词列表查询参数
 */
export interface GuestSiteKeywordQueryParam {
  id?: number //站点ID
  ids?: Array<number> //ID数组
  siteId?: number //站点ID
  keyword?: string //关键词
  bizType?: string //跳转业务类型
  bizId?: number //跳转业务ID
  state?: number //状态 -1:删除 0:停止使用 1:可以使用
  states?: Array<number> //状态 -1:删除 0:停止使用 1:可以使用数组
  stateGte?: number //大于等于状态 -1:删除 0:停止使用 1:可以使用
  stateLte?: number //小于等于状态 -1:删除 0:停止使用 1:可以使用
  $pg?: number //当前页码
  $rn?: number //每页条数
  $si?: number //起始位置
  $rt?: number //请求类型
  $sn?: Array<string> //排序名称
  $st?: Array<number> //排序类型
}
/**
 * 站点搜索词
 */
export interface SiteKeyword {
  id?: number //站点ID
  saasId?: number //运营商ID
  siteId?: number //站点ID
  keyword?: string //关键词
  bizType?: string //跳转业务类型
  bizId?: number //跳转业务ID
  searchNum?: number //搜索计数
  adjustNum?: number //运营调整计数
  modifyDate?: string //修改时间
  createDate?: string //创建时间
  lastUpdate?: string //上次更新时间
  state?: number //状态 -1:删除 0:停止使用 1:可以使用
}
/**
 * 站点信息
 */
export interface SiteInfo {
  id?: number //站点ID
  saasId?: number //运营商ID
  siteName?: string //站点名
  siteIcon?: string //站点图标
  siteDesc?: string //站点描述
  templateId?: number //模板ID
  mchId?: number //归属人
  areaCode?: number //地区编码
  rankOrder?: number //用于排序
  servicePhone?: string //客户电话
  siteConfig?: string //页面配置{index_rows:首页展示列数}
  createDate?: string //创建时间
  modifyDate?: string //修改时间
  state?: number //状态 -1:删除 0:停止使用 1:可以使用
}
/**
 * POI信息
 */
export interface PoiInfo {
  id?: number //主键编号
  sourceType?: number //接口来源。0代表内部，其他值代表接口ID
  poiType?: number //poi类型,可以使用TypePoi枚举
  poiTag?: string //poi标签
  poiStar?: number //poi星级
  poiScore?: number //poi分数
  poiName?: string //poi名称
  poiNameNative?: string //当地语言名称
  poiNameMatch?: string //poi匹配名称
  poiDesc?: string //poi描述
  poiPrice?: number //参考价
  poiService?: string //服务信息
  address?: string //poi地址
  addressNative?: string //当地语言地址
  openType?: number //开放类型
  openInfo?: string //营业信息，json格式[{desc:周一至周五,time:8:00~12:00}]
  areaCode?: number //poi地区编码
  postCode?: string //poi邮政编码
  phone?: string //poi服务电话,多个电话逗号隔开
  fax?: string //poi传真
  website?: string //官网地址
  imgMain?: string //poi主图地址
  imgList?: string //poi其它图片地址
  geoLng?: number //经度
  geoLat?: number //纬度
  geoHash?: string //geo-hash
  refNum?: number //引用计数
  createDate?: string //创建时间
  modifyDate?: string //修改时间
  state?: number //状态（-1-删除0-初始状态1-正常）
}
/**
 * 内容信息
 */
export interface SiteCmsInfo {
  id?: number //主键id
  saasId?: number //运营商id
  poiId?: number //poiid
  areaCode?: number //所在地区的area_code
  catalogId?: number //内容分类id
  infoName?: string //内容名称
  componentCode?: string //组件代码
  componentData?: string //组件数据
  rankOrder?: number //推荐值
  createDate?: string //创建时间
  modifyDate?: string //修改时间
  state?: number //状态：0启用，1禁用
}
/**
 * CMS目录树形结构
 */
export interface SiteCmsCatalogTreeVo {
  id?: number //主键id
  saasId?: number //运营商id
  parentId?: number //上级id
  poiId?: number //POI代码
  catalogType?: number //分类类型
  catalogName?: string //分类名称
  catalogCode?: string //分类代码
  catalogDesc?: string //分类描述
  rankOrder?: number //推荐值
  createDate?: string //创建时间
  modifyDate?: string //修改时间
  state?: number //状态：0启用，1禁用
  children?: any //子集
}
/**
 * 广告内容表列表查询参数
 */
export interface GuestSiteAdInfoQueryParam {
  id?: number //主键
  ids?: Array<number> //ID数组
  siteId?: number //站点ID
  spaceId?: number //广告位id
  spaceCode?: string //分类代码
  adTitle?: string //主标题
  subTitle?: string //副标题（可以不输入）
  adLink?: string //对应链接
  adImg?: string //对应图片
  rankOrder?: number //推荐值
  rankOrderRange?: Array<number> //推荐值范围
  expireDateRange?: Array<string> //到期时间范围
  state?: number //状态
  states?: Array<number> //状态数组
  stateGte?: number //大于等于状态
  stateLte?: number //小于等于状态
  $pg?: number //当前页码
  $rn?: number //每页条数
  $si?: number //起始位置
  $rt?: number //请求类型
  $sn?: Array<string> //排序名称
  $st?: Array<number> //排序类型
}
/**
 * 广告内容表
 */
export interface SiteAdInfo {
  id?: number //主键
  saasId?: number //运营商id
  siteId?: number //站点ID
  spaceId?: number //广告位id
  spaceCode?: string //分类代码
  adTitle?: string //主标题
  subTitle?: string //副标题（可以不输入）
  adLink?: string //对应链接
  adImg?: string //对应图片
  rankOrder?: number //推荐值
  clickNum?: number //点击数
  expireDate?: string //到期时间
  createDate?: string //创建时间
  modifyDate?: string //修改时间
  state?: number //状态
}
/**
 *
 */
export interface ProductSpecVo {
  saasId?: number //运营商ID
  productId?: number //产品id
  specId?: number //规格产品id
  sessionId?: number //场次时段id
  specName?: string //规格名称
  specDesc?: string //规格描述
  date?: string //日期
  stockNum?: number //库存数
  priceSale?: number //零售价
  priceList?: number //窗口价
  priceCurrency?: string //货币类型
}
/**
 * 产品场次列表查询参数
 */
export interface GuestProductSessionQueryParam {
  id?: number //
  ids?: Array<number> //ID数组
  productId?: number //产品id
  sessionId?: number //场次id
  sessionStartTimeRange?: Array<string> //开始时间范围
  sessionEndTimeRange?: Array<string> //结束时间范围
  sessionDateRange?: Array<string> //场次日期范围
  state?: number //状态 1-正常 0-禁用 -1删除
  states?: Array<number> //状态 1-正常 0-禁用 -1删除数组
  stateGte?: number //大于等于状态 1-正常 0-禁用 -1删除
  stateLte?: number //小于等于状态 1-正常 0-禁用 -1删除
  $pg?: number //当前页码
  $rn?: number //每页条数
  $si?: number //起始位置
  $rt?: number //请求类型
  $sn?: Array<string> //排序名称
  $st?: Array<number> //排序类型
}
/**
 * 产品场次
 */
export interface ProductSession {
  id?: number //
  saasId?: number //运营商ID
  productId?: number //产品id
  sessionId?: number //场次id
  sessionStartTime?: string //开始时间
  sessionEndTime?: string //结束时间
  sessionDate?: string //场次日期
  createDate?: string //创建时间
  modifyDate?: string //修改时间
  state?: number //状态 1-正常 0-禁用 -1删除
}
/**
 * 产品价格列表查询参数
 */
export interface GuestProductPriceQueryParam {
  id?: number //
  ids?: Array<number> //ID数组
  productId?: number //产品编号
  productSpecId?: number //规格产品id
  productStockId?: number //库存id
  productSessionId?: number //场次时段id
  priceDateRange?: Array<string> //日期范围
  priceTag?: string //价格标签
  priceSale?: number //零售价
  priceSaleRange?: Array<number> //零售价范围
  priceCurrency?: string //货币类型
  state?: number //状态 1-正常 -1删除
  states?: Array<number> //状态 1-正常 -1删除数组
  stateGte?: number //大于等于状态 1-正常 -1删除
  stateLte?: number //小于等于状态 1-正常 -1删除
  $pg?: number //当前页码
  $rn?: number //每页条数
  $si?: number //起始位置
  $rt?: number //请求类型
  $sn?: Array<string> //排序名称
  $st?: Array<number> //排序类型
}
/**
 * 产品价格
 */
export interface ProductPrice {
  id?: number //
  saasId?: number //运营商id
  productId?: number //产品编号
  productSpecId?: number //规格产品id
  productStockId?: number //库存id
  productSessionId?: number //场次时段id
  priceDate?: string //日期
  priceTag?: string //价格标签
  priceBase?: number //采购价
  priceDist?: number //分销价
  priceSale?: number //零售价
  priceList?: number //窗口价
  priceCurrency?: string //货币类型
  feeTax?: number //税费
  feeService?: number //服务费
  feeExtra?: number //额外人员费用
  rebateDistributor?: string //分销商返佣配置。 格式：mchGrade,rebateType,rebateValue,多个分号隔开
  rebateSupplier?: string //供应商分佣配置
  createDate?: string //创建时间
  modifyDate?: string //修改时间
  state?: number //状态 1-正常 -1删除
}
/**
 * 产品信息
 */
export interface ProductInfo {
  id?: number //id
  saasId?: number //运营商ID
  extId?: number //扩展表id
  areaCode?: number //地区代码
  catCode?: number //产品分类编码
  skuType?: number //sku类型(1:产品,2:场次,3:规格)
  productType?: number //产品类型TypeProduct
  productName?: string //产品名称
  productNameShort?: string //产品简称
  productUnitCode?: string //商品单位code
  imgMain?: string //主图地址
  imgList?: string //产品图片,多张逗号隔开
  tagIds?: string //产品标签,多个标签逗号隔开
  poiIds?: string //poiId,多个逗号隔开
  productDesc?: string //产品介绍
  stockType?: number //200 非日历库存 201 日历库存  202 日历场次库存
  stockAll?: number //总量库存(-1为不开启总量库存)
  stockSale?: number //已销售数量
  specType?: number //0 产品规格关闭  1 产品规格开启
  priceCurrency?: string //货币类型
  supplierConfigId?: number //供应商接口编号
  supplierMchId?: number //供应商商户id
  supplierProductId?: string //供应商产品ID
  supplierProductName?: string //供应商产品名称
  supplierSlaveInfo?: string //供应商货源从属信息
  supplierState?: number //供应商端状态 0-下架 1-上架
  supplierPoiId?: string //供应商poi编号
  bookInfo?: string //预定须知
  servicePhone?: string //服务电话
  refundInfo?: string //退款说明
  noticeInfo?: string //注意事项
  extInfo?: string //拓展信息{feeInfo:{include:费用包含,exclude:费用不包含},userInfo:使用说明,validateType:1,enterType:1,voucherType:凭证类型，多个以英文,分隔,voucherInfo:凭证说明,changeAddress:换票地址，多个以｜分隔,changeTime:[{start:480,end:1220,desc:换票时间说明}],enterAddress:入园地址，多个以｜分隔,enterTime:[{start:480,end:1220,desc:入园时间说明}],desc:其它说明,limitDateInfo:使用时间段限制}
  rankOrder?: number //推荐值排序
  nights?: number //连住几晚
  breakfast?: number //早餐
  unpayCancelMinutes?: number //下单后不支付自动取消分钟数
  isConfirm?: number //是否需要人工确认,0自动确认1人工确认
  signature?: string //数字签名
  createDate?: string //创建时间
  modifyDate?: string //修改时间
  state?: number //状态 1-正常 0-下架 -1删除
}
/**
 * 产品信息列表查询参数
 */
export interface GuestProductInfoQueryParam {
  id?: number //id
  ids?: Array<number> //ID数组
  areaCode?: number //地区代码
  areaCodeRange?: Array<number> //地区代码范围
  skuType?: number //产品类型(1:产品,2:场次,3:规格)
  productType?: number //产品类型TypeProduct
  productName?: string //产品名称
  productNameShort?: string //产品简称
  productUnitCode?: string //商品单位code
  tagIds?: string //产品标签,多个标签逗号隔开
  poiIds?: string //poiId,多个逗号隔开
  stockType?: number //200 非日历库存 201 日历库存  202 日历场次库存
  priceCurrency?: string //货币类型
  stockAll?: number //总量库存
  stockAllRange?: Array<number> //总量库存范围
  specType?: number //0 产品规格关闭  1 产品规格开启
  rankOrder?: number //推荐值排序
  nights?: number //连住几晚
  nightsRange?: Array<number> //连住几晚范围
  isConfirmRange?: Array<number> //是否需要人工确认,0自动确认1人工确认范围
  state?: number //状态 1-正常 0-下架 -1删除
  states?: Array<number> //状态 1-正常 0-下架 -1删除数组
  stateGte?: number //大于等于状态 1-正常 0-下架 -1删除
  stateLte?: number //小于等于状态 1-正常 0-下架 -1删除
  $pg?: number //当前页码
  $rn?: number //每页条数
  $si?: number //起始位置
  $rt?: number //请求类型
  $sn?: Array<string> //排序名称
  $st?: Array<number> //排序类型
}
/**
 * 产品vo
 */
export interface ProductInfoEx {
  id?: number //id
  saasId?: number //运营商ID
  extId?: number //扩展表id
  areaCode?: number //地区代码
  catCode?: number //产品分类编码
  skuType?: number //sku类型(1:产品,2:场次,3:规格)
  productType?: number //产品类型TypeProduct
  productName?: string //产品名称
  productNameShort?: string //产品简称
  productUnitCode?: string //商品单位code
  imgMain?: string //主图地址
  imgList?: string //产品图片,多张逗号隔开
  tagIds?: string //产品标签,多个标签逗号隔开
  poiIds?: string //poiId,多个逗号隔开
  productDesc?: string //产品介绍
  stockType?: number //200 非日历库存 201 日历库存  202 日历场次库存
  stockAll?: number //总量库存(-1为不开启总量库存)
  stockSale?: number //已销售数量
  specType?: number //0 产品规格关闭  1 产品规格开启
  priceCurrency?: string //货币类型
  supplierConfigId?: number //供应商接口编号
  supplierMchId?: number //供应商商户id
  supplierProductId?: string //供应商产品ID
  supplierProductName?: string //供应商产品名称
  supplierSlaveInfo?: string //供应商货源从属信息
  supplierState?: number //供应商端状态 0-下架 1-上架
  supplierPoiId?: string //供应商poi编号
  bookInfo?: string //预定须知
  servicePhone?: string //服务电话
  refundInfo?: string //退款说明
  noticeInfo?: string //注意事项
  extInfo?: string //拓展信息{feeInfo:{include:费用包含,exclude:费用不包含},userInfo:使用说明,validateType:1,enterType:1,voucherType:凭证类型，多个以英文,分隔,voucherInfo:凭证说明,changeAddress:换票地址，多个以｜分隔,changeTime:[{start:480,end:1220,desc:换票时间说明}],enterAddress:入园地址，多个以｜分隔,enterTime:[{start:480,end:1220,desc:入园时间说明}],desc:其它说明,limitDateInfo:使用时间段限制}
  rankOrder?: number //推荐值排序
  nights?: number //连住几晚
  breakfast?: number //早餐
  unpayCancelMinutes?: number //下单后不支付自动取消分钟数
  isConfirm?: number //是否需要人工确认,0自动确认1人工确认
  signature?: string //数字签名
  createDate?: string //创建时间
  modifyDate?: string //修改时间
  state?: number //状态 1-正常 0-下架 -1删除
  price?: number //价格
  poiNames?: string //poiId,多个逗号隔开
  tagNames?: string //产品标签,多个标签逗号隔开
}
/**
 * 产品限定表
 */
export interface ProductLimit {
  id?: number //主键
  saasId?: number //saasId
  productId?: number //商品id
  limiterClass?: string //限定类型
  limiterConfig?: string //限定配置
  limiterType?: number //限定类型
  createDate?: string //创建时间
  modifyDate?: string //修改日期
  state?: number //状态
}
/**
 * 产品限定表列表查询参数
 */
export interface ProductLimitQueryParam {
  id?: number //主键
  ids?: Array<number> //ID数组
  productId?: number //商品id
  limiterClass?: string //限定类型
  limiterType?: number //限定类型
  createDateRange?: Array<string> //创建时间范围
  modifyDateRange?: Array<string> //修改日期范围
  state?: number //状态
  states?: Array<number> //状态数组
  stateGte?: number //大于等于状态
  stateLte?: number //小于等于状态
  $pg?: number //当前页码
  $rn?: number //每页条数
  $si?: number //起始位置
  $rt?: number //请求类型
  $sn?: Array<string> //排序名称
  $st?: Array<number> //排序类型
}
/**
 * 酒店房床信息表
 */
export interface PoiHotelRoom {
  id?: number //主键ID
  saasId?: number //运营商编号
  poiCode?: string //POI代码
  roomTypeId?: number //房型编号
  roomName?: string //房型名称
  roomDesc?: string //房型介绍
  bedType?: string //床型
  bedSize?: string //房间床尺寸
  acreages?: string //客房面积
  hasWindow?: number //是否有窗
  allowAddBed?: number //是否允许加床
  floorDistribution?: string //房型分布楼层
  wifi?: number //wifi
  smoking?: number //是否禁烟,0未知;1可吸烟;2禁烟;3部分吸烟
  roomFacilities?: string //房型设施
  imgMain?: string //主图地址
  imgList?: string //产品图片，多张逗号隔开
  remark?: string //备注
  internet?: number //宽带
  createDate?: string //创建时间
  modifyDate?: string //修改时间
  state?: number //状态
}
/**
 * 酒店房床信息表列表查询参数
 */
export interface GuestPoiHotelRoomQueryParam {
  id?: number //主键ID
  ids?: Array<number> //ID数组
  poiCode?: string //POI代码
  roomTypeId?: number //房型编号
  roomName?: string //房型名称
  bedType?: string //床型
  bedSize?: string //房间床尺寸
  acreages?: string //客房面积
  hasWindow?: number //是否有窗
  hasWindowRange?: Array<number> //是否有窗范围
  allowAddBed?: number //是否允许加床
  allowAddBedRange?: Array<number> //是否允许加床范围
  floorDistribution?: string //房型分布楼层
  wifi?: number //wifi
  wifiRange?: Array<number> //wifi范围
  smoking?: number //是否禁烟,0未知;1可吸烟;2禁烟;3部分吸烟
  smokingRange?: Array<number> //是否禁烟,0未知;1可吸烟;2禁烟;3部分吸烟范围
  roomFacilities?: string //房型设施
  imgMain?: string //主图地址
  remark?: string //备注
  internet?: number //宽带
  internetRange?: Array<number> //宽带范围
  createDateRange?: Array<string> //创建时间范围
  modifyDateRange?: Array<string> //修改时间范围
  state?: number //状态
  states?: Array<number> //状态数组
  stateGte?: number //大于等于状态
  stateLte?: number //小于等于状态
  $pg?: number //当前页码
  $rn?: number //每页条数
  $si?: number //起始位置
  $rt?: number //请求类型
  $sn?: Array<string> //排序名称
  $st?: Array<number> //排序类型
}
/**
 * POI信息列表查询参数
 */
export interface GuestPoiInfoQueryParam {
  id?: number //主键编号
  ids?: Array<number> //ID数组
  poiType?: number //poi类型,可以使用poiType枚举
  poiStar?: number //poi星级
  poiStarRange?: Array<number> //poi星级范围
  poiScore?: number //poi分数
  poiScoreRange?: Array<number> //poi分数范围
  poiName?: string //poi名称
  poiNameNative?: string //当地语言名称
  poiNameMatch?: string //poi匹配名称
  poiPrice?: number //参考价
  poiPriceRange?: Array<number> //参考价范围
  address?: string //poi地址
  addressNative?: string //当地语言地址
  openType?: number //开放类型
  areaCode?: number //poi地区编码
  refNum?: number //引用计数
  state?: number //状态（-1-删除0-初始状态1-正常）
  states?: Array<number> //状态（-1-删除0-初始状态1-正常）数组
  stateGte?: number //大于等于状态（-1-删除0-初始状态1-正常）
  stateLte?: number //小于等于状态（-1-删除0-初始状态1-正常）
  $pg?: number //当前页码
  $rn?: number //每页条数
  $si?: number //起始位置
  $rt?: number //请求类型
  $sn?: Array<string> //排序名称
  $st?: Array<number> //排序类型
}
/**
 *
 */
export interface PoiInfoEx {
  id?: number //主键编号
  sourceType?: number //接口来源。0代表内部，其他值代表接口ID
  poiType?: number //poi类型,可以使用TypePoi枚举
  poiTag?: string //poi标签
  poiStar?: number //poi星级
  poiScore?: number //poi分数
  poiName?: string //poi名称
  poiNameNative?: string //当地语言名称
  poiNameMatch?: string //poi匹配名称
  poiDesc?: string //poi描述
  poiPrice?: number //参考价
  poiService?: string //服务信息
  address?: string //poi地址
  addressNative?: string //当地语言地址
  openType?: number //开放类型
  openInfo?: string //营业信息，json格式[{desc:周一至周五,time:8:00~12:00}]
  areaCode?: number //poi地区编码
  postCode?: string //poi邮政编码
  phone?: string //poi服务电话,多个电话逗号隔开
  fax?: string //poi传真
  website?: string //官网地址
  imgMain?: string //poi主图地址
  imgList?: string //poi其它图片地址
  geoLng?: number //经度
  geoLat?: number //纬度
  geoHash?: string //geo-hash
  refNum?: number //引用计数
  createDate?: string //创建时间
  modifyDate?: string //修改时间
  state?: number //状态（-1-删除0-初始状态1-正常）
  price?: number //价格
}
/**
 * 订单详情
 */
export interface OrderDetail {
  id?: number //id
  saasId?: number //运营商ID
  orderId?: number //订单号
  skuType?: number //sku类型(1:产品,2:场次,3:规格)
  productId?: number //产品ID
  productSpecId?: number //产品规格ID
  productExt?: string //产品扩展标签，用来存储比如酒店的早餐数
  productCurrency?: string //产品货币类型
  productInfo?: string //产品信息
  specInfo?: string //规格信息
  productSessionId?: number //场次id
  purchaseNum?: number //购买数量
  travelDate?: string //游玩日期,使用时间
  travelEndDate?: string //游玩结束日期,期票使用
  priceBase?: number //成本价
  priceSale?: number //零售价
  priceDist?: number //分销价
  supplierId?: number //供应商接口编号
  supplierMchId?: number //供应商商户编号
  supplierMoney?: number //供应商结算金额
  supplierOrderId?: string //供应商订单号
  supplierOrderInfo?: string //供应商订单信息
  supplierOrderState?: number //供应商订单状态
  supplierMoneyPaid?: number //已经支付供应商的金额
  supplierMoneyRefund?: number //供应商取消金额
  supplierOrderDate?: string //供应商订单时间
  supplierVerifyDate?: string //供应商对账时间
  supplierVerifyState?: number //供应商对账状态 -1 应付款有问题 0未对账 1已对账 未付款 2已付部分 3已付全款
  supplierCurrency?: string //供应商货币类型
  refundType?: number //取消政策 -1-不允许 1-随时取消[不支持部分退] 2-随时取消[支持部分退] 3-条件取消[不支持部分退] 4-条件取消[支持部分退]
  refundPolicy?: string //取消政策描述
  refundNum?: number //取消数量
  orderDate?: string //订单创建时间
  state?: number //-1删除 1已激活  2使用中 3已使用
}
/**
 * 订单客人信息
 */
export interface OrderGuest {
  id?: number //
  saasId?: number //运营商编号
  orderDetailId?: number //订单产品id
  orderId?: number //订单号
  guestName?: string //客户姓名
  guestNamePinyin?: string //客户姓名拼音
  guestMobile?: string //客户电话
  guestMobileArea?: string //客户电话区号
  guestEmail?: string //客户email
  guestBirthday?: string //出生年月
  guestAge?: number //客户年龄
  guestNational?: string //客户国籍
  guestGender?: number //客户性别
  guestAddress?: string //游客地址
  idType?: number //证件类型
  idInfo?: string //证件号码
  remark?: string //备注
  orderDate?: string //创建时间
  modifyDate?: string //修改时间
  state?: number //状态 1-正常 -1删除
}
/**
 * 订单信息扩展类
 */
export interface OrderInfoEx {
  id?: number //商城订单ID
  saasId?: number //运营商ID
  poiId?: number //商家ID
  siteId?: number //站点ID
  agentId?: number //合伙人ID
  guestId?: number //会员编号|客人ID
  orderInfo?: string //订单信息
  orderLang?: string //订单语言类型
  unpayCancelMinutes?: number //订单不支付,自动取消时间
  areaCode?: number //产品的区域编码
  saleType?: number //销售类型，0：普通销售，1：预约销售
  payType?: number //支付类型,参考paymentType
  payMoney?: number //实际支付金额
  payDate?: string //订单支付时间
  useDateType?: number //预约(使用)日期类型(1:抢购后x天内克预约,2:抢购后指定到日期x内可预约,3:抢购后在日期x到y内可预约)
  useDateInfo?: string //有效期信息，根据有效期类型决定
  useDate?: string //预约/配送时间 如果为需要配送,就是配送时间,反之则是预约时间
  contactName?: string //联系人姓名（first_name@last_name）
  contactPhone?: string //联系人电话
  contactEmail?: string //联系人电子邮箱
  deliveryType?: number //配送类型 -1:供应商配送 0:需要配送 1:自动发码 >1的时候为码库发码,这时候前端传码库ID来处理
  deliveryAddress?: string //配送地址
  deliveryState?: number //配送状态 0:未发货 1:已发货
  deliveryDate?: string //生成通知单时间
  confirmType?: number //0-不需要确认 1-需要确认
  confirmDate?: string //订单确认时间
  finishNum?: number //订单验证完成数量
  finishMoney?: number //订单验证完成金额
  finishDate?: string //订单验证完成时间
  remark?: string //客人备注
  channelId?: number //渠道接口编号
  distributorMchId?: number //分销商商户编号
  distributorParentId?: number //分销商直属上级ID
  distributorMoney?: number //渠道结算价
  distributorOrderId?: string //渠道订单号
  distributorOrderState?: number //渠道订单状态
  distributorMoneyReceipted?: number //已经收取分销商的金额
  distributorMoneyRefund?: number //分销商取消金额
  distributorVerifyDate?: string //分销商对账时间
  distributorVerifyState?: number //分销商对账状态 -1 应收款有问题 0未对账 1已对账 未收款 2已收部分 3已收全款
  distributorRebate?: number //分销商佣金
  issueType?: number //issue类型
  issueInfo?: string //issue信息
  issueState?: number //issue处理信息
  refundNum?: number //取消数量
  refundMoney?: number //退款金额
  refundState?: number //取消申请状态
  refundDate?: string //订单取消时间
  orderCurrency?: string //订单货币类型
  orderMoney?: number //订单总价格,含税费/服务费/配送费
  orderState?: number //订单状态
  orderDate?: string //订单时间
  state?: number //状态 0:锁定订单,1:解锁订单
  orderGuestList?: Array<OrderGuest> //订单客人信息集合
  orderVoucherList?: Array<OrderVoucher> //订单票码集合
  orderDetailList?: Array<OrderDetail> //订单详情集合
}
/**
 * 订单票码
 */
export interface OrderVoucher {
  id?: number //id
  saasId?: number //运营商ID
  orderId?: number //订单号
  orderDetailId?: number //订单详情id
  voucherAllNum?: number //验证总次数
  voucherFinishNum?: number //验证次数
  voucherData?: string //验证码详情
  voucherState?: number //码状态
  refundNum?: number //取消数量
  activeDate?: string //激活日期
  expireDate?: string //码过期时间
  startDate?: string //可用开始日期
  endDate?: string //可用结束日期
  lastUseDate?: string //最后使用时间
  refundDate?: string //取消时间
  orderDate?: string //订单创建时间
  state?: number //-1删除 1已激活  2使用中 3已使用
}
/**
 * 订单信息列表查询参数
 */
export interface GuestOrderInfoQueryParam {
  id?: number //商城订单ID
  ids?: Array<number> //ID数组
  poiId?: number //商家ID
  siteId?: number //站点ID
  agentId?: number //合伙人ID
  guestId?: number //会员编号|客人ID
  orderInfo?: string //订单信息
  orderLan?: string //订单语言类型
  areaCode?: number //产品的区域编码
  areaCodeRange?: Array<number> //产品的区域编码范围
  saleType?: number //销售类型，0：普通销售，1：预约销售
  payType?: number //支付类型,参考paymentType
  payDateRange?: Array<string> //订单支付时间范围
  useDateType?: number //预约(使用)日期类型(1:抢购后x天内克预约,2:抢购后指定到日期x内可预约,3:抢购后在日期x到y内可预约)
  useDateInfo?: string //有效期信息，根据有效期类型决定
  useDateRange?: Array<string> //预约/配送时间 如果为需要配送,就是配送时间,反之则是预约时间范围
  contactName?: string //联系人姓名（first_name@last_name）
  contactPhone?: string //联系人电话
  contactEmail?: string //联系人电子邮箱
  deliveryType?: number //配送类型 -1:供应商配送 0:需要配送 1:自动发码 >1的时候为码库发码,这时候前端传码库ID来处理
  deliveryState?: number //配送状态 0:未发货 1:已发货
  remark?: string //客人备注
  issueType?: number //issue类型
  issueInfo?: string //issue信息
  issueState?: number //issue处理信息
  refundState?: number //取消申请状态
  orderCurrency?: string //订单货币类型
  orderState?: number //订单状态
  orderDateRange?: Array<string> //订单时间范围
  state?: number //状态 0:锁定订单,1:解锁订单
  states?: Array<number> //状态 0:锁定订单,1:解锁订单数组
  stateGte?: number //大于等于状态 0:锁定订单,1:解锁订单
  stateLte?: number //小于等于状态 0:锁定订单,1:解锁订单
  $pg?: number //当前页码
  $rn?: number //每页条数
  $si?: number //起始位置
  $rt?: number //请求类型
  $sn?: Array<string> //排序名称
  $st?: Array<number> //排序类型
}
/**
 * 用户优惠劵
 */
export interface GuestCoupon {
  id?: number //id
  saasId?: number //运营商ID
  guestId?: number //用户ID
  couponId?: number //关联的优惠劵ID
  usedDate?: string //使用时间
  sendDate?: string //发放时间
  sendType?: number //发放方式（手动、自动、活动）
  startDate?: string //优惠劵生效时间
  endDate?: string //优惠劵失效时间
  createDate?: string //领取时间
  state?: number //使用状态（未使用、已使用、已过期、删除）
}
/**
 * 用户优惠劵
 */
export interface GuestCouponHistory {
  id?: number //id
  saasId?: number //运营商ID
  guestId?: number //用户ID
  couponId?: number //关联的优惠劵ID
  usedDate?: string //使用时间
  sendDate?: string //发放时间
  sendType?: number //发放方式（手动、自动、活动）
  startDate?: string //优惠劵生效时间
  endDate?: string //优惠劵失效时间
  createDate?: string //领取时间
  state?: number //使用状态（未使用、已使用、已过期、删除）
}
/**
 * 用户优惠劵列表查询参数
 */
export interface GuestGuestCouponQueryParam {
  id?: number //id
  ids?: Array<number> //ID数组
  guestId?: number //用户ID
  couponId?: number //关联的优惠劵ID
  usedDateRange?: Array<string> //使用时间范围
  sendDateRange?: Array<string> //发放时间范围
  sendType?: number //发放方式（手动、自动、活动）
  startDateRange?: Array<string> //优惠劵生效时间范围
  endDateRange?: Array<string> //优惠劵失效时间范围
  createDateRange?: Array<string> //领取时间范围
  state?: number //使用状态（未使用、已使用、已过期、删除）
  states?: Array<number> //使用状态（未使用、已使用、已过期、删除）数组
  stateGte?: number //大于等于使用状态（未使用、已使用、已过期、删除）
  stateLte?: number //小于等于使用状态（未使用、已使用、已过期、删除）
  $pg?: number //当前页码
  $rn?: number //每页条数
  $si?: number //起始位置
  $rt?: number //请求类型
  $sn?: Array<string> //排序名称
  $st?: Array<number> //排序类型
}
/**
 * 优惠劵信息表
 */
export interface CouponInfo {
  id?: number //优惠券ID (主键)
  saasId?: number //运营商ID
  siteId?: number //站点id
  couponName?: string //优惠券名称
  couponDesc?: string //优惠券描述
  couponType?: number //优惠券类型（如满减、折扣）
  couponValue?: number //优惠金额或折扣比例
  limitType?: number //限制类型
  limitValue?: number //限制数值
  startDate?: string //优惠券生效时间
  endDate?: string //优惠券失效时间
  limitScope?: string //适用范围
  stockAll?: number //优惠劵库存
  stockSend?: number //已发放的优惠劵数量
  createDate?: string //创建时间
  modifyDate?: string //更新时间
  state?: number //优惠券状态（有效、过期、删除等）
}
/**
 *
 */
export interface GuestCouponEx {
  id?: number //id
  saasId?: number //运营商ID
  guestId?: number //用户ID
  couponId?: number //关联的优惠劵ID
  usedDate?: string //使用时间
  sendDate?: string //发放时间
  sendType?: number //发放方式（手动、自动、活动）
  startDate?: string //优惠劵生效时间
  endDate?: string //优惠劵失效时间
  createDate?: string //领取时间
  state?: number //使用状态（未使用、已使用、已过期、删除）
  couponInfo?: CouponInfo //
}
/**
 * 用户优惠劵列表查询参数
 */
export interface GuestGuestCouponHistoryQueryParam {
  id?: number //id
  ids?: Array<number> //ID数组
  guestId?: number //用户ID
  couponId?: number //关联的优惠劵ID
  usedDateRange?: Array<string> //使用时间范围
  sendDateRange?: Array<string> //发放时间范围
  sendType?: number //发放方式（手动、自动、活动）
  startDateRange?: Array<string> //优惠劵生效时间范围
  endDateRange?: Array<string> //优惠劵失效时间范围
  createDateRange?: Array<string> //领取时间范围
  state?: number //使用状态（未使用、已使用、已过期、删除）
  states?: Array<number> //使用状态（未使用、已使用、已过期、删除）数组
  stateGte?: number //大于等于使用状态（未使用、已使用、已过期、删除）
  stateLte?: number //小于等于使用状态（未使用、已使用、已过期、删除）
  $pg?: number //当前页码
  $rn?: number //每页条数
  $si?: number //起始位置
  $rt?: number //请求类型
  $sn?: Array<string> //排序名称
  $st?: Array<number> //排序类型
}
/**
 * 优惠劵信息表列表查询参数
 */
export interface CouponInfoQueryParam {
  id?: number //优惠券ID (主键)
  ids?: Array<number> //ID数组
  siteId?: number //站点id
  couponName?: string //优惠券名称
  couponType?: number //优惠券类型（如满减、折扣）
  couponValue?: number //优惠金额或折扣比例
  couponValueRange?: Array<number> //优惠金额或折扣比例范围
  limitType?: number //限制类型
  limitValue?: number //限制数值
  limitValueRange?: Array<number> //限制数值范围
  startDateRange?: Array<string> //优惠券生效时间范围
  endDateRange?: Array<string> //优惠券失效时间范围
  stockAll?: number //优惠劵库存
  stockAllRange?: Array<number> //优惠劵库存范围
  stockSend?: number //已发放的优惠劵数量
  stockSendRange?: Array<number> //已发放的优惠劵数量范围
  createDateRange?: Array<string> //创建时间范围
  modifyDateRange?: Array<string> //更新时间范围
  state?: number //优惠券状态（有效、过期、删除等）
  states?: Array<number> //优惠券状态（有效、过期、删除等）数组
  stateGte?: number //大于等于优惠券状态（有效、过期、删除等）
  stateLte?: number //小于等于优惠券状态（有效、过期、删除等）
  $pg?: number //当前页码
  $rn?: number //每页条数
  $si?: number //起始位置
  $rt?: number //请求类型
  $sn?: Array<string> //排序名称
  $st?: Array<number> //排序类型
}
/**
 * 用户地址簿列表查询参数
 */
export interface GuestGuestAddressQueryParam {
  id?: number //主键ID
  ids?: Array<number> //ID数组
  guestId?: number //用户ID
  areaCode?: number //所在地区的area_code
  areaCodeRange?: Array<number> //所在地区的area_code范围
  guestName?: string //收货人
  guestPhone?: string //手机号码
  guestAddress?: string //详细地址
  addressTag?: string //地址标签,多个用逗号隔开,每个最多五个字
  isDefault?: number //是否默认地址 0:不是 1:是  不设置的话选第一条作为默认地址
  isDefaultRange?: Array<number> //是否默认地址 0:不是 1:是  不设置的话选第一条作为默认地址范围
  state?: number //地址状态 -1:删除 1:正常
  states?: Array<number> //地址状态 -1:删除 1:正常数组
  stateGte?: number //大于等于地址状态 -1:删除 1:正常
  stateLte?: number //小于等于地址状态 -1:删除 1:正常
  $pg?: number //当前页码
  $rn?: number //每页条数
  $si?: number //起始位置
  $rt?: number //请求类型
  $sn?: Array<string> //排序名称
  $st?: Array<number> //排序类型
}
