<script lang="ts" setup>
import { isBeyond } from '@/utils/tool'

const disabled = ref(false)
const props = withDefaults(
  defineProps<{
    text: string
    placement?:
      | 'top'
      | 'top-start'
      | 'top-end'
      | 'bottom'
      | 'bottom-start'
      | 'bottom-end'
      | 'left'
      | 'left-start'
      | 'left-end'
      | 'right'
      | 'right-start'
      | 'right-end'
    extend?: Record<string, any>
  }>(),
  {
    placement: 'right'
  }
)

//  鼠标移入
const handleMouse = (event: MouseEvent) => {
  const isOver = isBeyond(event)
  disabled.value = isOver
}
</script>

<template>
  <el-tooltip
    :content="props.text"
    :disabled="disabled"
    :placement="props.placement"
    v-bind="extend"
  >
    <el-text
      truncated
      @mouseenter="handleMouse($event)"
      @mouseleave="disabled = true"
    >
      {{ props.text }}
    </el-text>
  </el-tooltip>
</template>

<style lang="scss" scoped></style>
