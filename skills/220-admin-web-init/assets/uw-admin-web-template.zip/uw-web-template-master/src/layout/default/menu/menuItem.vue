<script lang="ts" setup>
import MenuItem from './menuItem.vue'
import MenuTip from './menuTip.vue'
import { ArrowDownBold } from '@element-plus/icons-vue'
import { useMainStore } from '@/store/main'
import { MENU_ITEM } from './type'
import { SHOW_SECOND_MENU_ICON } from '@/config/common'

type EMITS = (e: 'click', item: MENU_ITEM) => void

interface Porps extends MENU_ITEM {
  activeId?: number | string // 激活的ID
}

const props = withDefaults(defineProps<Porps>(), {
  name: ''
})

const emits = defineEmits<EMITS>()

const mainStore = useMainStore()
const router = useRouter()

const childShow = ref(false)

const collapseChild = computed(() => {
  if (mainStore.collapse) return false
  return childShow.value
})

const clickMenu = () => {
  if (props.list) {
    childShow.value = !childShow.value
  } else {
    if (props.route && !props.list) router.push(props.route)
    const item: MENU_ITEM = {
      route: props.route
    }
    emits('click', item)
  }
}

const clickMenuChild = (item: MENU_ITEM) => {
  emits('click', item)
}

watch(
  () => props.activeId,
  val => {
    if (props.list && props.list.length) {
      const isExpandChild = props.list.some(item => item.route === val)
      if (isExpandChild) {
        childShow.value = true
      }
    }
  },
  {
    immediate: true
  }
)
</script>

<template>
  <div
    class="menu-item"
    :class="{
      'menu-item__list': props.list,
      active: props.activeId === props.route
    }"
    @click.stop="clickMenu"
  >
    <template v-if="props.list">
      <div class="menu-item__title padding-right-10">
        <MenuIcon :icon-name="props.icon!" />
        <el-tooltip
          v-if="mainStore.collapse"
          effect="dark"
          placement="right"
        >
          <MenuIcon
            :icon-name="props.icon!"
            v-if="SHOW_SECOND_MENU_ICON"
          />
          <template #content>
            <MenuTip
              :list="props.list"
              @click="clickMenuChild"
            />
          </template>
        </el-tooltip>
        <Transition name="menu">
          <p
            class="menu-item__text space-between"
            v-if="!mainStore.collapse"
          >
            <slot>{{ props.name }}</slot>
            <el-icon
              :class="{
                'item-text__icon': true,
                'collapse-icon': collapseChild
              }"
              size="12"
            >
              <ArrowDownBold />
            </el-icon>
          </p>
        </Transition>
      </div>
      <el-collapse-transition>
        <div
          v-show="collapseChild"
          class="menu-item__child"
        >
          <MenuItem
            v-for="(item, index) in props.list"
            :key="index"
            :active-id="props.activeId"
            :list="item.list"
            :route="item.route"
            :icon="item.icon"
            @click="clickMenuChild"
          >
            <ToolTipText :text="$t(item.route)" />
          </MenuItem>
        </div>
      </el-collapse-transition>
    </template>
    <template v-else>
      <MenuIcon
        :icon-name="props.icon!"
        v-if="SHOW_SECOND_MENU_ICON || props.route.includes('dashboard')"
      />
      <el-tooltip
        effect="dark"
        placement="right"
        content=""
        v-if="mainStore.collapse"
        append-to=".layout-container"
        popper-class="custom-tooltip"
      >
        <MenuIcon
          :icon-name="props.icon!"
          v-if="SHOW_SECOND_MENU_ICON"
        />
        <template #content>
          <slot>{{ props.name }}</slot>
        </template>
      </el-tooltip>
      <Transition name="menu">
        <p
          class="menu-item_children__text"
          v-if="!mainStore.collapse"
          :class="{
            'padding-left-25':
              !SHOW_SECOND_MENU_ICON && !props.route.includes('dashboard')
          }"
        >
          <slot>{{ props.name }}</slot>
        </p>
      </Transition>
    </template>
  </div>
</template>

<style lang="scss" scoped>
.menu-item {
  cursor: pointer;
  display: flex;
  align-items: center;
  width: 100%;
  height: $asideItemHeight;
  color: $asidecolor;
  box-sizing: border-box;
  transition: background-color $asideTransitionTime;

  &:hover:not(.menu-item__list) {
    background-color: $asideBackgroundColorHover;
  }

  &.active {
    background-color: $asideBackgroundColorActive !important;
  }

  &.menu-item__list {
    display: flex;
    height: auto;
    flex-direction: column;
    align-items: flex-start;
    padding-left: 0;

    .menu-item__title {
      display: flex;
      align-items: center;
      white-space: nowrap;
      width: 100%;
      height: 50px;
      box-sizing: border-box;

      &:hover {
        background-color: $asideBackgroundColorHover;
      }
    }

    .menu-item__child {
      width: 100%;
      padding-left: 20px;
      box-sizing: border-box;
    }
  }

  .menu-item__text {
    // flex: 1;
    width: calc(100% - 65px);
    display: inline-flex;
    height: 100%;
    align-items: center;
    white-space: nowrap;
    font-size: 14px;

    .item-text__icon {
      transition: $asideTransitionTime;
      color: $asideArrowDownBoldColor;
    }

    .collapse-icon {
      transform: rotate(-90deg);
    }
  }

  .menu-item_children__text {
    width: calc(100% - 40px);
    display: inline-flex;
    height: 100%;
    align-items: center;
    white-space: nowrap;
    font-size: 14px;

    .item-text__icon {
      transition: $asideTransitionTime;
      color: $asideArrowDownBoldColor;
    }

    .collapse-icon {
      transform: rotate(-90deg);
    }

    :deep(.el-text) {
      color: $asidecolor;
    }
  }

  :deep(.menu-icon__box) {
    width: 40px;
  }
}

.menu-enter-active,
.menu-leave-active {
  transition: opacity $asideTransitionTime ease;
}

.menu-enter-from,
.menu-leave-to {
  opacity: 0;
}
</style>
