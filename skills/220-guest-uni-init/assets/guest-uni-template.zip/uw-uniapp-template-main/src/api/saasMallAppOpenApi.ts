import request from '@/api/request'
import type { ResponseData } from '@/api/type/API_TYPE'

/**
 * 发送验证码
 */
export const openGuestAuthSendVerifyCode = (data: GuestVerifyCodeVo) => {
  return request({
    url: '/saas-mall-app/open/guest/auth/sendVerifyCode',
    method: 'POST',
    data
  }) as Promise<ResponseData<void>>
}
/**
 * 重置密码
 */
export const openGuestAuthResetPass = (data: GuestResetPasswordRequest) => {
  return request({
    url: '/saas-mall-app/open/guest/auth/resetPass',
    method: 'POST',
    data
  }) as Promise<ResponseData<void>>
}
/**
 * 保存注册信息
 */
export const openGuestAuthRegistry = (data: GuestRegistryRequest) => {
  return request({
    url: '/saas-mall-app/open/guest/auth/registry',
    method: 'POST',
    data
  }) as Promise<ResponseData<GuestInfo>>
}
/**
 * 登录
 */
export const openGuestAuthLogin = (data: GuestLoginRequest) => {
  return request({
    url: '/saas-mall-app/open/guest/auth/login',
    method: 'POST',
    data
  }) as Promise<ResponseData<TokenResponse>>
}
/**
 * 生成Captcha
 */
export const openGuestAuthGenCaptcha = (params: {
  captchaId?: string //
}) => {
  return request({
    url: '/saas-mall-app/open/guest/auth/genCaptcha',
    method: 'GET',
    params
  }) as Promise<ResponseData<CaptchaQuestion>>
}
/**
 * 获取匿名token
 */
export const openGuestAuthGenANYToken = (params: {
  saasId: number // 运营商Id
  mchId: number // SAAS商户Id
}) => {
  return request({
    url: '/saas-mall-app/open/guest/auth/genANYToken',
    method: 'GET',
    params
  }) as Promise<ResponseData<string>>
}
/**
 * 获取所有枚举
 */
export const openEnumGetAllEnumMap = () => {
  return request({
    url: '/saas-mall-app/open/enum/getAllEnumMap',
    method: 'GET'
  }) as Promise<ResponseData<any>>
}

/**
 * 发送验证码
 */
export interface GuestVerifyCodeVo {
  deviceId?: string //设备Id（手机号或邮箱地址）
  deviceType?: number //设备类型
  captchaId?: string //验证码Id
  captchaSign?: string //验证码用户答案
}
/**
 * 重置密码Vo
 */
export interface GuestResetPasswordRequest {
  loginId?: string //登录信息
  deviceType?: number //设备类型
  verifyCode?: string //验证码
  newPassword?: string //新密码
}
/**
 * 注册
 */
export interface GuestRegistryRequest {
  saasId?: number //saasId
  mobile?: string //手机
  email?: string //邮箱
  username?: string //登录名称
  password?: string //密码
  gender?: number //性别1男0女 -1未知
  birthday?: string //用户生日
  userIcon?: string //用户头像
  idCard?: string //身份证号码
  realName?: string //真实名称
  wxId?: string //微信ID
  mchId?: number //商户id
  idType?: number //证件类型
  areaCode?: number //所在地区的area_code
  captcha?: string //验证码
  deviceType?: number //设备类型
}
/**
 * 用户信息
 */
export interface GuestInfo {
  id?: number //主键
  saasId?: number //saasId
  mchId?: number //商户id
  mobile?: string //手机
  mobileArea?: string //联系电话区号
  email?: string //邮箱
  username?: string //登录名称
  password?: string //密码
  gender?: number //性别1男0女 -1未知
  birthday?: string //用户生日
  userIcon?: string //用户头像
  idType?: number //证件类型
  idInfo?: string //身份证号码
  realName?: string //真实名称
  wxId?: string //微信ID
  areaCode?: number //所在地区的area_code
  orderAmount?: number //下单总金额
  regIp?: string //创建ip
  lastPasswdDate?: string //最后更新密码时间
  lastLogonDate?: string //最后登录时间
  lastLogonIp?: string //最后登录ip
  logonCount?: number //登录次数
  createDate?: string //创建日期
  modifyDate?: string //修改日期
  state?: number //状态：-1: 删除 0: 冻结 1: 正常
}
/**
 * 登录请求对象
 */
export interface GuestLoginRequest {
  loginType?: number //登录类型
  loginId?: string //登录信息
  loginSecret?: string //登录加密密码
  loginPass?: string //登录明文密码
  saasId?: number //saasId
  userType?: number //用户类型
  captchaId?: string //验证码Id
  captchaSign?: string //验证码用户答案

  verifyCode?: string // 验证码
}
/**
 * token返回结果
 */
export interface TokenResponse {
  tokenType?: number //token类型
  saasId?: number //saasId
  saasName?: string //saas名称
  userType?: number //用户类型
  userId?: number //用户Id
  mchId?: number //商户编号
  groupId?: number //所属用户组ID
  userName?: string //登录名
  realName?: string //真实名称
  nickName?: string //别名 [用于业务前台匿名]
  mobile?: string //手机号码
  email?: string //email
  lastPasswdDate?: string //最后更新密码时间
  loginNotice?: string //登录提示信息
  token?: string //token
  refreshToken?: string //刷新token
  expiresIn?: number //token过期时间
  refreshExpiresIn?: number //刷新token过期时间
  createAt?: number //创建时间
}
/**
 * captcha问题信息
 */
export interface CaptchaQuestion {
  captchaId?: string //captchaId
  captchaTTL?: number //captcha有效期
  captchaType?: string //captcha类型
  mainImageBase64?: string //原生图片base64
  subImageBase64?: string //拼图图片base64
  subData?: string //附加数据
}
