import request from '@/utils/request'
import { ResponseData, EnumStruct, ESDataList } from './uwAuthCenterAuthApi'

//修改我的信息
export const userUpdateProfile = (
  data: MscUser
): Promise<ResponseData<void>> => {
  return request('/uw-auth-center/user/updateProfile', {
    method: 'PUT',
    data
  })
}
//修改密码
export const userUpdatePassword = (params: {
  oldPassword: string // 旧密码
  newPassword: string // 新密码
}): Promise<ResponseData<void>> => {
  return request('/uw-auth-center/user/updatePassword', {
    method: 'PUT',
    params
  })
}
//设备解绑
export const userUnbindDevice = (params: {
  mfaType: number // 设备类型
  password: string // 登录密码
}): Promise<ResponseData<void>> => {
  return request('/uw-auth-center/user/unbindDevice', {
    method: 'PUT',
    params
  })
}
//TOTP密钥签发
export const userIssueTotpSecret = (): Promise<
  ResponseData<TotpSecretData>
> => {
  return request('/uw-auth-center/user/issueTotpSecret', {
    method: 'PUT'
  })
}
//TOTP密钥清空
export const userClearTotpSecret = (params: {
  password: string // 登录密码
}): Promise<ResponseData<void>> => {
  return request('/uw-auth-center/user/clearTotpSecret', {
    method: 'PUT',
    params
  })
}
//TOTP密钥绑定
export const userBindTotpSecret = (params: {
  totpSecret: string // totp密钥
  totpCode: string // totpCode
}): Promise<ResponseData<void>> => {
  return request('/uw-auth-center/user/bindTotpSecret', {
    method: 'PUT',
    params
  })
}
//设备绑定
export const userBindDevice = (params: {
  mfaType: number // 设备类型
  deviceId: string // 设备ID,手机号或email
  deviceCode: string // 设备码
  password: string // 登录密码
}): Promise<ResponseData<void>> => {
  return request('/uw-auth-center/user/bindDevice', {
    method: 'PUT',
    params
  })
}
//设备验证码发送
export const userSendDeviceCode = (params: {
  mfaType: number // 设备类型
  deviceId: string // 设备ID,手机号或email
  captchaId?: string // captchaId
  captchaSign?: string // captchaSign
}): Promise<ResponseData<void>> => {
  return request('/uw-auth-center/user/sendDeviceCode', {
    method: 'POST',
    params
  })
}
//MFA验证
export const userMfaVerify = (params: {
  loginAgent: string // 登录代理
  mfaType: number // mfa类型
  mfaCode: string // mfaCode
}): Promise<ResponseData<TokenResponse>> => {
  return request('/uw-auth-center/user/mfaVerify', {
    method: 'POST',
    params
  })
}
//获取用户类型配置
export const userUserTypeConfig = (): Promise<ResponseData<UserTypeConfig>> => {
  return request('/uw-auth-center/user/userTypeConfig', {
    method: 'GET'
  })
}
//我的信息
export const userProfile = (): Promise<ResponseData<MscUserInfo>> => {
  return request('/uw-auth-center/user/profile', {
    method: 'GET'
  })
}
//MFA可用类型
export const userMfaTypes = (): Promise<ResponseData<Array<EnumStruct>>> => {
  return request('/uw-auth-center/user/mfaTypes', {
    method: 'GET'
  })
}
//加载权限菜单
export const userLoadAppMenu = (params: {
  appId?: number // 应用id，如果设置为0则拉取全部
}): Promise<ResponseData<Array<MscAppPermVo>>> => {
  return request('/uw-auth-center/user/loadAppMenu', {
    method: 'GET',
    params
  })
}
//登录日志查询
export const userListLoginLog = (
  params: MscLoginLogEsQueryParam
): Promise<ResponseData<ESDataList<MscLoginEsLog>>> => {
  return request('/uw-auth-center/user/listLoginLog', {
    method: 'GET',
    params
  })
}
//操作日志查询
export const userListActionLog = (
  params: MscActionEsLogQueryParam
): Promise<ResponseData<ESDataList<MscActionEsLog>>> => {
  return request('/uw-auth-center/user/listActionLog', {
    method: 'GET',
    params
  })
}
//退出登录
export const userLogout = (params: {
  loginAgent: string // 登录代理
}): Promise<ResponseData<void>> => {
  return request('/uw-auth-center/user/logout', {
    method: 'DELETE',
    params
  })
}

//MSC用户
export interface MscUser {
  id?: number //用户Id
  saasId?: number //运营商Id
  userType?: number //用户类型
  mchId?: number //商户编号
  groupId?: number //所属用户组ID
  isMaster?: number //是否管理员
  username?: string //登录名称
  password?: string //登录密码
  realName?: string //真实名称
  nickName?: string //别名 [用于业务前台匿名]
  mobile?: string //手机号码
  email?: string //email
  wxId?: string //微信ID
  gender?: number //性别-1未知0女1男
  areaCode?: number //地区
  idType?: number //证件类型
  idInfo?: string //证件信息
  userIcon?: string //用户头像
  userGrade?: number //用户级别
  authFlag?: number //验证标识
  authSecret?: string //验证密钥
  remark?: string //备注
  lastPasswdDate?: string //最后更新密码时间
  lastLogonType?: number //最后登录类型
  lastLogonDate?: string //最后登录时间
  lastLogonIp?: string //最后登录ip
  logonCount?: number //登录次数
  createDate?: string //创建日期
  modifyDate?: string //修改日期
  state?: number //状态：-1: 删除 0: 冻结 1: 正常
}
//Totp密钥数据
export interface TotpSecretData {
  secret?: string //密钥
  uri?: string //二维码链接
  qr?: string //二维码图片base64
}
//token返回结果
export interface TokenResponse {
  tokenType?: number //token类型
  saasId?: number //saasId
  saasName?: string //saas名称
  userType?: number //用户类型
  userId?: number //用户Id
  mchId?: number //商户编号
  groupId?: number //所属用户组ID
  userName?: string //登录名
  realName?: string //真实名称
  nickName?: string //别名 [用于业务前台匿名]
  mobile?: string //手机号码
  email?: string //email
  lastPasswdDate?: string //最后更新密码时间
  loginNotice?: string //登录提示信息
  token?: string //token
  refreshToken?: string //刷新token
  expiresIn?: number //token过期时间
  refreshExpiresIn?: number //刷新token过期时间
  createAt?: number //创建时间
}
//数据
export interface UserTypeConfig {
  tokenExpire?: any //
  tokenRefreshExpire?: any //
  tokenTempExpire?: any //
  tokenSudoExpire?: any //
  passwordConfig?: any //登录类型
  loginTypes?: Array<string> //
  mfaTypes?: Array<string> //
}
//MSC用户信息
export interface MscUserInfo {
  id?: number //用户Id
  saasId?: number //运营商Id
  userType?: number //用户类型
  mchId?: number //商户编号
  groupId?: number //用户组ID
  groupName?: string //用户组名
  isMaster?: number //是否管理员
  username?: string //登录名称
  realName?: string //真实名称
  nickName?: string //别名 [用于业务前台匿名]
  mobile?: string //手机号码
  email?: string //email
  wxId?: string //微信ID
  gender?: number //性别-1未知0女1男
  areaCode?: number //地区
  idType?: number //证件类型
  idInfo?: string //证件信息
  userIcon?: string //用户头像
  userGrade?: number //用户级别
  authFlag?: number //验证标记
  remark?: string //备注
  lastPasswdDate?: string //最后更新密码时间
  lastLogonDate?: string //最后登录时间
  lastLogonIp?: string //最后登录ip
  logonCount?: number //登录次数
  createDate?: string //创建日期
  modifyDate?: string //修改日期
  state?: number //状态：-1: 删除 0: 冻结 1: 正常
}
//MSC菜单权限Vo
export interface MscAppPermVo {
  id?: number //应用Id
  appName?: string //应用唯一名称
  appVersion?: string //应用版本
  appLabel?: string //应用名称
  appRank?: number //应用显示顺序[ASC]
  lastUpdate?: string //最后更新时间
  displayState?: number //显示状态
  permVoList?: Array<PermVo> //菜单树列表
}
//菜单树列表
export interface PermVo {
  id?: number //id
  permCode?: string //权限菜单URI
  permName?: string //权限菜单名称
  permRank?: number //菜单排序
  licenseCode?: string //许可代码
  displayState?: number //1:显示,0:隐藏
}
//用户登录日志查询参数
export interface MscLoginLogEsQueryParam {
  mchId?: number //商户ID
  userId?: number //用户id
  userType?: number //用户类型
  appInfo?: string //App信息
  appHost?: string //App主机
  loginAgent?: string //登录代理
  loginType?: number //登录类型
  loginId?: string //登录标识
  groupId?: number //用户组ID
  userName?: string //用户名
  nickName?: string //用户昵称
  realName?: string //真实名称
  userIp?: string //操作人ip
  responseState?: string //响应状态
  responseCode?: string //响应代码
  responseMillisRange?: Array<number> //请求毫秒数范围
  loginDateRange?: Array<string> //登录时间范围
  $pg?: number //当前页码
  $rn?: number //每页条数
  $si?: number //起始位置
  $rt?: number //请求类型
  $sn?: Array<string> //排序名称
  $st?: Array<number> //排序名称
}
//用户登录ES日志
export interface MscLoginEsLog {
  appInfo?: string //App信息
  appHost?: string //App主机
  loginAgent?: string //登录客户端
  loginType?: number //登录类型
  loginId?: string //登录标识
  userId?: number //用户Id
  userName?: string //用户信息
  nickName?: string //昵称信息
  realName?: string //真实姓名
  saasId?: number //运营商Id
  mchId?: number //商户Id
  groupId?: number //用户组Id
  userType?: number //用户类型
  userIp?: string //登录IP
  clientType?: number //登录设备
  clientAgent?: string //用户代理
  responseState?: string //响应状态
  responseCode?: string //响应代码
  responseMsg?: string //响应消息
  loginDate?: string //登录时间
  responseMillis?: number //响应毫秒数
}
//用户操作日志查询参数
export interface MscActionEsLogQueryParam {
  mchId?: number //商户ID
  userId?: number //用户id
  userType?: number //用户类型
  appInfo?: string //应用信息
  appHost?: string //应用主机
  groupId?: number //用户组ID
  userName?: string //用户名
  nickName?: string //用户昵称
  realName?: string //真实名称
  userIp?: string //操作人ip
  bizType?: string //操作对象类型
  bizId?: string //操作对象id
  apiUri?: string //请求uri
  apiName?: string //API名称
  responseState?: string //响应状态
  responseCode?: string //响应代码
  responseMillisRange?: Array<number> //请求毫秒数范围
  statusCode?: number //响应状态码
  statusCodeRange?: Array<number> //响应状态码范围
  requestDateRange?: Array<string> //创建时间范围
  $pg?: number //当前页码
  $rn?: number //每页条数
  $si?: number //起始位置
  $rt?: number //请求类型
  $sn?: Array<string> //排序名称
  $st?: Array<number> //排序名称
}
//用户操作ES日志
export interface MscActionEsLog {
  appInfo?: string //App信息
  appHost?: string //App主机
  saasId?: number //运营商Id
  mchId?: number //商户Id
  userId?: number //用户Id
  userType?: number //用户类型
  groupId?: number //用户组Id
  userName?: string //用户信息
  nickName?: string //昵称信息
  realName?: string //真实姓名
  userIp?: string //用户IP
  apiUri?: string //API URI
  apiName?: string //API名称
  bizType?: string //业务类型
  bizId?: any //业务Id
  bizLog?: string //业务日志
  requestBody?: string //请求参数
  requestDate?: string //请求时间
  responseBody?: string //响应日志
  responseState?: string //响应状态
  responseCode?: string //响应代码
  responseMsg?: string //响应消息
  responseMillis?: number //执行返回毫秒数
  statusCode?: number //响应状态码
}
