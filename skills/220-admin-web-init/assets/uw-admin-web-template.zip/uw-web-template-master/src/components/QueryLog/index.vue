<script setup lang="ts">
const props = withDefaults(
  defineProps<{
    modelValue: boolean
    title?: string
    content: string
  }>(),
  {
    title: '详情'
  }
)

// 是否显示
const isShow = useModel(props, 'modelValue')
</script>

<template>
  <el-dialog
    v-model="isShow"
    :title="title"
    width="800px"
    draggable
  >
    <el-input
      readonly
      :rows="28"
      :value="content || '暂无数据'"
      type="textarea"
    />
  </el-dialog>
</template>

<style scoped lang="scss"></style>
