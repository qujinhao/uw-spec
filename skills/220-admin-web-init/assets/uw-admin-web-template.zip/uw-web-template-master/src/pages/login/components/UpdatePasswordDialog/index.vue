<script setup lang="ts">
import { useI18n } from 'vue-i18n'
import { ElMessage, type FormInstance } from 'element-plus'
import {
  userUpdatePassword,
  userUserTypeConfig,
  type UserTypeConfig
} from '@/api/uwAuthCenterUserApi'
import { useMainStore } from '@/store/main'
import { secureRSAEncryption } from '@/utils/encryptionAndDecryption'
import { useCountdown } from '@/hooks/useCountdown'

const { t } = useI18n()
const props = defineProps<{
  modelValue: boolean
}>()

// 是否显示
const isShow = useModel(props, 'modelValue')
const mainStore = useMainStore()
const loading = ref(false)

// 关闭的回调
const closeCallback = () => {
  updatePassWordFormRef.value?.resetFields()
  mainStore.setLoginInfo({})
  stop()
}

// 修改密码
const updatePassWordForm = reactive({
  oldPassword: '',
  newPassword: '',
  repeatNewPassword: ''
})
// 表单
const updatePassWordFormRef = ref<FormInstance>()

// 新密码校验
const validateNewPassword = (rule: any, value: any, callback: any) => {
  if (
    /^(?=.*[A-Za-z])(?=.*\d)[\w!@#$%^&*\-+=(){}[\]|\\:;"'<>,.?/`~]{8,72}$/.test(
      value
    )
  ) {
    if (updatePassWordForm.oldPassword === updatePassWordForm.newPassword) {
      callback(t('updatePasswordTip'))
    } else {
      callback()
    }
  } else {
    callback(new Error(t('passwordFormat')))
  }
}

// 旧密码校验
const validateRepeatPassword = (rule: any, value: any, callback: any) => {
  if (value !== updatePassWordForm.newPassword) {
    callback(new Error(t('user.passwordError')))
  } else {
    callback()
  }
}

// 提交
const handleSubmit = () => {
  updatePassWordFormRef.value?.validate(valid => {
    if (valid) {
      loading.value = true
      const oldPassword = secureRSAEncryption(updatePassWordForm.oldPassword)
      const newPassword = secureRSAEncryption(updatePassWordForm.newPassword)
      userUpdatePassword({
        oldPassword: oldPassword as string,
        newPassword: newPassword as string
      })
        .then(res => {
          if (res.state === 'success') {
            ElMessage.success(
              t('passwordEdit') + t('success') + ',' + t('loginAgain')
            )
            isShow.value = false
          } else {
            if (res.code === 'auth.center.passwd.complexity.error') {
              if (passwordConfig.value) {
                const msg = handlePasswordTip()
                ElMessage.error(msg || res.msg)
              } else {
                ElMessage.error(res.msg || t('passwordEdit') + t('error'))
              }
            } else {
              ElMessage.error(res.msg || t('passwordEdit') + t('error'))
            }
          }
          loading.value = false
        })
        .catch(() => {
          loading.value = false
        })
    }
  })
}

// 处理密码提示
const handlePasswordTip = () => {
  if (passwordConfig.value === 'ULTIMATE') {
    return t('ULTIMATEPasswordRule')
  } else if (passwordConfig.value === 'EXTREME') {
    return t('EXTREMEPasswordRule')
  } else if (passwordConfig.value === 'STRICT') {
    return t('STRICTPasswordRule')
  } else if (passwordConfig.value === 'STANDARD') {
    return t('STANDARDPasswordRule')
  } else if (passwordConfig.value === 'NORMAL') {
    return t('passwordFormat')
  }
}

// 密码配置要求
const passwordConfig = computed(() => {
  return userTypeConfig.value.passwordConfig?.name || ''
})

const userTypeConfig = ref<UserTypeConfig>({})
// 获取用户类型配置
const handleLoadUserConfig = () => {
  userUserTypeConfig()
    .then(res => {
      userTypeConfig.value = res.data || {}
    })
    .catch(() => {
      userTypeConfig.value = {}
    })
}

// 倒计时
const { start, currentTime, stop } = useCountdown({
  onEnd() {
    if (isShow.value) {
      //  倒计时完成后提示过期之后跳回登录界面
      ElMessage.warning(t('tempTokenExpired'))
      isShow.value = false
    }
  }
})

// 展示的倒计时时间 HH:mm:ss
const displayTime = computed(() => {
  if (currentTime.value) {
    const hours = Math.floor(currentTime.value / 3600)
    const minutes = Math.floor((currentTime.value % 3600) / 60)
    const seconds = Math.floor(currentTime.value % 60)
    return `${hours.toString().padStart(2, '0')}:${minutes
      .toString()
      .padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`
  }
  return '00:00:00'
})

watch(
  () => isShow.value,
  val => {
    if (val) {
      handleLoadUserConfig()
    }
  }
)

defineExpose({
  start
})
</script>

<template>
  <div>
    <el-dialog
      v-model="isShow"
      :title="t('passwordEdit')"
      @close="closeCallback"
      width="450px"
      draggable
      :close-on-click-modal="false"
    >
      <div
        class="padding-top-30 padding-right-10 padding-left-10"
        v-loading="loading"
      >
        <span class="flex-center title">
          {{
            `${t(
              'pleaseCompleteTheOperationWithinTheSpecifiedTime'
            )} ${displayTime}`
          }}
        </span>
        <el-form
          :model="updatePassWordForm"
          label-width="0"
          ref="updatePassWordFormRef"
        >
          <el-row
            type="flex"
            justify="center"
          >
            <el-col :span="24">
              <el-form-item
                label=""
                prop="oldPassword"
                :rules="[
                  {
                    required: true,
                    message: t('pleaseInput') + t('user.oldPassword'),
                    trigger: 'blur'
                  }
                ]"
              >
                <el-input
                  v-model="updatePassWordForm.oldPassword"
                  type="password"
                  show-password
                  clearable
                  :placeholder="t('pleaseInput') + t('user.oldPassword')"
                  size="large"
                />
              </el-form-item>
            </el-col>
            <el-col :span="24">
              <el-form-item
                label=""
                prop="newPassword"
                :rules="[
                  {
                    required: true,
                    message: t('pleaseInput') + t('user.newPassword'),
                    trigger: 'blur'
                  },
                  {
                    validator: validateNewPassword
                  }
                ]"
              >
                <el-input
                  v-model="updatePassWordForm.newPassword"
                  type="password"
                  show-password
                  clearable
                  :placeholder="
                    t('pleaseInput') +
                    t('user.newPassword') +
                    ',' +
                    t('passwordFormat')
                  "
                  size="large"
                />
              </el-form-item>
            </el-col>
            <el-col :span="24">
              <el-form-item
                label=""
                prop="repeatNewPassword"
                :rules="[
                  {
                    required: true,
                    message: t('pleaseInput') + t('user.repeatNewPassword'),
                    trigger: 'blur'
                  },
                  {
                    validator: validateRepeatPassword
                  }
                ]"
              >
                <el-input
                  v-model="updatePassWordForm.repeatNewPassword"
                  type="password"
                  show-password
                  clearable
                  :placeholder="
                    t('pleaseInput') +
                    t('user.repeatNewPassword') +
                    ',' +
                    t('passwordFormat')
                  "
                  size="large"
                />
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>
      <template #footer>
        <el-button
          @click="isShow = false"
          icon="Close"
        >
          {{ t('cancel') }}
        </el-button>
        <el-button
          type="primary"
          @click="handleSubmit"
          icon="Check"
        >
          {{ t('edit') }}
        </el-button>
      </template>
    </el-dialog>
  </div>
</template>

<style scoped lang="scss">
.title {
  font-size: 16px;
  font-weight: bold;
  color: var(--el-text-color-primary);
  margin-bottom: 18px;
}
</style>
