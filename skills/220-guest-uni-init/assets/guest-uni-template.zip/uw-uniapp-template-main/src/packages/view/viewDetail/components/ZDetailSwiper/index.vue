<!--顶部产品轮播图-->
<script lang="ts" setup>
import { onMounted } from 'vue'

withDefaults(
  defineProps<{
    covers?: string[] // 数量
  }>(),
  {
    covers: () => []
  }
)
const emits = defineEmits<{
  (e: 'click', item: any): void
}>()
const handleClick = (item: any) => {
  emits('click', item)
}

// const state = reactive({
//   // covers: [
//   //   'https://cdn.pixabay.com/photo/2016/02/10/16/37/cat-1192026_1280.jpg',
//   //   'https://cdn.pixabay.com/photo/2023/06/29/12/28/cats-8096304_1280.jpg',
//   //   'https://qyb.jihainet.com/static/uploads/images/2021/02/20/d1db83a7c389fdffd9cdc4c1cf955feb.png'
//   // ] as any[],
//   video_url:
//     'https://qyb.jihainet.com/static/uploads/images/2021/02/20/d1db83a7c389fdffd9cdc4c1cf955feb.png'
// })

onMounted(() => {
  // console.log('xxx Com ---')
})
</script>

<template>
  <view class="rf-product-detail__carousel">
    <!-- <view class="video-wrapper">
      <video
        :poster="state.video_url"
        :src="state.video_url"
        object-fit="contain"
      />
    </view> -->
    <swiper
      class="swiper"
      :indicator-dots="false"
      :circular="true"
      controls
    >
      <swiper-item
        class="swiper-item"
        v-for="(item, index) in covers"
        :key="index"
        @click="handleClick(item)"
      >
        <img
          class="image"
          :style="{
            width: '750rpx',
            height: '100%'
          }"
          :src="item"
          lazy-load
          mode="aspectFill"
        />
        <view class="swiper-item-tag flex-align-items font-sm">
          {{ `${index + 1} / ${covers.length}` }}
        </view>
      </swiper-item>
    </swiper>
  </view>
</template>

<style lang="scss" scoped>
.rf-product-detail {
  position: relative;
  padding-bottom: calc(env(safe-area-inset-bottom) / 2 + 40rpx);
  /* 商品轮播图 */
  &__carousel {
    height: 450rpx;
    position: relative;
    .video-wrapper {
      width: 100%;
      height: 100%;
      video {
        width: 100%;
        height: 100%;
      }
    }
    .swiper {
      height: 100%;
      .swiper-item {
        .swiper-item-tag {
          position: absolute;
          right: 20rpx;
          bottom: 20rpx;
          background-color: rgba(0, 0, 0, 0.4);
          padding: 6rpx 16rpx;
          color: #fff;
          border-radius: 28rpx;
          transform: scale(0.8);
        }
      }
    }
  }
}
</style>
