<template>
  <!-- 未开发 -->
  <view class="container">
    <view class="grid-container">
      <p
        v-for="(item, index) in addressList"
        :key="index"
        class="tab-item"
        :class="{
          active: item.path === addressName
        }"
        :style="{
          backgroundColor:
            item.path === addressName ? props.primaryColor : '#FFF',
          color: item.path === addressName ? '#FFF' : props.primaryColor
        }"
        @click="clickAddress(item)"
      >
        <template v-if="!item.name">
          <svg
            t="1750992568735"
            class="icon"
            viewBox="0 0 1024 1024"
            version="1.1"
            xmlns="http://www.w3.org/2000/svg"
            p-id="5111"
            xmlns:xlink="http://www.w3.org/1999/xlink"
            width="25"
            height="26"
          >
            <path
              d="M946.5 505L560.1 118.8l-25.9-25.9c-12.3-12.2-32.1-12.2-44.4 0L77.5 505c-12.3 12.3-18.9 28.6-18.8 46 0.4 35.2 29.7 63.3 64.9 63.3h42.5V940h691.8V614.3h43.4c17.1 0 33.2-6.7 45.3-18.8 12.1-12.1 18.7-28.2 18.7-45.3 0-17-6.7-33.1-18.8-45.2zM568 868H456V664h112v204z m217.9-325.7V868H632V640c0-22.1-17.9-40-40-40H432c-22.1 0-40 17.9-40 40v228H238.1V542.3h-96l370-369.7 23.1 23.1L882 542.3h-96.1z"
              p-id="5112"
              :fill="item.path === addressName ? '#FFF' : props.primaryColor"
            ></path>
          </svg>
        </template>
        <text v-else>{{ item.name }}</text>
      </p>
    </view>
  </view>
</template>

<script setup lang="ts">
import { ref } from 'vue'

const props = defineProps({
  primaryColor: {
    type: String,
    default: '#b9995c'
  }
})

const addressList = ref([
  { path: 'home', name: '' },
  { path: 'guangzhou', name: '广州' },
  { path: 'zhuhai', name: '珠海' },
  { path: 'qingyuan', name: '清远' }
])

const addressName = ref('home')

const clickAddress = (item: any) => {
  addressName.value = item.path
}
</script>

<style scoped>
.container {
  display: flex;
  width: 100%;
  align-items: center;
  justify-content: center;
  /* padding-left: 10px; */
  /* padding-right: 10px; */
}

.grid-container {
  display: grid;
  width: 100%;
  height: 80rpx;
  grid-template-columns: repeat(4, 1fr);
  gap: 16rpx;
  background-color: rgba(255, 255, 255, 0.59);
  padding: 12rpx;
  border-radius: 100rpx;
}

.tab-item {
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 50%;
  font-family: 'Bold', sans-serif;
  font-weight: 700;
  cursor: pointer;
  transition: all 0.3s ease;
}

.tab-item.small {
  border-radius: 100rpx;
  font-size: 28rpx;
}

.tab-item:not(.small) {
  border-radius: 150rpx;
  font-size: 32rpx;
}

/* .tab-item.active {
  background-color: #b9995c;
  color: #fff;
}

.tab-item:not(.active) {
  background-color: white;
  color: #b9995c;
} */

.tab-icon {
  height: 50rpx;
  width: 54rpx;
}
</style>
