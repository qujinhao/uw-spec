// import koLocale from 'element-plus/lib/locale/lang/ko'
import koLocale from 'element-plus/dist/locale/ko.mjs'

// 自动导入当前文件夹的所有文件下多语言包
const twCN = import.meta.glob(['./*', '!./index', '!./type.d.ts'], {
  import: 'default',
  eager: true
})

let i18nKo = {
  ...koLocale
}

for (const key in twCN) {
  if (Object.hasOwn(twCN, key)) {
    const item = twCN[key]
    i18nKo = Object.assign(i18nKo, item)
  }
}
export default i18nKo
