import request from '@/utils/request'
import { ResponseData, DataList, ESDataList } from './uwAuthCenterAuthApi'

//修改当前商户
export const mchMchInfoUpdate = (
  data: SaasMchInfo,
  params: {
    remark: string // 备注
  }
): Promise<ResponseData<void>> => {
  return request('/saas-base-app/mch/mch/info/update', {
    method: 'PUT',
    data,
    params
  })
}
//通知上传成功
export const mchCommonOssUploadSuccess = (params: {
  configSid?: string // 配置id
  id: number // 文件id
  filePath: string // 文件名
}): Promise<ResponseData<SysOssFile>> => {
  return request('/saas-base-app/mch/common/oss/uploadSuccess', {
    method: 'PUT',
    params
  })
}
//更新refId
export const mchCommonOssUpdateRefId = (params: {
  id: number // 文件id
  filePath: string // 文件名
  refId: string // 文件refId
}): Promise<ResponseData<SysOssFile>> => {
  return request('/saas-base-app/mch/common/oss/updateRefId', {
    method: 'PUT',
    params
  })
}
//解除链接
export const mchCommonOssUnlink = (params: {
  id: number // 文件id
  filePath: string // 文件名
}): Promise<ResponseData<SysOssFile>> => {
  return request('/saas-base-app/mch/common/oss/unlink', {
    method: 'PUT',
    params
  })
}
//链接文件
export const mchCommonOssLink = (params: {
  id: number // 要链接的文件id
  filePath: string // 文件名
  refType: string // 关联的表名
  refId: string // 关联表的id
}): Promise<ResponseData<SysOssFile>> => {
  return request('/saas-base-app/mch/common/oss/link', {
    method: 'PUT',
    params
  })
}
//新增资质
export const mchMchCertSave = (
  data: SaasMchCert
): Promise<ResponseData<SaasMchCert>> => {
  return request('/saas-base-app/mch/mch/cert/save', {
    method: 'POST',
    data
  })
}
//获取我的商户信息
export const mchMchInfoLoad = (): Promise<ResponseData<SaasMchInfo>> => {
  return request('/saas-base-app/mch/mch/info/load', {
    method: 'GET'
  })
}
//资质列表
export const mchMchCertList = (
  params: SaasMchCertQueryParam
): Promise<ResponseData<DataList<SaasMchCert>>> => {
  return request('/saas-base-app/mch/mch/cert/list', {
    method: 'GET',
    params
  })
}
//文件列表
export const mchCommonOssList = (
  params: SysOssFileQueryParam
): Promise<ResponseData<DataList<SysOssFile>>> => {
  return request('/saas-base-app/mch/common/oss/list', {
    method: 'GET',
    params
  })
}
//生成上传参数
export const mchCommonOssGenUploadParam = (params: {
  configSid?: string // 配置id
  refType: string // 关联类型
  refId: string // 关联ID
  fileName: string // 文件名
  fileSize: number // 文件大小
  accessType?: number // 访问类型。0，公共文件；1.隐私文件
  expireDate?: string // 文件过期时间
}): Promise<ResponseData<OssUploadParam>> => {
  return request('/saas-base-app/mch/common/oss/genUploadParam', {
    method: 'GET',
    params
  })
}
//删除资质
export const mchMchCertDelete = (params: {
  id: number // 主键ID
  remark: string // 备注
}): Promise<ResponseData<void>> => {
  return request('/saas-base-app/mch/mch/cert/delete', {
    method: 'DELETE',
    params
  })
}

//商户信息
export interface SaasMchInfo {
  id?: number //主键ID
  saasId?: number //运营商编号
  mchType?: number //商户类型 1-供应商 2-分销商
  bdId?: number //关联业务员ID
  parentId?: number //上级ID
  agentId?: number //合伙人编号
  mchName?: string //商户名称
  mchLang?: string //语种类型
  mchCurrency?: string //货币类型
  gradeLevel?: number //商户等级Id
  contactName?: string //商户联系人
  contactPhone?: string //商户联系电话
  contactMobile?: string //商户联系手机
  contactEmail?: string //商户联系邮箱
  contactAddress?: string //公司地址
  mchDesc?: string //商户介绍
  mchConfig?: string //商户资源
  statsOrder?: number //总订单量
  statsMoney?: number //总订单金额
  statsProduct?: number //总销售量
  createDate?: string //创建时间
  modifyDate?: string //修改时间
  state?: number //状态
}
//系统存储文件
export interface SysOssFile {
  id?: number //主键
  parentId?: number //父级ID
  saasId?: number //saas id
  mchId?: number //商户id
  configId?: number //配置id
  accessType?: number //访问类型
  fileInfo?: string //文件信息
  filePath?: string //文件路径
  fileType?: string //文件后缀
  fileSize?: number //文件大小
  fileHash?: string //文件hash
  refType?: string //关联表名
  refId?: string //关联表的id
  linkNum?: number //链接计数
  userId?: number //userId
  userInfo?: string //用户名
  userIp?: string //用户IP
  userType?: number //用户类型
  requestDate?: string //请求日期
  uploadDate?: string //上传日期
  expireDate?: string //过期日期
  lastUpdate?: string //更新时间
  state?: number //状态
}
//商户证件信息
export interface SaasMchCert {
  id?: number //主键ID
  saasId?: number //运营商编号
  mchId?: number //商户编号
  certType?: string //证书类型
  certId?: string //证书编码
  certInfo?: string //证书信息
  certImg?: string //证书照片
  accessType?: number //访问类型
  startDate?: string //有效期开始时间
  endDate?: string //有效期结束时间
  createDate?: string //创建时间
  modifyDate?: string //修改日期
  auditState?: number //审批状态
  auditUserId?: number //审批人ID
  auditUserInfo?: string //审批人信息
  auditRemark?: string //审批信息
  auditDate?: string //审核时间
  state?: number //状态
}
//商户证件信息列表查询参数
export interface SaasMchCertQueryParam {
  mchId?: number //商户编号
  id?: number //主键ID
  ids?: Array<number> //ID数组
  certType?: string //证书类型
  certId?: string //证书编码
  certInfo?: string //证书信息
  certImg?: string //证书照片
  accessType?: number //访问类型
  startDateRange?: Array<string> //有效期开始时间范围
  endDateRange?: Array<string> //有效期结束时间范围
  createDateRange?: Array<string> //创建时间范围
  modifyDateRange?: Array<string> //修改日期范围
  auditState?: number //审批状态
  auditUserId?: number //审批人ID
  auditUserInfo?: string //审批人信息
  auditRemark?: string //审批信息
  auditDateRange?: Array<string> //审核时间范围
  state?: number //状态
  states?: Array<number> //状态数组
  stateGte?: number //大于等于状态
  stateLte?: number //小于等于状态
  $pg?: number //当前页码
  $rn?: number //每页条数
  $si?: number //起始位置
  $rt?: number //请求类型
  $sn?: Array<string> //排序名称
  $st?: Array<number> //排序名称
}
//系统存储文件列表查询参数
export interface SysOssFileQueryParam {
  mchId?: number //商户id
  userId?: number //userId
  userType?: number //用户类型
  id?: number //主键
  ids?: Array<number> //ID数组
  parentId?: number //父级ID
  configId?: number //配置id
  accessType?: number //访问类型
  fileInfo?: string //文件信息
  filePath?: string //文件路径
  fileType?: string //文件后缀
  fileSize?: number //文件大小
  fileSizeRange?: Array<number> //文件大小范围
  fileHash?: string //文件hash
  refType?: string //关联表名
  refId?: string //关联表的id
  linkNum?: number //链接计数
  linkNumRange?: Array<number> //链接计数范围
  userInfo?: string //用户名
  userIp?: string //用户IP
  requestDateRange?: Array<string> //请求日期范围
  uploadDateRange?: Array<string> //上传日期范围
  expireDateRange?: Array<string> //过期日期范围
  lastUpdateRange?: Array<string> //更新时间范围
  state?: number //状态
  states?: Array<number> //状态数组
  stateGte?: number //大于等于状态
  stateLte?: number //小于等于状态
  $pg?: number //当前页码
  $rn?: number //每页条数
  $si?: number //起始位置
  $rt?: number //请求类型
  $sn?: Array<string> //排序名称
  $st?: Array<number> //排序名称
}
//预签名返回参数
export interface OssUploadParam {
  id?: number //文件ID
  key?: string //文件名
  ossHost?: string //上传主机
  uploadParam?: Record<string, string> //上传参数
}
