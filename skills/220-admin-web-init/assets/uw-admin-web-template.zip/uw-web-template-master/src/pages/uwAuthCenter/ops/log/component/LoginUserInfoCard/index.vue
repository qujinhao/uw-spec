<script lang="ts" setup>
import { computed } from 'vue'

interface DataType {
  saasId?: number
  mchId?: number
  userId?: number
  groupId?: number
  userName?: string
  nickName?: string
  realName?: string
}
const props = withDefaults(
  defineProps<{
    data: DataType
  }>(),
  {}
)

// 头像名称
const headSculptureName = computed(() => {
  return props.data.userName
})
</script>

<template>
  <div class="saasInfo-wrapper">
    <el-row :gutter="10">
      <el-col
        :span="8"
        style="display: flex; justify-content: center; align-items: center"
      >
        <div class="no-image flex-center align-center">
          <span>{{ headSculptureName?.charAt(0).toLocaleUpperCase() }}</span>
        </div>
      </el-col>
      <el-col :span="16">
        <div class="item-right">
          <div
            class="realName"
            v-if="props.data.nickName"
          >
            {{ props.data.nickName }}
          </div>
          <div class="userId">
            saasId：{{ props.data.saasId }}&nbsp;&nbsp;&nbsp;商户ID：{{
              props.data.mchId
            }}
          </div>
          <div class="userId">
            ID：{{ props.data.userId }}&nbsp;&nbsp;&nbsp;组 ID：{{
              props.data.groupId
            }}
          </div>
          <!-- <div class="userType">
            <p>昵称：{{ props.data.nickName ? props.data.nickName : '--' }}</p>
          </div> -->
        </div>
      </el-col>
    </el-row>
  </div>
</template>

<style lang="scss" scoped>
.saasInfo-wrapper {
  width: 100%;
  overflow: hidden;

  .no-image {
    width: 100px;
    height: 100px;
    span {
      display: inline;
      width: 100%;
      color: #fff;
      font-size: 36px;
      font-weight: 500;
      background-color: #46d6d2;
      color: #fff;
      text-align: center;
      line-height: 100px;
      border-radius: 16px;
    }
  }
  .item-right {
    display: flex;
    flex-direction: column;
    justify-content: space-around;
    height: 100px;

    .realName {
      font-size: 16px;
      font-weight: 600;
      color: var(--el-text-color-primary);
    }

    .userType,
    .userId {
      font-size: 14px;
    }
  }
}
</style>
