/**
 * Token 管理模块
 * 用于解耦 request 和 store 之间的循环依赖
 * 提供获取和监听 token 变化的能力
 */

import { getAuthToken } from '@/utils/auth'

// Token 状态（内部使用，不直接暴露）
let currentToken: string = ''
let currentRefreshToken: string = ''
let currentSaasId: number = 0

// 订阅者列表（用于 token 刷新后通知）
type TokenChangeCallback = () => void
const tokenChangeCallbacks: TokenChangeCallback[] = []

/**
 * 获取当前 token
 * 优先从内存获取，如果没有则从 sessionStorage 获取
 */
export function getToken(): string {
  if (currentToken) {
    return currentToken
  }
  // 从 sessionStorage 获取（外部传入的 token）
  const outsideToken = getAuthToken()
  if (outsideToken) {
    return outsideToken
  }
  // 返回匿名 token
  return `0$1!0@${currentSaasId || 0}`
}

/**
 * 获取当前 refreshToken
 */
export function getRefreshToken(): string {
  return currentRefreshToken
}

/**
 * 获取当前 saasId
 */
export function getSaasId(): number {
  return currentSaasId
}

/**
 * 设置 token 信息
 * 由 store 在用户登录或刷新 token 时调用
 */
export function setTokenInfo(info: {
  token?: string
  refreshToken?: string
  saasId?: number
}) {
  if (info.token !== undefined) {
    currentToken = info.token
  }
  if (info.refreshToken !== undefined) {
    currentRefreshToken = info.refreshToken
  }
  if (info.saasId !== undefined) {
    currentSaasId = info.saasId
  }
}

/**
 * 清除 token 信息
 * 由 store 在用户退出登录时调用
 */
export function clearTokenInfo() {
  currentToken = ''
  currentRefreshToken = ''
  currentSaasId = 0
}

/**
 * 订阅 token 变化事件
 * 用于 token 刷新后重新发送请求
 */
export function onTokenChange(callback: TokenChangeCallback): () => void {
  tokenChangeCallbacks.push(callback)
  // 返回取消订阅函数
  return () => {
    const index = tokenChangeCallbacks.indexOf(callback)
    if (index > -1) {
      tokenChangeCallbacks.splice(index, 1)
    }
  }
}

/**
 * 触发 token 变化事件
 * 由 store 在 token 刷新后调用
 */
export function notifyTokenChange() {
  tokenChangeCallbacks.forEach((callback) => callback())
}

/**
 * 获取登录代理标识
 * 用于 refreshToken 请求
 */
export function getLoginAgent(): string {
  // 动态获取，避免在模块加载时计算
  try {
    const { name, version } = import.meta.glob('../../package.json', {
      eager: true
    })['../../package.json'] as { name: string; version: string }
    return `${name}:${version}`
  } catch {
    return 'app:1.0.0'
  }
}
