<script lang="ts" setup>
import { onMounted } from 'vue'

const props = withDefaults(
  defineProps<{
    title: string // 标题
    titleSize?: string // 标题字体大小
    titleColor?: string // 标题颜色
    fontWeight?: string // 字体加粗
    align?: string // 对齐方式
    isShowMore?: boolean // 是否显示更多
    moreLabel?: string // 更多按钮的名称
    padding?: string // // 内边距
    backgroundColor?: string // 背景
  }>(),
  {
    title: '标题',
    titleSize: '16px',
    titleColor: '',
    fontWeight: '600',
    align: 'flex-end',
    isShowMore: false,
    moreLabel: '更多商品',
    padding: '15px',
    backgroundColor: ''
  }
)

const emits = defineEmits<{
  (e: 'clickMore'): void
}>()

const handleClick = (item: any) => {
  console.log('child-click', item)
  emits('clickMore')
}

onMounted(() => {
  // console.log('动态 ---')
})
</script>

<template>
  <view
    class="slot"
    :style="{
      padding: props.padding,
      backgroundColor: props.backgroundColor,
      alignItems: props.align
    }"
  >
    <view
      class="name"
      :style="{
        fontSize: props.titleSize,
        fontWeight: props.fontWeight,
        color: props.titleColor
      }"
    >
      {{ props.title }}
    </view>
    <view
      class="more"
      v-if="isShowMore"
      @click="handleClick"
    >
      {{ props.moreLabel }} >
    </view>
    <!-- 自定义右侧占位 -->
    <view
      class="more"
      v-else
    >
      <slot></slot>
    </view>
  </view>
</template>

<style lang="scss" scoped>
.slot {
  display: flex;
  justify-content: space-between;
  .name {
    color: #333333;
  }
  .more {
    display: flex;
    align-items: center;
    color: #333333;
    font-size: 12px;
  }
}
</style>
