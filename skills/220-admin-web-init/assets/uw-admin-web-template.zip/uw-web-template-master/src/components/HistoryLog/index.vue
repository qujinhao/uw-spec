<script setup lang="ts">
import { useCommonSelectTypes } from '@/utils/selectOptions'
import { ResponseData, DataList } from '@/api/uwAuthCenterAuthApi'
import { useI18n } from 'vue-i18n'
import { commonType } from '@/types'

//系统数据历史
interface SysDataHistory {
  id?: number //ID
  saasId?: number //saasId
  mchId?: number //商户ID
  userId?: number //用户ID
  userType?: number //用户类型
  groupId?: number //用户的组ID
  userName?: string //用户名称
  nickName?: string //用户昵称
  realName?: string //真实名称
  entityClass?: string //实体类
  entityId?: string //实体ID
  entityName?: string //实体名
  entityData?: string //实体数据
  entityUpdateInfo?: string //实体修改信息
  remark?: string //备注信息
  userIp?: string //用户IP
  createDate?: string //创建日期
}

//系统数据历史列表查询参数
interface SysDataHistoryQueryParam {
  mchId?: number //商户ID
  userId?: number //用户ID
  userType?: number //用户类型
  id?: number //ID
  ids?: Array<number> //数组ID
  groupId?: number //用户的组ID
  userName?: string //用户名称
  nickName?: string //用户昵称
  realName?: string //真实名称
  entityClass?: string //实体类
  entityId?: string //实体ID
  entityName?: string //实体名
  userIp?: string //用户IP
  createDateRange?: Array<string> //创建日期范围
  $pg?: number //当前页码
  $rn?: number //每页条数
  $si?: number //起始位置
  $rt?: number //请求类型
  $sn?: Array<string> //排序名称
  $st?: Array<number> //排序名称
}

interface historyLogType {
  showDetail: boolean // 显示更改详情的弹窗变量
  detailDialogForm: Record<string, any> // 示更改详情的弹窗表单
  dialogType: number
  dialogTitle: string
  width?: string // 弹窗宽度
  queryHistory: (
    item: SysDataHistoryQueryParam
  ) => Promise<ResponseData<DataList<SysDataHistory>>> // 请求的接口  :xxx="xxx(item: OpsDataHistoryQueryParam))"
  showPage?: boolean // 是否显示分页
  handleDetailCallback?: (id: number, item: string) => void
}

// 传入的props
const props = withDefaults(defineProps<historyLogType>(), {
  width: '800px',
  showPage: false
})

const emits = defineEmits<{
  (e: 'update:showDetail', val: boolean): void
  (e: 'update:detailDialogForm', val: Record<string, any>): void
  (e: 'update:dialogType', val: number): void
  (e: 'update:dialogTitle', val: string): void
}>()

const { t } = useI18n()

// 显示更改的详情与否
const showDetail = computed({
  get() {
    return props.showDetail
  },
  set(val) {
    emits('update:showDetail', val)
  }
})

// 更改详情的表单
const detailDialogForm = computed({
  get() {
    return props.detailDialogForm
  },
  set(val) {
    emits('update:detailDialogForm', val)
  }
})

// 更改的类型
const dialogType = computed({
  get() {
    return props.dialogType
  },
  set(val) {
    emits('update:dialogType', val)
  }
})

// 更改的标题
const dialogTitle = computed({
  get() {
    return props.dialogTitle
  },
  set(val) {
    emits('update:dialogTitle', val)
  }
})

// 是否显示
const isShow = ref(false)
const { userTypes } = useCommonSelectTypes()

// 表格数据
const historyData = ref<SysDataHistory[]>([])
const params = ref<SysDataHistoryQueryParam>({
  $pg: 1,
  $rn: 10,
  $rt: 2,
  $st: [2],
  $sn: ['id']
})
const tableSizeAll = ref(0)
const historyLoading = ref(false)

// 获取表格数据
const getHistoryList = () => {
  historyLoading.value = true
  // 是否显示分页，显示分页则默认取10，不显示默认取100
  if (props.showPage) {
    params.value.$rn = 10
  } else {
    params.value.$rn = 100
  }
  props
    .queryHistory(params.value)
    .then(res => {
      historyData.value = res.data?.results || []
      tableSizeAll.value = res.data?.sizeAll || 0
      historyLoading.value = false
    })
    .catch(() => {
      historyLoading.value = false
    })
}

// 关闭重置相关变量
const resetForm = () => {
  historyData.value = []
  params.value = {
    $pg: 1,
    $rn: 10,
    $rt: 2,
    $st: [2],
    $sn: ['id']
  }
}

// 历史记录弹窗标题
const historyTitle = ref('')

// 历史查看
const handleReplaceDetail = (id: number, item: string) => {
  if (props.handleDetailCallback) {
    props.handleDetailCallback(id, item)
  } else {
    const data = JSON.parse(item)
    Object.keys(data).forEach(key => {
      detailDialogForm.value[key] = data[key]
    })

    dialogTitle.value = `查看详情#${detailDialogForm.value.id}`
    nextTick(() => {
      dialogType.value = 2
      showDetail.value = true
    })
  }
}

// 打开查看历史弹窗
const openHistoryLog = (entityId: string | number) => {
  isShow.value = true
  params.value.entityId = String(entityId)
  historyTitle.value = `历史记录#${entityId}`
  params.value.$rt = 2
  getHistoryList()
}

// 关闭查看历史弹窗
const closeHistoryLog = () => {
  isShow.value = false
  resetForm()
}

// 表格数据处理
const handleTableType = (
  data: string | number,
  findList: commonType[]
): string => {
  const target = findList.find(item => item.value === data)
  if (target) {
    return target.label
  }
  return ''
}

// 实体类显示
const handleShowTip = (row: SysDataHistory) => {
  if (row.entityId) {
    return row.entityClass + (row.entityId ? ':' + row.entityId : '')
  }
  return row.entityClass || '--'
}

defineExpose({
  openHistoryLog,
  closeHistoryLog
})
</script>

<template>
  <div class="historyDetail">
    <el-dialog
      v-model="isShow"
      :title="historyTitle"
      @close="closeHistoryLog"
      :width="props.width"
      draggable
      :close-on-click-modal="false"
    >
      <el-table
        border
        :style="{ width: '100%' }"
        :header-cell-style="{
          backgroundColor: 'var(--el-color-info-light-9)'
        }"
        :data="historyData"
        v-loading="historyLoading"
      >
        <el-table-column
          prop="id"
          label="ID"
          align="center"
          fixed="left"
          minWidth="60"
        ></el-table-column>
        <el-table-column
          prop="entityId"
          :label="t('saasBaseAppExtend.SysDataHistory.entityId')"
          align="center"
          minWidth="100"
        ></el-table-column>
        <el-table-column
          prop="saasId"
          :label="t('user.saasId')"
          align="center"
          fixed="left"
          minWidth="100"
        ></el-table-column>
        <el-table-column
          prop="userId"
          label="用户ID"
          align="center"
          fixed="left"
          minWidth="100"
        ></el-table-column>
        <el-table-column
          prop="userName"
          :label="t('user.username')"
          align="center"
          minWidth="120"
        ></el-table-column>
        <el-table-column
          prop="userType"
          :label="t('user.userType')"
          align="center"
          minWidth="120"
        >
          <template #default="scope">
            <span>{{ handleTableType(scope.row.userType, userTypes) }}</span>
          </template>
        </el-table-column>
        <el-table-column
          prop="userIp"
          :label="t('saasBaseAppExtend.SysDataHistory.userIp')"
          align="center"
          minWidth="120"
        ></el-table-column>
        <el-table-column
          prop="entityName"
          :label="t('saasBaseAppExtend.SysDataHistory.entityName')"
          align="center"
          minWidth="120"
        >
          <template #default="{ row }">
            <el-tooltip
              class="box-item"
              effect="dark"
              :content="handleShowTip(row)"
              placement="bottom"
              trigger="click"
            >
              <el-link
                underline="never"
                :type="row.entityClass ? 'primary' : 'default'"
              >
                {{ row.entityName }}
              </el-link>
            </el-tooltip>
          </template>
        </el-table-column>
        <el-table-column
          prop="remark"
          :label="t('saasBaseAppExtend.SysDataHistory.remark')"
          align="center"
          minWidth="150"
        ></el-table-column>
        <el-table-column
          prop="entityData"
          :label="t('saasBaseAppExtend.SysDataHistory.entityData')"
          align="center"
          minWidth="150"
        >
          <template #default="scope">
            <el-link
              type="primary"
              @click="
                handleReplaceDetail(
                  scope.row.id,
                  scope.row.entityData as string
                )
              "
            >
              {{ t('saasBaseAppExtend.SysDataHistory.replacementDetails') }}
            </el-link>
          </template>
        </el-table-column>
      </el-table>
      <Pagination
        v-show="props.showPage"
        v-model:page-size="params.$rn"
        @page-size-change="getHistoryList"
        :total="tableSizeAll"
        v-model:current-page="params.$pg"
        @current-change="getHistoryList"
      />
    </el-dialog>
  </div>
</template>

<style scoped lang="scss">
.historyDetail {
  :deep(.el-dialog__body) {
    height: 500px;
    overflow: auto;
  }
}
</style>
