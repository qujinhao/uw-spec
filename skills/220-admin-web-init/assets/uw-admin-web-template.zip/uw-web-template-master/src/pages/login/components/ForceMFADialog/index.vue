<script setup lang="ts">
import { useI18n } from 'vue-i18n'
import {
  ElMessage,
  type FormInstance,
  type TabsPaneContext
} from 'element-plus'
import {
  userMfaVerify,
  userMfaTypes,
  userSendDeviceCode
} from '@/api/uwAuthCenterUserApi'
import { useMainStore } from '@/store/main'
import { EnumStruct, TokenResponse } from '@/api/uwAuthCenterAuthApi'
import InputCode from '@/pages/login/components/InputCode/index.vue'

const { t } = useI18n()
const props = defineProps<{
  modelValue: boolean
  captchaId?: string
  captchaSign?: string
}>()

const emits = defineEmits<{
  (e: 'update:modelValue', val: boolean): void
  (e: 'login', val: TokenResponse): void
}>()

// 是否显示
const isShow = computed({
  get() {
    return props.modelValue
  },
  set(val) {
    emits('update:modelValue', val)
  }
})
const mainStore = useMainStore()
const loading = ref(false)

// 关闭的回调
const closeCallback = () => {
  validateFormRef.value?.resetFields()
  mainStore.setLoginInfo({})
}

// 修改密码
const validateForm = ref<{
  loginAgent?: string // 登录代理
  mfaType?: number // mfa类型
  linkPhone?: string // 手机号
  linkEmail?: string // email
  linkPhoneByShow?: string // 展示用的手机号
  linkEmailByShow?: string // 展示用的邮箱
  mfaCodeArray?: string[]
}>({
  mfaCodeArray: ['', '', '', '', '', '']
})
// 表单
const validateFormRef = ref<FormInstance>()
const inputCodeRef = ref()

// 提交
const handleSubmit = () => {
  validateFormRef.value?.validate(valid => {
    if (valid) {
      const data = {
        loginAgent: mainStore.loginAgent,
        mfaType: activeName.value as number,
        mfaCode: splicingVerificationCode(
          validateForm.value.mfaCodeArray!
        ) as string
      }
      loading.value = true
      userMfaVerify(data)
        .then(res => {
          if (res.state === 'success') {
            ElMessage.success(t('MFAValidate') + t('success'))
            emits('login', res.data!)
          } else {
            inputCodeRef.value?.handleInputFocus(0)
            validateForm.value.mfaCodeArray = ['', '', '', '', '', '']
            ElMessage.error(res.msg || t('MFAValidate') + t('error'))
          }
          loading.value = false
        })
        .catch(() => {
          loading.value = false
        })
    }
  })
}

// 获取验证码是否禁用
const disabledGetCodeBtn = computed(() => {
  const reg1 =
    /^(13[0-9]|14[01456879]|15[0-35-9]|16[2567]|17[0-8]|18[0-9]|19[0-35-9])\d{8}$/
  const reg2 = /^\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/
  if (activeName.value === 23) {
    return !(
      !!validateForm.value.linkPhone && reg1.test(validateForm.value.linkPhone)
    )
  } else if (activeName.value === 22) {
    return !(
      !!validateForm.value.linkEmail && reg2.test(validateForm.value.linkEmail)
    )
  }
  return true
})

// 校验code
const validateCode = (rule: any, value: string, callback: any) => {
  if (validateForm.value.mfaCodeArray) {
    if (
      validateForm.value.mfaCodeArray?.length === 6 &&
      validateForm.value.mfaCodeArray.every(item => item)
    ) {
      callback()
    } else {
      callback(new Error(t('pleaseInput') + t('validateCode')))
    }
  } else {
    callback(new Error(t('pleaseInput') + t('validateCode')))
  }
}

// 获取MFA类型
const mfaTypes = shallowRef<EnumStruct[]>([])
const getMFATypes = () => {
  userMfaTypes()
    .then(res => {
      // 过滤去除恢复码登录的情况
      mfaTypes.value = res.data?.filter(item => item.value !== 20) || []
      // 查找目标元素索引
      const targetIndex = mfaTypes.value.findIndex(item => item.value === 21)
      // 执行元素移动操作
      if (targetIndex > 0) {
        const [targetItem] = mfaTypes.value.splice(targetIndex, 1)
        mfaTypes.value.unshift(targetItem)
      }
      // 去除登录二字
      mfaTypes.value.forEach(item => {
        item.label = item.label!.replace('登录', '')
      })
    })
    .catch(() => {
      mfaTypes.value = []
    })
}

// 拼接验证码
const splicingVerificationCode = (data: string[]) => {
  let result = ''
  for (const item of data) {
    result += item
  }
  return result
}

const countNum = ref<number>(60) //倒计时计数
const showGetCode = ref(true) //获取验证码按钮

let timer = 0
// 发送验证码
const toSendVerifyCode = () => {
  if (validateForm.value.linkPhone || validateForm.value.linkEmail) {
    const data = {
      mfaType: activeName.value as number,
      deviceId: '',
      captchaId: props.captchaId || '',
      captchaSign: props.captchaSign || ''
    }
    if (activeName.value === 23) {
      data.deviceId = validateForm.value.linkPhone!
    }
    if (activeName.value === 22) {
      data.deviceId = validateForm.value.linkEmail!
    }
    userSendDeviceCode(data).then(res => {
      if (res.state === 'success') {
        showGetCode.value = false
        timer = setInterval(() => {
          if (countNum.value > 0) {
            countNum.value = countNum.value - 1
          } else {
            countNum.value = 60
            clearInterval(timer)
            showGetCode.value = true
          }
        }, 1000)
        ElMessage.success(
          activeName.value === 23 ? t('smsCodeIsSend') : t('emailCodeIsSend')
        )
      } else {
        ElMessage.error(res.msg)
      }
    })
  }
}

// 当前激活页签
const activeName = ref(21) // 默认显示TOTP

// 点击页签
const handleClick = (pane: TabsPaneContext) => {
  validateFormRef.value?.resetFields()
  showGetCode.value = true
  countNum.value = 60
  timer && clearInterval(timer)
  if (pane.paneName === 21) {
    const timer = setTimeout(() => {
      inputCodeRef.value?.handleInputFocus(0)
      clearTimeout(timer)
    }, 0)
  }
}

// 验证码更新
const handleCodeChange = (code: Array<string>) => {
  if (code.length === 6 && code.every(item => item)) {
    handleSubmit()
  }
}

// 填充手机跟邮箱
const handleFillPhoneAndEmail = () => {
  if (mainStore.loginInfo.mobile) {
    // 真正发送的手机号
    validateForm.value.linkPhone = mainStore.loginInfo.mobile.replace('!', '')
    validateForm.value.linkPhoneByShow = maskPhone(
      mainStore.loginInfo.mobile.replace('!', '')
    )
  }

  if (mainStore.loginInfo.email) {
    // 真正发送的邮箱
    validateForm.value.linkEmail = mainStore.loginInfo.email.replace('!', '')
    validateForm.value.linkEmailByShow = maskEmail(
      mainStore.loginInfo.email.replace('!', '')
    )
  }
}

// 将手机号中间四位替换为*
const maskPhone = (phone: string) => {
  const cleaned = phone.replace(/\D/g, '') // 去除非数字字符
  if (cleaned.length !== 11) return phone // 检查长度是否为11位
  return `${cleaned.slice(0, 3)}****${cleaned.slice(-4)}`
}

// 将邮箱号中间四位替换为*
const maskEmail = (email: string) => {
  const parts = email.split('@')
  if (parts.length !== 2) return email // 检查邮箱格式是否合法
  const [localPart, domain] = parts
  const len = localPart.length
  if (len < 4) return `****@${domain}` // 本地部分不足4位时默认给四位
  const start = Math.floor((len - 4) / 2) // 计算中间四位的起始位置
  const masked = localPart.slice(0, start) + '****' + localPart.slice(start + 4)
  return masked + '@' + domain
}

watch(
  () => isShow.value,
  val => {
    if (val) {
      getMFATypes()
      activeName.value = 21
      const timer = setTimeout(() => {
        inputCodeRef.value?.handleInputFocus(0)
        clearTimeout(timer)
      }, 0)
      // 手机、邮箱号填充
      handleFillPhoneAndEmail()
    }
  }
)

onUnmounted(() => {
  timer && clearInterval(timer)
})
</script>

<template>
  <div>
    <el-dialog
      v-model="isShow"
      :title="t('MFAValidate')"
      @close="closeCallback"
      width="450px"
      draggable
      :close-on-click-modal="false"
    >
      <div
        v-loading="loading"
        style="padding: 0 10px"
      >
        <el-tabs
          v-model="activeName"
          type="card"
          @tab-click="handleClick"
          style="margin-bottom: 13px"
        >
          <el-tab-pane
            :label="item.label"
            :name="item.value"
            v-for="item in mfaTypes"
            :key="item.value"
          ></el-tab-pane>
        </el-tabs>
        <el-form
          :model="validateForm"
          label-width="0"
          ref="validateFormRef"
        >
          <el-row
            type="flex"
            justify="center"
          >
            <el-col
              :span="24"
              v-show="activeName === 23"
            >
              <el-form-item
                label=""
                prop="linkPhoneByShow"
              >
                <el-input
                  v-model="validateForm.linkPhoneByShow"
                  clearable
                  :placeholder="t('pleaseInput') + t('linkPhone')"
                  size="large"
                  style="width: 100%; flex: 1"
                  disabled
                />
                <el-button
                  type="success"
                  round
                  :disabled="disabledGetCodeBtn"
                  @click="toSendVerifyCode"
                  v-if="showGetCode"
                  class="margin-left-5"
                >
                  {{ t('getValidateCode') }}
                </el-button>
                <el-button
                  type="success"
                  round
                  :disabled="true"
                  v-else
                  class="margin-left-5"
                >
                  {{ `${t('getValidateCode')}(${countNum}s)` }}
                </el-button>
              </el-form-item>
            </el-col>
            <el-col
              :span="24"
              v-show="activeName === 22"
            >
              <el-form-item
                label=""
                prop="linkEmailByShow"
              >
                <el-input
                  v-model="validateForm.linkEmailByShow"
                  clearable
                  :placeholder="t('pleaseInput') + t('linkEmail')"
                  size="large"
                  style="width: 100%; flex: 1"
                  disabled
                />
                <el-button
                  type="success"
                  round
                  :disabled="disabledGetCodeBtn"
                  @click="toSendVerifyCode"
                  v-if="showGetCode"
                  class="margin-left-5"
                >
                  {{ t('getValidateCode') }}
                </el-button>
                <el-button
                  type="success"
                  round
                  :disabled="true"
                  v-else
                  class="margin-left-5"
                >
                  {{ `${t('getValidateCode')}(${countNum}s)` }}
                </el-button>
              </el-form-item>
            </el-col>
            <el-col :span="24">
              <el-form-item
                label=""
                prop="mfaCodeArray"
                :rules="[
                  {
                    required: true,
                    validator: validateCode,
                    trigger: 'blur'
                  }
                ]"
              >
                <InputCode
                  v-model="validateForm.mfaCodeArray"
                  @complete="handleCodeChange"
                  ref="inputCodeRef"
                ></InputCode>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>
      <template #footer>
        <div>
          <el-button
            @click="isShow = false"
            icon="Close"
          >
            {{ t('cancel') }}
          </el-button>
          <el-button
            type="primary"
            @click="handleSubmit"
            icon="Check"
            :disabled="loading"
          >
            {{ t('validate') }}
          </el-button>
        </div>
      </template>
    </el-dialog>
  </div>
</template>

<style scoped lang="scss">
:deep(.sms-code-container) {
  .input-group {
    padding: 0 !important;
    .input-element {
      border-width: 1px !important;
    }
  }
}

:deep(.el-dialog) {
  .el-dialog__footer {
    padding: 0px 20px 20px 0;
  }
}
</style>
