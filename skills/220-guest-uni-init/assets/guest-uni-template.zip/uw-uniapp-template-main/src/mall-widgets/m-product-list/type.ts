export interface Styles {
  cmpUpperPadding?: number // 上边距
  cmpLowerPadding?: number // 下边距
  radius?: number // 容器圆角
  salePriceSize?: number // 价格字体大小
  regionPosition?: string // 定位位置
  unitSize?: number // 价格单位大小
  titleSize?: number // 标题字体大小
  titleColor?: string // 标题颜色
  progressColor?: string // 进度条标题色
  progressBorderColor?: string // 进度条边线色
  progressBackgroundColor?: string // 进度条背景色
  progressStyle?: string // 进度条色
  salePriceColor?: string // 价格颜色
  backgroundColor?: string // 容器背景色
  cmpBackground?: string // 背景色
  width?: number | string // 宽度
  imgWidth?: number | string // 图片宽度
  imgHeight?: number // 图片高度
  titleRow?: number // 标题行数
  countDownType?: string // 倒计时类型
  countDownPosition?: string // 倒计时位置
  countDownBackground?: string // 倒计时背景色
  countDownRadius?: number // 倒计时圆角
  countDownFontSize?: number // 倒计时字体大小
  countDownColor?: string // 倒计时颜色
  countDownIcon?: string // 倒计时图标
  countIconWidth?: number // 倒计时图标宽度
  countIconHeight?: number // 倒计时图标高度
  regionFontSize?: number // 区域字体大小
  regionFontColor?: string // 区域字体颜色
  regionBackground?: string // 区域背景色
  regionIcon?: string // 区域图标
  regionIconWidth?: number // 区域图标宽度
  regionIconHeight?: number // 区域图标高度
  titleWeight?: string // 标题字体粗细
  priceDesShow?: boolean // 是否显示价格描述
  priceDes?: string // 价格描述
  priceDesSize?: number // 价格描述字体大小
  marketPriceShow?: boolean // 是否显示市场价
  marketPriceSize?: number // 市场价字体大小
  marketPriceColor?: string // 市场价颜色
  marketPriceWeight?: number | string // 市场价字体粗细
  marketPriceLine?: boolean // 市场价是否有删除线
  showProgressTitle?: boolean // 是否显示进度条标题
  progressWidth?: number | string // 进度条宽度
  progressHeight?: number // 进度条高度
  progressFontSize?: number // 进度条字体大小
  tagFontSize?: number[] // 标签字体大小
  tagColor?: string[] // 标签颜色
  tagTextColor?: string[] // 标签文字颜色
  dateSize?: number // 日期字体大小
  dateColor?: string // 日期颜色
  dateTagPositio?: string // 日期标签位置
  pricePosition?: string
}
export interface Attrs {
  typeStyle?:
    | 'rush'
    | 'rush-min'
    | 'reserve'
    | 'info'
    | 'info-default'
    | 'card'
    | 'card-min' // 类型样式
  typeUi?: 'B2B' | 'B2C' // UI类别
  lists?: Array<{
    img: string // 产品背景图
    currentTime: number // 当前时间戳
    orderStartDate: number // 抢购开始时间戳
    orderEndDate: number // 抢购结束时间戳
    areaName: string // 区域名称
    title: string // 抢购标题
    insuranceId?: string // 保险ID
    insuranceTitle?: string // 保险标题
    themes?: Array<{ themeName: string; themeId: string; color?: string }> // 主题数组
    salePrice?: number // 零售价
    minSalePrice?: number // 最小零售价
    price?: number // 分销价
    marketPrice?: number // 市场价
    brokerage?: number // 佣金
    progressBar?: number // 进度条百分比
    createDate?: number // 活动创建时间
    treeName?: string // 类目名称
    treeId?: number // 类目ID
  }>
  marketPriceShow?: boolean // 是否显示市场价
}
