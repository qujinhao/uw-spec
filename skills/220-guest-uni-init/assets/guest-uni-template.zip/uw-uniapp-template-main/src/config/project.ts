export const initProject = {
  config: {
    navigation: {
      label: '导航',
      styles: {
        background: '#fff'
      },
      list: [
        {
          id: '00001',
          icon: 'home',
          text: '首页',
          jump: {
            type: 'custom',
            id: '000000'
          }
        },
        {
          id: '00003',
          icon: 'danwei',
          text: '分类',
          jump: {
            type: 'fixed',
            id: 'category'
          }
        },
        {
          id: '00004',
          icon: 'huodong',
          text: '活动',
          jump: {
            type: 'fixed',
            id: 'car'
          }
        },
        {
          id: '00005',
          icon: 'zhanghao',
          text: '我的',
          jump: {
            type: 'fixed',
            id: 'my'
          }
        }
      ]
    },
    backgroundColor: '',
    isShowTabbar: true
  },
  pages: [
    // 自定义页面集合
    {
      id: '000000',
      name: '首页',
      home: true,
      backgroundColor: 'rgba(255, 255, 255, 1)',
      backgroundImage: '',
      backgroundImageSize: 'cover',
      backgroundImagePostion: 'center',
      showTopSearch: false,
      showMpTopNav: true,
      isShowTabbar: '',
      componentList: []
    }
  ]
}
