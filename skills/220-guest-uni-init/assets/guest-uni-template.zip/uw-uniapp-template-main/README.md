> # uniapp + vue3 + Vite + TS + yarn + vueI18n

#### H5内网访问地址：[http://192.168.88.21:30800/#/template/index](http://192.168.88.21:30800/#/template/index)

#### 介绍

初始的目录结构如下：

```
src  目录
├─components            公共组件目录
├─pages			应用页面
│  ├─cart               购物车相关页面
│  ├─index              首页以及搜索页
│  ├─register		        注册相关页面
│  ├─login		          登录相关页面
├─packages	分包根目录
│  ├─product/xxx            产品相关页...
│  ├─product/login       登陆页...
│  ├─product/register    注册页...
│  ├─product/user        用户相关页...
│  ├─setting             设置相关页...
├─config                配置文件目录
│  ├─login            登陆相关配置...
│  ├─tabbar            原生tabbar配置...
├─static                静态文件目录
├─utils                 工具文件包
├─store                 Pinia菠萝存储
```

#### git commit 需要遵守语法规则

```javaScript
// 必须是以下单词开头
// 示例 -> git commit -m 'feat: 新增首页路由'
[
  'feat', //新功能
  'fix', //修复bug
  'docx', //文档变更
  'style', //修改代码格式，不影响代码逻辑
  'refactor', //代码重构，理论上不影响功能逻辑
  'perf', //性能优化
  'test', //增加测试
  'chore', //构建或其他工具的变动(如webpack、vite)
  'revert', //还原以前的提交
  'build' //打包
]
```

#### vscode 插件推荐

###### vue3 TS 项目 用到的插件

> Vue Language Features (Volar) TypeScript Vue Plugin (Volar)
> 注意：如果项目插件中有 Vetur 那么要禁用此插件

###### vue2 用到的插件

> Vetur
> 注意：如果项目插件中有 Language Features (Volar) 和 TypeScript Vue Plugin (Volar) 那么要禁用 此两款插件

###### 通用插件推荐

> ESLint // eslint 校验保存格式化代码 [教程](https://blog.csdn.net/asacmxjc/article/details/125474692) >`<br>`Auto Rename Tag // 自动重命名配对的标签
> `<br>`Auto Close Tag // 自动闭合标签
> `<br>`i18n Ally // i18n 拓展提示工具
> `<br>`Code Spell Checker // 代码拼写检查
