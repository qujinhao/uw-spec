<script setup lang="ts">
import { FormInstance } from 'element-plus'
import { isJSON } from '@/utils/tool'

//   'string' |
//   'text' |
//   'textRich' |
//   'set<string>' |
//   'int' |
//   'set<int>' |
//   'long' |
//   'boolean' |
//   'float' |
//   'set<float>' |
//   'double' |
//   'set<double>' |
//   'date' |
//   'set<date>' |
//   'time' |
//   'set<time>' |
//   'datetime' |
//   'set<datetime>' |
//   'enum' |
//   'set<enum>' |
//   'map'
interface configListType {
  key: string
  value: string | string[]
  desc: string
  name?: string
  regex?: RegExp | null
  type: string
}

const props = withDefaults(
  defineProps<{
    configList: configListType[] // 配置列表
    configCheck: { [key: string]: boolean } // 选中项
    configData?: string // 配置数据
    defaultConfigList?: string | configListType[] // 默认配置列表
    isDelete?: boolean // 是否可以删除
  }>(),
  {
    isDelete: false
  }
)

// 参数
// const typeOptions = computed(() => [
//   {
//     label: '字符串',
//     value: 'string'
//   },
//   {
//     label: '字符串数组',
//     value: 'set<string>'
//   },
//   {
//     label: '文本',
//     value: 'text'
//   },
//   {
//     label: '富文本',
//     value: 'textRich'
//   },
//   {
//     label: '整数',
//     value: 'int'
//   },
//   {
//     label: '整数数组',
//     value: 'set<int>'
//   },
//   {
//     label: '长整型',
//     value: 'long'
//   },
//   {
//     label: '布尔',
//     value: 'boolean'
//   },
//   {
//     label: '浮点数',
//     value: 'float'
//   },
//   {
//     label: '浮点数数组',
//     value: 'set<float>'
//   },
//   {
//     label: '双精度',
//     value: 'double'
//   },
//   {
//     label: '双精度数组',
//     value: 'set<double>'
//   },
//   {
//     label: '日期',
//     value: 'date'
//   },
//   {
//     label: '日期范围',
//     value: 'set<date>'
//   },
//   {
//     label: '时间',
//     value: 'time'
//   },
//   {
//     label: '时间范围',
//     value: 'set<time>'
//   },
//   {
//     label: '日期时间',
//     value: 'datetime'
//   },
//   {
//     value: 'set<datetime>',
//     label: '日期时间范围'
//   },
//   {
//     label: '枚举',
//     value: 'enum'
//   },
//   {
//     label: '枚举数组',
//     value: 'set<enum>'
//   },
//   {
//     label: 'map结构',
//     value: 'map'
//   }
// ])

// 配置列表
const configTableList = useModel(props, 'configList')
// 选中项
const configTableCheck = useModel(props, 'configCheck')

// 设置系统配置多选框变化
const handleCheckChange = (val: number | boolean | string, key: string) => {
  const target = configTableList.value.find(item => item.key === key)
  if (val) {
    // 选中
    if (target) {
      // 存在配置的数据
      if (props.configData) {
        const data: Record<string, any> = JSON.parse(props.configData)
        const keyArray = Object.keys(data)
        const valueArray = Object.values(data)
        const index = keyArray.findIndex(item => item === key)
        if (index > -1) {
          target.value = valueArray[index] as string
        }
      } else {
        if (
          target.type === 'set<string>' ||
          target.type === 'set<int>' ||
          target.type === 'set<float>' ||
          target.type === 'set<double>'
        ) {
          target.value = []
        } else {
          target.value = ''
        }
      }
    }
  } else {
    // 未选中拿取旧值
    if (target) {
      const data: configListType[] = props.defaultConfigList
        ? isJSON(props.defaultConfigList)
          ? JSON.parse(props.defaultConfigList as string)
          : props.defaultConfigList
        : []
      if (data?.length) {
        const childTarget = data.find(item => item.key === key)
        let defaultValue: string | string[] = ''
        if (
          target.type === 'set<string>' ||
          target.type === 'set<int>' ||
          target.type === 'set<float>' ||
          target.type === 'set<double>' ||
          target.type === 'set<enum>'
        ) {
          defaultValue = []
        } else {
          defaultValue = ''
        }
        target.value = childTarget?.value || defaultValue
      } else {
        if (
          target.type === 'set<string>' ||
          target.type === 'set<int>' ||
          target.type === 'set<float>' ||
          target.type === 'set<double>' ||
          target.type === 'set<enum>'
        ) {
          target.value = []
        } else {
          target.value = ''
        }
      }
    }
    formRef.value?.clearValidate()
  }
}

// 点击删除
const handleDelete = (row: configListType) => {
  const index = configTableList.value.findIndex(item => item.key === row.key)
  if (index > -1) {
    configTableList.value.splice(index, 1)
  }
}

const formRef = ref<FormInstance>()
const formData = ref({})

// 通用校验
const commonValidate = (rule: any, value: string, callback: any) => {
  const index = rule.field.split('-')[2]
  const field = rule.field.split('-')[0]
  const target = configTableList.value[index]
  if (target.regex && target?.value) {
    let regex = target.regex
    // @ts-expect-error
    const firstReg = regex[0] === '/'
    // @ts-expect-error
    const lastReg = regex[target.regex.length - 1] === '/'
    if (firstReg && lastReg) {
      // @ts-expect-error
      regex = regex.substring(1, target.regex.length - 1)
    }
    const reg = new RegExp(regex)
    if (reg.test(target[field as keyof configListType] as string)) {
      callback()
    } else {
      callback(new Error('自定义校验不通过'))
    }
  } else {
    callback()
  }
}

// 参数默认值--数组形式
const commonValidateValueByArray = (rule: any, value: any, callback: any) => {
  const index = rule.field.split('-')[2]
  const field = rule.field.split('-')[0]
  const target = configTableList.value[index]
  if (target?.regex) {
    let regex = target.regex
    // @ts-expect-error
    const firstReg = regex[0] === '/'
    // @ts-expect-error
    const lastReg = regex[target.regex.length - 1] === '/'
    if (firstReg && lastReg) {
      // @ts-expect-error
      regex = regex.substring(1, target.regex.length - 1)
    }
    const reg = new RegExp(regex)
    const targetArray = target[field as keyof configListType] as string[]
    const isRight = targetArray.every(item => reg.test(item))
    if (isRight) {
      callback()
    } else {
      callback(new Error('自定义校验不通过'))
    }
  } else {
    callback()
  }
}

// 校验整数正则
const validateIntValue = (rule: any, value: any, callback: any) => {
  const index = rule.field.split('-')[2]
  const field = rule.field.split('-')[0]
  const target = configTableList.value[index]
  if (target[field as keyof configListType]) {
    if (/^-?\d+$/.test(target[field as keyof configListType] as string)) {
      if (target.regex) {
        let regex = target.regex
        // @ts-expect-error
        const firstReg = regex[0] === '/'
        // @ts-expect-error
        const lastReg = regex[target.regex.length - 1] === '/'
        if (firstReg && lastReg) {
          // @ts-expect-error
          regex = regex.substring(1, target.regex.length - 1)
        }
        const reg = new RegExp(regex)
        if (reg.test(target[field as keyof configListType] as string)) {
          callback()
        } else {
          callback(new Error('自定义校验不通过'))
        }
      } else {
        callback()
      }
    } else {
      callback(new Error('请输入整数'))
    }
  } else {
    callback()
  }
}

// 校验long类型正则
const validateLongValue = (rule: any, value: any, callback: any) => {
  const index = rule.field.split('-')[2]
  const field = rule.field.split('-')[0]
  const target = configTableList.value[index]
  if (target[field as keyof configListType]) {
    if (
      /^[+-]?(0|[1-9]\d*)$/.test(
        target[field as keyof configListType] as string
      )
    ) {
      if (target.regex) {
        let regex = target.regex
        // @ts-expect-error
        const firstReg = regex[0] === '/'
        // @ts-expect-error
        const lastReg = regex[target.regex.length - 1] === '/'
        if (firstReg && lastReg) {
          // @ts-expect-error
          regex = regex.substring(1, target.regex.length - 1)
        }
        const reg = new RegExp(regex)
        if (reg.test(target[field as keyof configListType] as string)) {
          callback()
        } else {
          callback(new Error('自定义校验不通过'))
        }
      } else {
        callback()
      }
    } else {
      callback(new Error('请输入long类型'))
    }
  } else {
    callback()
  }
}

// 校验double类型正则
const validateDoubleValue = (rule: any, value: any, callback: any) => {
  const index = rule.field.split('-')[2]
  const field = rule.field.split('-')[0]
  const target = configTableList.value[index]
  if (target[field as keyof configListType]) {
    if (
      /^[+-]?\d*\.?\d+$/.test(target[field as keyof configListType] as string)
    ) {
      if (target.regex) {
        let regex = target.regex
        // @ts-expect-error
        const firstReg = regex[0] === '/'
        // @ts-expect-error
        const lastReg = regex[target.regex.length - 1] === '/'
        if (firstReg && lastReg) {
          // @ts-expect-error
          regex = regex.substring(1, target.regex.length - 1)
        }
        const reg = new RegExp(regex)
        if (reg.test(target[field as keyof configListType] as string)) {
          callback()
        } else {
          callback(new Error('自定义校验不通过'))
        }
      } else {
        callback()
      }
    } else {
      callback(new Error('请输入double类型'))
    }
  } else {
    callback()
  }
}

// 校验float类型正则
const validateFloatValue = (rule: any, value: any, callback: any) => {
  const index = rule.field.split('-')[2]
  const field = rule.field.split('-')[0]
  const target = configTableList.value[index]
  if (target[field as keyof configListType]) {
    if (
      /^[+-]?\d*\.?\d+$/.test(target[field as keyof configListType] as string)
    ) {
      if (target.regex) {
        let regex = target.regex
        // @ts-expect-error
        const firstReg = regex[0] === '/'
        // @ts-expect-error
        const lastReg = regex[target.regex.length - 1] === '/'
        if (firstReg && lastReg) {
          // @ts-expect-error
          regex = regex.substring(1, target.regex.length - 1)
        }
        const reg = new RegExp(regex)
        if (reg.test(target[field as keyof configListType] as string)) {
          callback()
        } else {
          callback(new Error('自定义校验不通过'))
        }
      } else {
        callback()
      }
    } else {
      callback(new Error('请输入float类型'))
    }
  } else {
    callback()
  }
}

// 校验整数正则
const validateIntArrayValue = (rule: any, value: any, callback: any) => {
  const index = rule.field.split('-')[2]
  const field = rule.field.split('-')[0]
  const target = configTableList.value[index]
  if (
    target[field as keyof configListType] &&
    Array.isArray(target[field as keyof configListType])
  ) {
    const isRight = (target[field as keyof configListType] as string[]).every(
      item => /^[0-9]*$/.test(item)
    )
    if (isRight) {
      if (target.regex) {
        let regex = target.regex
        // @ts-expect-error
        const firstReg = regex[0] === '/'
        // @ts-expect-error
        const lastReg = regex[target.regex.length - 1] === '/'
        if (firstReg && lastReg) {
          // @ts-expect-error
          regex = regex.substring(1, target.regex.length - 1)
        }
        const reg = new RegExp(regex)
        const customValidate = (
          target[field as keyof configListType] as string[]
        ).every(item => reg.test(item))
        if (customValidate) {
          callback()
        } else {
          callback(new Error('自定义校验不通过'))
        }
      } else {
        callback()
      }
    } else {
      callback(new Error('请输入整数'))
    }
  } else {
    callback()
  }
}

// 校验float类型正则
const validateFloatArrayValue = (rule: any, value: any, callback: any) => {
  const index = rule.field.split('-')[2]
  const field = rule.field.split('-')[0]
  const target = configTableList.value[index]
  if (
    target[field as keyof configListType] &&
    Array.isArray(target[field as keyof configListType])
  ) {
    const isRight = (target[field as keyof configListType] as string[]).every(
      item => /^[+-]?\d*\.?\d+$/.test(item)
    )
    if (isRight) {
      if (target.regex) {
        let regex = target.regex
        // @ts-expect-error
        const firstReg = regex[0] === '/'
        // @ts-expect-error
        const lastReg = regex[target.regex.length - 1] === '/'
        if (firstReg && lastReg) {
          // @ts-expect-error
          regex = regex.substring(1, target.regex.length - 1)
        }
        const reg = new RegExp(regex)
        const customValidate = (
          target[field as keyof configListType] as string[]
        ).every(item => reg.test(item))
        if (customValidate) {
          callback()
        } else {
          callback(new Error('自定义校验不通过'))
        }
      } else {
        callback()
      }
    } else {
      callback(new Error('请输入float类型'))
    }
  } else {
    callback()
  }
}

// 校验double类型正则
const validateDoubleArrayValue = (rule: any, value: any, callback: any) => {
  const index = rule.field.split('-')[2]
  const field = rule.field.split('-')[0]
  const target = configTableList.value[index]
  if (
    target[field as keyof configListType] &&
    Array.isArray(target[field as keyof configListType])
  ) {
    const isRight = (target[field as keyof configListType] as string[]).every(
      item => /^[+-]?\d*\.?\d+$/.test(item)
    )
    if (isRight) {
      if (target.regex) {
        let regex = target.regex
        // @ts-expect-error
        const firstReg = regex[0] === '/'
        // @ts-expect-error
        const lastReg = regex[target.regex.length - 1] === '/'
        if (firstReg && lastReg) {
          // @ts-expect-error
          regex = regex.substring(1, target.regex.length - 1)
        }
        const reg = new RegExp(regex)
        const customValidate = (
          target[field as keyof configListType] as string[]
        ).every(item => reg.test(item))
        if (customValidate) {
          callback()
        } else {
          callback(new Error('自定义校验不通过'))
        }
      } else {
        callback()
      }
    } else {
      callback(new Error('请输入double类型'))
    }
  } else {
    callback()
  }
}

const validateEnum = (rule: any, value: any, callback: any) => {
  const index = rule.field.split('-')[2]
  const field = rule.field.split('-')[0]
  const target = configTableList.value[index]
  if (target[field as keyof configListType]) {
    // 枚举值可以只填写一个或多个
    if (!(target[field as keyof configListType] as string)?.includes(',')) {
      // 如果存在一个的情况，则只是字符串就行
      callback()
    } else {
      // 多个的情况
      if (
        /^[^,]+(,[^,]+){2}$/.test(
          target[field as keyof configListType] as string
        )
      ) {
        if (target.regex) {
          let regex = target.regex
          // @ts-expect-error
          const firstReg = regex[0] === '/'
          // @ts-expect-error
          const lastReg = regex[target.regex.length - 1] === '/'
          if (firstReg && lastReg) {
            // @ts-expect-error
            regex = regex.substring(1, target.regex.length - 1)
          }
          const reg = new RegExp(regex)
          if (reg.test(target[field as keyof configListType] as string)) {
            callback()
          } else {
            callback(new Error('自定义校验不通过'))
          }
        } else {
          callback()
        }
      } else {
        callback(new Error('格式错误，请输入： xxx,xxx,xxx 格式的值'))
      }
    }
  } else {
    callback()
  }
}

const validateEnumByArray = (rule: any, value: any, callback: any) => {
  const index = rule.field.split('-')[2]
  const field = rule.field.split('-')[0]
  const target = configTableList.value[index]
  if (
    target[field as keyof configListType] &&
    Array.isArray(target[field as keyof configListType])
  ) {
    const isRight = (target[field as keyof configListType] as string[]).every(
      item => /^[^,]+(,[^,]+){2}$/.test(item)
    )
    if (isRight) {
      if (target.regex) {
        let regex = target.regex
        // @ts-expect-error
        const firstReg = regex[0] === '/'
        // @ts-expect-error
        const lastReg = regex[target.regex.length - 1] === '/'
        if (firstReg && lastReg) {
          // @ts-expect-error
          regex = regex.substring(1, target.regex.length - 1)
        }
        const reg = new RegExp(regex)
        const customValidate = (
          target[field as keyof configListType] as string[]
        ).every(item => reg.test(item))
        if (customValidate) {
          callback()
        } else {
          callback(new Error('自定义校验不通过'))
        }
      } else {
        callback()
      }
    } else {
      callback(new Error('格式错误，请输入： xxx,xxx,xxx 格式的值'))
    }
  } else {
    callback()
  }
}

// 校验
const validate = async (callback?: (data: string) => void) => {
  if (callback) {
    formRef.value?.validate(val => {
      if (val) {
        callback(JSON.stringify(configTableList.value))
      }
    })
  } else {
    return new Promise(resolve => {
      formRef.value?.validate(validate => {
        resolve(validate)
      })
    })
  }
}

defineExpose({
  validate
})
</script>

<template>
  <el-form
    ref="formRef"
    :model="formData"
    label-width="0"
    :style="{ width: '100%' }"
  >
    <el-table
      :data="configTableList"
      border
      :header-cell-style="{ backgroundColor: '#f2f2f2' }"
    >
      <el-table-column
        label="参数"
        width="150px"
        align="left"
        header-align="center"
      >
        <template #default="{ row }">
          <span>{{ row.key }}</span>
        </template>
      </el-table-column>
      <!-- <el-table-column
        label="参数类型"
        width="150px"
        align="left"
        header-align="center"
        prop="type"
      >
        <template #default="{ row }">
          <span>
            {{ typeOptions.find(item => item.value === row.type)?.label }}
          </span>
        </template>
      </el-table-column> -->
      <el-table-column
        label="参数值"
        minWidth="350px"
        align="center"
      >
        <template #default="{ row, $index }">
          <div class="flex-start">
            <el-form-item
              :prop="`value-${row.key}-${$index}`"
              :rules="[
                {
                  validator: commonValidate,
                  trigger: 'blur'
                }
              ]"
              class="flex-1"
              v-if="row.type === 'string'"
            >
              <el-input
                v-model="row.value"
                placeholder="请输入参数值"
                class="w100"
                :disabled="!configTableCheck[row.key]"
              />
            </el-form-item>
            <el-form-item
              :prop="`value-${row.key}-${$index}`"
              :rules="[
                {
                  validator: commonValidate,
                  trigger: 'blur'
                }
              ]"
              class="flex-1"
              v-else-if="row.type === 'text' || row.type === 'textRich'"
            >
              <el-input
                v-model="row.value"
                placeholder="请输入参数值"
                class="w100"
                :disabled="!configTableCheck[row.key]"
                type="textarea"
                :rows="4"
              />
            </el-form-item>
            <el-form-item
              :prop="`value-${row.key}-${$index}`"
              :rules="[
                {
                  validator: commonValidateValueByArray,
                  trigger: 'blur'
                }
              ]"
              class="flex-1"
              v-else-if="row.type === 'set<string>'"
            >
              <InputTag
                v-model:tagValue="row.value"
                placeholder="请输入参数值"
                class="w100"
                :disabled="!configTableCheck[row.key]"
              />
            </el-form-item>
            <el-form-item
              :prop="`value-${row.key}-${$index}`"
              :rules="[
                {
                  validator: validateIntValue,
                  trigger: 'blur'
                }
              ]"
              class="flex-1"
              v-else-if="row.type === 'int'"
            >
              <el-input-number
                v-model="row.value"
                placeholder="请输入参数值"
                class="w100"
                :disabled="!configTableCheck[row.key]"
              />
            </el-form-item>
            <el-form-item
              :prop="`value-${row.key}-${$index}`"
              :rules="[
                {
                  validator: validateLongValue,
                  trigger: 'blur'
                }
              ]"
              class="flex-1"
              v-else-if="row.type === 'long'"
            >
              <el-input
                v-model="row.value"
                placeholder="请输入参数值"
                class="w100"
                :disabled="!configTableCheck[row.key]"
              />
            </el-form-item>
            <el-form-item
              :prop="`value-${row.key}-${$index}`"
              :rules="[
                {
                  validator: validateDoubleValue,
                  trigger: 'blur'
                }
              ]"
              class="flex-1"
              v-else-if="row.type === 'double'"
            >
              <el-input-number
                v-model="row.value"
                placeholder="请输入参数值"
                class="w100"
                :disabled="!configTableCheck[row.key]"
              />
            </el-form-item>
            <el-form-item
              :prop="`value-${row.key}-${$index}`"
              :rules="[
                {
                  validator: validateFloatValue,
                  trigger: 'blur'
                }
              ]"
              class="flex-1"
              v-else-if="row.type === 'float'"
            >
              <el-input-number
                v-model="row.value"
                placeholder="请输入参数值"
                class="w100"
                :disabled="!configTableCheck[row.key]"
              />
            </el-form-item>
            <el-form-item
              :prop="`value-${row.key}-${$index}`"
              :rules="[
                {
                  validator: validateIntArrayValue,
                  trigger: 'blur'
                }
              ]"
              class="flex-1"
              v-else-if="row.type === 'set<int>'"
            >
              <InputTag
                v-model:tagValue="row.value"
                placeholder="请输入参数值"
                class="w100"
                :disabled="!configTableCheck[row.key]"
              />
            </el-form-item>
            <el-form-item
              :prop="`value-${row.key}-${$index}`"
              :rules="[
                {
                  validator: validateFloatArrayValue,
                  trigger: 'blur'
                }
              ]"
              class="flex-1"
              v-else-if="row.type === 'set<float>'"
            >
              <InputTag
                v-model:tagValue="row.value"
                placeholder="请输入参数值"
                class="w100"
                :disabled="!configTableCheck[row.key]"
              />
            </el-form-item>
            <el-form-item
              :prop="`value-${row.key}-${$index}`"
              :rules="[
                {
                  validator: validateDoubleArrayValue,
                  trigger: 'blur'
                }
              ]"
              class="flex-1"
              v-else-if="row.type === 'set<double>'"
            >
              <InputTag
                v-model:tagValue="row.value"
                placeholder="请输入参数值"
                class="w100"
                :disabled="!configTableCheck[row.key]"
              />
            </el-form-item>
            <el-form-item
              :prop="`value-${row.key}-${$index}`"
              :rules="[
                {
                  validator: commonValidate,
                  trigger: 'blur'
                }
              ]"
              class="flex-1"
              v-else-if="row.type === 'boolean'"
            >
              <el-radio-group
                v-model="row.value"
                class="w100"
                :disabled="!configTableCheck[row.key]"
              >
                <el-radio :value="true">true</el-radio>
                <el-radio :value="false">false</el-radio>
              </el-radio-group>
            </el-form-item>
            <el-form-item
              :prop="`value-${row.key}-${$index}`"
              :rules="[
                {
                  validator: commonValidate,
                  trigger: 'blur'
                }
              ]"
              class="flex-1"
              v-else-if="row.type === 'date'"
            >
              <el-date-picker
                v-model="row.value"
                type="date"
                value-format="YYYY-MM-DD HH:mm:ss"
                :style="{ width: '100%' }"
                :disabled="!configTableCheck[row.key]"
              />
            </el-form-item>
            <el-form-item
              :prop="`value-${row.key}-${$index}`"
              :rules="[
                {
                  validator: commonValidateValueByArray,
                  trigger: 'blur'
                }
              ]"
              class="flex-1"
              v-else-if="row.type === 'set<date>'"
            >
              <el-date-picker
                v-model="row.value"
                type="daterange"
                value-format="YYYY-MM-DD HH:mm:ss"
                :style="{ width: '100%' }"
                :disabled="!configTableCheck[row.key]"
              />
            </el-form-item>
            <el-form-item
              :prop="`value-${row.key}-${$index}`"
              :rules="[
                {
                  validator: commonValidate,
                  trigger: 'blur'
                }
              ]"
              class="flex-1"
              v-else-if="row.type === 'time'"
            >
              <el-time-picker
                v-model="row.value"
                arrow-control
                value-format="YYYY-MM-DD HH:mm:ss"
                :style="{ width: '100%' }"
                :disabled="!configTableCheck[row.key]"
              />
            </el-form-item>
            <el-form-item
              :prop="`value-${row.key}-${$index}`"
              :rules="[
                {
                  validator: commonValidateValueByArray,
                  trigger: 'blur'
                }
              ]"
              class="flex-1"
              v-else-if="row.type === 'set<time>'"
            >
              <el-time-picker
                v-model="row.value"
                is-range
                value-format="YYYY-MM-DD HH:mm:ss"
                :style="{ width: '100%' }"
                :disabled="!configTableCheck[row.key]"
              />
            </el-form-item>
            <el-form-item
              :prop="`value-${row.key}-${$index}`"
              :rules="[
                {
                  validator: commonValidate,
                  trigger: 'blur'
                }
              ]"
              class="flex-1"
              v-else-if="row.type === 'datetime'"
            >
              <el-date-picker
                v-model="row.value"
                type="datetime"
                value-format="YYYY-MM-DD HH:mm:ss"
                class="w100"
                :disabled="!configTableCheck[row.key]"
              />
            </el-form-item>
            <el-form-item
              :prop="`value-${row.key}-${$index}`"
              :rules="[
                {
                  validator: commonValidateValueByArray,
                  trigger: 'blur'
                }
              ]"
              class="flex-1"
              v-else-if="row.type === 'set<datetime>'"
            >
              <el-date-picker
                v-model="row.value"
                type="datetimerange"
                value-format="YYYY-MM-DD HH:mm:ss"
                class="w100"
                :disabled="!configTableCheck[row.key]"
              />
            </el-form-item>
            <el-form-item
              :prop="`value-${row.key}-${$index}`"
              :rules="[
                {
                  validator: validateEnum,
                  trigger: 'blur'
                }
              ]"
              class="flex-1"
              v-else-if="row.type === 'enum'"
            >
              <el-input
                v-model="row.value"
                class="w100"
                :disabled="!configTableCheck[row.key]"
                placeholder="请输入 eg: xxx,xxx,xxx"
              />
            </el-form-item>
            <el-form-item
              :prop="`value-${row.key}-${$index}`"
              :rules="[
                {
                  validator: validateEnumByArray,
                  trigger: 'blur'
                }
              ]"
              class="flex-1"
              v-else-if="row.type === 'set<enum>'"
            >
              <InputTag
                v-model:tagValue="row.value"
                class="w100"
                :disabled="!configTableCheck[row.key]"
                placeholder="请输入 eg: xxx,xxx,xxx"
              />
            </el-form-item>
            <el-form-item
              :prop="`value-${row.key}-${$index}`"
              :rules="[
                {
                  validator: validateEnumByArray,
                  trigger: 'blur'
                }
              ]"
              class="flex-1"
              v-else-if="row.type === 'map'"
            >
              <el-input
                v-model="row.value"
                type="textarea"
                :rows="4"
                placeholder="请输入 eg: {'xxx': 'xxx', 'xxx': 'xxx'}"
                class="w100"
                :disabled="!configTableCheck[row.key]"
              />
            </el-form-item>
            <!-- 兼容旧数据 -->
            <el-form-item
              :prop="`value-${row.key}-${$index}`"
              :rules="[
                {
                  validator: commonValidate,
                  trigger: 'blur'
                }
              ]"
              class="flex-1"
              v-else
            >
              <el-input
                v-model="row.value"
                placeholder="请输入参数值"
                class="w100"
                :disabled="!configTableCheck[row.key]"
              />
            </el-form-item>
            <div class="checkBox-wrapper">
              <el-checkbox
                v-model="configTableCheck[row.key]"
                label="配置"
                class="margin-left-5"
                @change="(val: any) => handleCheckChange(val, row.key)"
              />
            </div>
          </div>
        </template>
      </el-table-column>
      <el-table-column
        label="参数描述"
        width="250px"
        align="center"
      >
        <template #default="{ row }">
          <span>{{ row.desc }}</span>
        </template>
      </el-table-column>
      <!-- <el-table-column
        label="参数校验规则"
        width="200px"
        align="center"
        prop="regex"
      ></el-table-column> -->
      <el-table-column
        label="操作"
        width="100px"
        align="center"
        v-if="isDelete"
      >
        <template #default="{ row }">
          <el-text
            type="danger"
            @click="handleDelete(row)"
          >
            删除
          </el-text>
        </template>
      </el-table-column>
    </el-table>
  </el-form>
</template>

<style lang="scss" scoped>
.w100 {
  width: 100%;
}

.flex-1 {
  flex: 1;
}

.checkBox-wrapper {
  display: flex;
  align-items: center;
  width: 70px;
}

:deep(.el-form-item__content) {
  min-height: 64px;
  .el-form-item__error {
    top: 75% !important;
  }
}
</style>
