import { type CascaderOption } from 'element-plus'

export interface SearchFormType {
  formItem?: {
    prop?: string | string[]
    label?: string
    labelWidth?: string | number
    labelPosition?: 'left' | 'right' | 'top'
    required?: boolean
    rules?: import('element-plus').FormItemRule[]
  }
  formItemWidth?: number | string // formTtem 的整体宽度
  componentWidth?: number | string // 组件宽度
  componentType:
    | 'radio'
    | 'select'
    | 'datePicker'
    | 'input'
    | 'selectv2'
    | 'inputNumber'
    | 'cascader'
    | 'selectAndDatePicker'
    | 'inputNumberRange'
    | 'timePicker' // 组件的类型
  br?: boolean // 是否换行
  type?: string // UI组件的原生类型
  field: string // 唯一字符串 数据回传的时候会使用这个字段的值作为 label 的值
  disabled?: boolean
  readonly?: boolean
  placeholder?: string // 占位字符串
  startPlaceholder?: string // 范围选择时开始日期的占位内容
  endPlaceholder?: string // 范围选择时开始日期的占位内容
  clearable?: boolean // 是否可清空
  format?: string // 显示在输入框中的格式
  valueFormat?: string // 可选，绑定值的格式。 不指定则绑定值为 Date 对象
  defaultTime?: [Date, Date] | Date // 选择日期后的默认时间值。 如未指定则默认时间值为 00:00:00
  showPassword?: boolean // 是否显示切换密码图标
  enterable?: boolean // 当为输入框时，是否启用回车触发提交功能
  loading?: boolean
  options?: Array<{ value?: string | number; label?: string }>
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  value?: any // 默认值  如果是按钮组件的话，必传
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  expand?: Record<string, any> // 拓展字段，将会绑定到每一个 UI 组件上 优先级低于列出来的字段
  change?: (val: any) => void
  click?: () => void // 组件的点击事件 componentType 为 button 有效
  isShow?: boolean // 是否显示，默认显示
  combinationField?: string // 组合副组件的 唯一字符串
  combinationWidth?: number | string // 组合副组件宽度
  combinationOptions?: Array<{ value?: string | number; label?: string }> // 组合副组件下拉项
  combinationExpand?: Record<string, any> // 组合副组件拓展字段，将会绑定到每一个 UI 组件上 优先级低于列出来的字段
  cascaderOptions?: CascaderOption[] // 级联选择器下拉选项
}

export interface FormAttributes {
  inline?: boolean
  labelPosition?: 'left' | 'right' | 'top'
  size?: 'large' | 'default' | 'small'
  disabled?: boolean // 禁用表单所有组件
}

export interface SearchFormProps {
  modelValue: Record<string, string | number | any>
  formAttributes?: FormAttributes
  type?: 'search' | 'form' // 表单类型 搜索类型
  list: Array<SearchFormType>
  bntLoading?: boolean
  rules?: import('element-plus').FormRules
  contentWidth?: number
}
