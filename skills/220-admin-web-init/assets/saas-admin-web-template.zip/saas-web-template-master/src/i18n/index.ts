// 定义语言国际化内容
import { createI18n } from 'vue-i18n'
import type { I18N } from './i18n.type'
import { name } from '../../package.json'

export const messages: Partial<Record<I18N, any>> = {}

// 引入i18n文件夹下所有集合index.ts文件
const modules: Record<string, any> = import.meta.glob(
  ['./*/index.ts', '!./*/type.ts', '!./type.d.ts'],
  {
    eager: true
  }
)

// https://vitejs.cn/vite3-cn/guide/features.html#glob-import
for (const path in modules) {
  const match = path.match(/\.\/([\w-]+)\//)
  const key = match ? match[1] : null //  取出文件夹名的 en、zh-cn、zh-tw ... 作为key
  // @ts-expect-error
  messages[key] = modules[path].default
}

// 获取默认语言（避免循环依赖，直接读取 localStorage）
const defaultLang = localStorage.getItem(`${name}-lang`) as I18N
const browserLang = window.navigator.language as I18N

// 创建单例 i18n 实例
export const i18n = createI18n({
  legacy: false, // 表示不使用 Vue 2 的传统 API，而是使用 Vue 3 的新 API。
  locale: defaultLang || browserLang.toLocaleLowerCase(), // 默认使用本地存储语言标识 || 浏览器默认语言标识
  fallbackLocale: 'zh-CN', // 没有定义的文件包 默认使用中文
  messages
})

// 导出类型已锁定的 t 函数，避免在使用处触发 createI18n 泛型递归推断 (TS2589)
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const getT = (): ((key: string, ...args: any[]) => string) => {
  // @ts-expect-error: 避免 createI18n 泛型递归推断 (TS2589)
  return i18n.global.t
}

// 切换语言函数（延迟导入 store 避免循环依赖）
export const setLocale = (lang: I18N) => {
  i18n.global.locale.value = lang
  localStorage.setItem(`${name}-lang`, lang)
  // 动态导入 store 避免循环依赖
  import('../store/main').then(({ useMainStore }) => {
    import('../store').then(piniaModule => {
      const mainStore = useMainStore(piniaModule.default)
      mainStore.setI18n(lang)
    })
  })
}

export default i18n
