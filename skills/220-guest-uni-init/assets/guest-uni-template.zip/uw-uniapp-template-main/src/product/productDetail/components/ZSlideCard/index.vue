<template>
  <view class="z-slide-card">
    <view :class="type === 0 ? `z-hot-sell` : 'z-hot-sell-box'">
      <view class="ul">
        <view
          class="li"
          v-for="(item, index) in dataList"
          :key="item.id"
          @click.stop="handlerHostClick(item, index)"
        >
          <view
            class="sell-bg div"
            :style="{ backgroundImage: `url(${item.signImg || item.img})` }"
          >
            <view
              class="sell-bg-icon i"
              v-if="showTop"
            >
              TOP {{ index + 1 }}
            </view>
            <view
              class="sell-icon-site"
              v-if="item.areaName && type === 0"
            >
              <u-icon name="map"></u-icon>
              {{ item.areaName }}
            </view>
          </view>
          <view
            v-if="type !== 0 && showTop"
            class="sell-bg-icon-new i"
          >
            TOP {{ index + 1 }}
          </view>
          <view class="sell-title p">
            {{ item.infoTitle || item.title || item.viewName }}
          </view>
          <view class="sell-money div">
            <view class="sell-money-item">
              <view
                class="sell-salePrice p"
                v-if="item.salePrice && type === 0"
              >
                <text class="i">{{ currency }}</text>
                <text class="span">{{ item.salePrice }}</text>
                <text class="text">起</text>
              </view>
              <view
                class="sell-marketPrice p"
                v-if="item.marketPrice && type === 0"
              >
                市场价{{ currency }}{{ item.marketPrice }}
              </view>
            </view>
            <template v-if="type === 0">
              <button
                v-if="userType === 0"
                @click.stop="handlerHostClick(item, index)"
                class="post-video"
              >
                立即预订
              </button>
              <button
                v-if="userType !== 0 && (!item.posterImg || !item.posterType)"
                class="post-video"
                open-type="share"
                @click.stop
                :data-signimg="item.signImg"
                :data-productno="item.infoId"
                :data-posterimg="item.posterImg"
                :data-postertype="item.posterType"
                :data-infotitle="item.infoTitle"
                :data-infotitledesc="item.infoTitleDesc"
              >
                一键分享
              </button>
              <button
                v-else-if="userType !== 0 && item.posterImg && item.posterType"
                class="post-video"
                @click.stop="toShowModalX(index)"
                :data-productno="item.infoId"
                :data-videotitle="item.infoTitle"
              >
                一键发圈
              </button>
            </template>
          </view>
          <view
            class="sell-icon-site"
            v-if="item.areaName && type === 1"
          >
            <u-icon name="map"></u-icon>
            {{ item.areaName }}
          </view>
        </view>
        <view
          v-if="type !== 1"
          class="last li"
        ></view>
        <view
          v-if="type === 1"
          class="last li"
          @click.stop="handleClick"
        >
          <text class="span">查看更多</text>
          <text class="i"></text>
        </view>
      </view>
    </view>
  </view>
</template>

<script lang="ts" setup>
import { computed } from 'vue'
// import { useUserStore } from '@/store/user'

// 定义列表项接口
interface ListItem {
  id: number | string
  signImg?: string
  img?: string
  areaName?: string
  infoTitle?: string
  title?: string
  viewName?: string
  salePrice?: number | string
  marketPrice?: number | string
  posterImg?: string
  posterType?: string
  infoId?: number
  infoTitleDesc?: string
}

// 定义组件props
const props = withDefaults(
  defineProps<{
    list: ListItem[]
    type?: number
    infoId?: number
    isShowModal?: boolean
    posterImg?: string
    posterType?: string
    infoTitle?: string
    infoTitleDesc?: string
    showTop?: boolean
  }>(),
  {
    type: 0,
    infoId: 0,
    isShowModal: false,
    posterImg: '',
    posterType: '',
    infoTitle: '',
    infoTitleDesc: '',
    showTop: true
  }
)

// const useStore = useUserStore()

// 定义emit事件
const emit = defineEmits<{
  (e: 'click', item: ListItem): void
  (e: 'more'): void
  (
    e: 'change',
    data: {
      isShowModal: boolean
      infoId?: number
      infoTitle?: string
      infoTitleDesc?: string
      signImg?: string
    }
  ): void
}>()

// 计算货币符号
const currency = computed(() => '￥')

// 处理列表数据，当type为1且列表长度为偶数时去掉最后一个元素
const dataList = computed(() => {
  if (props.type === 1 && props.list.length % 2 !== 1) {
    return props.list.slice(0, -1)
  }
  return props.list
})

// 获取用户类型，默认为0
const userType = computed(() => {
  const userType = 0
  return userType === undefined ? 0 : userType
})

// 处理点击事件
const handlerHostClick = (item: ListItem, index: number) => {
  emit('click', dataList.value[index])
}

// 处理查看更多点击事件
const handleClick = () => {
  emit('more')
}

// 显示弹框
const toShowModalX = (index: number) => {
  const item = dataList.value[index]
  const data = {
    isShowModal: true,
    infoId: item.infoId,
    infoTitle: item.infoTitle,
    infoTitleDesc: item.infoTitleDesc,
    signImg: item.signImg
  }
  emit('change', data)
}
</script>

<style lang="scss" scoped>
// 超值热销
.z-slide-card {
  background-color: #f6f6f6;
  &::-webkit-scrollbar {
    display: none;
  }
  .z-hot-sell {
    width: 100%;
    padding-top: 20rpx;
    padding-bottom: 26rpx;
    overflow-x: scroll;
    overflow-y: hidden;
    -webkit-overflow-scrolling: touch;

    .ul {
      display: flex;
      padding-left: 32rpx;
    }

    .li {
      flex-shrink: 0;
      width: 535rpx;
      padding-bottom: 24rpx;
      margin-right: 22rpx;
      border-radius: 20rpx;
      background-color: #fff;

      .sell-bg {
        width: 100%;
        height: 340rpx;
        margin-bottom: 20rpx;
        background-repeat: no-repeat;
        background-position: center;
        background-size: cover;
        border-radius: 20rpx 20rpx 0 0;
        .sell-bg-icon {
          display: inline-block;
          width: 120rpx;
          height: 40rpx;
          color: #fff;
          font-weight: 600;
          font-size: 24rpx;
          line-height: 40rpx;
          text-align: center;
          background: url('http://qnimg.zowoyoo.com/img/84826/1757063031183.png')
            no-repeat center;
          background-size: cover;
          transform: translate(0, -10rpx);
        }

        .sell-icon-site {
          line-height: 1;
          display: inline-block;
          vertical-align: baseline;
          padding: 4rpx 10rpx;
          background: rgba(0, 0, 0, 0.4);
          border-radius: 16rpx;
          transform: translate(-100rpx, 288rpx);
          color: #fff;
          font-size: 24rpx;
        }
      }

      .sell-title {
        margin-bottom: 20rpx;
        padding: 4rpx 20rpx 0;
        overflow: hidden;
        font-weight: 600;
        font-size: 32rpx;
        color: #222222;
        white-space: nowrap;
        text-overflow: ellipsis;
      }

      .sell-money {
        display: flex;
        align-items: center;
        justify-content: space-between;
        box-sizing: border-box;
        padding: 0 20rpx;
        .sell-money-item {
          line-height: 1;
          flex: 2;
          display: flex;
          align-items: baseline;
          justify-content: flex-start;
          .sell-salePrice {
            color: #f47f02;
            font-size: 38rpx;
            margin-right: 36rpx;
            .i {
              margin-right: 6rpx;
            }
            .text {
              margin-left: 6rpx;
              font-size: 24rpx;
              text-decoration: none;
            }
          }
        }
        .money-item-btn {
          flex: 1;
          justify-content: flex-end;
        }

        .sell-marketPrice {
          color: rgba(187, 187, 187, 1);
          font-weight: 400;
          font-size: 20rpx;
          text-decoration: line-through;
        }
      }
    }

    .last {
      width: 1rpx;
    }
  }
  .z-hot-sell-box {
    width: 100%;
    padding: 0 0 32rpx;
    overflow-x: scroll;
    -webkit-overflow-scrolling: touch;

    .ul {
      display: flex;
      flex-direction: column;
      flex-wrap: wrap;
      height: 436rpx;
      padding-left: 32rpx;

      .li {
        position: relative;
        box-sizing: border-box;
        width: 282rpx;
        height: 212rpx;
        margin-right: 10rpx;
        margin-bottom: 10rpx;
        background-size: cover;

        .sell-bg {
          height: 100%;
          background-repeat: no-repeat;
          background-position: center;
          background-size: cover;
        }

        .sell-title {
          position: absolute;
          top: 0rpx;
          padding: 50rpx 0 40rpx;
          width: 100%;
          padding-left: 20rpx;
          overflow: hidden;
          color: #fff;
          font-size: 32rpx;
          white-space: nowrap;
          text-overflow: ellipsis;
          background-image: linear-gradient(rgba(0, 0, 0, 0.8), transparent);
        }
        .sell-bg-icon-new {
          top: 0;
          left: 0;
          position: absolute;
          z-index: 9;
          display: inline-block;
          width: 120rpx;
          height: 40rpx;
          color: #fff;
          font-weight: 600;
          font-size: 24rpx;
          line-height: 40rpx;
          text-align: center;
          background: url('http://qnimg.zowoyoo.com/img/84826/1757063242238.png')
            no-repeat center;
          background-size: cover;
        }

        .sell-icon-site {
          position: absolute;
          bottom: 20rpx;
          left: 20rpx;
          padding: 4rpx 10rpx;
          background: rgba(0, 0, 0, 0.4);
          border-radius: 16rpx;
          color: #fff;
          font-size: 20rpx;
        }

        .i {
          display: block;
          width: 120rpx;
          height: 40rpx;
          margin-bottom: 20rpx;
          color: #fff;
          font-weight: 600;
          font-size: 24rpx;
          line-height: 40rpx;
          text-align: center;
          background: url('http://qnimg.zowoyoo.com/img/84826/1757063425290.png')
            no-repeat center;
          background-size: cover;
        }
      }

      .li:first-child {
        width: 434rpx;
        height: 434rpx;
        margin-bottom: 0;
        overflow: hidden;
        background-repeat: no-repeat;
        background-position: center;
        background-size: cover;
        border-radius: 20rpx 0 0 20rpx;
      }

      .li:nth-child(2) {
        width: 342rpx;
      }

      .li:nth-child(3) {
        width: 342rpx;
      }

      .li:nth-child(odd) {
        margin-bottom: 0;
      }

      .li:nth-last-child(2) {
        overflow: hidden;
        border-bottom-right-radius: 20rpx;
      }

      .li:nth-last-child(3) {
        overflow: hidden;
        border-top-right-radius: 20rpx;
      }

      .last {
        z-index: 1;
        display: flex;
        flex: 1;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        width: 84rpx;
        height: 436rpx;
        margin-right: 0;
        margin-left: -20rpx;

        .span {
          margin-bottom: 10rpx;
          color: #bbb;
          writing-mode: vertical-rl;
        }

        .i {
          width: 24rpx;
          height: 24rpx;
          background: url('http://qnimg.zowoyoo.com/img/84826/1757063391750.png')
            no-repeat center;
          background-size: contain;
        }
      }
    }
  }
}
</style>
