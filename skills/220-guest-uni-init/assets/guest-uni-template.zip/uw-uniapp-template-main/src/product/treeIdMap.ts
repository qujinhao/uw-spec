export const treeIdMap = {
  0: {
    name: '门票',
    channelPath: '',
    detailPath: '/productdetail/0',
    bookPath: '/placeorder/0'
  },
  1: {
    name: '套餐',
    channelPath: '',
    detailPath: '/productdetail/1',
    bookPath: '/placeorder/1'
  },
  2: {
    name: '自由行',
    channelPath: '',
    detailPath: '/productdetail/2',
    bookPath: '/placeorder/2'
  },
  3: {
    name: '线路',
    channelPath: '/linechannel',
    detailPath: '/productdetail/3',
    bookPath: '/placeorder/3'
  },
  5: {
    name: '酒店',
    channelPath: '',
    detailPath: '/productdetail/5',
    bookPath: '/placeorder/5'
  },
  7: {
    name: '租车',
    channelPath: '',
    detailPath: '/productdetail/7',
    bookPath: '/placeorder/7'
  },
  8: {
    name: '签证',
    channelPath: '',
    detailPath: '/productdetail/8',
    bookPath: '/placeorder/8'
  },
  11: {
    name: '商品',
    channelPath: '',
    detailPath: '/productdetail/11',
    bookPath: '/placeorder/11'
  },
  // 以抢购为例
  12: {
    name: '抢购',
    channelPath: '/snapchannel', // 频道页路径
    detailPath: '/productdetail/12', // 产品详情路径
    bookPath: '/placeorder/12' // 下单路径
  },
  14: {
    name: '交通',
    channelPath: '/snapchannel', // 频道页路径
    detailPath: '/productdetail/14', // 产品详情路径
    bookPath: '/placeorder/14' // 下单路径
  }
}

export const treeNameMap = {
  0: '门票',
  1: '套餐',
  2: '自由行',
  3: '线路',
  5: '酒店',
  7: '租车',
  8: '签证',
  11: '商品',
  12: '抢购',
  14: '交通'
}
