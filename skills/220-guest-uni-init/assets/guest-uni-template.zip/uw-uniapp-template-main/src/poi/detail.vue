<script lang="ts" setup>
import { computed, reactive, ref } from 'vue'
import { onLoad } from '@dcloudio/uni-app'
import {
  guestPoiInfoLoad,
  guestProductInfoList,
  guestProductInfoLoad,
  guestProductInfoSessionList,
  type GuestProductInfoQueryParam,
  type PoiInfo,
  type ProductInfo,
  type ProductSession
} from '@/api/saasMallAppGuestApi'
import {
  CalculationPrice,
  formatParam,
  parseJsonToMediaList,
  resolveMedia
} from '@/utils/tool'
import ProdItem from './component/ProdItem.vue'
import dayjs from 'dayjs'
// import { useI18n } from 'vue-i18n'
import ZTag from '@/components/ZTag/index.vue'
import ZDateScrollView from '@/components/ZDateScrollView/index.vue'

// const { t } = useI18n()

const poiDetail = ref<PoiInfo>({})
const state = reactive({
  id: undefined as number | undefined
})

// 轮播列表
const swiperList = computed(() => {
  const list = parseJsonToMediaList(
    '{"1809":"8821909/product_info/0_1809.png", "1808":"8821909/product_info/0_1808.png"}'
  )
  let list1: any[] = []
  if (poiDetail.value.imgMain) {
    list1 = poiDetail.value.imgMain!.split(',').map((url) => {
      return {
        id: Math.random(),
        url,
        type: resolveMedia(url)
      }
    })
  }
  // debugger
  return [...list1, ...list]
  // TODO: 获取轮播列表
  // return parseJsonToMediaList(poiDetail.value.imgMain!)
})

// 标签列表
const poiTags = computed(() => {
  let list: { id: string; name: string }[] = []
  try {
    // "{\"104033\":\"遛娃宝藏地\",\"296\":\"自然山水\",\"1658245\":\"公园&植物园\",\"66028\":\"避暑纳凉\",\"254012\":\"赏秋叶\"}"
    if (poiDetail.value?.poiTag) {
      const obj = JSON.parse(poiDetail.value.poiTag)
      Object.keys(obj).forEach((key) => {
        list.push({
          id: key,
          name: obj[key]
        })
      })
    }
  } catch (error) {
    console.log('poiTags', error)
  }
  return list
})

// 营业信息
const openInfo = computed(() => {
  if (poiDetail.value.openInfo) {
    try {
      const list = JSON.parse(poiDetail.value.openInfo)
      const obj = list[0]
      return obj
    } catch (error) {
      console.log('poiDetail.value.openInfo', error)
    }
  }
  return {}
})

// 是否展开
const isUnfold = ref(false)
// 折叠的产品列表数据
const unfoldProductList = computed(() => {
  return isUnfold.value ? productList.value : productList.value.slice(0, 3)
})

// 获取POI详情
const getPoiDetail = async (poiId: number) => {
  const res = await guestPoiInfoLoad({ poiId })
  if (res.state === 'success') {
    poiDetail.value = res.data || {}
  } else {
    poiDetail.value = {}
  }

  // if (import.meta.env.DEV) {
  //   poiDetail.value = {
  //     id: 216714,
  //     sourceType: 198821909,
  //     poiType: 0,
  //     poiTag: '{"139":"博物馆"}',
  //     poiStar: 0,
  //     poiScore: 0,
  //     poiName: '临沂市博物馆',
  //     poiNameMatch: '博物馆',
  //     poiDesc:
  //       '临沂市博物馆是临沂市综合性博物馆由两大馆区组成，老馆地处山东省临沂市兰山区兰山路孔庙内，新馆（主馆区）地处临沂市北城新区兰陵路。老馆是临沂市人民政府在金代临沂孔庙旧址上建立起来的地质综合性博物馆。新馆在北城新区，2012年后作为主要展览区，建筑面积20805平方米。截至2017年11月，共有文物3万多件，珍贵文物2132件，常年陈列有“石钺”、“玉铲”、“蛋壳黑陶”、“镂空高柄杯”、“白陶双层口”、“金镂玉衣”、“汉画像石”等重要文物。临沂市博物馆有着丰富的新石器时代和汉晋出土文物，馆内文物多次被国家文物局调到日本、美国等国家进行展出。',
  //     poiPrice: 10,
  //     address: '临沂市北城新区兰陵路10号',
  //     openType: 0,
  //     openInfo:
  //       '[{"desc": "全年 周二-周日 09:00-16:00开放;全年 周一 全天不开放", "time": ""}]',
  //     areaCode: 100003700130000000,
  //     geoLng: 118.35069920324298,
  //     geoLat: 35.09009138773338,
  //     geoHash: 'wwhpt7',
  //     refNum: 4,
  //     state: 1
  //   }
  // }

  await getProductList(poiDetail.value.id!)
}

const productList = ref<ProductInfo[]>([])
// 根据POI获取产品列表
const getProductList = async (poiId: number) => {
  if (!poiId) return
  const params: GuestProductInfoQueryParam = {
    $pg: 1,
    $rn: 99,
    state: 1,
    $sn: ['id'],
    $st: [2],
    poiIds: poiDetail.value.id?.toString()
  }
  const res = await guestProductInfoList(params)
  if (res.state === 'success') {
    productList.value = res.data?.results || []
  } else {
    productList.value = []
  }
}

// 出发日期
const curTravelDate = ref<string>(dayjs().format('YYYY-MM-DD'))

// 日期变更
const handleDateChange = (date: string) => {
  console.log('handleDateChange', date)
}

const detailData = ref<ProductInfo>({})
// 获取产品信息
const getProductInfo = async (id: number) => {
  const res = await guestProductInfoLoad({ id })
  try {
    if (res.state === 'success' && res.data) {
      console.log('guestProductInfoLoad', res.data)
      detailData.value = res.data
    } else {
      detailData.value = {}
    }

    /**
     * skuType = 1 产品 直接下单即可
     * skuType = 2 场次 拉 场次 & 规格 & 价格
     * skuType = 3 && specType = 1 规格 拉价格
     *  */
    if (detailData.value?.skuType === 2) {
      getProductSessions()
    }
    // // 单规格 且 开启
    // if (
    //   detailData.value?.skuType === 3 &&
    //   detailData.value?.specType === 1
    // ) {
    //   getSpecInfos({ sessionId: 0 })
    // }
  } catch (error) {
    console.log('guestProductInfoLoad error', error)
  }
}

// 产品场次集合
const sessionList = ref<ProductSession[]>([])
// 获取产品场次
const getProductSessions = async () => {
  const res = await guestProductInfoSessionList({
    $pg: 1,
    $rn: 9999,
    state: 1,
    productId: detailData.value.id
  })
  if (res.state === 'success') {
    sessionList.value = res.data?.results || []
  } else {
    sessionList.value = []
  }
}

// 跳转产品详情
const handleDetailClick = (item: ProductInfo) => {
  console.log('handleDetailClick', item)

  const obj = {
    id: item.id
  }
  uni.navigateTo({
    url: '/product/productDetail/index?' + formatParam(obj)
  })
}

// 跳转至下单页面
const handleBookClick = async (item: ProductInfo) => {
  console.log('handleBookClick', item)
  const productId = item.id!
  await getProductInfo(productId) // TODO 可能用不到这个接口
  // await getProductPriceList(productId)
  const obj = {
    productId,
    poiId: poiDetail.value?.id || '',
    curTravelDate: curTravelDate.value
  }
  uni.navigateTo({
    url: '/product/placeOrder/index?' + formatParam(obj)
  })
}

// 打开地图控件
const handleOpenLocation = () => {
  uni.openLocation({
    name: poiDetail.value.poiName,
    address: poiDetail.value.address,
    latitude: poiDetail.value.geoLat,
    longitude: poiDetail.value.geoLng,
    success: function () {
      console.log('success')
    }
  })
}

// 轮播图点击
const handleClickSwiper = (index: number) => {
  console.log('handleClickSwiper', index)
  const urls = swiperList.value.map((item) => (item.url ? item.url : item))
  uni.previewImage({
    current: index,
    urls
  })
}

onLoad((options) => {
  state.id = options?.id
  if (state.id) {
    getPoiDetail(state.id)
  } else {
    uni.showToast({
      icon: 'none',
      title: '参数错误',
      duration: 2000
    })
  }
})
</script>

<template>
  <up-swiper
    v-if="swiperList.length"
    :list="swiperList"
    keyName="url"
    indicator
    :autoplay="false"
    @click="handleClickSwiper"
  ></up-swiper>

  <div class="poi-detail flex flex-col gap-[20rpx] p-[20rpx] bg-[#f7f7f7]">
    <div class="div-shadow">
      <div class="flex justify-between items-center">
        <div class="text-[18px] font-semibold">
          {{ poiDetail.poiName }}
        </div>
        <span class="">
          <span class="text-primary-buy text-xl font-semibold">
            CNY {{ CalculationPrice(poiDetail.poiPrice! / 100) }}
          </span>
          <span class="text-[#8A9098]">起</span>
        </span>
      </div>
      <div class="div-br"></div>

      <template v-if="poiTags.length">
        <div class="flex gap-4 overflow-x-scroll">
          <ZTag
            v-for="item in poiTags"
            :key="item.id"
            :text="item.name"
          />
        </div>
        <div class="div-br"></div>
      </template>

      <div class="flex flex-col gap-1">
        <div
          v-if="openInfo && Object.keys(openInfo).length"
          class="topPoi-item flex items-center justify-between gap-2"
        >
          <div class="left">
            <up-icon name="clock-fill"></up-icon>
          </div>
          <div
            class="center flex flex-nowrap items-center gap-2 overflow-hidden line-clamp-1"
          >
            <span class="flex shrink-0 text-[#31c7cf]">营业</span>
            <div class="text-nowrap truncate">
              <span v-if="openInfo.time">{{ openInfo.time }}</span>
              <span v-if="openInfo.desc">{{ openInfo.desc }}</span>
            </div>
          </div>
          <div class="right">
            <up-icon name="arrow-right"></up-icon>
          </div>
        </div>
        <div
          v-if="poiDetail.phone"
          class="topPoi-item flex items-center justify-between gap-2"
        >
          <div class="left">
            <up-icon name="phone-fill"></up-icon>
          </div>
          <div
            class="center flex flex-nowrap items-center gap-2 overflow-hidden line-clamp-1"
          >
            <div class="text-nowrap truncate">
              <span>{{ poiDetail.phone }}</span>
            </div>
          </div>
          <div class="right">
            <up-icon name="arrow-right"></up-icon>
          </div>
        </div>
        <div
          v-if="poiDetail.address"
          class="topPoi-item flex items-center justify-between gap-2"
        >
          <div class="left">
            <up-icon name="map-fill"></up-icon>
          </div>
          <div
            class="center flex flex-nowrap items-center gap-2 overflow-hidden line-clamp-1"
          >
            <div class="text-nowrap truncate">
              <span>{{ poiDetail.address }}</span>
            </div>
          </div>
          <div class="right flex">
            <span
              class="text-primary cursor-pointer"
              @click="handleOpenLocation()"
            >
              地图
            </span>
            <up-icon
              name="arrow-right"
              color="#2979ff"
            ></up-icon>
          </div>
        </div>
      </div>
    </div>

    <div class="div-shadow">
      <div
        class="m-[0_30rpx] flex h-[100rpx] items-center border-b border-[#E5E5E5] text-[18px] leading-[42px] font-bold text-[#14293F]"
      >
        景点门票
      </div>
      <div class="div-br"></div>

      <!-- 日期选择栏 -->
      <ZDateScrollView
        v-model="curTravelDate"
        @change="handleDateChange"
      />
      <!-- <div class="flex gap-2 overflow-x-scroll">
        <div
          v-for="item in dateList"
          :key="item.id"
          class="flex text-nowrap border border-gray-200 rounded-[10rpx] p-[10rpx_20rpx]"
          :class="{
            'text-white bg-[#14293f]': curTravelId === item.id
          }"
          @click="onSelect(item)"
        >
          {{ item.title }}
          <up-icon
            v-if="item.id === 'all'"
            name="arrow-right"
          ></up-icon>
        </div>
      </div> -->

      <div class="p-[20rpx_0rpx] flex flex-col gap-2">
        <ProdItem
          v-for="item in unfoldProductList"
          :key="item.id"
          :item="item"
          @goDetail="handleDetailClick(item)"
          @bookClick="handleBookClick(item)"
        />

        <up-button
          v-if="productList.length > 3"
          type="primary"
          shape="circle"
          :text="isUnfold ? '收起' : '展开'"
          @click="isUnfold = !isUnfold"
        ></up-button>
      </div>
    </div>

    <div
      class="div-shadow"
      v-if="poiDetail && poiDetail.poiDesc"
    >
      <div
        class="m-[0_30rpx] flex h-[100rpx] items-center border-b border-[#E5E5E5] p-[0_30rpx] text-[18px] leading-[42px] font-bold text-[#14293F]"
      >
        景点介绍
      </div>
      <div
        class="p-[20rpx_30rpx]"
        v-html="poiDetail.poiDesc"
      ></div>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.poi-detail {
  .topPoi-item {
    // .left {
    // }
    .center {
      display: flex;
      flex: 1;
    }
    // .right {
    // }
  }
}
</style>
