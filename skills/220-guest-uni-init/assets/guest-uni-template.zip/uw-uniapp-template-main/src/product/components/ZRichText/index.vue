<template>
  <div class="z-rich-text">
    <!-- 标题区域 -->
    <p class="z-rich-text-title">{{ title }}</p>
    <!-- 内容区域，动态设置高度 -->
    <div
      :style="{ height: styleHight }"
      class="z-rich-text-main"
      id="rich"
    >
      <slot></slot>
    </div>
    <!-- 展开/收起控制区域，当内容高度超过显示高度时显示 -->
    <div
      class="z-rich-text-look"
      v-if="richHight > showHight && showHight"
    >
      <div
        class="hidden-show"
        @click="toggleShow"
      >
        {{ show ? '隐藏' : '查看全部' }}
        <u-icon name="arrow" />
      </div>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { ref, computed, onMounted, watch, nextTick } from 'vue'

// 定义组件属性
const props = withDefaults(
  defineProps<{
    // 标题文本
    title?: string
    // 显示高度，传入才会有隐藏显示功能，并默认高度为传入的高度
    showHight?: number
  }>(),
  {
    title: '',
    showHight: 0
  }
)

// 是否展开显示全部内容
const show = ref(false)
// 内容实际高度
const richHight = ref(0)

// 计算内容区域高度样式
const styleHight = computed(() => {
  // 如果已展开或不需要限制高度，则显示自动高度
  if (show.value || !props.showHight || props.showHight >= richHight.value) {
    return 'auto'
  }
  // 否则限制为指定高度
  return `${props.showHight}px`
})

// 监听内容高度变化
watch(richHight, (newHeight) => {
  // 如果内容高度超过显示高度，默认收起
  if (newHeight > (props.showHight || 0)) {
    show.value = false
  }
})

// 切换展开/收起状态
const toggleShow = () => {
  show.value = !show.value
}

// 测量内容高度
const measureHeight = () => {
  // 在uni-app环境中使用uni.createSelectorQuery()
  if (typeof uni !== 'undefined' && uni.createSelectorQuery) {
    const query = uni.createSelectorQuery().in(this)
    query
      .select('#rich')
      .boundingClientRect((res: any) => {
        richHight.value = res ? res.height || 0 : 0
      })
      .exec()
  } else {
    // 非uni-app环境或SSR时的备选方案
    nextTick(() => {
      // const el = document.getElementById("rich");
      const el = document.querySelector('#rich')
      if (el) {
        richHight.value = el.getBoundingClientRect().height || 0
      }
    })
  }
}

// 组件挂载后测量高度
onMounted(() => {
  measureHeight()
})

// 暴露方法供父组件调用
defineExpose({
  measureHeight
})
</script>

<style lang="scss">
.z-rich-text {
  padding: 0 16px;
  background-color: #fff;
  border-radius: 30rpx;
  overflow: hidden;
  .z-rich-text-title {
    font-weight: 600;
    color: rgba(34, 34, 34, 1);
    font-size: 16px;
    line-height: 50px;
    border-bottom: 1px solid #e5e5e5;
  }
  .z-rich-text-main {
    padding: 10px 0;
    overflow: hidden;
    transition: height 300ms;
  }
  .z-rich-text-look {
    display: flex;
    justify-content: center;
    padding: 20px 0;
    .hidden-show {
      display: flex;
      align-items: center;
      padding: 6px 14px 6px 20px;
      color: #666;
      font-size: 14px;
      border: 1px solid #d8d8d9;
      border-radius: 12px;
      cursor: pointer;
    }
  }
}
</style>
