import { computed, onUnmounted, Ref, ref } from 'vue'

// 入参
interface CountdownOptions {
  /** 初始时间（单位：秒） */
  initialTime?: number
  /** 倒计时间隔（单位：毫秒，默认 1000ms） */
  interval?: number
  /** 倒计时结束回调 */
  onEnd?: () => void
}

// 回参
interface CountdownControls {
  /** 当前剩余时间（秒） */
  currentTime: Ref<number>
  /** 格式化后的时间字符串（MM:SS） */
  formattedTime: Readonly<Ref<string>>
  /** 是否正在倒计时 */
  isRunning: Readonly<Ref<boolean>>
  /** 开始倒计时 */
  start: (val?: number) => void
  /** 暂停倒计时 */
  pause: () => void
  /** 停止 */
  stop: () => void
  /** 重置倒计时 */
  reset: (newTime?: number) => void
}

/**
 * 倒计时hooks
 * @param options
 * @returns
 */
export const useCountdown = (
  options: CountdownOptions = {}
): CountdownControls => {
  const { initialTime = 60, interval = 1000, onEnd } = options

  // 状态管理
  const currentTime = ref(initialTime)
  const isRunning = ref(false)
  let timer: number | null = null

  // 自动清理定时器
  const cleanup = () => {
    if (timer) {
      clearInterval(timer)
      timer = null
    }
  }

  // 时间格式化（补零操作）
  const formattedTime = computed(() => {
    const minutes = Math.floor(currentTime.value / 60)
    const seconds = currentTime.value % 60
    return `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(
      2,
      '0'
    )}`
  })

  // 倒计时主逻辑
  const start = (val?: number) => {
    if (currentTime.value <= 0) return
    if (isRunning.value) return
    if (val) {
      currentTime.value = val
    }
    isRunning.value = true
    timer = setInterval(() => {
      currentTime.value -= 1
      if (currentTime.value <= 0) {
        cleanup()
        isRunning.value = false
        onEnd?.()
      }
    }, interval)
  }

  // 暂停功能
  const pause = () => {
    cleanup()
    isRunning.value = false
  }

  // 停止
  const stop = () => {
    cleanup()
    isRunning.value = false
    currentTime.value = initialTime
  }

  // 重置功能
  const reset = (newTime?: number) => {
    cleanup()
    currentTime.value = newTime ?? initialTime
    isRunning.value = false
  }

  // 组件卸载清理定时器
  onUnmounted(() => {
    stop()
  })

  return {
    currentTime,
    formattedTime,
    isRunning,
    start,
    pause,
    stop,
    reset
  }
}
