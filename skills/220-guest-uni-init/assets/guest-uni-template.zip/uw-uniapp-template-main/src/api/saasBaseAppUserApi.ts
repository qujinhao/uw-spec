import request from '@/api/request'
import type { ResponseData, DataList } from '@/api/type/API_TYPE'

/**
 * 获取系统公告详情
 */
export const userCommonNoticeLoadSysNotice = (params: {
  id: number // 公告 ID
}) => {
  return request({
    url: '/saas-base-app/user/common/notice/loadSysNotice',
    method: 'GET',
    params
  }) as Promise<ResponseData<SysNoticeInfo>>
}
/**
 * 获取运营商公告详情
 */
export const userCommonNoticeLoadSaasNotice = (params: {
  id: number // 公告 ID
}) => {
  return request({
    url: '/saas-base-app/user/common/notice/loadSaasNotice',
    method: 'GET',
    params
  }) as Promise<ResponseData<SaasNoticeInfo>>
}
/**
 * 系统公告列表
 */
export const userCommonNoticeListSysNotice = (
  params: SysNoticeInfoQueryParam
) => {
  return request({
    url: '/saas-base-app/user/common/notice/listSysNotice',
    method: 'GET',
    params
  }) as Promise<ResponseData<DataList<SysNoticeInfo>>>
}
/**
 * 运营商公告列表
 */
export const userCommonNoticeListSaasNotice = (
  params: SaasNoticeInfoQueryParam
) => {
  return request({
    url: '/saas-base-app/user/common/notice/listSaasNotice',
    method: 'GET',
    params
  }) as Promise<ResponseData<DataList<SaasNoticeInfo>>>
}
/**
 * 获得系统OssSite信息
 */
export const userCommonInfoSysOssSite = (params: {
  configSid?: string // 配置id
}) => {
  return request({
    url: '/saas-base-app/user/common/info/sysOssSite',
    method: 'GET',
    params
  }) as Promise<ResponseData<string>>
}
/**
 * 获得运营商OssSite信息
 */
export const userCommonInfoSaasOssSite = (params: {
  configSid?: string // 配置id
}) => {
  return request({
    url: '/saas-base-app/user/common/info/saasOssSite',
    method: 'GET',
    params
  }) as Promise<ResponseData<string>>
}
/**
 * 获取我的运营商信息
 */
export const userCommonInfoMySaasInfo = () => {
  return request({
    url: '/saas-base-app/user/common/info/mySaasInfo',
    method: 'GET'
  }) as Promise<ResponseData<SaasInfoVo>>
}
/**
 * 获取我的商户信息
 */
export const userCommonInfoMyMchInfo = () => {
  return request({
    url: '/saas-base-app/user/common/info/myMchInfo',
    method: 'GET'
  }) as Promise<ResponseData<SaasMchInfoVo>>
}
/**
 * 获得系统字典信息
 */
export const userCommonInfoListSysDict = (params: {
  parentCode: string //
}) => {
  return request({
    url: '/saas-base-app/user/common/info/listSysDict',
    method: 'GET',
    params
  }) as Promise<ResponseData<Array<SysDictInfoVo>>>
}
/**
 * 获得SAAS字典信息
 */
export const userCommonInfoListSaasDict = (params: {
  parentCode: string //
}) => {
  return request({
    url: '/saas-base-app/user/common/info/listSaasDict',
    method: 'GET',
    params
  }) as Promise<ResponseData<Array<SysDictInfoVo>>>
}
/**
 * 列表Saas证件
 */
export const userCommonInfoListSaasCert = () => {
  return request({
    url: '/saas-base-app/user/common/info/listSaasCert',
    method: 'GET'
  }) as Promise<ResponseData<Array<SaasCertInfo>>>
}
/**
 * 列表商户证件
 */
export const userCommonInfoListMchCert = () => {
  return request({
    url: '/saas-base-app/user/common/info/listMchCert',
    method: 'GET'
  }) as Promise<ResponseData<Array<SaasMchCert>>>
}

/**
 * 系统公告
 */
export interface SysNoticeInfo {
  id?: number //主键ID
  accessType?: number //访问类型
  releaseType?: number //发布类型
  stick?: number //是否置顶 0 不置顶 1 置顶
  tags?: string //标签 用 , 分割
  title?: string //标题
  content?: string //公告内容
  viewNum?: number //点击数
  userId?: number //发布人
  userName?: string //发布人名称
  createDate?: string //创建时间
  releaseDate?: string //发布时间
  stickDate?: string //截止置顶时间
  expireDate?: string //过期时间
  modifyDate?: string //最后修改时间
  state?: number //状态
}
/**
 * 运营商公告
 */
export interface SaasNoticeInfo {
  id?: number //主键ID
  saasId?: number //运营商编号
  accessType?: number //访问类型
  releaseType?: number //发布类型
  stick?: number //是否置顶 0 不置顶 1 置顶
  tags?: string //标签 用 , 分割
  title?: string //标题
  content?: string //公告内容
  viewNum?: number //点击数
  userId?: number //发布人
  userName?: string //发布人名称
  createDate?: string //创建时间
  releaseDate?: string //发布时间
  stickDate?: string //截止置顶时间
  expireDate?: string //过期时间
  modifyDate?: string //最后修改时间
  state?: number //状态
}
/**
 * 系统公告列表查询参数
 */
export interface SysNoticeInfoQueryParam {
  id?: number //主键ID
  ids?: Array<number> //ID数组
  accessType?: number //访问类型
  releaseType?: number //发布类型
  stick?: number //是否置顶 0 不置顶 1 置顶
  stickRange?: Array<number> //是否置顶 0 不置顶 1 置顶范围
  tags?: string //标签 用 , 分割
  title?: string //标题
  viewNum?: number //点击数
  viewNumRange?: Array<number> //点击数范围
  userId?: number //发布人
  userName?: string //发布人名称
  createDateRange?: Array<string> //创建时间范围
  releaseDateRange?: Array<string> //发布时间范围
  stickDateRange?: Array<string> //截止置顶时间范围
  expireDateRange?: Array<string> //过期时间范围
  modifyDateRange?: Array<string> //最后修改时间范围
  state?: number //状态
  states?: Array<number> //状态数组
  stateGte?: number //大于等于状态
  stateLte?: number //小于等于状态
  $pg?: number //当前页码
  $rn?: number //每页条数
  $si?: number //起始位置
  $rt?: number //请求类型
  $sn?: Array<string> //排序名称
  $st?: Array<number> //排序类型
}
/**
 * 运营商公告列表查询参数
 */
export interface SaasNoticeInfoQueryParam {
  userId?: number //发布人
  id?: number //主键ID
  ids?: Array<number> //ID数组
  accessType?: number //访问类型
  releaseType?: number //发布类型
  stick?: number //是否置顶 0 不置顶 1 置顶
  stickRange?: Array<number> //是否置顶 0 不置顶 1 置顶范围
  tags?: string //标签 用 , 分割
  title?: string //标题
  viewNum?: number //点击数
  viewNumRange?: Array<number> //点击数范围
  userName?: string //发布人名称
  createDateRange?: Array<string> //创建时间范围
  releaseDateRange?: Array<string> //发布时间范围
  stickDateRange?: Array<string> //截止置顶时间范围
  expireDateRange?: Array<string> //过期时间范围
  modifyDateRange?: Array<string> //最后修改时间范围
  state?: number //状态
  states?: Array<number> //状态数组
  stateGte?: number //大于等于状态
  stateLte?: number //小于等于状态
  $pg?: number //当前页码
  $rn?: number //每页条数
  $si?: number //起始位置
  $rt?: number //请求类型
  $sn?: Array<string> //排序名称
  $st?: Array<number> //排序类型
}
/**
 * 运营商信息
 */
export interface SaasInfoVo {
  id?: number //主键ID
  saasName?: string //运营商名称
  saasLogo?: string //运营商logo
  orgType?: number //组织类型
  serviceType?: number //付费类型
  saasCurrency?: string //系统币种
  saasLang?: string //系统默认语言
  bdId?: number //招商负责人
  bdInfo?: string //招商负责人姓名
  opId?: number //运营负责人
  opInfo?: string //运营负责人姓名
  areaCode?: number //区域编码
  orgName?: string //机构名称
  orgDesc?: string //机构简介
  orgId?: string //机构号码
  orgAddress?: string //机构地址
  contactName?: string //公司联系人姓名
  contactPhone?: string //公司联系电话
  contactFax?: string //公司联系传真
  contactEmail?: string //公司联系邮箱
  contactMobile?: string //公司联系手机
  contactIm?: string //公司联系IM
  statsProductNum?: number //统计产品数
  statsOrderNum?: number //统计订单数
  statsOrderAmount?: number //统计订单额
  createDate?: string //创建时间
  modifyDate?: string //修改时间
  auditDate?: string //审核时间
  auditState?: number //审核状态
  lastLoginDate?: string //最后登录时间
  lastOrderDate?: string //最后下单时间
  state?: number //运营商状态
}
/**
 * 商户信息
 */
export interface SaasMchInfoVo {
  id?: number //主键ID
  saasId?: number //运营商编号
  mchType?: number //商户类型 1-供应商 2-分销商
  bdId?: number //关联业务员ID
  parentId?: number //上级ID
  agentId?: number //合伙人编号
  mchName?: string //商户名称
  orgName?: string //机构名称
  mchLang?: string //语种类型
  mchCurrency?: string //货币类型
  gradeLevel?: number //商户等级Id
  contactName?: string //商户联系人
  contactPhone?: string //商户联系电话
  contactMobile?: string //商户联系手机
  contactEmail?: string //商户联系邮箱
  contactAddress?: string //公司地址
  mchDesc?: string //商户介绍
  mchConfig?: string //商户资源
  statsOrder?: number //总订单量
  statsMoney?: number //总订单金额
  statsProduct?: number //总销售量
  createDate?: string //创建时间
  modifyDate?: string //修改时间
  state?: number //状态
}
/**
 * 系统字典
 */
export interface SysDictInfoVo {
  id?: number //主键
  saasId?: number //saasId
  parentId?: number //父级id
  dictCode?: string //字典项数值
  dictName?: string //字典项名称
  dictDesc?: string //字典项描述
  dictRank?: number //同一层级的排序
  createDate?: string //创建时间
  modifyDate?: string //修改日期
  state?: number //状态
}
/**
 * 运营商证件信息
 */
export interface SaasCertInfo {
  id?: number //主键ID
  saasId?: number //运营商编号
  certType?: string //证书类型
  certId?: string //证书编码
  certInfo?: string //证书信息
  certImg?: string //证书照片
  accessType?: number //访问类型
  startDate?: string //有效期开始时间
  endDate?: string //有效期结束时间
  createDate?: string //创建时间
  modifyDate?: string //修改日期
  auditState?: number //审批状态
  auditRemark?: string //审批信息
  auditUserId?: number //审批人ID
  auditUserInfo?: string //审批人信息
  auditDate?: string //审核时间
  state?: number //状态
}
/**
 * 商户证件信息
 */
export interface SaasMchCert {
  id?: number //主键ID
  saasId?: number //运营商编号
  mchId?: number //商户编号
  certType?: string //证书类型
  certId?: string //证书编码
  certInfo?: string //证书信息
  certImg?: string //证书照片
  accessType?: number //访问类型
  startDate?: string //有效期开始时间
  endDate?: string //有效期结束时间
  createDate?: string //创建时间
  modifyDate?: string //修改日期
  auditState?: number //审批状态
  auditUserId?: number //审批人ID
  auditUserInfo?: string //审批人信息
  auditRemark?: string //审批信息
  auditDate?: string //审核时间
  state?: number //状态
}
