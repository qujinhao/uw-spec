import { ResponseData, DataList } from '@/api/uwAuthCenterAuthApi'
import { ElMessage, ElMessageBox, type FormInstance } from 'element-plus'
import {
  reactive,
  ref,
  nextTick,
  type Ref,
  type UnwrapRef,
  type UnwrapNestedRefs
} from 'vue'
import { clone } from '@/utils/tool'
import { useI18n } from 'vue-i18n'

// 传入的参数类型  T: 新增编辑返回的数据类型 Promise<ResponseData<void>>
export interface paramsType<T, U> {
  listFn: () => Promise<ResponseData<DataList<T>>> // 返回一个列表接口
  saveFn?: () => Promise<ResponseData<T | void>> // 返回一个保存接口
  updateFn?: (remark?: string) => Promise<ResponseData<T | void>> // remark: 修改备注 返回一个修改接口
  deleteFn?: (params: U) => Promise<ResponseData<string | number | T | void>> // 返回一个删除接口
  listSuccessCallback?: (data: DataList<T>) => void // 列表请求成功回调
  listErrorCallback?: () => void // 列表请求失败回调
  saveSuccessCallback?: (data: T) => void // 保存成功调用函数
  saveErrorCallback?: () => void // 保存失败调用函数
  updateSuccessCallback?: (data: T) => void // 修改成功调用函数
  updateErrorCallback?: () => void // 修改失败调用函数
  deleteSuccessCallback?: () => void // 删除成功调用函数
  deleteErrorCallback?: () => void // 删除失败调用函数
  openSaveDialogCallback?: () => void // 打开新增弹窗回调函数，可做特殊处理
  openUpdateDialogCallback?: () => void // 打开编辑弹窗回调函数，可做特殊处理
  submitDialogCallback?: () => void // 点击弹窗的确认按钮进行其他逻辑分流
  resetDialogCallback?: () => void // 关闭弹窗的回调，可做特殊处理
}

// 扩展属性
export interface expandParamsType {
  openUpdateRemark?: boolean // 开启修改时增加备注填写，填写完毕才发起请求
  openDeleteRemark?: boolean // 开启删除时增加备注填写，填写完毕才发起请求
  isCombinedFetch?: boolean // 是否开启完整请求，默认不开启，开启后，会请求全部数据，并返回总数量，默认为false
  dialogSubTitleField?: string // 弹窗副标题字段
}

// 基本分页
export interface baseListType {
  state?: number //状态
  $pg?: number //当前页码
  $rn?: number //每页条数
  $si?: number //起始位置
  $rt?: number //请求类型
  $sn?: Array<string> //排序名称
  $st?: Array<number> //排序类型
  stateGte?: number // 取state >=0
}

// 弹窗相关配置属性
export interface dialogConfigType<T> {
  dialogLoading: boolean // 弹窗过渡效果显示
  dialogShow: boolean // 新增、编辑弹窗显示
  dialogType: number // 弹窗打开操作类型 默认 0 新增  1 编辑  其余类型自定义
  dialogTitle: string // 弹窗标题
  dialogFormData: Partial<T> // 绑定的表单数据
}

// 表格配置相关属性
export interface tableConfigType<T, Q> {
  queryParams: Partial<baseListType & Q> // 请求参数，包含基本的分页参数以及传进来的泛型
  tableLoading: boolean // 表格加载过渡loading效果
  sizeAll: number // 表格总数
  dataList: T[] // 表格数据源
}

// 返回的类型
export interface returnType<T, Q, U> {
  tableConfig: UnwrapNestedRefs<tableConfigType<T, Q>> // 表格相关属性, 具体查看接口类型tableConfigType
  dialogConfig: UnwrapNestedRefs<dialogConfigType<T>> // 弹窗相关属性, 具体查看接口类型dialogConfigType
  dialogFormRef: Ref<FormInstance> // 表单ref元素
  handleList: (queryPageInfo?: boolean) => void // 列表请求函数  queryPageInfo为true则还需要请求分页数据
  handleSave: () => void // 保存函数
  handleUpdate: () => void // 编辑函数
  handleDelete: (params: U) => void // 删除函数
  handleOpenSaveDialog: () => void // 点击新增按钮,打开新增弹窗
  handleOpenUpdateDialog: (editInfo: T) => void // 点击编辑按钮,打开编辑弹窗
  handleResetDialog: () => void //重置弹窗表单数据
  handleSubmitDialog: () => void // 点击点击弹窗的确认按钮,提交表单
}

/**
 * 基本表达那增删改查hooks
 * @param params 值查看paramsType，泛型<T：新增编辑返回的数据类型, Q: 列表请求参数类型
 * @returns 返回参数查看returnType类型
 */
export const useCrud = <
  T extends Record<string, any>,
  Q extends Record<string, any>,
  U = any
>(
  params: paramsType<T, U>,
  expandParams?: expandParamsType
): returnType<T, Q, U> => {
  const { t } = useI18n()

  const {
    listFn,
    saveFn,
    updateFn,
    deleteFn,
    listSuccessCallback,
    listErrorCallback,
    saveSuccessCallback,
    saveErrorCallback,
    updateSuccessCallback,
    updateErrorCallback,
    deleteSuccessCallback,
    deleteErrorCallback,
    openSaveDialogCallback,
    openUpdateDialogCallback,
    submitDialogCallback,
    resetDialogCallback
  } = params

  // 表格配置
  const tableConfig = reactive<tableConfigType<T, Q>>({
    tableLoading: false,
    sizeAll: 0,
    dataList: [],
    queryParams: {
      $pg: 1, // 默认1页
      $rn: 20, // 默认20条
      $rt: 2, // 默认获取全部数据
      $sn: ['id'], // 排序名称
      $st: 2, // 默认倒叙
      stateGte: 0
    } as Partial<baseListType & Q>
  })

  // 表单ref元素
  const dialogFormRef = ref<FormInstance>() as Ref<FormInstance>
  // 弹窗属性
  const dialogConfig = reactive<dialogConfigType<T>>({
    dialogLoading: false,
    dialogShow: false,
    dialogType: 0,
    dialogTitle: '新增',
    dialogFormData: {} as Partial<T>
  })

  // 列表获取数据  张总要求（2025.5.30)   虽然很难受，但并非我本意
  const handleList = (queryPageInfo = true) => {
    // 是否是ES数据列表
    if (expandParams && expandParams.isCombinedFetch) {
      handleListByCompleteData()
    } else {
      handleListData(queryPageInfo)
    }
  }

  // 首次请求，分成请求2次，第一次请求获取总条数 $rt=0，第二次请求获取数据 $rt=1   张总要求（2025.5.30）
  // 只请求数据
  const handleListData = (queryPageInfo: boolean) => {
    tableConfig.tableLoading = true
    // @ts-expect-error
    tableConfig.queryParams.$rt = 1
    listFn()
      .then(res => {
        if (res.state === 'success' && res.data) {
          tableConfig.dataList = (res.data?.results || []) as UnwrapNestedRefs<
            T[]
          >
          listSuccessCallback &&
            listSuccessCallback(clone<DataList<T>>(res.data))
          // 判断是否需要请求分页数据
          if (queryPageInfo) {
            if (tableConfig.dataList?.length) {
              // 如果数据长度小于结果集长度，直接使用数据长度作为allSize，否则去数据库count
              if (
                res.data.startIndex === 0 &&
                res.data!.size! < res.data!.resultNum!
              ) {
                tableConfig.sizeAll = res.data!.size!
              } else {
                handleListPage()
              }
            } else {
              tableConfig.sizeAll = 0
            }
          }
        } else {
          tableConfig.sizeAll = 0
          tableConfig.dataList = []
          listErrorCallback && listErrorCallback()
        }
        tableConfig.tableLoading = false
      })
      .catch(() => {
        tableConfig.tableLoading = false
        tableConfig.dataList = []
        tableConfig.sizeAll = 0
      })
  }

  // 只请求条数
  const handleListPage = () => {
    // @ts-expect-error
    tableConfig.queryParams.$rt = 0
    listFn()
      .then(res => {
        tableConfig.sizeAll = res.data?.sizeAll || 0
      })
      .catch(() => {
        tableConfig.sizeAll = 0
      })
  }

  // 后续请求，直接请求数据、条数 $rt=2（内置逻辑判断，处理$rt）
  const handleListByCompleteData = () => {
    tableConfig.tableLoading = true
    // @ts-expect-error
    tableConfig.queryParams.$rt = 2
    listFn()
      .then(res => {
        if (res.state === 'success' && res.data) {
          tableConfig.dataList = (res.data?.results || []) as UnwrapNestedRefs<
            T[]
          >
          listSuccessCallback &&
            listSuccessCallback(clone<DataList<T>>(res.data))
        } else {
          tableConfig.dataList = []
          listErrorCallback && listErrorCallback()
        }
        // 张总要求（2025.6.10）
        // esDataList页面由于分页数据有限制，数量会限制10000条，因此超过10000条数据时，将sizeAll设置为10000，其余显示正常对应条数
        if (res.data?.sizeAll) {
          if (res.data.sizeAll > 10000) {
            tableConfig.sizeAll = 10000
          } else {
            tableConfig.sizeAll = res.data.sizeAll
          }
        } else {
          tableConfig.sizeAll = 0
        }
        tableConfig.tableLoading = false
      })
      .catch(() => {
        tableConfig.tableLoading = false
      })
  }

  // 新增函数
  const handleSave = () => {
    if (saveFn) {
      dialogConfig.dialogLoading = true
      saveFn()
        .then(res => {
          if (res.state === 'success') {
            ElMessage.success(res.msg || '新增成功')
            handleList()
            dialogConfig.dialogShow = false
            // 新增成功回调
            saveSuccessCallback && saveSuccessCallback(res.data as T)
          } else {
            ElMessage.error(res.msg)
            // 新增失败回调
            saveErrorCallback && saveErrorCallback()
          }
          dialogConfig.dialogLoading = false
        })
        .catch(() => {
          dialogConfig.dialogLoading = false
        })
    }
  }

  // 编辑函数
  const handleUpdate = () => {
    if (updateFn) {
      // 存在编辑函数
      if (expandParams && expandParams.openUpdateRemark) {
        // 扩展属性存在且开启编辑需填写备注
        updateNeedRemarkFn()
      } else {
        // 默认编辑请求，不需要填写备注
        updateUnNeedRemarkFn()
      }
    }
  }

  // 编辑时需要填写备注的请求
  const updateNeedRemarkFn = () => {
    if (updateFn) {
      ElMessageBox.prompt(t('pleaseInput') + '修改说明', '提示', {
        type: 'warning',
        confirmButtonText: t('confirm'),
        cancelButtonText: t('cancel'),
        inputValidator: (value: string) => {
          if (value) {
            return true
          }
          return false
        },
        inputErrorMessage: t('pleaseInput') + '修改说明',
        inputType: 'textarea'
      })
        .then(({ value }) => {
          dialogConfig.dialogLoading = true
          updateFn(value)
            .then(res => {
              if (res.state === 'success') {
                ElMessage.success(res.msg || '编辑成功')
                handleList()
                dialogConfig.dialogShow = false
                // 编辑成功回调
                updateSuccessCallback && updateSuccessCallback(res.data as T)
              } else {
                ElMessage.error(res.msg)
                // 编辑失败回调
                updateErrorCallback && updateErrorCallback()
              }
              dialogConfig.dialogLoading = false
            })
            .catch(() => {
              dialogConfig.dialogLoading = false
            })
        })
        .catch(() => {
          ElMessage({
            type: 'info',
            message: '操作取消'
          })
        })
    }
  }

  // 编辑时不需要填写备注，默认编辑请求
  const updateUnNeedRemarkFn = () => {
    if (updateFn) {
      dialogConfig.dialogLoading = true
      updateFn()
        .then(res => {
          if (res.state === 'success') {
            ElMessage.success('编辑成功')
            handleList()
            dialogConfig.dialogShow = false
            // 编辑成功回调
            updateSuccessCallback && updateSuccessCallback(res.data as T)
          } else {
            ElMessage.error(res.msg)
            // 编辑失败回调
            updateErrorCallback && updateErrorCallback()
          }
          dialogConfig.dialogLoading = false
        })
        .catch(() => {
          dialogConfig.dialogLoading = false
        })
    }
  }

  // 删除函数
  const handleDelete = (params: U) => {
    if (deleteFn) {
      // 存在删除函数
      if (expandParams && expandParams.openDeleteRemark) {
        // 扩展属性存在且开启删除需填写备注
        deleteNeedRemarkFn(params)
      } else {
        // 默认删除请求，不需要填写备注
        deleteUnNeedRemarkFn(params)
      }
    }
  }

  // 删除时需要填写备注的请求
  const deleteNeedRemarkFn = (params: U) => {
    if (deleteFn) {
      ElMessageBox.prompt(t('pleaseInput') + '删除说明', '提示', {
        type: 'warning',
        confirmButtonText: t('confirm'),
        cancelButtonText: t('cancel'),
        inputValidator: (value: string) => {
          if (value) {
            return true
          }
          return false
        },
        inputErrorMessage: t('pleaseInput') + '删除说明',
        inputType: 'textarea'
      })
        .then(({ value }) => {
          tableConfig.tableLoading = true
          const deleteQueryParams = {
            ...params,
            remark: value
          }
          deleteFn(deleteQueryParams)
            .then(res => {
              if (res.state === 'success') {
                ElMessage.success(res.msg || '删除成功')
                handleList()
                // 删除成功回调
                deleteSuccessCallback && deleteSuccessCallback()
              } else {
                ElMessage.error(res.msg)
                // 删除失败回调
                deleteErrorCallback && deleteErrorCallback()
              }
              tableConfig.tableLoading = false
            })
            .catch(() => {
              tableConfig.tableLoading = false
            })
        })
        .catch(() => {
          ElMessage({
            type: 'info',
            message: '操作取消'
          })
        })
    }
  }

  // 删除时不需要填写备注的请求
  const deleteUnNeedRemarkFn = (params: U) => {
    if (deleteFn) {
      ElMessageBox.confirm('确认删除该项数据？', '警告', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(() => {
          tableConfig.tableLoading = true
          deleteFn(params)
            .then(res => {
              if (res.state === 'success') {
                ElMessage.success(res.msg || '删除成功')
                handleList()
                // 删除成功回调
                deleteSuccessCallback && deleteSuccessCallback()
              } else {
                ElMessage.error(res.msg)
                // 删除失败回调
                deleteErrorCallback && deleteErrorCallback()
              }
              tableConfig.tableLoading = false
            })
            .catch(() => {
              tableConfig.tableLoading = false
            })
        })
        .catch(() => {
          ElMessage({
            type: 'info',
            message: '操作取消'
          })
        })
    }
  }

  // 点击新增按钮
  const handleOpenSaveDialog = () => {
    dialogConfig.dialogType = 0
    dialogConfig.dialogShow = true
    dialogConfig.dialogTitle = '新增'
    // 点击新增回调
    openSaveDialogCallback && openSaveDialogCallback()
  }

  // 点击编辑按钮
  const handleOpenUpdateDialog = (editInfo: T) => {
    dialogConfig.dialogType = 1
    dialogConfig.dialogShow = true
    nextTick(() => {
      // 赋值
      Object.keys(editInfo).forEach(key => {
        dialogConfig.dialogFormData[key as keyof UnwrapRef<Partial<T>>] =
          editInfo[key]
      })
      if (
        expandParams &&
        expandParams.dialogSubTitleField &&
        expandParams.dialogSubTitleField in editInfo
      ) {
        // 存在子标题字段
        dialogConfig.dialogTitle = `编辑#${
          (dialogConfig.dialogFormData as Record<string, any>)?.id
        }~${editInfo[expandParams.dialogSubTitleField]}`
      } else {
        dialogConfig.dialogTitle = `编辑#${
          (dialogConfig.dialogFormData as Record<string, any>)?.id
        }`
      }

      // 点击编辑回调
      openUpdateDialogCallback && openUpdateDialogCallback()
    })
  }

  // 点击弹窗的确认，对表单进行检验，判断是新增、修改或者是其他
  const handleSubmitDialog = () => {
    dialogFormRef.value?.validate(valid => {
      if (valid) {
        if (dialogConfig.dialogType === 0) handleSave()
        if (dialogConfig.dialogType === 1) handleUpdate()
        submitDialogCallback && submitDialogCallback()
      }
    })
  }

  // 重置弹窗表单form
  const handleResetDialog = () => {
    dialogFormRef.value?.resetFields()
    resetDialogCallback && resetDialogCallback()
  }

  return {
    tableConfig,
    dialogFormRef,
    dialogConfig,
    handleList,
    handleSave,
    handleUpdate,
    handleDelete,
    handleOpenSaveDialog,
    handleOpenUpdateDialog,
    handleResetDialog,
    handleSubmitDialog
  }
}
