<script lang="ts" setup>
// 活动倒计时
import { ref, computed, watch, onBeforeUnmount } from 'vue'
import { cmpStyle, unit } from '../utils/registerBaseStyle'

const props = withDefaults(
  defineProps<{
    attrs: {
      text?: string
      startTime?: string
      endTime?: string
      currentTime?: string
    }
    styles: {
      isTitle?: boolean
      model?: string
      location?: string
      paddingLeft?: number
      paddingRight?: number
      paddingTop?: number
      paddingBottom?: number
      containerRadius?: number
      titleColor?: string
      timeColor?: string
      backgroundColor?: string
      width?: number | string
      height?: number | string
    }
  }>(),
  {
    attrs: () => ({}),
    styles: () => ({})
  }
)
const mergedAttrs = computed(() => ({
  text: '活动名',
  startTime: '2021-01-01 00:00:00',
  endTime: '2022-01-01 00:00:00',
  ...props.attrs
}))

const mergedStyles = computed(() => ({
  isTitle: true,
  model: 'one',
  location: 'left',
  paddingLeft: 0,
  paddingRight: 0,
  paddingTop: 0,
  paddingBottom: 0,
  containerRadius: 0,
  titleColor: '#000000',
  timeColor: '#000000',
  backgroundColor: '',
  ...props.styles
}))
const status = ref<'unStart' | 'ongoing' | 'end'>('unStart')
const diff = ref(0)
const timer = ref<number | null>(null)

const day = computed(() => Math.floor(diff.value / 1000 / 3600 / 24))
const hour = computed(() => {
  if (day.value > 0) {
    return Math.floor(diff.value / 1000 / 3600) - day.value * 24
  } else {
    return Math.floor(diff.value / 1000 / 3600)
  }
})
const minutes = computed(() => Math.floor(diff.value / 1000 / 60) % 60)
const seconds = computed(() => Math.floor(diff.value / 1000) % 60)

const countdownStyle = computed(() => ({
  width: unit(mergedStyles.value.width),
  height: unit(mergedStyles.value.height),
  boxSizing: 'border-box' as const,
  paddingLeft: unit(mergedStyles.value.paddingLeft),
  paddingRight: unit(mergedStyles.value.paddingRight),
  paddingTop: unit(mergedStyles.value.paddingTop),
  paddingBottom: unit(mergedStyles.value.paddingBottom),
  borderRadius: unit(mergedStyles.value.containerRadius),
  backgroundColor: mergedStyles.value.backgroundColor || undefined
}))

// 时间补零格式化
const timeFormat = (value: number) => {
  const str = value + ''
  if (str.length === 1) {
    return `0${str}`
  }
  return str
}

// 倒计时处理
const countdownHandle = () => {
  // 立即执行一次
  diffTimeHandle()
  // 定时循环执行
  timer.value = setInterval(diffTimeHandle, 1000) as unknown as number
}

const diffTimeHandle = () => {
  diff.value -= 1000

  if (diff.value <= 1000) {
    if (timer.value) {
      clearTimeout(timer.value)
      timer.value = null
    }
  }
}

const getWrapStyle = () => {
  return {
    ...cmpStyle(mergedStyles.value),
    justifyContent:
      mergedStyles.value.location === 'left'
        ? 'flex-start'
        : mergedStyles.value.location === 'right'
          ? 'flex-end'
          : 'center'
  }
}

const getLabelStyle = () => {
  return {
    color: mergedStyles.value.titleColor
  }
}

const getItemStyle = () => {
  const styleObj: Record<string, string> = {
    background: mergedStyles.value.timeColor || ''
  }

  if (mergedStyles.value.model === 'two') {
    styleObj.padding = '10rpx 10rpx'
  }

  return styleObj
}

watch(
  () => mergedAttrs.value,
  () => {
    if (timer.value) {
      clearTimeout(timer.value)
      timer.value = null
    }

    const startDate = new Date(mergedAttrs.value.startTime || '')
    const endDate = new Date(mergedAttrs.value.endTime || '')
    const now = mergedAttrs.value.currentTime
      ? new Date(mergedAttrs.value.currentTime)
      : new Date()
    const startUni = Math.floor(startDate.getTime() / 1000)
    const endUni = Math.floor(endDate.getTime() / 1000)
    const nowUni = Math.floor(now.getTime() / 1000)

    // 活动还未到开始时间
    if (nowUni < startUni) {
      status.value = 'unStart'
      countdownHandle()
      diff.value = startDate.getTime() - now.getTime()
    }
    // 活动正在进行中
    else if (startUni <= nowUni && nowUni < endUni) {
      status.value = 'ongoing'
      countdownHandle()
      diff.value = endDate.getTime() - now.getTime()
    }
    // 活动已结束
    else {
      status.value = 'end'
      if (timer.value) {
        clearTimeout(timer.value)
        timer.value = null
      }
    }
  },
  { immediate: true, deep: true }
)

onBeforeUnmount(() => {
  if (timer.value) {
    clearTimeout(timer.value)
  }
})
</script>

<template>
  <view :style="countdownStyle">
    <view
      class="m-countdown"
      :style="[getWrapStyle()]"
    >
      <!-- 标题 -->
      <view
        class="m-countdown-label"
        :style="[getLabelStyle()]"
        v-if="mergedStyles.isTitle"
      >
        <text v-if="status == 'unStart'">距{{ mergedAttrs.text }}开始</text>
        <text v-if="status == 'ongoing'">距{{ mergedAttrs.text }}结束</text>
        <text v-if="status == 'end'">{{ mergedAttrs.text }}已经结束</text>
      </view>

      <!-- 倒计时 -->
      <view v-if="status != 'end'">
        <!-- 样式1 -->
        <view
          v-if="['one', 'two'].includes(mergedStyles.model || '')"
          style="display: flex; font-size: 24rpx"
        >
          <text v-if="day">
            <p
              class="block-time"
              :style="[getItemStyle()]"
            >
              {{ timeFormat(day) }}
            </p>
            天 :
          </text>
          <text>
            <p
              class="block-time"
              :style="[getItemStyle()]"
            >
              {{ timeFormat(hour) }}
            </p>
            :
          </text>
          <text>
            <p
              class="block-time"
              :style="[getItemStyle()]"
            >
              {{ timeFormat(minutes) }}
            </p>
            :
          </text>
          <text>
            <p
              class="block-time"
              :style="[getItemStyle()]"
            >
              {{ timeFormat(seconds) }}
            </p>
          </text>
        </view>

        <!-- 样式2 -->
        <view
          v-if="mergedStyles.model == 'three'"
          style="font-size: 26rpx"
        >
          <text style="margin-left: 6rpx; margin-right: 6rpx">
            <text
              class="m-countdown-label-time"
              :style="{ color: mergedStyles.timeColor }"
            >
              {{ timeFormat(hour) }}
            </text>
            时
          </text>
          <text style="margin-right: 6rpx">
            <text
              class="m-countdown-label-time"
              :style="{ color: mergedStyles.timeColor }"
            >
              {{ timeFormat(minutes) }}
            </text>
            分
          </text>
          <text>
            <text
              class="m-countdown-label-time"
              :style="{ color: mergedStyles.timeColor }"
            >
              {{ timeFormat(seconds) }}
            </text>
            秒
          </text>
        </view>
      </view>
    </view>
  </view>
</template>

<style lang="scss" scoped>
@import './style/index.scss';
</style>
