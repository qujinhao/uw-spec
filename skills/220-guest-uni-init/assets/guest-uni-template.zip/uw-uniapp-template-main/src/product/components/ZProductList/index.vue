<script lang="ts" setup>
import type { ProductInfo } from '@/api/saasMallAppGuestApi'
import { onMounted } from 'vue'
import { getProductSingleImg } from '@/utils/tool'

const props = withDefaults(
  defineProps<{
    data: ProductInfo[]
  }>(),
  {
    data: () => []
  }
)

const emits = defineEmits<{
  (e: 'click', item: ProductInfo): void
}>()

onMounted(() => {
  // console.log('ZProductList ---')
})
</script>

<template>
  <div class="z-product-list">
    <div
      v-for="item in props.data"
      :key="item.id"
      class="product"
      @click="emits('click', item)"
    >
      <div class="product-image">
        <image
          class="img"
          mode="widthFix"
          :src="getProductSingleImg(item.imgMain)"
        />
      </div>
      <div class="p-[18rpx_20rpx]">
        <div class="line-clamp-2 font-bold text-[#303133]">
          {{ item.productName }}
        </div>
        <div class="flex flex-wrap gap-[8rpx]">
          <span
            class="bg-primary-bg border text-primary flex h-[26rpx] items-center rounded-[10rpx] p-[0_10rpx] text-[24rpx] leading-[24rpx]"
            v-for="tag in item.tagIds?.split(',')"
            :key="tag"
          >
            {{ tag }}
          </span>
        </div>
        <!-- <div class="mt-auto flex items-center gap-[2px] text-[#B6BBC1]">
          <span class="text-[24px] leading-[28px]">
            {{ $t('button.rise') }}
          </span>
          <div class="text-[#FF6100]">
            {{ $t('currency') }}
            <span class="font-bold">{{ item.productUnitCode }}</span>
          </div>
        </div> -->
      </div>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.z-product-list {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  padding: 0 30rpx;
  gap: 20rpx;
}
.product {
  width: 48%;
  box-sizing: border-box;
  border-radius: 20rpx;
  &:nth-child(n + 3) {
    margin-top: 2%;
  }
  .product-image {
    margin-bottom: 12rpx;
    .img {
      width: 100%;
      // height: 320rpx;
      border-radius: 20rpx;
    }
  }
}
</style>
