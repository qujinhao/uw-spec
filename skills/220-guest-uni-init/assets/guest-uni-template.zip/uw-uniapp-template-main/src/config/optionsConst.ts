export const TypeAddressOptions = [
  { label: '正常', value: 0 },
  { label: '默认', value: 1 }
]

export const TypeTagParentOptions = [
  { label: '门票', value: 'TICKET' },
  { label: '酒店', value: 'HOTEL' }
]

export const StateOrderOptions = [
  { label: '初始状态', value: 0 },
  { label: '新订单', value: 10 },
  { label: '已审核', value: 11 },
  { label: '下单失败', value: 19 },
  { label: '支付中', value: 20 },
  { label: '支付成功', value: 21 },
  { label: '支付超时', value: 28 },
  { label: '支付失败', value: 29 },
  { label: '预定中', value: 30 },
  { label: '已确认', value: 31 },
  { label: '已拒单', value: 39 },
  { label: '取消审核中', value: 40 },
  { label: '允许取消', value: 41 },
  { label: '已取消', value: 42 },
  { label: '订单超时取消', value: 47 },
  { label: '取消失败', value: 49 },
  { label: '开始退款', value: 50 },
  { label: '退款成功', value: 51 },
  { label: '退款失败', value: 59 },
  { label: '发货中', value: 60 },
  { label: '已发货', value: 61 },
  { label: '已签收', value: 62 },
  { label: '发货失败', value: 69 },
  { label: '预约中', value: 70 },
  { label: '预约成功', value: 71 },
  { label: '订单离线', value: 76 },
  { label: '预约失败', value: 79 },
  { label: '核销中', value: 90 },
  { label: '核销完毕', value: 91 },
  { label: '核销失败', value: 99 }
]

export const StateGuestAccountOptions = [
  { label: '正常', value: 1 },
  { label: '冻结', value: 0 },
  { label: '删除', value: -1 }
]

export const TypeGuestDataOptions = [
  { label: '姓名', value: 1 },
  { label: '英语名', value: 2 },
  { label: '英语姓', value: 3 },
  { label: '性别', value: 4 },
  { label: '出生日期', value: 5 },
  { label: '出生地(省份)', value: 6 },
  { label: '国家/地区', value: 7 },
  { label: '身高（cm）', value: 8 },
  { label: '体重（kg）', value: 9 },
  { label: '电话', value: 10 },
  { label: '联系电话区号', value: 11 },
  { label: '地址', value: 12 },
  { label: '邮箱', value: 13 },
  { label: '证件签发日期', value: 14 },
  { label: '证件有效期', value: 15 }
]

export const TypeLimitUnitOptions = [
  { label: '次', value: 0 },
  { label: '张', value: 1 }
]

export const SaasMallResponseCodeOptions = [
  {
    label: '用户名或密码不能为空！',
    value: 'saas.mall.app.account.info.login'
  },
  { label: '邮箱为空', value: 'saas.mall.app.account.info.registry.email' },
  {
    label: '邮箱验证码为空！',
    value: 'saas.mall.app.account.info.registry.code'
  },
  {
    label: '手机号格式不正确！',
    value: 'saas.mall.app.account.info.registry.mobile'
  },
  {
    label: '注册失败！',
    value: 'saas.mall.app.account.info.registry.result.fail'
  },
  {
    label: '此手机号已被绑定,请直接登录！',
    value: 'saas.mall.app.account.info.registry.phone.check.fail'
  },
  {
    label: '此电子邮箱已被绑定,请直接登录！',
    value: 'saas.mall.app.account.info.registry.email.check.fail'
  },
  {
    label: '邮箱和手机号不能都为空！',
    value: 'saas.mall.app.account.info.registry.check.fail'
  },
  {
    label: '用户名不正确！',
    value: 'saas.mall.app.account.reset.password.user.not.found'
  },
  {
    label: '账号已被冻结！',
    value: 'saas.mall.app.account.reset.password.account.frozen'
  },
  {
    label: '与当前使用的密码一致，请重新输入！',
    value: 'saas.mall.app.account.reset.password.duplicate.password'
  },
  { label: '查询用户异常！', value: 'saas.mall.app.account.info.change.user' },
  {
    label: '密码错误！',
    value: 'saas.mall.app.account.info.change.password.fail'
  },
  {
    label: '账号已注销！',
    value: 'saas.mall.app.account.logoff.account.already.deactivated'
  },
  { label: '密码错误！', value: 'saas.mall.app.account.logoff.password.error' },
  {
    label: '用户登录系统错误！',
    value: 'saas.mall.app.account.login.exception'
  },
  { label: '用户未注册！', value: 'saas.mall.app.account.login.unregistered' },
  { label: '用户不存在！', value: 'saas.mall.app.account.login.unavailable' },
  {
    label: '用户名或密码不正确！',
    value: 'saas.mall.app.account.login.incorrect'
  },
  { label: '登录API调用异常！', value: 'saas.mall.app.account.api.error' },
  {
    label: '未找到指定ID的用户信息！',
    value: 'saas.mall.app.user.info.not.found'
  },
  {
    label: '用户账号存在交易订单，不可删除！',
    value: 'saas.mall.app.account.logoff.error'
  },
  { label: '产品不存在！', value: 'saas.mall.app.product.not.found' },
  {
    label: '产品[%s]日历库存不足！',
    value: 'saas.mall.app.product.calendar.stock.not.enough'
  },
  {
    label: '产品[%s]总库存不足！',
    value: 'saas.mall.app.product.stock.not.enough'
  },
  {
    label: '产品[%s]场次库存不足！',
    value: 'saas.mall.app.product.session.stock.not.enough'
  },
  { label: 'sku类型错误！', value: 'saas.mall.app.sku.type.error' },
  {
    label: '该日期商品不存在！',
    value: 'saas.mall.app.product.price.not.found'
  },
  {
    label: '该订单已存在申请变更！',
    value: 'saas.mall.app.already.exist.apply.change'
  },
  { label: '找不到订单详情！', value: 'saas.mall.app.order.detail.not.found' },
  {
    label: '找不到订单凭证！',
    value: 'saas.mall.app.order.credential.not.found'
  },
  { label: '退票数量超出限制！', value: 'saas.mall.app.refund.num.over.limit' },
  { label: '退票数量不正确！', value: 'saas.mall.app.invalid.refund.quantity' },
  {
    label: '该商品不支持退改！',
    value: 'saas.mall.app.product.not.support.refund.change'
  },
  {
    label: '该商品不支持改！',
    value: 'saas.mall.app.product.not.support.modify'
  },
  { label: '保存订单失败！', value: 'saas.mall.app.failed.to.save.the.order' },
  {
    label: '订单详情保存出错！',
    value: 'saas.mall.app.failed.to.save.the.order.detail'
  },
  {
    label: '订单游客信息保存失败！',
    value: 'saas.mall.app.failed.to.save.the.order.guest'
  },
  {
    label: '退款申请保存失败！',
    value: 'saas.mall.app.failed.to.save.the.order.change'
  },
  {
    label: '商城订单不存在，订单ID: [%s]',
    value: 'saas.mall.app.order.not.exist'
  },
  {
    label: '商城订单状态异常，订单ID:[%s]',
    value: 'saas.mall.app.order.status.error'
  },
  { label: '参数错误', value: 'saas.mall.app.params.error' },
  {
    label: '预定数量不能小于最小值',
    value: 'saas.mall.app.booking.quantity.min.limit'
  },
  {
    label: '预定数量不能大于最大值',
    value: 'saas.mall.app.booking.quantity.max.limit'
  },
  {
    label: '游玩日期超过最大可预定天数',
    value: 'saas.mall.app.travel.date.over.max.days'
  },
  { label: '年龄必须大于最小值', value: 'saas.mall.app.age.min.limit' },
  { label: '年龄必须小于最大值', value: 'saas.mall.app.age.max.limit' },
  { label: '身份证超过购买张数', value: 'saas.mall.app.id.quantity.limit' },
  { label: '身份证超过购买次数', value: 'saas.mall.app.id.frequency.limit' },
  { label: '手机超过购买张数', value: 'saas.mall.app.phone.quantity.limit' },
  { label: '手机超过购买次数', value: 'saas.mall.app.phone.frequency.limit' },
  { label: '用户性别不符合', value: 'saas.mall.app.user.gender.mismatch' },
  {
    label: '用户不在包含区域中',
    value: 'saas.mall.app.user.not.in.included.region'
  },
  { label: '用户在排除区域中', value: 'saas.mall.app.user.in.excluded.region' },
  { label: '超过场次限购数量', value: 'saas.mall.app.session.quantity.limit' },
  {
    label: '该时间段内，该商品已售完',
    value: 'saas.mall.app.time.slot.sold.out'
  },
  {
    label: '不在每日售卖时间内',
    value: 'saas.mall.app.daily.sale.time.not.in'
  },
  { label: '不在销售时间范围内', value: 'saas.mall.app.sale.period.not.in' },
  {
    label: '超过当天可预定时间',
    value: 'saas.mall.app.daily.booking.time.over'
  },
  { label: '支付配置ID错误！', value: 'saas.mall.app.payment.config.id.error' },
  { label: '支付金额错误！', value: 'saas.mall.app.the.payment.amount.error' },
  { label: '货币代码错误！', value: 'saas.mall.app.currency.error' },
  { label: '处理中，请稍等', value: 'saas.mall.app.under.processing' }
]

export const AuthErrorTypeOptions = [
  { label: '登录类型不合法! ', value: 'AUTH-0001' },
  { label: '用户类型错误! ', value: 'AUTH-0002' },
  { label: '用户名或密码不能为空! ', value: 'AUTH-0003' },
  { label: '登录标识[%s]未在系统中注册! ', value: 'AUTH-0004' },
  { label: '登录代理信息丢失! ', value: 'AUTH-0005' },
  { label: '用户信息不存在! ', value: 'AUTH-0010' },
  { label: '用户名或密码错误! ', value: 'AUTH-0011' },
  { label: '用户状态错误! ', value: 'AUTH-0012' },
  { label: '用户权限加载错误! ', value: 'AUTH-0013' },
  { label: '用户权限状态错误! ', value: 'AUTH-0014' },
  { label: 'SAAS权限加载错误! ', value: 'AUTH-0015' },
  { label: 'SAAS权限状态错误! ', value: 'AUTH-0016' },
  { label: '原密码错误! ', value: 'AUTH-0020' },
  { label: '用户重置密码失败! ', value: 'AUTH-0021' },
  { label: 'API调用失败! ', value: 'AUTH-0022' }
]

export const LockStateOrderInfoOptions = [
  { label: '锁定订单', value: 0 },
  { label: '解锁订单', value: 1 }
]

export const TypeOrderChangeOptions = [
  { label: '退票', value: 0 },
  { label: '改签', value: 1 }
]

export const TypePoiOptions = [
  { label: '景区', value: 0 },
  { label: '酒店', value: 1 }
]

export const TypeGenderOptions = [
  { label: '男', value: 0 },
  { label: '女', value: 1 }
]

export const TypeOrderLogOptions = [
  { label: '系统备注', value: 0 },
  { label: '游客备注', value: 1 },
  { label: '供应商备注', value: 2 },
  { label: '分销商备注', value: 3 },
  { label: '运营商备注', value: 5 }
]

export const TypeAuthOptions = [
  { label: '删除', value: 0 },
  { label: '新增', value: 1 },
  { label: '变更', value: 2 }
]

export const TypeIdPrefixOptions = [
  { label: '包含', value: 0 },
  { label: '排除', value: 1 }
]

export const TypeSaleShareOptions = [
  { label: '是', value: 0 },
  { label: '否', value: 1 }
]

export const TypeCodeOptions = [
  { label: '数字码', value: 1 },
  { label: '二维码', value: 2 },
  { label: 'PDF', value: 3 },
  { label: '字符码', value: 4 },
  { label: '组合码', value: 5 }
]

export const TypeCancelOptions = [
  { label: '不允许取消', value: -1 },
  { label: '随时取消[不支持部分退]', value: 1 },
  { label: '随时取消[支持部分退]', value: 2 },
  { label: '条件取消[不支持部分退]', value: 3 },
  { label: '条件取消[支持部分退]', value: 4 },
  { label: '只允许改', value: 5 }
]

export const GuestIdTypeOptions = [
  { label: '身份证', value: 0 },
  { label: '护照', value: 1 },
  { label: '香港身份证', value: 2 },
  { label: '澳门身份证', value: 3 },
  { label: '台胞证', value: 4 },
  { label: '外国人永久居留证', value: 5 },
  { label: '警官证', value: 10 },
  { label: '军官证', value: 11 },
  { label: '士兵证', value: 12 },
  { label: '外交官证', value: 13 }
]

export const TypeSaleRangeOptions = [
  { label: '同行和直客', value: 0 },
  { label: '仅对同行', value: 1 },
  { label: '仅对直客', value: 2 }
]

export const TypeConfirmOptions = [
  { label: '手动确认', value: 0 },
  { label: '自动确认', value: 1 }
]

export const StateProductOptions = [
  { label: '下架', value: 0 },
  { label: '上架', value: 1 },
  { label: '删除', value: -1 }
]

export const StateGuestCouponOptions = [
  { label: '待使用', value: 0 },
  { label: '已使用', value: 1 },
  { label: '已过期', value: 2 }
]

export const TypeSendCouponOptions = [
  { label: '手动', value: 0 },
  { label: '自动', value: 1 },
  { label: '活动', value: 2 }
]

export const StateOrderVoucherOptions = [
  { label: '删除', value: -1 },
  { label: '未使用', value: 1 },
  { label: '使用中', value: 2 },
  { label: '已失效', value: 3 },
  { label: '已过期', value: 4 },
  { label: '核销中', value: 5 },
  { label: '退款中', value: 8 }
]

export const TypeFinPayOptions = [
  { label: '线下支付', value: 0 },
  { label: '在线支付', value: 1 },
  { label: '预存', value: 10 },
  { label: '授信', value: 11 },
  { label: '货仓预存', value: 20 }
]

export const TypeValidityPeriodOptions = [
  { label: '游玩日期当天有效', value: 0 },
  { label: '预订日期延后N天有效', value: 1 },
  { label: '预订日期截止到指定日期N有效', value: 2 },
  { label: '游玩日期延后N天有效', value: 3 },
  { label: '游玩日期截止到指定日期N有效', value: 4 },
  { label: '指定日期N~M有效', value: 5 }
]

export const TypeCodeValidateOptions = [
  { label: '一码一验', value: 0 },
  { label: '一码多验', value: 1 }
]

export const TypeDeductStockOptions = [
  { label: '支付扣减', value: 1 },
  { label: '下单扣减', value: 2 }
]

export const TypeRebateOptions = [
  { label: '固定金额', value: 1 },
  { label: '利润比例', value: 2 },
  { label: '销售额比例', value: 3 }
]

export const StateOrderChangeOptions = [
  { label: '审核中', value: 0 },
  { label: '审核通过', value: 1 },
  { label: '审核拒绝', value: 2 }
]

export const TypeIdTypeOptions = [
  { label: '身份证', value: 1 },
  { label: '游客护照', value: 2 },
  { label: '港澳通行证', value: 3 },
  { label: '台胞证', value: 4 },
  { label: '台湾通行证', value: 5 },
  { label: '军官证', value: 6 },
  { label: '警官证', value: 7 },
  { label: '驾驶证', value: 8 },
  { label: '海员证', value: 9 },
  { label: '港澳台居民居住证', value: 10 },
  { label: '外国人永久居留身份证', value: 11 },
  { label: '港澳台居民来往内地通行证', value: 12 },
  { label: '学生证', value: 13 },
  { label: '国民身份证（台湾）', value: 14 },
  { label: '香港永久居民身份证', value: 15 },
  { label: '香港居民身份证', value: 16 },
  { label: '澳门永久居民身份证', value: 17 },
  { label: '澳门居民身份证', value: 18 },
  { label: '户口本(儿童请选择此项)', value: 19 },
  { label: '台湾居民来往大陆通行证', value: 20 },
  { label: '香港居民往来内地通行证', value: 21 },
  { label: '入台证', value: 22 },
  { label: '中华人民共和国旅行证', value: 23 },
  { label: '回乡证', value: 24 }
]

export const TypeMallVoucherOptions = [
  { label: '商家短信', value: 1 },
  { label: '商家邮件', value: 2 },
  { label: '商家电子码', value: 3 },
  { label: '二维码', value: 4 },
  { label: '身份证', value: 5 },
  { label: '商家订单号', value: 6 },
  { label: '手机号', value: 7 },
  { label: '确认单', value: 8 },
  { label: '陪同单', value: 9 },
  { label: '商家电子票', value: 10 },
  { label: '其它', value: 99 }
]

export const LanguageEnumsOptions = [
  { label: '简体中文', value: '简体中文' },
  { label: '英语', value: '英语' },
  { label: '繁体中文', value: '繁体中文' }
]

export const TypeLangTop10Options = [
  { label: '简体中文', value: 'zh-CN' },
  { label: '繁體中文', value: 'zh-TW' },
  { label: 'English', value: 'en' },
  { label: '日本語', value: 'ja' },
  { label: '한국어', value: 'ko' },
  { label: 'français', value: 'fr' },
  { label: 'Deutsch', value: 'de' },
  { label: 'русский', value: 'ru' },
  { label: 'español', value: 'es' },
  { label: 'العربية', value: 'ar' }
]

export const TypeLangTop50Options = [
  { label: '简体中文', value: 'zh-CN' },
  { label: '繁體中文', value: 'zh-TW' },
  { label: 'English', value: 'en' },
  { label: '日本語', value: 'ja' },
  { label: '한국어', value: 'ko' },
  { label: 'français', value: 'fr' },
  { label: 'Deutsch', value: 'de' },
  { label: 'русский', value: 'ru' },
  { label: 'español', value: 'es' },
  { label: 'العربية', value: 'ar' },
  { label: 'português', value: 'pt' },
  { label: 'italiano', value: 'it' },
  { label: 'Nederlands', value: 'nl' },
  { label: 'svenska', value: 'sv' },
  { label: 'suomi', value: 'fi' },
  { label: 'dansk', value: 'da' },
  { label: 'norsk', value: 'no' },
  { label: 'polski', value: 'pl' },
  { label: 'Türkçe', value: 'tr' },
  { label: 'ελληνικά', value: 'el' },
  { label: 'čeština', value: 'cs' },
  { label: 'magyar', value: 'hu' },
  { label: 'română', value: 'ro' },
  { label: 'български', value: 'bg' },
  { label: 'українська', value: 'uk' },
  { label: 'ไทย', value: 'th' },
  { label: 'Tiếng Việt', value: 'vi' },
  { label: 'Bahasa Melayu', value: 'ms' },
  { label: 'Bahasa Indonesia', value: 'id' },
  { label: 'हिन्दी', value: 'hi' },
  { label: 'বাংলা', value: 'bn' },
  { label: 'தமிழ்', value: 'ta' },
  { label: 'فارسی', value: 'fa' },
  { label: 'עברית', value: 'he' },
  { label: 'Hausa', value: 'ha' },
  { label: 'Kiswahili', value: 'sw' },
  { label: 'አማርኛ', value: 'am' },
  { label: 'Yorùbá', value: 'yo' },
  { label: 'isiZulu', value: 'zu' },
  { label: 'isiXhosa', value: 'xh' },
  { label: 'Soomaali', value: 'so' },
  { label: 'Tagalog', value: 'tl' },
  { label: 'සිංහල', value: 'si' },
  { label: 'ქართული', value: 'ka' },
  { label: 'հայերեն', value: 'hy' },
  { label: 'ދިވެހި', value: 'dv' },
  { label: 'oʻzbek', value: 'uz' },
  { label: 'қазақша', value: 'kk' },
  { label: 'кыргызча', value: 'ky' }
]

export const TypeMallFormOptions = [
  { label: '不需要游玩人信息', value: 0 },
  { label: '需要填写每个游客的信息', value: 1 },
  { label: '只需要填写一个游客的信息', value: 2 }
]

export const TypeAgeRangeOptions = [
  { label: '大于等于', value: 0 },
  { label: '小于等于', value: 1 }
]

export const TypeTemplateOptions = [
  { label: '邮件', value: 0 },
  { label: '电子', value: 1 },
  { label: '出票短信', value: 2 },
  { label: '预定短信', value: 3 }
]

export const TypeLimitOptions = [
  { label: '预订规则', value: 0 },
  { label: '限购规则', value: 1 },
  { label: '销售规则', value: 2 },
  { label: '资料凭证', value: 3 }
]

export const StateTagOptions = [
  { label: '申请', value: 0 },
  { label: '同意', value: 1 },
  { label: '拒绝', value: 2 }
]

export const TypeStockOptions = [
  { label: '总量', value: 0 },
  { label: '场次库存', value: 1 },
  { label: '规格库存', value: 2 },
  { label: '日历库存', value: 3 }
]

export const TypeSkuOptions = [
  { label: '产品', value: 1 },
  { label: '场次', value: 2 },
  { label: '规格', value: 3 }
]
