export interface PropsType {
  attrs: {
    btnText: string // 按钮文本
  }
  styles: {
    pagePadding: number //	页面边距
    cmpUpperPadding: number //	上边距
    cmpLowerPadding: number //	下边距
    iconColor: string //	图标颜色
    cmpBackground: string //	组件背景
  }
  list: Record<string, string>[]
}
export interface Attrs {
  btnText: string // 按钮文本
}
export interface Styles {
  pagePadding: number //	页面边距
  cmpUpperPadding: number //	上边距
  cmpLowerPadding: number //	下边距
  iconColor: string //	图标颜色
  cmpBackground: string //	组件背景
}
