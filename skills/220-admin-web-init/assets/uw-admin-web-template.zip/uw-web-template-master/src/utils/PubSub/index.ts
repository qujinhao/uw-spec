export class Observer {
  constructor(fun: () => void) {
    this.fun = fun
  }

  fun

  // 目标对象更新时触发的回调，即收到更新通知后的回调
  update() {
    this.fun()
  }
}

export class Subject {
  constructor() {
    this.observers = [] // 观察者列表
  }

  observers: Observer[] = []

  // 添加订阅者
  add(observer: Observer) {
    this.observers.push(observer)
  }

  // 删除...
  remove(observer: Observer) {
    const idx = this.observers.findIndex(item => item === observer)
    idx > -1 && this.observers.splice(idx, 1)
  }

  // 通知
  notify() {
    for (const o of this.observers) {
      o.update()
    }
  }
}

export default Subject
