import { createApp, Directive } from "vue";
import pinia from "./store/index";
import i18n from "./i18n";
import router from "./router/index";
import App from "./App.vue";
import "element-plus/dist/index.css";
import "element-plus/theme-chalk/dark/css-vars.css";
import "./styles/basics.scss";
import "@/styles/var.css";
import directives from "@/directives/index";
import * as ElementPlusIconsVue from "@element-plus/icons-vue"; //  全局引入字体图标
import dayjs from "dayjs";
import useActivated from "@/hooks/useActivated";
import "@/styles/layout.css";
import "nprogress/nprogress.css"; // 进度条样式
import VueDOMPurifyHTML from "vue-dompurify-html";

const app = createApp(App);
app.use(pinia).use(i18n).use(router).mount("#app");
app.use(VueDOMPurifyHTML);

//  注册指令
Object.keys(directives).forEach((key) => {
  //Object.keys() 返回一个数组，值是所有可遍历属性的key名
  app.directive(
    key.replace(/^.*\/([^/]+)\.\w+$/, "$1"),
    (directives as { [key: string]: Directive })[key]
  ); //key是自定义指令名字；后面应该是自定义指令的值
});

// 全局引入图标
for (const [key, component] of Object.entries(ElementPlusIconsVue)) {
  app.component(key, component);
}

// 标准格式化日期函数
const formatDate = (
  time?: string | Date | number,
  format?: string,
  defaultValue = ""
) => {
  if (time) {
    return dayjs(time).format(format ? format : "YYYY-MM-DD HH:mm:ss");
  }
  return defaultValue;
};

// 挂载相关全局变量
app.config.globalProperties.dayjs = dayjs;
app.config.globalProperties.useActivated = useActivated;
app.config.globalProperties.formatDate = formatDate;
