// 自动导入当前文件夹的所有文件下多语言包
const zhTW = import.meta.glob(['./*', '!./index', '!./type.d.ts'], {
  import: 'default',
  eager: true
})

let i18nZh = {
  ...zhTW
}

for (const key in zhTW) {
  if (Object.prototype.hasOwnProperty.call(zhTW, key)) {
    const item = zhTW[key]
    i18nZh = Object.assign(i18nZh, item)
  }
}
export default i18nZh
