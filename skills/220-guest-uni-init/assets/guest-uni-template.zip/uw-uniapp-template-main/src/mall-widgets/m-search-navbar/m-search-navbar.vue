<script lang="ts" setup>
// 搜索导航
import { computed, onMounted, ref } from 'vue'
import type { Attrs, Styles } from './type'

const props = withDefaults(
  defineProps<{
    attrs?: Partial<Attrs>
    styles?: Partial<Styles>
    id?: string
  }>(),
  {
    attrs: () => ({}),
    styles: () => ({})
  }
)
// 默认值
const mergedAttrs = computed(() => ({
  leftType: 'icon', // 纯洁模式icon 返回文字font 回到首页home 不显示左边none
  centerType: 'title', // 显示标题title 显示搜索框search 不显示none
  fixed: true, // 固定页面顶部
  border: false, // 显示下边框
  title: '标题', // 导航栏标题
  bgColor: '#fff', // 导航栏背景颜色
  url: '',
  query: '',
  ...props.attrs
}))

// 默认值
// const mergedStyles = computed(() => ({
//   ...props.styles
// }))
const menuButton = ref({
  searchBarHight: 32,
  searchBarTop: 10,
  pageTop: 0,
  wxMenuButtonW: 0
})

const emit = defineEmits<{
  jump: [item: object]
}>()

const navbarStyle = computed(() => {
  return {
    paddingTop: menuButton.value.searchBarTop + 'px',
    paddingRight: menuButton.value.wxMenuButtonW + 5 + 'px'
  }
})

const leftClick = (type: string) => {
  if (type === 'back') {
    uni.navigateBack()
    return
  }
  uni.navigateTo({
    url: '/pages/home/index'
  })
}
const clickSearch = () => {
  const url = mergedAttrs.value.url
  const query = mergedAttrs.value.query
  if (url) {
    const type = url.includes('/') ? 'link' : 'custom'
    emit('jump', { id: url, type, query })
  }
}

onMounted(() => {
  // #ifndef H5
  const wxMenuButton = uni.getMenuButtonBoundingClientRect()
  menuButton.value.searchBarHight = wxMenuButton.height || 0
  menuButton.value.searchBarTop = wxMenuButton.top || 0
  menuButton.value.pageTop = wxMenuButton.top! + wxMenuButton.height! + 15
  uni.getSystemInfo({
    success: (res) => {
      menuButton.value.wxMenuButtonW = res.screenWidth! - wxMenuButton.left!
    }
  })
  // #endif
})
</script>

<template>
  <view
    class="navbar-box"
    :id="props.id"
    :class="{ fixed: mergedAttrs.fixed }"
    :style="navbarStyle"
  >
    <!-- 左侧图标 -->
    <view
      v-if="mergedAttrs.leftType !== 'none'"
      class="nav-slot-left"
      :style="{ height: menuButton.searchBarHight + 'px' }"
    >
      <u-icon
        name="arrow-left"
        size="19"
        @click="leftClick('back')"
      ></u-icon>
      <u-line
        v-if="!['font', 'icon'].includes(mergedAttrs.leftType)"
        direction="column"
        :hairline="false"
        length="16"
        margin="0 6px"
      ></u-line>
      <u-icon
        v-if="!['font', 'icon'].includes(mergedAttrs.leftType)"
        name="home"
        size="22"
        @click="leftClick('home')"
      ></u-icon>
      <text
        v-if="['font'].includes(mergedAttrs.leftType)"
        @click="leftClick('back')"
      >
        返回
      </text>
    </view>
    <!-- 中间输入框或者标题 -->
    <view
      v-if="mergedAttrs.centerType !== 'none'"
      class="nav-slot-center flex-align flex-center"
      :style="{ height: menuButton.searchBarHight + 'px' }"
    >
      <view
        v-if="mergedAttrs.centerType === 'title'"
        class="title"
        :style="{ 'margin-top': menuButton.searchBarHight + 'rpx' }"
      >
        {{ mergedAttrs.title }}
      </view>
      <view
        v-else
        style="width: 93%"
      >
        <u-search
          :showAction="false"
          :disabled="true"
          placeholder="搜索关键字"
          @click="clickSearch"
        ></u-search>
      </view>
    </view>
  </view>
  <!-- #ifdef H5 -->
  <view
    v-if="mergedAttrs.fixed"
    style="height: 42px"
  ></view>
  <!-- #endif -->
</template>

<style lang="scss" scoped>
.navbar-box {
  width: 100%;
  min-height: 42px;
  padding-left: 16rpx;
  display: flex;
  align-items: center;
  position: relative;
  .nav-slot-left {
    font-size: 32rpx;
    display: flex;
    align-items: center;
    flex-shrink: 0;
  }
  .nav-slot-center {
    flex: 1;
    margin-left: 20rpx;
    // #ifdef H5
    .h5-style {
      width: 93%;
    }
    // #endif
  }
  .title {
    position: absolute;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);
    // #ifdef H5
    transform: translate(-50%, -85%);
    // #endif
  }
}
.fixed {
  position: fixed;
  top: 0;
  left: 0;
}
</style>
