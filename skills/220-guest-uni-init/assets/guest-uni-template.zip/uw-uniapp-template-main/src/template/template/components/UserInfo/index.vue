<script lang="ts" setup>
import { ref, onMounted, computed } from 'vue'
import { useUserStore } from '@/store/user'
import { navToUrl } from '@/utils/tool'

const userStore = useUserStore()

// const props = withDefaults(
//   defineProps<{
//   }>(),
//   {
//   }
// )

// const emits = defineEmits<{
//   (e: 'click', item: any): void
// }>()
// const handleClick = (item: any) => {
//   console.log('child-click')
//   emits('click', item)
// }

const topBackGroupImageIndex = ref(5)
const modalName = ref(null)
const picName = ref('流星之夜')
const pic = [
  {
    link: 'https://cdn.zhoukaiwen.com/zjx_me_bg1.jpeg',
    name: '春天'
  },
  {
    link: 'https://cdn.zhoukaiwen.com/zjx_me_bg2.jpeg',
    name: '夏天'
  },
  {
    link: 'https://cdn.zhoukaiwen.com/zjx_me_bg3.jpeg',
    name: '秋天'
  },
  {
    link: 'https://cdn.zhoukaiwen.com/zjx_me_bg4.jpeg',
    name: '冬天'
  },
  {
    link: 'https://cdn.zhoukaiwen.com/zjx_me_bg5.jpeg',
    name: '幽静'
  },
  {
    link: 'https://cdn.zhoukaiwen.com/zjx_me_bg6.jpg',
    name: '天空'
  }
]
const inter = [
  {
    title: 'mimicry',
    name: '活力春天',
    color: ''
  },
  {
    title: 'theme',
    name: '清爽夏日',
    color: ''
  },
  {
    title: 'theme',
    name: '金秋之韵',
    color: ''
  },
  {
    title: 'theme',
    name: '冬日之阳',
    color: ''
  },
  {
    title: 'theme',
    name: '幽兰星空',
    color: ''
  },
  {
    title: 'theme',
    name: '流星之夜',
    color: ''
  }
]

// 用户信息
const userInfo = computed(() => {
  return userStore.userInfo
})

const isLogin = computed(() => {
  return Boolean(Object.keys(userStore.userInfo).length > 0)
})

// 切换背景
function switchImage(index: number, name: string) {
  topBackGroupImageIndex.value = index
  modalName.value = null
  picName.value = name
}

onMounted(() => {
  // console.log('UserInfo ---')
})
</script>

<template>
  <view class="UserInfo">
    <!-- 顶部背景 -->
    <view
      class="UCenter-bg"
      :style="
        'background-image: url(' + pic[topBackGroupImageIndex].link + ');'
      "
    >
      <slot></slot>
      <view class="user-info flex-align">
        <view class="info-left flex-align">
          <img
            class="user-head"
            src="http://qnimg.zowoyoo.com/img/84826/1676964639024.png"
            lazy-load
            mode="aspectFill"
          />
          <view class="user-center flex-col">
            <view
              class="user-info__name"
              @click="
                navToUrl(
                  isLogin ? '/packages/setting/index' : '/pages/login/index'
                )
              "
            >
              {{ userInfo?.username || '登录' }}
            </view>
            <view class="user-info__msg ellipsis">
              {{ '这个人太懒，啥也没留下' }}
            </view>
          </view>
        </view>
        <view class="info-right"></view>
      </view>

      <img
        mode="scaleToFill"
        src="http://qnimg.zowoyoo.com/img/84826/1692870468521.gif"
        lazy-load
        class="gif-wave"
      />
    </view>

    <!-- 控制背景样式 -->
    <view class="modal_main">
      <view class="nav-list margin-top">
        <view
          :class="'nav-li bg-zt' + (index + 1)"
          v-for="(item, index) in inter"
          :key="index"
          @click="switchImage(index, item.name)"
        >
          <view class="nav-name">{{ item.name }}</view>
        </view>
      </view>
    </view>
  </view>
</template>

<style lang="scss" scoped>
.UserInfo {
  .user-info {
    width: 100%;
    .info-left {
      flex: 1;
      padding-left: 30rpx;
      .user-head {
        width: 105rpx;
        height: 105rpx;
        border-radius: 50%;
        overflow: hidden;
        flex-shrink: 0;
      }
      .user-center {
        margin-left: 10px;
      }
    }
    .info-right {
      font-family: '宋体';
      font-weight: bold;
      margin-left: 10px;
      padding-right: 30rpx;
    }
  }
  .UCenter-bg {
    background: #fff;
    // background-size: 100% 100%;
    background-size: cover;
    height: 400rpx;
    display: flex;
    justify-content: center;
    padding-top: 40rpx;
    overflow: hidden;
    position: relative;
    flex-direction: column;
    align-items: center;
    color: #fff;
    font-weight: 300;
    text-shadow: 0 0 3px rgba(0, 0, 0, 0.3);
    .gif-wave {
      position: absolute;
      width: 100%;
      bottom: 0;
      left: 0;
      z-index: 99;
      height: 100rpx;
      mix-blend-mode: screen;
    }
  }
  .modal_main {
    margin-top: 20px;
    /* 主题色 */
    .bg-zt1 {
      color: #fff;
      background: #81d949;
    }

    .bg-zt2 {
      color: #fff;
      background: #b2e6ff;
    }

    .bg-zt3 {
      color: #fff;
      background: #f3cd41;
    }

    .bg-zt4 {
      color: #fff;
      background: #ddecf7;
    }

    .bg-zt5 {
      color: #fff;
      background: #152e9d;
    }

    .bg-zt6 {
      color: #fff;
      background: #0f1358;
    }
    .nav-list {
      display: flex;
      flex-wrap: wrap;
      padding: 0px 40upx 0px;
      justify-content: space-between;
    }
    .nav-li {
      padding: 22upx;
      border-radius: 12upx;
      width: 42%;
      margin: 0 0.5% 40upx;
      background-image: url('https://yanshi.zowoyoo.com/img/84826/1692687554324.png');
      background-size: cover;
      background-position: center;
      position: relative;
      z-index: 1;
      &::after {
        content: '';
        position: absolute;
        z-index: -1;
        background-color: inherit;
        width: 100%;
        height: 100%;
        left: 0;
        bottom: -10%;
        border-radius: 10upx;
        opacity: 0.2;
        transform: scale(0.9, 0.9);
      }
      &.cur {
        color: #fff;
        background: rgb(94, 185, 94);
        box-shadow: 4upx 4upx 6upx rgba(94, 185, 94, 0.4);
      }
      text {
        position: absolute;
        right: 30upx;
        top: 30upx;
        font-size: 52upx;
        width: 60upx;
        height: 60upx;
        text-align: center;
        line-height: 60upx;
      }
    }
    .nav-name {
      font-size: 28upx;
      text-transform: Capitalize;
      position: relative;
      &::before {
        content: '';
        position: absolute;
        display: block;
        width: 40upx;
        height: 6upx;
        background: #fff;
        bottom: 0;
        right: 0;
        opacity: 0.5;
      }
      &::after {
        content: '';
        position: absolute;
        display: block;
        width: 100upx;
        height: 1px;
        background: #fff;
        bottom: 0;
        right: 40upx;
        opacity: 0.3;
      }
      &::first-letter {
        font-weight: bold;
        font-size: 36upx;
        margin-right: 1px;
      }
    }
  }
}
</style>
