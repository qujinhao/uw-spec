<template>
  <!-- #ifdef H5 -->
  <!-- 搜索框 -->
  <scroll-view
    scroll-y
    style="position: fixed; top: 0; z-index: 999"
  >
    <view class="search-box">
      <view
        :class="
          scrollFlex
            ? 'top-search scroll-flex m-w-375 m-auto'
            : 'top-search m-w-375 m-auto'
        "
        :style="topSearchStyle"
      >
        <p
          v-if="pageConfig.tip.includes('city')"
          class="top-city"
          @click="handlerCityClick"
        >
          <text :style="cityStyle">
            {{ cityInfo.areaName === '全部' ? '全部' : cityInfo.areaName }}
          </text>
          <i
            class="i"
            :style="cityIconStyle"
          ></i>
        </p>
        <view
          v-if="pageConfig.tip.includes('search')"
          :style="topSearchInput"
          @click="handlerClickSearch"
        >
          <i :style="searchInputIcon"></i>
          <text :style="searchInputText">{{ copyRight.searchTips }}</text>
        </view>
        <text
          v-if="pageConfig.tip.includes('language')"
          :class="{
            'language-css': true,
            'language-css-en': language === 'en'
          }"
          :style="languageStyle"
          @click="clickLanguage"
        ></text>
      </view>
    </view>
  </scroll-view>
  <!-- #endif -->
  <!-- #ifndef H5 -->
  <view
    :class="{ home_search: true, sticky: scrollFlex }"
    :style="searchBoxStyle"
  >
    <view
      class="search-city"
      :style="{
        height: `${searchBarHight}px`
      }"
      @click.stop="handlerCityClick"
    >
      <text>{{ cityInfo.areaName || '全部' }}</text>
      <!-- <image class="image" src="/static/images/down.png" /> -->
      <u-icon
        name="city-c"
        custom-prefix="custom-icon"
        size="30"
        :color="scrollFlex ? '#000' : '#fff'"
      ></u-icon>
    </view>
    <view
      class="search-box"
      :style="{
        height: `${searchBarHight}px`
      }"
      @click="handlerClickSearch"
    >
      <icon
        class="icon"
        type="search"
      />
      <text>搜索目的地/景点/酒店</text>
    </view>
  </view>
  <!-- #endif -->
</template>

<script lang="ts" setup>
import { ref, computed, onMounted } from 'vue'
import { jump } from '@/utils/global'

// 定义接口
interface CityInfo {
  areaName?: string
}

interface PageConfig {
  backgroundColor: string
  activeBackgroundColor: string
  tip: string[]
  city: {
    iconShow: boolean
    icon: string
    activeIcon: string
    iconSize: number
    color: string
    activeColor: string
    fontSize: number
  }
  search: {
    backgroundColor: string
    activeBackgroundColor: string
    radius: number
    height: number
    contentLocation: string
    iconShow: boolean
    icon: string
    activeIcon: string
    iconSize: number
    textFontSize: number
    textColor: string
    activetextColor: string
  }
  language: {
    color: string
    activeColor: string
    size: number
  }
}

interface CopyRight {
  searchTips: string
}

// 定义响应式变量
const scrollFlex = ref(false) // 记录搜索框是否需要改变样式
const language = ref('zh')
const searchBarTop = ref(0) // 搜索栏到顶部距离
const searchBarHight = ref(0) // 搜索栏高度
const wxMenuButtonW = ref(0) // 搜索栏右边距离

// 计算属性
const env = computed(() => process.env.VUE_APP_PLATFORM)
const searchBoxStyle = computed(() => {
  if (env.value === 'mp-toutiao' || env.value === 'mp-xhs') {
    return `
          padding-right: 30rpx;
          padding-top: 20rpx;
        `
  }
  return `
          padding-right: ${wxMenuButtonW.value}px;
          padding-top: ${searchBarTop.value}px;
        `
})
const cityInfo: any = computed<CityInfo>(() => {
  return {}
})
const pageConfig: any = computed<PageConfig>(() => {
  return {
    backgroundColor: 'rgba(0, 0, 0, 0)', // 搜索框组件整体背景颜色
    activeBackgroundColor: '#ffffff', // 搜索框组件整体背景颜色(吸顶状态) 默认 #ffffff
    tip: ['city', 'search', 'language'], // 搜索框组件中用到的功能
    city: {
      iconShow: true, // 是否显示城市右侧的icon图 如果设置为 false 那么 iconUrl 和 iconSize 将无效
      icon: 'https://qnimg.zowoyoo.com/img/84826/1658735606655.png', // 自定义icon图标(未吸顶状态) url 地址
      activeIcon: 'https://qnimg.zowoyoo.com/img/84826/1658736686317.png', // 自定义icon图标(吸顶状态) url 地址
      iconSize: 12, // 图标大小  默认 12
      color: '#ffffff', // 字体颜色(未吸顶状态) 默认 #ffffff
      activeColor: '#222222', // 字体颜色(吸顶状态) 默认 #222222
      fontSize: 14 // 字体大小 默认14
    },
    search: {
      backgroundColor: '#ffffff', // 搜索框背景颜色(未吸顶状态) 默认 #ffffff
      activeBackgroundColor: '#f3f3f3', // 搜索框背景颜色(吸顶状态) 默认 #f3f3f3
      radius: 20, // 搜索框 圆角角度
      height: 35, // 搜索框高度
      contentLocation: 'center', // 文字位置 默认 center 可选 left right
      iconShow: true, // 是否显示搜索icon图标 如果为 false 那么搜索框icon的设置无效
      icon: 'https://qnimg.zowoyoo.com/img/84826/1658799548211.png', // 自定义icon图标(未吸顶状态) url 地址
      activeIcon: 'https://qnimg.zowoyoo.com/img/84826/1658799548211.png', // 自定义icon图标(吸顶状态) url 地址
      iconSize: 14, // 图标大小  默认 14
      textFontSize: 14, // 文字大小
      textColor: '#666666', // 文字颜色(未吸顶状态)
      activetextColor: '#666666' // 文字颜色(吸顶状态)
    },
    language: {
      color: '#ffffff', // 语言切换文字颜色(未吸顶状态)
      activeColor: '#000000', // 语言切换文字颜色(吸顶状态)
      size: 1 // 缩放大小
    }
  }
})
const copyRight: any = computed<CopyRight>(() => {
  return { searchTips: '搜索目的地、景点、酒店' }
})
// --- 样式处理 --- start
const topSearchStyle = computed(() => {
  return {
    backgroundColor: scrollFlex.value
      ? pageConfig.value.activeBackgroundColor
      : pageConfig.value.backgroundColor
  }
})
const cityStyle = computed(() => {
  return {
    fontSize: '14px',
    color: scrollFlex.value
      ? pageConfig.value.city.activeColor
      : pageConfig.value.city.color
  }
})
const cityIconStyle = computed(() => {
  const style: any = {
    display: pageConfig.value.city.iconShow ? 'inline-block' : 'none',
    width: '12px',
    height: '12px',
    textShadow: scrollFlex.value ? 'none' : '2px 3px 2px rgba(0, 0, 0, 0.7)',
    borderRadius: '50%'
  }
  if (pageConfig.value.city.iconShow !== '') {
    style.backgroundImage = `url(${
      scrollFlex.value
        ? pageConfig.value.city.activeIcon
        : pageConfig.value.city.icon
    })`
    style.backgroundRepeat = 'no-repeat'
    style.backgroundPosition = 'center'
    style.backgroundSize = 'contain'
  }
  return style
})
const searchInputIcon = computed(() => {
  const style: any = {
    display: pageConfig.value.search.iconShow ? 'inline-block' : 'none',
    marginRight: '10px'
  }
  if (pageConfig.value.search.iconShow) {
    style.width = '12px'
    style.height = '12px'
    style.backgroundImage = `url(${
      scrollFlex.value
        ? pageConfig.value.search.activeIcon
        : pageConfig.value.search.icon
    })`
    style.backgroundRepeat = 'no-repeat'
    style.backgroundPosition = 'center'
    style.backgroundSize = 'contain'
  }
  return style
})
const topSearchInput = computed<any>(() => {
  return {
    display: 'flex',
    flex: 1,
    justifyContent: pageConfig.value.search.contentLocation,
    alignItems: 'center',
    height: '35px',
    borderRadius: '20px',
    backgroundColor: scrollFlex.value
      ? pageConfig.value.search.activeBackgroundColor
      : pageConfig.value.search.backgroundColor,
    marginLeft: '12px!important',
    boxShadow: '0px 1px 4px 0px rgba(0, 0, 0, 0.1)',
    padding: '0px 8px}',
    boxSizing: 'border-box'
  }
})
const searchInputText = computed(() => {
  return {
    color: scrollFlex.value
      ? pageConfig.value.search.activetextColor
      : pageConfig.value.search.textColor,
    fontSize: '14px'
  }
})
const languageStyle = computed(() => {
  const style: any = {
    flexShrink: 0,
    position: 'relative',
    display: 'inline-block',
    width: '20px',
    height: '20px',
    fontSize: '10px',
    borderRadius: '50%',
    borderWidth: '2px',
    borderStyle: 'solid',
    borderColor: '#fff',
    marginLeft: '14px',
    borderRightColor: 'transparent',
    borderLeftColor: 'transparent',
    color: scrollFlex.value
      ? pageConfig.value.language.activeColor
      : pageConfig.value.language.color,
    transform: `rotate(${language.value === 'en' ? 225 : 45}deg) scale(${
      pageConfig.value.language.size
    })`,
    transition: '0.3s'
  }
  if (scrollFlex.value) {
    style.borderTopColor = pageConfig.value.language.activeColor
    style.borderBottomColor = pageConfig.value.language.activeColor
  }
  return style
})

// 方法
// 城市点击
const handlerCityClick = () => {
  jump({ id: '/pages/city/index', type: 'link' })
  // this.$router.push("/city");
}
// 搜索
const handlerClickSearch = () => {
  jump({ id: '/search', type: 'link' })
  // this.$router.push("/search");
}
// 中英文切换
const clickLanguage = () => {
  if (language.value === 'en') {
    language.value = 'zh'
  } else {
    language.value = 'en'
  }
}

// 生命周期
onMounted(() => {
  // #ifndef H5
  const wxMenuButton = uni.getMenuButtonBoundingClientRect()
  console.log('wxMenuButton')
  console.log(wxMenuButton)

  searchBarHight.value = wxMenuButton.height || 0
  searchBarTop.value = wxMenuButton.top || 0
  uni.getSystemInfo({
    success: (res) => {
      wxMenuButtonW.value = res.screenWidth! - wxMenuButton.left!
    }
  })
  // #endif
})
</script>

<style lang="scss" scoped>
.loading {
  text-align: center;
}

.box-bg {
  background-image: linear-gradient(180deg, #fff 40px, #f5f5f5 80px);
  overflow: hidden;
}

.search-box {
  position: relative;
  z-index: 9;

  .top-search {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 15px 16px;
    transition: 0.5s;

    &.scroll-flex {
      padding: 15px 16px;
      border-bottom: 1px solid #dddddd;

      .top-city {
        text-shadow: none;
      }
    }

    .top-city {
      display: flex;
      align-items: center;
      padding-left: 8px;
      white-space: nowrap;
      -webkit-text-shadow: 2px 3px 2px rgba(0, 0, 0, 0.7);
      -moz-text-shadow: 2px 3px 2px rgba(0, 0, 0, 0.7);
      -o-text-shadow: 2px 3px 2px rgba(0, 0, 0, 0.7);
      text-shadow: 2px 3px 2px rgba(0, 0, 0, 0.7);

      .i {
        margin-left: 4px;
      }
    }

    .language-css {
      &::before,
      &::after {
        position: absolute;
        transform: rotate(-45deg);
        transition: 0.3s;
      }

      &::before {
        content: '中';
        top: 4px;
        left: -8px;
      }

      &::after {
        content: 'En';
        bottom: 5px;
        right: -9px;
      }

      &.language-css-en {
        &::before,
        &::after {
          transform: rotate(-225deg);
        }
      }
    }
  }
}

.home_search {
  position: fixed;
  top: 0;
  z-index: 22;
  display: flex;
  align-items: center;
  padding-left: 32rpx;
  padding-bottom: 30rpx;
  /* #ifdef MP-TOUTIAO */
  padding-bottom: 20rpx;
  /* #endif */
  font-size: 30rpx;
  width: 100%;
  box-sizing: border-box;
  .search-city {
    display: flex;
    align-items: center;
    padding-left: 12rpx;
    text {
      color: #fff;
      margin-right: 8rpx;
      text-shadow: 0 2rpx 6rpx rgba(0, 0, 0, 0.5);
    }
    .image {
      width: 24rpx;
      height: 24rpx;
    }
  }
  .search-box {
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: center;
    /* #ifdef MP-TOUTIAO */
    justify-content: flex-start;
    /* #endif */
    background-color: #fff;
    border-radius: 35rpx;
    margin: 0 16rpx 0 24rpx;
    .icon {
      margin-right: 10rpx;
      /* #ifdef MP-TOUTIAO */
      margin-left: 20rpx;
      /* #endif */
    }
    image {
      width: 48rpx;
      height: 48rpx;
    }
  }
}
.sticky {
  border-bottom: 1rpx solid #ddd;
  background-color: #fff;
  .search-city {
    text {
      color: #222;
      text-shadow: none;
    }
  }
  .search-box {
    background-color: #f3f3f3;
  }
}
</style>
